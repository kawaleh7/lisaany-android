# Lisaany — what to do now (Sept 24)

Everything in the audit that could be fixed in code is fixed and inside this zip. What is left
are the accounts and keys only you can create. Each numbered part is independent — you can stop
after any of them — but **Part 1 must be done before the next App Store build**, or the Premium
screen will show "not available in this version yet" on iPhone.

The full technical details for Part 1 are in `docs/revenuecat-webhook.md` inside the zip.

**All keys now live in one file: `.env`** in the app folder. Every build reads it — the iPhone
build (`eas build`), the Android build on GitHub (the zip carries it) and `npx expo start`.
Nothing goes in `eas.json` any more.

---

## 0. The Google review that is waiting right now (5 minutes of your time)

The build Google is reviewing still has the old "Continue · $99.99 / year" button that opens
lisaany.com checkout in the browser. Google can reject for that (outside-the-store payment for
digital content; only allowed in the US, UK and EU through an enrolment programme — not Canada).
A rejection does not count against your developer account; it just means you send a fixed build.

1. Leave the current review alone (sending something new now puts you at the back of the queue).
2. Build the new version (Part 5 below) and upload it to **Internal testing** — no review wait.
   Check on the Galaxy: it opens, a lesson plays with sound, and the Premium screen shows no
   price and no website button.
3. When Google answers:
   - **Rejected** → Play Console → Internal testing → the new release → **Promote release →
     Closed testing** → send for review. That is the fix; no appeal needed.
   - **Approved** → promote the new release to Closed testing anyway, soon, so the old
     checkout button is not what testers (or a later review) see.
4. Store listing: make sure the description does not tell people to buy on lisaany.com.

On Android, until you add the Google Play key, the app sells nothing itself and the Premium
screen says, as plain text with no link, that Premium is available on lisaany.com. Google allows
exactly that for an app that sells nothing in-app. Once the Android key is in `.env`, the app
sells through Google Play and that line disappears automatically.

---

## 1. Purchases — RevenueCat + the two stores (about 1½ hours, first time)

Both iPhone and Android now buy Premium through the App Store / Google Play (via RevenueCat).
There is no Stripe checkout in the app any more — Google's payment policy forbade it, and Apple
never allowed it. lisaany.com keeps Stripe for web sign-ups exactly as before.

1. Follow **Part 1** of `docs/revenuecat-webhook.md`: RevenueCat project, the two store apps,
   the four products (`lisaany_premium_monthly`, `lisaany_premium_yearly` on each store), the
   `premium` entitlement, the `default` offering.
2. Open `.env` in the app folder with Notepad and replace the two `PASTE` lines with the public
   SDK keys (`appl_…` and `goog_…`). Save. That's the only place they go.
3. **Part 2** of the doc: App Store Connect subscription group + the two subscriptions, Paid
   Apps agreement, sandbox tester; Play Console: the two subscriptions with base plans `monthly`
   and `yearly`, license testers.
4. **Part 3** of the doc: the webhook, so a phone purchase also unlocks lisaany.com. It needs the
   Supabase **service-role** key as a Cloudflare Worker secret (never in the app) and one new
   route in the Worker.

Until step 2 is done: on iPhone the Premium screen shows a calm "not available yet" state with a
Sign-in button; on Android it says Premium is available on lisaany.com (plain text). No prices,
no dead Continue button, and every free unit still works.

---

## 2. Supabase — three SQL files to run once (about 10 minutes)

Open https://supabase.com/dashboard/project/cfaxrzfqvoalwznkhwnx/sql/new and run each file
from the `supabase` folder of the zip (open in Notepad → select all → copy → paste → **Run**):

1. `store_subscriptions.sql` — adds the columns the webhook writes (`source`, `store_product_id`,
   …) and prints RLS checks. Read the comments: the last, optional block creates a unique index
   on `subscriptions.user_id` and must only run if the check query above it returns no rows.
2. `norania_progress.sql` — new table so a child's Learn-to-read progress follows the parent's
   account to a new phone. Until it exists, Norania stays per-device (the app is silent about it).
3. `delete_user.sql` — the **new block at the end** makes every table that points at a user
   delete with the account (`ON DELETE CASCADE`). Without it, "Delete account" fails and the app
   shows "Could not delete…", which Apple will reject (guideline 5.1.1(v)). Read the verification
   query's output: every row must show delete rule `c`. Then test Delete account with a throwaway
   account once.

Also in Supabase: **Authentication → URL Configuration → Redirect URLs** → add
`https://lisaany.com/auth.html` (needed for "Forgot your password?" below).

---

## 3. Website — two small things (about 30 minutes)

1. Run the curriculum patch on the website file (same 18 edits the app already has —
   unit 1.1 restructure and the Hello/Welcome vocabulary rule), in PowerShell, one line at a time:

       cd C:\dev\lisaany-web
       python tools\patch-curriculum.py arabic_platform.html --dry-run
       python tools\patch-curriculum.py arabic_platform.html

   (`patch-curriculum.py` is in the zip under `tools`; copy it next to the website file first.
   It refuses to run twice, so it is safe.)
2. `auth.html` must handle Supabase's password-recovery link: when the page opens with a
   recovery token (the `PASSWORD_RECOVERY` auth event), show a "Choose a new password" form that
   calls `supabase.auth.updateUser({ password })`. The app now sends people there from
   "Forgot your password?".
3. Add to `audioIndex`: `"بِخَيْر، الْحَمْدُ لِلَّه، شُكْرًا يَا أَحْمَد.":"974c0e542129"` (the mp3 sent
   earlier), and record the five new clips: أَهلاً بِكِ · مَرحَباً بِكَ · جَزِيلاً · بِكِ · مَرْيَم.

---

## 4. Crash reporting (about 15 minutes, optional but recommended)

1. Create a free account at sentry.io → new project → platform **React Native**.
2. Copy the **DSN** (starts with `https://…@…ingest.sentry.io/…`) into `.env`, replacing the
   `PASTE_YOUR_SENTRY_DSN` line.

With the placeholder DSN the reporter stays completely off; nothing is sent anywhere. Crash
reports arrive with minified JavaScript stack traces (readable source maps need a Sentry token in
both build pipelines — a later job, not needed to start).

---

## 5. New builds (both stores)

Everything since 1.2.1 (1) needs a fresh native build — new packages (audio session, crash
reporting) mean a live update cannot carry it.

**iPhone / iPad** (PowerShell, one line at a time; the first line every new window):

    $env:EAS_NO_VCS=1
    cd C:\dev\lisaany-app
    npm install
    eas build --platform ios --profile production
    eas submit --platform ios --latest

**Android**: replace `lisaany-app.zip` in the `lisaany-android` repo as before → Actions →
**Expo app — signed AAB** → Run workflow → download `app-release.aab` → Play Console →
Internal testing → new release. (No change to the workflow file is needed.)

Before submitting for review, read the "STORE REVIEW RISKS" section of AUDIT.md once more:
privacy labels (email, user id, learning progress, purchases) and Play's Data safety form. The
child's first name on the Norania certificate stays on the device — it is not part of the sync,
so nothing about a child leaves the phone.

---

## What was fixed in this zip (short version)

Payments: RevenueCat on both platforms; prices only from the stores; no browser checkout; a paid
subscriber stays Premium offline (last known plan is remembered). Progress: the app reads your
cloud progress at sign-in and start-up, so web learners see their real XP, streak and next unit;
the last part finished before closing a lesson is uploaded by the app itself. Sessions: fresh
token before every lesson, auto-refresh follows the app state, no more sign-outs after a long
break. Lessons: a Close button and a timeout on the loading screen, automatic recovery after a
web-view crash, error state with Try again; deep links respect the paywall; Review session hides
Premium vocabulary. Accounts: Forgot password; sign-in from the landing page lands in the app;
sign-out and delete clear the previous learner's data; delete text mentions store subscriptions;
first-launch flash gone. Norania progress syncs to the account. Notification tap opens Today.
iPhone: lesson audio plays with the mute switch on. Crash reporting wired (off until a DSN is
set). A second, independent review of the batch found and closed three more: a subscriber whose
token had expired while offline was treated as a guest (now the last signed-in learner and their
remembered plan are used), a lesson finished offline could be saved as a guest's and lost (the
page now keeps the learner's own slot whatever the session does), and the delete-account SQL
would have removed family circles with their owner (it now only touches the foreign keys that
block a delete). ESLint configured (`npm run check` = typecheck + lint); the lesson test harness is green;
the iPad full-screen flag is now set the way Expo expects (the old setting was silently ignored
and would have failed App Store upload).
