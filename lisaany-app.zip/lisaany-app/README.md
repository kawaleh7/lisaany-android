# Lisaany — React Native (Expo)

Native app for the **Arabic course** at [lisaany.com](https://lisaany.com), built on Expo SDK 57 /
React Native 0.86 with expo-router. It talks to the **same** Supabase project as the web app, so
accounts, subscriptions and progress carry over with no migration.

### Scope

This app is the Arabic curriculum from `arabic_platform.html` and nothing else — no Qur'an reader,
duas or memorisation, no English course, no French platform, no school/tutor portals. Those stay
on the web.

---

## How it's built: a native shell around the real lesson engine

Every lesson — the conversation stage, vocabulary, grammar, drills, quizzes, the daily review, all
2,900+ audio clips, the tap-any-word glossary — is **the website's own code**, not a rewrite. A
build script lifts the lesson engine straight out of `arabic_platform.html`, and it runs inside the
app in a web view. Home, the lessons map, unit pages, sign-in and the paywall are native React
Native screens, built to match.

That split is deliberate:

- **The lesson content is one source of truth.** When you fix a typo or re-record a clip on the
  website, this app picks it up the next time you run the build script — nothing to port by hand,
  nothing to drift out of sync.
- **Every block type, every drill, every animation works from day one** — no block type is
  "coming soon" here, because it's the same code that already works on lisaany.com.
- **The parts people compare an app on — opening it, moving between screens, the paywall, signing
  in — are fully native**, which is what actually makes an app feel like an app rather than a
  website in a frame. Apple's app-store review (guideline 4.2) looks for exactly this: a native
  shell around embedded content passes; a bare wrapper around a website does not.
- **The design can be restyled without touching a single lesson.** The dark navy/gold shell here
  matches the current site; if you want the "crisp, interior-designer" look we discussed, that's a
  CSS pass over the shell screens (`src/constants/lisaany.ts` + the screens in `src/app`) — the
  lesson engine's own look is a separate, smaller CSS pass inside `tools/build-lesson-page.py`.

### The moving parts

```
tools/build-lesson-page.py     → reads ../src/Lisaany-main/arabic_platform.html,
                                   strips the website's own nav/chrome, embeds the
                                   fonts + Supabase client, adds the app bridge,
                                   writes assets/lesson/lesson.html + src/data/lesson-page.ts
tools/extract-curriculum.mjs   → boots that page headlessly and reads back CUR,
                                   including the blocks the engine generates at
                                   runtime, into src/data/curriculum.json
tools/test-lesson-page.mjs     → plays through every block of every unit in headless
                                   Chromium and fails on any JS error
tools/patch-curriculum.py      → exact find→replace edits to the curriculum (greetings
                                   labels + the Unit 1.1 restructure); run it once on the
                                   website's arabic_platform.html so a rebuild keeps them
```

Re-run both build steps (`npm run lesson:build`) whenever `arabic_platform.html` changes. Run
`npm run lesson:test` after that to check nothing broke before you ship.

### The bridge

The lesson page never navigates anywhere the app doesn't know about. It's opened with a small
config (which unit/block, the signed-in session, a premium flag, progress already known) and it
posts messages back: `opened`, `progress` (after every save — mirrored into `AsyncStorage` so
native screens can show it without opening the page), `navigate` (the learner backed out to a view
the shell owns — units list, sign-up, upgrade), and `view` (which colours sit at the top/bottom
edge, so the native status bar and safe areas match the page underneath). See
`src/lib/lesson-bridge.ts` for the full contract and `src/app/lesson/[unit].tsx` for how the app
uses it.

---

## Running it

```bash
npm install
npx expo start --tunnel
```

Scan the QR code with **Expo Go**, or press `a` / `i` for an emulator/simulator.

### A note on Node

This project is built and bundle-tested on **Node 22**. If `npx expo start` throws anything odd out
of Metro, that's the first thing to rule out (`nvm install 22 && nvm use 22`).

### Building for the Play Store / App Store

```bash
npm install -g eas-cli
eas login
eas build:configure
eas build --platform android --profile production
```

The package name is `com.lisaany.arabic` / bundle id `com.lisaany.arabic` in `app.json`, matching
the Play Console listing already in progress (internal testing, v1.0.11 as of writing) so this can
ship as an update to that listing rather than a new app.

---

## What's here

| Screen | File | What it does |
| --- | --- | --- |
| Today | `src/app/(tabs)/index.tsx` | Streak, XP, resume-where-you-left-off, daily review shortcuts |
| Lessons — 14 modules, 47 units | `src/app/(tabs)/lessons.tsx` | Module accordion, per-unit lock state |
| Unit overview | `src/app/unit/[id].tsx` | Objectives, block list in order, opens the lesson engine |
| **Lesson** (any block, any drill, review) | `src/app/lesson/[unit].tsx` | Full-screen web view running the real lesson engine |
| Profile / plan / lesson language | `src/app/(tabs)/profile.tsx` | Billing, sign out, English/French toggle for the lesson UI |
| Sign in / sign up | `src/app/sign-in.tsx` | Same Supabase project as the website |

### Libraries

- `src/lib/curriculum.ts` — course **structure** (ids, titles, block types, sizes) read from the
  running engine by `tools/extract-curriculum.mjs`. The lesson *content* lives only in
  `src/data/lesson-page.ts` — there is no second copy of the curriculum text to keep in sync.
- `src/lib/progress.ts` — mirrors the engine's own progress (`PROG`/`POS`/`XP`/streak) into
  `AsyncStorage` from the bridge's `progress` messages, so native screens can show it instantly
- `src/lib/lesson-bridge.ts` — the message contract between the app and the lesson page
- `src/lib/plan.ts` — a direct port of the web app's `plan.js`: same four-state model plus the
  `staff` bypass, same `FREE_UNITS` (`1.1`, `1.2`)
- `src/lib/supabase.ts` / `auth-context.tsx` — session + plan, available anywhere via `useAuth()`
- `src/components/lesson-host.tsx` (+ `.web.tsx`) — the web view (native) / iframe (web preview)
  that hosts the lesson page

---

## Design

The native shell's tokens (`src/constants/lisaany.ts`) are taken from the current site's CSS: navy
`#0e1b32`, gold `#e6b85a`, Cinzel for titles, Amiri for Arabic, Inter for UI, Material Symbols for
icons (rendered from a codepoint map — see below). This is the fastest place to try a different
palette, since it's plain `StyleSheet` objects with no lesson logic mixed in.

The lesson engine's own look — the pearl-room lesson stage, the quick-check cards, the daily
review — is controlled by `tools/build-lesson-page.py`'s `app_css` block plus whatever CSS already
lives in `arabic_platform.html`. Changing it there changes it on the website too, which is exactly
the point: one look, one place to tune it.

Material Symbols icons render from a codepoint map (`tools/fonts/subset_icons.py`,
`src/data/icon-codepoints.json`) rather than the ligature the web relies on, because React Native
on Android doesn't reliably apply font ligature substitution.

---

## Before you ship

1. **Single-device enforcement** (`session.js` on the web) is not ported to the shell. The lesson
   page's own Supabase client never persists or refreshes its session — the app hands it a fresh
   token on every open — so this is a native-shell decision, not something split across two copies
   of the logic.
2. **Purchases go through RevenueCat on both stores** (App Store on iPhone, Google Play on
   Android): the SDK keys live in `.env` (read by every build — EAS for iPhone, GitHub Actions for
   Android), the store, product and webhook setup is in `docs/revenuecat-webhook.md`. There is no browser checkout in the app any more — the
   Stripe / `pricing.html` flow is the website's only, so nothing in the app steers to it.
3. **Move the keys to `.env`** if you want different Supabase projects per environment — see
   `src/constants/lisaany.ts` for the `EXPO_PUBLIC_*` overrides. Never put a service-role key in one
   of those; only the publishable key belongs in a client.

---

## Verified

- `npx tsc --noEmit` — clean
- `npx expo export --platform android` and `--platform web` — both bundle clean
- `npm run lesson:test` — every block of all 47 units opens with no JavaScript error, fonts load,
  icons render as glyphs (not literal text), a full unit (1.1) is played block-by-block including
  every quick check, and the shell handoff (leaving a lesson) posts the expected message
- The shell → unit → lesson flow was walked in a headless browser against the exported web build:
  Today → Lessons → Module 1 → Unit 1.1 → Start lesson opens the real conversation stage with no
  console errors

Not verified: behaviour on a real device. Arabic text shaping, RTL layout and the web view's
audio/keyboard behaviour are worth checking on your phone before anything else.
