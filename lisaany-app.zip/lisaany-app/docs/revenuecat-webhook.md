# App Store and Google Play purchases → lisaany.com (RevenueCat setup + webhook)

The app sells Lisaany Premium through the App Store (iPhone) and Google Play (Android) using
RevenueCat. Those purchases never go through Stripe, so the website does not know about them until
RevenueCat tells it. This guide sets up RevenueCat, the two stores, the keys the app needs, and a
small webhook in the Cloudflare Worker that writes each purchase into the Supabase `subscriptions`
table (the one table the website and the lesson engine read).

Do the four parts in order. Part 3 assumes you have already run
`supabase/store_subscriptions.sql` once in the Supabase SQL editor.

---

## Part 1 — RevenueCat

1. Create a free account at revenuecat.com and a project called **Lisaany**.
2. **Apps** → add an **App Store** app: bundle id `com.lisaany.arabic`. Upload an App Store
   Connect API key when asked (App Store Connect → Users and Access → Integrations → In-App
   Purchase → generate a key, download the `.p8` file once, note the Issuer ID and Key ID). Also
   paste the **App-Specific Shared Secret** (App Store Connect → your app → App Information).
3. **Apps** → add a **Play Store** app: package `com.lisaany.arabic`. Upload the Google service
   account JSON (Google Cloud Console → IAM → Service accounts → create one → Keys → JSON; then in
   Play Console → Users and permissions → invite that service account's email with **View financial
   data** and **Manage orders and subscriptions**). RevenueCat's page links the exact steps.
4. **Products** → add four products, two per store, with **these ids exactly**:
   - `lisaany_premium_monthly` (App Store) and `lisaany_premium_monthly` (Play Store, base plan `monthly`)
   - `lisaany_premium_yearly` (App Store) and `lisaany_premium_yearly` (Play Store, base plan `yearly`)

   The app decides "monthly or yearly" from the word `yearly` in the id, so keep the names.
5. **Entitlements** → create one entitlement with the id `premium` and attach all four products.
6. **Offerings** → the offering called `default` (create it if missing) → add two packages:
   - `$rc_monthly` → attach the App Store monthly product and the Play Store monthly product
   - `$rc_annual` → attach the App Store yearly product and the Play Store yearly product

   Make `default` the **current** offering.
7. **API keys** (Project settings → API keys) → copy the two **public SDK keys**:
   - the App Store app's key, which starts with `appl_`
   - the Play Store app's key, which starts with `goog_`

   These two are safe to ship inside the app. The **secret** keys (`sk_…`) are not — never put
   those in the app or in `.env`.
8. Give the keys to the app: open the file **`.env`** in the app folder (Notepad is fine) and
   replace the two `PASTE` lines:

   ```
   EXPO_PUBLIC_REVENUECAT_IOS_KEY=appl_xxxxxxxxxxxxxxxxxxxxxxxx
   EXPO_PUBLIC_REVENUECAT_ANDROID_KEY=goog_xxxxxxxxxxxxxxxxxxxxxxxx
   ```

   That one file is read by every build — the iPhone build (`eas build`), the Android build on
   GitHub Actions (the zip carries `.env` with it) and `npx expo start` on your PC — so there is
   nothing to set anywhere else. (Do not also create EAS environment variables with the same
   names: those would win over `.env`.)

   The app checks the prefix: a key that does not start with `appl_` / `goog_`, or still contains
   `PASTE`, counts as missing. On iPhone the Premium screen then says "Premium is not available in
   this version yet"; on Android it says Premium is available on lisaany.com (plain text, no link —
   Google allows that only for an app that sells nothing itself, which is exactly the Android app
   without its key). The moment the Android key is in, the Android app sells through Google Play
   and that website line disappears on its own. Expo Go never talks to the stores; use a preview or production
   build to test purchases.

---

## Part 2 — The stores

### App Store Connect

1. Agreements, Tax, and Banking → sign the **Paid Apps** agreement and complete banking and tax
   forms. Until this is done, products never load in the app.
2. Your app → **Subscriptions** → create a subscription group **Lisaany Premium**.
3. In the group, add two auto-renewable subscriptions:
   - Reference name `Lisaany Premium Monthly`, product id `lisaany_premium_monthly`, duration 1 month
   - Reference name `Lisaany Premium Yearly`, product id `lisaany_premium_yearly`, duration 1 year

   For each: set the price (pick the base country; Apple fills the other currencies), add at least
   one localization (display name and description in English; French is worth adding), a review
   screenshot of the Premium screen, and save. The status should read "Ready to Submit".
4. Users and Access → **Sandbox** → Testers → add a sandbox tester with an email you control. On the
   test iPhone: Settings → App Store → Sandbox Account → sign in with it.
5. App Store description: add the subscription names and prices, a link to
   `https://lisaany.com/terms.html` and `https://lisaany.com/privacy.html` (Apple requires these in
   the metadata for auto-renewable subscriptions).

### Google Play Console

1. Your app → Monetize → **Subscriptions** → create two subscriptions:
   - Product id `lisaany_premium_monthly`, name "Lisaany Premium Monthly", one base plan with id
     `monthly`, auto-renewing, billing period 1 month
   - Product id `lisaany_premium_yearly`, name "Lisaany Premium Yearly", one base plan with id
     `yearly`, auto-renewing, billing period 1 year

   Set prices and **activate** each base plan.
2. Settings → **License testing** → add the Google accounts that will test; they pay nothing and
   subscriptions renew every few minutes.
3. Testing → **Internal testing** → create a release with the `.aab` from `eas build --platform
   android --profile production` and add the same testers. Products only load in a build that Play
   knows about (internal testing is enough), installed from the Play Store link.
4. Policy → App content → Data safety: declare purchase history (Play Billing), email, user id and
   app activity.

---

## Part 3 — The webhook (RevenueCat → your Worker → Supabase)

### 3.1 Two secrets for the Worker

Generate a random webhook secret in PowerShell:

```powershell
[guid]::NewGuid().ToString('N') + [guid]::NewGuid().ToString('N')
```

Copy the output. Then, in the **website** repo folder (where `wrangler.toml` is), store the two
secrets in the Worker, one command per line; each asks you to paste the value:

```powershell
wrangler secret put REVENUECAT_WEBHOOK_SECRET
wrangler secret put SUPABASE_SERVICE_ROLE_KEY
```

The service-role key is in Supabase → Project Settings → API → **service_role** (secret). It
bypasses Row Level Security, so it must live **only** in the Worker secret. Never put it in the app,
in `.env`, in `.env.example`, or in any HTML/JS the browser can load. If it ever leaks, rotate
it in the same Supabase page.

If the Worker does not already have `SUPABASE_URL` as a variable, add it to `wrangler.toml`:

```toml
[vars]
SUPABASE_URL = "https://cfaxrzfqvoalwznkhwnx.supabase.co"
```

### 3.2 The Worker code

Add this function to `src/index.js` in the website repo, and add one line to the existing `fetch`
handler where the other `/api/...` routes are matched:

```js
if (url.pathname === '/api/revenuecat' && request.method === 'POST') {
  return handleRevenueCatWebhook(request, env);
}
```

The function (plain JavaScript, no dependencies):

```js
// RevenueCat webhook: keeps public.subscriptions in step with App Store / Google Play.
// Setup: docs/revenuecat-webhook.md in the app repo. Secrets: REVENUECAT_WEBHOOK_SECRET,
// SUPABASE_SERVICE_ROLE_KEY. Variable: SUPABASE_URL.
async function handleRevenueCatWebhook(request, env) {
  const ok = (msg) => new Response(JSON.stringify({ ok: true, msg }), { status: 200, headers: { 'content-type': 'application/json' } });

  // 1. Only RevenueCat may call this: the Authorization header must equal our secret.
  const auth = request.headers.get('Authorization') || '';
  const expected = env.REVENUECAT_WEBHOOK_SECRET || '';
  if (!expected || auth !== expected) return new Response('unauthorized', { status: 401 });

  // 2. Parse the event.
  let body;
  try { body = await request.json(); } catch { return new Response('bad json', { status: 400 }); }
  const ev = body && body.event;
  if (!ev || !ev.type) return new Response('no event', { status: 400 });

  const type = String(ev.type);
  const store = ev.store === 'APP_STORE' || ev.store === 'MAC_APP_STORE' ? 'apple'
              : ev.store === 'PLAY_STORE' ? 'google' : String(ev.store || 'unknown').toLowerCase();
  const productId = ev.product_id || null;
  const expiresAt = ev.expiration_at_ms ? new Date(Number(ev.expiration_at_ms)).toISOString() : null;
  const entitlements = Array.isArray(ev.entitlement_ids) ? ev.entitlement_ids : (ev.entitlement_id ? [ev.entitlement_id] : []);

  // 3. Map the event type to a status. Events we do not need are answered 200 and dropped.
  let status;
  switch (type) {
    case 'INITIAL_PURCHASE':
    case 'RENEWAL':
    case 'UNCANCELLATION':
    case 'PRODUCT_CHANGE':
    case 'NON_RENEWING_PURCHASE':
      status = ev.period_type === 'TRIAL' ? 'trialing' : 'active';
      break;
    case 'CANCELLATION': {
      // Auto-renew was turned off (or a refund was granted). The website only honours
      // status 'active'/'trialing', so the learner keeps 'active' until the paid period ends;
      // the EXPIRATION event below then closes it. A refund (CUSTOMER_SUPPORT) or an expiration
      // already in the past ends access now.
      const stillPaid = expiresAt && new Date(expiresAt).getTime() > Date.now();
      status = stillPaid && ev.cancel_reason !== 'CUSTOMER_SUPPORT' ? 'active' : 'canceled';
      break;
    }
    case 'EXPIRATION':
      status = 'expired';
      break;
    default:
      // TEST, TRANSFER, BILLING_ISSUE, SUBSCRIBER_ALIAS, SUBSCRIPTION_PAUSED, ... — log and move on.
      console.log('revenuecat: ignored event', type, ev.app_user_id);
      return ok('ignored ' + type);
  }

  // 4. Only the entitlement that unlocks lessons matters.
  if (entitlements.length && !entitlements.includes('premium')) return ok('other entitlement, skipped');

  // 5. Which Supabase user? The app calls Purchases.logIn(<supabase user id>), so app_user_id is
  //    that id. Anonymous ids ($RCAnonymousID:...) belong to guests who have not signed in yet —
  //    nothing to write; answer 200 so RevenueCat does not retry. If the guest has since signed in,
  //    one of the aliases is their real id.
  const isUuid = (s) => typeof s === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(s);
  const candidates = [ev.app_user_id, ev.original_app_user_id].concat(Array.isArray(ev.aliases) ? ev.aliases : []);
  const userId = candidates.find(isUuid) || null;
  if (!userId) { console.log('revenuecat: no signed-in user for', type, ev.app_user_id); return ok('anonymous, skipped'); }

  const headers = {
    apikey: env.SUPABASE_SERVICE_ROLE_KEY,
    Authorization: 'Bearer ' + env.SUPABASE_SERVICE_ROLE_KEY,
    'Content-Type': 'application/json',
  };
  const base = (env.SUPABASE_URL || 'https://cfaxrzfqvoalwznkhwnx.supabase.co') + '/rest/v1/subscriptions';

  // 6. Never let a store event downgrade an active subscription that came from somewhere else
  //    (a learner who also pays on the website through Stripe keeps their access).
  if (status !== 'active' && status !== 'trialing') {
    const res = await fetch(base + '?user_id=eq.' + encodeURIComponent(userId) + '&select=source,status', { headers });
    const rows = res.ok ? await res.json() : [];
    const row = rows[0];
    if (row && row.source && row.source !== store && (row.status === 'active' || row.status === 'trialing')) {
      return ok('kept ' + row.source + ' subscription');
    }
  }

  // 7. Upsert the row (one row per user — see supabase/store_subscriptions.sql).
  const row = {
    user_id: userId,
    plan: 'premium',
    status,
    source: store,
    store_app_user_id: ev.app_user_id || null,
    store_product_id: productId,
    current_period_end: expiresAt,
    updated_at: new Date().toISOString(),
  };
  const up = await fetch(base + '?on_conflict=user_id', {
    method: 'POST',
    headers: { ...headers, Prefer: 'resolution=merge-duplicates,return=minimal' },
    body: JSON.stringify([row]),
  });
  if (!up.ok) {
    const text = await up.text();
    console.error('revenuecat: supabase upsert failed', up.status, text);
    // 500 makes RevenueCat retry later (it retries for a few hours with back-off).
    return new Response('supabase error', { status: 500 });
  }
  console.log('revenuecat:', type, '→', userId, status, productId, store);
  return ok(type + ' written');
}
```

Deploy with `wrangler deploy` (or however the site is normally deployed).

### 3.3 Tell RevenueCat where to send events

RevenueCat → your project → **Integrations** → **Webhooks** → Add:

- Webhook URL: `https://lisaany.com/api/revenuecat`
- Authorization header value: the secret you generated in 3.1 (the same value you gave
  `wrangler secret put REVENUECAT_WEBHOOK_SECRET`)
- Environment: both Production and Sandbox (sandbox purchases are written too, so you can test;
  they carry `environment: "SANDBOX"` if you later want the Worker to ignore them)
- Event types: all (the Worker ignores the ones it does not need)

Save, then use **Send test event**. The Worker answers 200 with `ignored TEST` — that proves the URL
and the secret are right. A 401 means the header value does not match the secret.

### 3.4 Known gap — guests who sign in later

A purchase made **before** signing in belongs to an anonymous RevenueCat id; the Worker skips it.
The app itself is fine (RevenueCat carries the entitlement over when the learner signs in), but
lisaany.com only learns about it from the next event that names their user id (the next RENEWAL).
The app nudges guests to sign in on the Premium and welcome screens, so this is rare. If it
matters, the fix is a second route the app calls after sign-in that asks RevenueCat's REST API
(`GET https://api.revenuecat.com/v1/subscribers/<user id>` with a **secret** RevenueCat API key
kept as a Worker secret) and upserts the same row.

---

## Part 4 — Test checklist

### iPhone (sandbox)

1. Build: `eas build --platform ios --profile preview` (TestFlight also works). Install it.
2. Settings → App Store → Sandbox Account: sign in with the sandbox tester from Part 2.
3. In the app, sign in to a Lisaany account you can check in Supabase. Open a locked lesson
   (1.4) → **See plans**. The two cards show App Store prices in your currency; "BEST VALUE"
   appears only if the yearly plan really is at least 15 % cheaper per month.
4. Continue → confirm the sandbox purchase → the Welcome to Premium screen opens and lesson 1.4
   starts.
5. Supabase → Table editor → `subscriptions`: a row for that user with `plan = premium`,
   `status = active`, `source = apple`, `store_product_id = lisaany_premium_yearly` (or monthly),
   `current_period_end` a few minutes ahead (sandbox time runs fast).
6. Open lisaany.com in a browser, sign in with the same account: Premium units open.
7. Sandbox renewals arrive every few minutes as RENEWAL events; after the sandbox subscription
   expires (12 renewals for monthly), EXPIRATION sets `status = expired` and the website locks
   again. Cancel in Settings → Apple ID → Subscriptions → Sandbox to see CANCELLATION (status stays
   `active` until the period ends).
8. Delete the app, reinstall, sign in → **Restore purchases** on the Premium screen or in Settings
   brings Premium back without paying.
9. Airplane mode → open the app → premium lessons still open (the plan is remembered on the device).

### Android (Play internal testing)

1. Upload the production `.aab` to Internal testing and install it from the tester link (not a
   sideloaded APK — Play Billing needs a Play-installed build).
2. Be signed in on the phone with a Google account listed under License testing.
3. Same steps as iPhone 3–6; the fine print says Google Play, the row has `source = google`.
4. Cancel in Play Store → Payments & subscriptions → Subscriptions; test renewals every 5 minutes.

### What to look at when something is off

- Prices missing / "Premium is not available in this version yet": key placeholder still in
  `.env`, Paid Apps agreement not signed, products not "Ready to Submit"/activated, or the
  build is Expo Go.
- Purchase works but no Supabase row: RevenueCat → Customers → the user → Events shows whether the
  webhook was sent and the response code; Cloudflare → Workers → Logs shows the Worker's
  `console.log` lines. 401 = secret mismatch; 500 = Supabase rejected the write (most often the
  unique index from `store_subscriptions.sql` step 4 is missing).
- Row exists but the website still says free: `status` must be `active` or `trialing` and `plan`
  must be `premium`; the website checks exactly those.
