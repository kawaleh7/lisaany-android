# Sign in with Google and Apple — setup

The buttons are built into the app but stay hidden until you switch them on in
`.env` (`EXPO_PUBLIC_SSO_GOOGLE=on`, `EXPO_PUBLIC_SSO_APPLE=on`) and build again.
Do the setup below first, then switch on, then build.

## Google (Android and iPhone) — about 10 minutes

The website already signs people in with Google, so Supabase's Google login
already works. The app uses that same login, so there is only one thing to add:

1. Supabase → **Authentication → URL Configuration → Redirect URLs** →
   **Add URL**: `lisaany://auth-callback` → Save.
2. Check Supabase → **Authentication → Providers → Google** is **Enabled**.
3. In `.env` set `EXPO_PUBLIC_SSO_GOOGLE=on`.

## Apple (iPhone) — about 15 minutes

1. Apple Developer (developer.apple.com) → **Certificates, Identifiers & Profiles
   → Identifiers** → `com.lisaany.arabic` → tick **Sign in with Apple** → Save.
   (EAS may also offer to do this during `eas build` — answer **Yes**.)
2. Supabase → **Authentication → Providers → Apple** → **Enable**.
   In **Client IDs** enter: `com.lisaany.arabic` → Save.
   (The secret key fields are only for Apple sign-in on a website; the app does
   not need them.)
3. In `.env` set `EXPO_PUBLIC_SSO_APPLE=on`.

## Then

Build as usual (iPhone: `eas build --platform ios --profile production`;
Android: upload the zip to the lisaany-android repo).

## How accounts connect

- Someone who already has a lisaany.com account with the same Gmail address lands
  in that same account (Supabase links accounts with the same confirmed email).
- Apple users who choose "Hide my email" get a private Apple address, so that is
  a new account.
- Apple only shares the person's name the very first time; the app saves it then.
