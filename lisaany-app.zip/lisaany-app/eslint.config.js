// ESLint (flat config) — `npm run lint`. Expo's shared rules for React Native
// + TypeScript; the generated lesson/Norania page strings are skipped.
const { defineConfig } = require('eslint/config');
const expoConfig = require('eslint-config-expo/flat');

module.exports = defineConfig([
  expoConfig,
  {
    // Animated.Value refs are read while rendering (the standard React Native
    // pattern) and several sheets reset their state when a prop flips. Both
    // are flagged by the React-Compiler-era hook rules; they stay visible as
    // warnings rather than blocking the build.
    rules: {
      'react-hooks/refs': 'warn',
      'react-hooks/set-state-in-effect': 'warn',
      'react-hooks/immutability': 'warn',
    },
  },
  {
    ignores: ['dist/*', 'node_modules/*', 'android/*', 'ios/*', '.expo/*', 'src/data/lesson-page.ts', 'src/data/norania-page.ts', 'tools/*', 'assets/*'],
  },
]);
