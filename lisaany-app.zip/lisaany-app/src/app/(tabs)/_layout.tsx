import { Tabs } from 'expo-router/js-tabs';
import { StyleSheet, useWindowDimensions, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Icon } from '@/components/icon';
import { CONTENT_MAX } from '@/components/content-width';
import { Fonts } from '@/constants/lisaany';
import { useLang } from '@/lib/i18n';
import { useTheme } from '@/theme';

/** Distance from the icon's top up to the tab bar's top edge. */
const GLOW_OFFSET = 11;

export default function TabsLayout() {
  // edge-to-edge puts the tab bar under Android's navigation buttons.
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const { c } = useTheme();
  // The bar stays edge to edge; its four items sit in the same centred column
  // the screens use, so they don't drift into the corners of a tablet.
  const gutter = Math.max(0, (width - CONTENT_MAX) / 2);
  const { t } = useLang();
  const dark = c.scheme === 'dark';

  return (
    <Tabs
      screenOptions={{
        headerStyle: { backgroundColor: c.bg },
        headerTintColor: c.text,
        headerTitleStyle: { fontFamily: Fonts.display, fontSize: 17 },
        headerShadowVisible: false,
        sceneStyle: { backgroundColor: c.bg },
        tabBarStyle: {
          backgroundColor: c.tabBar,
          borderTopColor: dark ? 'rgba(255,255,255,0.06)' : c.line,
          borderTopWidth: 1,
          height: 72 + insets.bottom,
          paddingTop: 8,
          paddingBottom: 10 + insets.bottom,
          paddingHorizontal: gutter,
          elevation: 0,
        },
        tabBarLabelStyle: {
          fontFamily: Fonts.bodySemi,
          fontSize: 11,
          letterSpacing: 0.3,
          marginTop: 2,
        },
        // Space look: deep navy bar, gold active tab.
        tabBarActiveTintColor: dark ? c.goldFill : c.gold,
        tabBarInactiveTintColor: dark ? '#8792a6' : c.muted,
      }}>
      <Tabs.Screen
        name="index"
        options={{
          title: t('Today'),
          headerShown: false,
          tabBarIcon: ({ color, focused }) => <TabIcon name="home" color={String(color)} focused={focused} glow={c.goldFill} />,
        }}
      />
      <Tabs.Screen
        name="lessons"
        options={{
          title: t('Lessons'),
          headerShown: false,
          tabBarIcon: ({ color, focused }) => <TabIcon name="auto_stories" color={String(color)} focused={focused} glow={c.goldFill} />,
        }}
      />
      <Tabs.Screen
        name="circle"
        options={{
          title: t('Board'),
          headerShown: false,
          tabBarIcon: ({ color, focused }) => <TabIcon name="leaderboard" color={String(color)} focused={focused} glow={c.goldFill} />,
        }}
      />
      <Tabs.Screen
        name="profile"
        options={{
          title: t('Settings'),
          headerShown: false,
          tabBarIcon: ({ color, focused }) => <TabIcon name="settings" color={String(color)} focused={focused} glow={c.goldFill} />,
        }}
      />
    </Tabs>
  );
}

/** Icon with the glowing gold line above it when its tab is active. */
function TabIcon({ name, color, focused, glow }: { name: string; color: string; focused: boolean; glow: string }) {
  return (
    <View style={styles.iconWrap}>
      {focused ? <View style={[styles.glow, { backgroundColor: glow, shadowColor: glow }]} /> : null}
      <Icon name={name} color={color} size={23} />
    </View>
  );
}

const styles = StyleSheet.create({
  iconWrap: { alignItems: 'center', justifyContent: 'center', overflow: 'visible' },
  glow: {
    position: 'absolute',
    top: -GLOW_OFFSET,
    width: 34,
    height: 3,
    borderBottomLeftRadius: 3,
    borderBottomRightRadius: 3,
    shadowOpacity: 0.9,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 0 },
    elevation: 6,
  },
});
