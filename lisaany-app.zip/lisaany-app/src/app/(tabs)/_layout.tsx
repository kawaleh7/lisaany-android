import { Tabs } from 'expo-router/js-tabs';
import { StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Icon } from '@/components/icon';
import { Fonts } from '@/constants/lisaany';
import { useLang } from '@/lib/i18n';
import { useTheme } from '@/theme';

/** Distance from the icon's top up to the tab bar's top edge. */
const GLOW_OFFSET = 11;

export default function TabsLayout() {
  // edge-to-edge puts the tab bar under Android's navigation buttons.
  const insets = useSafeAreaInsets();
  const { c } = useTheme();
  const { t } = useLang();

  return (
    <Tabs
      screenOptions={{
        headerStyle: { backgroundColor: c.bg },
        headerTintColor: c.text,
        headerTitleStyle: { fontFamily: Fonts.display, fontSize: 17 },
        headerShadowVisible: false,
        sceneStyle: { backgroundColor: c.bg },
        tabBarStyle: {
          backgroundColor: c.tabBar,
          borderTopColor: c.line,
          borderTopWidth: 1,
          height: 72 + insets.bottom,
          paddingTop: 8,
          paddingBottom: 10 + insets.bottom,
          elevation: 0,
        },
        tabBarLabelStyle: {
          fontFamily: Fonts.bodySemi,
          fontSize: 11,
          letterSpacing: 0.3,
          marginTop: 2,
        },
        tabBarActiveTintColor: c.gold,
        tabBarInactiveTintColor: c.muted,
      }}>
      <Tabs.Screen
        name="index"
        options={{
          title: t('Today'),
          headerShown: false,
          tabBarIcon: ({ color, focused }) => <TabIcon name="home" color={String(color)} focused={focused} glow={c.goldFill} />,
        }}
      />
      <Tabs.Screen
        name="lessons"
        options={{
          title: t('Lessons'),
          headerShown: false,
          tabBarIcon: ({ color, focused }) => <TabIcon name="auto_stories" color={String(color)} focused={focused} glow={c.goldFill} />,
        }}
      />
      <Tabs.Screen
        name="profile"
        options={{
          title: t('Settings'),
          headerShown: false,
          tabBarIcon: ({ color, focused }) => <TabIcon name="settings" color={String(color)} focused={focused} glow={c.goldFill} />,
        }}
      />
    </Tabs>
  );
}

/** Icon with the glowing gold line above it when its tab is active. */
function TabIcon({ name, color, focused, glow }: { name: string; color: string; focused: boolean; glow: string }) {
  return (
    <View style={styles.iconWrap}>
      {focused ? <View style={[styles.glow, { backgroundColor: glow, shadowColor: glow }]} /> : null}
      <Icon name={name} color={color} size={23} />
    </View>
  );
}

const styles = StyleSheet.create({
  iconWrap: { alignItems: 'center', justifyContent: 'center', overflow: 'visible' },
  glow: {
    position: 'absolute',
    top: -GLOW_OFFSET,
    width: 34,
    height: 3,
    borderBottomLeftRadius: 3,
    borderBottomRightRadius: 3,
    shadowOpacity: 0.9,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 0 },
    elevation: 6,
  },
});
