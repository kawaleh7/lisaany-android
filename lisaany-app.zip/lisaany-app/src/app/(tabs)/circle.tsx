/**
 * Circle tab — the leaderboard.
 *
 * "Star League" is always there: a practice board of star-named rivals
 * (clearly labelled, not real learners) that keeps the learner mid-pack and a
 * few XP from the next place. Signed-in learners can also start or join a
 * private family & friends circle with a code and compete with real people.
 */
import { useFocusEffect, useRouter } from 'expo-router';
import { useCallback, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Alert, Pressable, ScrollView, Share, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { Icon } from '@/components/icon';
import { SpaceBackdrop } from '@/components/space-backdrop';
import { GoldStar, StarSlot, StarTalk, useStarGuide } from '@/components/star-guide';
import { CardFill, currentCard, spaceCard } from '@/components/ui';
import { Fonts, Spacing } from '@/constants/lisaany';
import { useAuth } from '@/lib/auth-context';
import {
  badgeColor,
  circleBoard,
  CircleFailure,
  createCircle,
  getLastCircle,
  initials,
  joinCircle,
  leaveCircle,
  myCircles,
  rank,
  reportXp,
  setLastCircle,
  starLeague,
  type BoardRow,
  type Circle,
  type CircleError,
} from '@/lib/circles';
import { useLang } from '@/lib/i18n';
import { makeStyles, useTheme } from '@/theme';

const LEAGUE = 'star-league';
type Period = 'week' | 'all';
type Panel = null | 'start' | 'join';

const ERRORS: Record<CircleError, string> = {
  not_signed_in: 'Please sign in first.',
  circle_not_found: 'No circle has that code. Check it and try again.',
  circle_full: 'That circle is full (30 people).',
  too_many_circles: 'You can be in up to 5 circles.',
  name_required: 'Give your circle a name.',
  display_name_required: 'Add the name others will see.',
  not_a_member: 'You’re no longer in this circle.',
  not_set_up: 'Circles aren’t switched on yet. Please try again later.',
  offline: 'You seem to be offline. Try again when you’re connected.',
  unknown: 'Something went wrong. Please try again.',
};

export default function CircleScreen() {
  const router = useRouter();
  const { session } = useAuth();
  const { c } = useTheme();
  const styles = useStyles();
  const { t, lang } = useLang();

  const [circles, setCircles] = useState<Circle[]>([]);
  const [sel, setSel] = useState<string>(LEAGUE);
  const [rows, setRows] = useState<BoardRow[]>([]);
  const [period, setPeriod] = useState<Period>('week');
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);
  const [panel, setPanel] = useState<Panel>(null);
  const [busy, setBusy] = useState(false);
  const [formErr, setFormErr] = useState<string | null>(null);
  const [cName, setCName] = useState('');
  const [code, setCode] = useState('');
  const [myName, setMyName] = useState('');
  const loadSeq = useRef(0);

  const user = session?.user;
  const defaultName = useMemo(() => {
    const meta = (user?.user_metadata ?? {}) as Record<string, unknown>;
    const full = (typeof meta.full_name === 'string' && meta.full_name) || (typeof meta.name === 'string' && meta.name) || '';
    const first = full ? full.split(/\s+/)[0] : (user?.email ?? '').split('@')[0];
    return first ? first.charAt(0).toUpperCase() + first.slice(1, 24) : '';
  }, [user]);

  const loadBoard = useCallback(async (id: string) => {
    const seq = ++loadSeq.current;
    setLoading(true);
    setErr(null);
    try {
      const data = id === LEAGUE ? await starLeague() : await circleBoard(id);
      if (seq === loadSeq.current) setRows(data);
    } catch (e) {
      if (seq !== loadSeq.current) return;
      const code = e instanceof CircleFailure ? e.code : 'unknown';
      setErr(t(ERRORS[code]));
      setRows([]);
    } finally {
      if (seq === loadSeq.current) setLoading(false);
    }
  }, [t]);

  useFocusEffect(
    useCallback(() => {
      let active = true;
      (async () => {
        let list: Circle[] = [];
        if (session) {
          await reportXp();
          try {
            list = await myCircles();
          } catch {
            list = [];
          }
        }
        if (!active) return;
        setCircles(list);
        const last = await getLastCircle();
        const pick = last && (last === LEAGUE || list.some((x) => x.id === last)) ? last : LEAGUE;
        setSel(pick);
        loadBoard(pick);
      })();
      return () => {
        active = false;
      };
    }, [session, loadBoard])
  );

  const current = circles.find((x) => x.id === sel) ?? null;
  const isLeague = sel === LEAGUE;
  const ranked = useMemo(() => rank(rows, isLeague ? 'week' : period), [rows, isLeague, period]);
  const xpOf = (r: BoardRow) => (isLeague || period === 'week' ? r.weekXp : r.totalXp);
  const myIdx = ranked.findIndex((r) => r.isMe);
  const me = myIdx >= 0 ? ranked[myIdx] : null;
  const ahead = myIdx > 0 ? ranked[myIdx - 1] : null;

  const nameOf = (r: BoardRow) => (r.isMe ? (isLeague ? t('You') : r.name || t('You')) : r.name);

  /* ── the star ──────────────────────────────────────────────── */
  const ordinal = (n: number) => {
    if (lang === 'fr') return n === 1 ? '1er' : `${n}e`;
    const s = n % 100 >= 11 && n % 100 <= 13 ? 'th' : ['th', 'st', 'nd', 'rd'][n % 10] ?? 'th';
    return `${n}${s}`;
  };
  const status = useMemo(() => {
    if (loading || !me) return null;
    if (myIdx === 0) return t('You’re top of the board — keep it up!');
    if (ahead) {
      const gap = Math.max(1, xpOf(ahead) - xpOf(me) + 1);
      return t('You’re {place} — {gap} XP more passes {name}.', { place: ordinal(myIdx + 1), gap, name: nameOf(ahead) });
    }
    return null;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading, me, myIdx, ahead, period, sel]);
  const tips = [
    ...(status ? [status] : []),
    isLeague
      ? t('Star rivals set the pace each week. Start a circle to compete with family and friends.')
      : t('Share your code so family and friends can join.'),
  ];
  const guide = useStarGuide(tips, { greet: status, greetKey: `circle:${sel}:${period}` });

  /* ── actions ───────────────────────────────────────────────── */
  const choose = (id: string) => {
    setSel(id);
    setPanel(null);
    setLastCircle(id);
    loadBoard(id);
  };

  const openPanel = (p: Exclude<Panel, null>) => {
    if (!session) {
      router.push('/sign-in');
      return;
    }
    setFormErr(null);
    if (!myName) setMyName(defaultName);
    setPanel((cur) => (cur === p ? null : p));
  };

  const submit = async () => {
    if (!panel) return;
    setBusy(true);
    setFormErr(null);
    try {
      const made = panel === 'start' ? await createCircle(cName, myName) : await joinCircle(code, myName);
      const list = await myCircles().catch(() => [made]);
      setCircles(list);
      setCName('');
      setCode('');
      setPanel(null);
      choose(made.id);
      guide.say(panel === 'start' ? t('Your circle is ready. Share the code {code} to invite people.', { code: made.code }) : t('Welcome to {name}!', { name: made.name }));
    } catch (e) {
      const code = e instanceof CircleFailure ? e.code : 'unknown';
      setFormErr(t(ERRORS[code]));
    } finally {
      setBusy(false);
    }
  };

  const share = () => {
    if (!current) return;
    Share.share({
      message: t('Join my Arabic circle “{name}” on Lisaany. Open the Circle tab, tap Join and enter the code {code}.', { name: current.name, code: current.code }),
    }).catch(() => {});
  };

  const leave = () => {
    if (!current) return;
    Alert.alert(t('Leave this circle?'), t('You can join again later with the code {code}.', { code: current.code }), [
      { text: t('Cancel'), style: 'cancel' },
      {
        text: t('Leave'),
        style: 'destructive',
        onPress: async () => {
          try {
            await leaveCircle(current.id);
          } catch {
            /* the list refresh below shows the real state */
          }
          const list = await myCircles().catch(() => circles.filter((x) => x.id !== current.id));
          setCircles(list);
          choose(LEAGUE);
        },
      },
    ]);
  };

  /* ── pieces ────────────────────────────────────────────────── */
  const Badge = ({ r, size = 36 }: { r: BoardRow; size?: number }) =>
    r.rival ? (
      <View style={[styles.badge, styles.badgeRival, { width: size, height: size, borderRadius: size / 2 }]}>
        <Icon name="star" size={size * 0.5} color={c.gold} />
      </View>
    ) : (
      <View style={[styles.badge, { width: size, height: size, borderRadius: size / 2, backgroundColor: r.isMe && isLeague ? c.goldTint : badgeColor(r.userId) }, r.isMe && styles.badgeMe]}>
        <Text style={[styles.badgeText, { fontSize: size * 0.34 }, r.isMe && isLeague && { color: c.gold }]}>
          {r.isMe && isLeague ? (defaultName ? initials(defaultName) : t('Me')) : initials(r.name)}
        </Text>
      </View>
    );

  const podium = ranked.slice(0, 3);
  const rest = ranked.slice(3);
  const MEDAL = ['#e8c86a', '#c9d3e6', '#d39a6a'];

  return (
    <SafeAreaView style={styles.screen} edges={['top', 'left', 'right']}>
      <SpaceBackdrop />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        <View style={styles.headRow}>
          <View style={{ flex: 1 }}>
            <Text style={styles.eyebrow}>{isLeague ? t('THIS WEEK · PRACTICE') : t('FAMILY & FRIENDS')}</Text>
            <Text style={styles.title} numberOfLines={1} adjustsFontSizeToFit>
              {isLeague ? t('Star League') : current?.name ?? ''}
            </Text>
          </View>
          <StarSlot guide={guide} />
        </View>
        <StarTalk guide={guide} />

        {/* switch boards */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.chipsWrap} contentContainerStyle={styles.chips}>
          <Pressable onPress={() => choose(LEAGUE)} style={[styles.chip, isLeague && styles.chipOn]}>
            <Icon name="star" size={15} color={isLeague ? c.btnText : c.muted} />
            <Text style={[styles.chipText, isLeague && styles.chipTextOn]}>{t('Star League')}</Text>
          </Pressable>
          {circles.map((x) => (
            <Pressable key={x.id} onPress={() => choose(x.id)} style={[styles.chip, sel === x.id && styles.chipOn]}>
              <Text style={[styles.chipText, sel === x.id && styles.chipTextOn]} numberOfLines={1}>
                {x.name}
              </Text>
            </Pressable>
          ))}
          <Pressable onPress={() => openPanel('start')} style={[styles.chip, styles.chipAdd]} accessibilityLabel={t('Start or join a circle')}>
            <Icon name="add" size={16} color={c.gold} />
            <Text style={[styles.chipText, { color: c.gold }]}>{t('Circle')}</Text>
          </Pressable>
        </ScrollView>

        {/* start / join */}
        {panel ? (
          <View style={[styles.panel, spaceCard(c)]}>
            <CardFill radius={20} />
            <View style={styles.seg}>
              {(['start', 'join'] as const).map((p) => (
                <Pressable key={p} onPress={() => { setPanel(p); setFormErr(null); }} style={[styles.segBtn, panel === p && styles.segOn]}>
                  <Text style={[styles.segText, panel === p && styles.segTextOn]}>{p === 'start' ? t('Start a circle') : t('Join with a code')}</Text>
                </Pressable>
              ))}
            </View>
            {panel === 'start' ? (
              <>
                <Text style={styles.label}>{t('Circle name')}</Text>
                <TextInput value={cName} onChangeText={setCName} placeholder={t('e.g. The Family, Grade 8')} placeholderTextColor={c.faint} style={styles.input} maxLength={40} />
              </>
            ) : (
              <>
                <Text style={styles.label}>{t('Code')}</Text>
                <TextInput value={code} onChangeText={(v) => setCode(v.toUpperCase())} placeholder="LSN-7K2P" placeholderTextColor={c.faint} style={[styles.input, styles.codeInput]} autoCapitalize="characters" autoCorrect={false} maxLength={12} />
              </>
            )}
            <Text style={styles.label}>{t('Your name in the circle')}</Text>
            <TextInput value={myName} onChangeText={setMyName} placeholder={t('First name')} placeholderTextColor={c.faint} style={styles.input} maxLength={24} />
            {formErr ? <Text style={styles.formErr}>{formErr}</Text> : null}
            <Pressable
              onPress={submit}
              disabled={busy || !myName.trim() || (panel === 'start' ? !cName.trim() : code.replace(/[^A-Za-z0-9]/g, '').length < 4)}
              style={({ pressed }) => [styles.cta, (busy || !myName.trim() || (panel === 'start' ? !cName.trim() : code.replace(/[^A-Za-z0-9]/g, '').length < 4)) && { opacity: 0.4 }, pressed && { opacity: 0.85 }]}>
              {busy ? <ActivityIndicator color={c.btnText} /> : <Text style={styles.ctaText}>{panel === 'start' ? t('Create circle') : t('Join circle')}</Text>}
            </Pressable>
            <Text style={styles.small}>{t('Only people in your circle see your name and XP.')}</Text>
          </View>
        ) : null}

        {!isLeague ? (
          <View style={styles.seg2}>
            {(['week', 'all'] as const).map((p) => (
              <Pressable key={p} onPress={() => setPeriod(p)} style={[styles.segBtn, period === p && styles.segOn]}>
                <Text style={[styles.segText, period === p && styles.segTextOn]}>{p === 'week' ? t('This week') : t('All time')}</Text>
              </Pressable>
            ))}
          </View>
        ) : null}

        {loading ? (
          <ActivityIndicator color={c.gold} style={{ marginTop: 40 }} />
        ) : err ? (
          <Text style={styles.err}>{err}</Text>
        ) : (
          <>
            {/* podium */}
            <View style={styles.podium}>
              {[1, 0, 2].map((i) => {
                const r = podium[i];
                if (!r) return <View key={i} style={{ flex: 1 }} />;
                const h = i === 0 ? 86 : i === 1 ? 60 : 44;
                return (
                  <View key={r.userId} style={styles.pd}>
                    {i === 0 ? <GoldStar size={28} halo={false} /> : null}
                    <Badge r={r} size={i === 0 ? 52 : 46} />
                    <Text style={[styles.pdName, r.isMe && { color: c.gold }]} numberOfLines={1}>
                      {nameOf(r)}
                    </Text>
                    <Text style={styles.pdXp}>{xpOf(r)} XP</Text>
                    <View style={[styles.block, { height: h }]}>
                      <Text style={[styles.blockNum, { color: MEDAL[i] }]}>{i + 1}</Text>
                    </View>
                  </View>
                );
              })}
            </View>

            {/* the rest */}
            <View style={{ gap: 8 }}>
              {rest.map((r, i) => (
                <View key={r.userId} style={[styles.row, spaceCard(c), r.isMe && currentCard(c)]}>
                  <CardFill radius={16} />
                  <Text style={styles.rank}>{i + 4}</Text>
                  <Badge r={r} />
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.rowName, r.isMe && { color: c.gold }]} numberOfLines={1}>
                      {nameOf(r)}
                    </Text>
                    <Text style={styles.rowSub} numberOfLines={1}>
                      {r.rival ? t('Practice rival') : r.streak === 1 ? t('1-day streak') : r.streak > 1 ? t('{n}-day streak', { n: r.streak }) : ' '}
                    </Text>
                  </View>
                  <Text style={styles.rowXp}>{xpOf(r)} XP</Text>
                </View>
              ))}
            </View>

            {isLeague ? (
              <View style={styles.note}>
                <Icon name="info" size={16} color={c.muted} />
                <Text style={styles.noteText}>
                  {t('Star rivals are practice pace-setters, not real learners. New rivals every Monday.')}
                </Text>
              </View>
            ) : current ? (
              <>
                <Pressable onPress={share} style={({ pressed }) => [styles.invite, pressed && { opacity: 0.85 }]}>
                  <Icon name="share" size={18} color={c.gold} />
                  <Text style={styles.inviteText}>
                    {t('Invite with the code')} <Text style={styles.code}>{current.code}</Text>
                  </Text>
                </Pressable>
                <Pressable onPress={leave} style={styles.leave}>
                  <Text style={styles.leaveText}>{t('Leave circle')}</Text>
                </Pressable>
              </>
            ) : null}

            {isLeague && !circles.length ? (
              <Pressable onPress={() => openPanel('start')} style={[styles.promo, spaceCard(c)]}>
                <CardFill radius={20} />
                <View style={styles.promoIc}>
                  <Icon name="hub" size={22} color={c.gold} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.promoTitle}>{t('Compete with family & friends')}</Text>
                  <Text style={styles.promoSub}>{session ? t('Start a circle or join one with a code.') : t('Sign in to start or join a circle.')}</Text>
                </View>
                <Icon name="chevron_right" size={22} color={c.gold} />
              </Pressable>
            ) : null}
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const useStyles = makeStyles((c) => {
  const light = c.scheme === 'light';
  return {
    screen: { flex: 1, backgroundColor: c.bg },
    content: { paddingHorizontal: Spacing.lg, paddingTop: 14, paddingBottom: 36 },
    headRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
    eyebrow: { fontFamily: Fonts.bodyBold, fontSize: 10.5, letterSpacing: 2.2, color: c.gold },
    title: { fontFamily: Fonts.displayBold, fontSize: 28, color: c.text, marginTop: 4 },

    chipsWrap: { marginTop: 14, marginHorizontal: -Spacing.lg },
    chips: { gap: 8, paddingHorizontal: Spacing.lg },
    chip: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 6,
      height: 36,
      paddingHorizontal: 14,
      borderRadius: 18,
      borderWidth: 1,
      borderColor: light ? c.line : 'rgba(255,255,255,0.12)',
      backgroundColor: light ? c.card : 'rgba(255,255,255,0.05)',
      maxWidth: 180,
    },
    chipOn: { backgroundColor: c.btnBg, borderColor: c.btnBorder },
    chipAdd: { borderStyle: 'dashed', borderColor: c.btnBorder, backgroundColor: 'transparent' },
    chipText: { fontFamily: Fonts.bodySemi, fontSize: 13.5, color: c.muted },
    chipTextOn: { color: c.btnText },

    panel: { marginTop: 14, borderRadius: 20, padding: 16, overflow: 'hidden' },
    seg: { flexDirection: 'row', gap: 6, padding: 4, borderRadius: 14, backgroundColor: light ? c.raised : 'rgba(255,255,255,0.05)' },
    seg2: { flexDirection: 'row', gap: 6, padding: 4, borderRadius: 14, marginTop: 14, backgroundColor: light ? c.raised : 'rgba(255,255,255,0.05)' },
    segBtn: { flex: 1, alignItems: 'center', paddingVertical: 9, borderRadius: 10 },
    segOn: { backgroundColor: c.btnBg },
    segText: { fontFamily: Fonts.bodySemi, fontSize: 13.5, color: c.muted },
    segTextOn: { color: c.btnText },
    label: { fontFamily: Fonts.bodySemi, fontSize: 12.5, color: c.muted, marginTop: 14, marginBottom: 6 },
    input: {
      position: 'relative', // above the card's gradient layer on web
      height: 48,
      borderRadius: 14,
      paddingHorizontal: 14,
      borderWidth: 1,
      borderColor: light ? c.line : 'rgba(255,255,255,0.14)',
      backgroundColor: light ? '#f7f9fc' : 'rgba(0,0,0,0.2)',
      color: c.text,
      fontFamily: Fonts.body,
      fontSize: 16,
    },
    codeInput: { fontFamily: Fonts.bodyBold, letterSpacing: 2 },
    formErr: { fontFamily: Fonts.body, fontSize: 13.5, color: c.red, marginTop: 10 },
    cta: { height: 50, borderRadius: 25, marginTop: 16, alignItems: 'center', justifyContent: 'center', backgroundColor: c.btnBg, borderWidth: 1.2, borderColor: c.btnBorder },
    ctaText: { fontFamily: Fonts.bodyBold, fontSize: 15.5, color: c.btnText },
    small: { fontFamily: Fonts.body, fontSize: 12, color: c.muted, textAlign: 'center', marginTop: 10 },

    podium: { flexDirection: 'row', alignItems: 'flex-end', gap: 8, marginTop: 22, marginBottom: 14 },
    pd: { flex: 1, alignItems: 'center', gap: 3 },
    pdName: { fontFamily: Fonts.bodySemi, fontSize: 14, color: c.text, maxWidth: '100%' },
    pdXp: { fontFamily: Fonts.bodyBold, fontSize: 12, color: c.gold },
    block: {
      alignSelf: 'stretch',
      marginTop: 6,
      borderTopLeftRadius: 14,
      borderTopRightRadius: 14,
      borderWidth: 1,
      borderBottomWidth: 0,
      borderColor: light ? 'rgba(184,134,31,0.3)' : 'rgba(214,178,90,0.25)',
      backgroundColor: light ? 'rgba(214,178,90,0.12)' : 'rgba(214,178,90,0.1)',
      alignItems: 'center',
      paddingTop: 8,
    },
    blockNum: { fontFamily: Fonts.bodyBold, fontSize: 18 },

    badge: { alignItems: 'center', justifyContent: 'center' },
    badgeRival: { backgroundColor: c.goldTint, borderWidth: 1, borderColor: light ? 'rgba(184,134,31,0.3)' : 'rgba(214,178,90,0.3)' },
    badgeMe: { borderWidth: 2, borderColor: c.goldFill },
    badgeText: { fontFamily: Fonts.bodyBold, color: '#ffffff' },

    row: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 10, paddingHorizontal: 12, borderRadius: 16, overflow: 'hidden' },
    rank: { width: 20, textAlign: 'center', fontFamily: Fonts.bodyBold, fontSize: 14, color: c.muted },
    rowName: { fontFamily: Fonts.bodySemi, fontSize: 15, color: c.text },
    rowSub: { fontFamily: Fonts.body, fontSize: 12, color: c.muted, marginTop: 1 },
    rowXp: { fontFamily: Fonts.bodyBold, fontSize: 13.5, color: c.gold },

    note: { flexDirection: 'row', gap: 8, alignItems: 'flex-start', marginTop: 14, paddingHorizontal: 4 },
    noteText: { flex: 1, fontFamily: Fonts.body, fontSize: 12.5, lineHeight: 18, color: c.muted },
    invite: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      marginTop: 16,
      paddingVertical: 14,
      borderRadius: 16,
      borderWidth: 1,
      borderStyle: 'dashed',
      borderColor: c.btnBorder,
    },
    inviteText: { fontFamily: Fonts.body, fontSize: 14, color: c.muted },
    code: { fontFamily: Fonts.bodyBold, color: c.gold, letterSpacing: 1 },
    leave: { alignSelf: 'center', paddingVertical: 14, paddingHorizontal: 20 },
    leaveText: { fontFamily: Fonts.bodySemi, fontSize: 13.5, color: c.red },

    promo: { flexDirection: 'row', alignItems: 'center', gap: 12, marginTop: 16, padding: 14, borderRadius: 20, overflow: 'hidden' },
    promoIc: { width: 44, height: 44, borderRadius: 14, backgroundColor: c.goldTint, alignItems: 'center', justifyContent: 'center' },
    promoTitle: { fontFamily: Fonts.bodyBold, fontSize: 15.5, color: c.text },
    promoSub: { fontFamily: Fonts.body, fontSize: 13, color: c.muted, marginTop: 2 },
    err: { fontFamily: Fonts.body, fontSize: 14, color: c.muted, textAlign: 'center', marginTop: 30, paddingHorizontal: 20 },
  };
});
