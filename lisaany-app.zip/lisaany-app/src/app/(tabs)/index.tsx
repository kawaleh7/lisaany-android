import { LinearGradient } from 'expo-linear-gradient';
import { useFocusEffect, useRouter } from 'expo-router';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Svg, { Circle, Defs, LinearGradient as SvgGradient, Stop } from 'react-native-svg';

import { GoalPickerSheet } from '@/components/goal-controls';
import { Icon } from '@/components/icon';
import { PopPressable, usePop } from '@/components/pop-card';
import { SpaceBackdrop } from '@/components/space-backdrop';
import { markGreeted, StarSlot, StarTalk, useStarGuide } from '@/components/star-guide';
import { CardFill, currentCard, spaceCard } from '@/components/ui';
import { WelcomeBackSheet, WELCOME_FLY_AT, type StarPoint } from '@/components/welcome-back-sheet';
import { EmailAskSheet } from '@/components/email-ask-sheet';
import { answerEmailAsk, shouldAskEmail } from '@/lib/email-reminders';
import { Fonts, Spacing } from '@/constants/lisaany';
import { useAuth } from '@/lib/auth-context';
import { blockSizeLabel, getModuleForUnit, getUnit, MODULES, TOTAL_BLOCKS, type Block } from '@/lib/curriculum';
import { useLang } from '@/lib/i18n';
import { getHasSeenLanding } from '@/lib/onboarding';
import { canAccessUnit } from '@/lib/plan';
import {
  completedFromProg,
  countLearned,
  getEngineProgress,
  getLastUnit,
  getLearnedToday,
  getTodayXp,
  nextBlockFor,
  setLastUnit,
  type CompletedMap,
  type LastUnit,
} from '@/lib/progress';
import { makeStyles, useTheme } from '@/theme';
import { onWelcomeBack, takeWelcomeBack } from '@/lib/welcome-back';
import { reportXp } from '@/lib/circles';
import { DEFAULT_MIN_GOAL, getMinGoal, getMinutesHistory, getTodaySecs, localDay } from '@/lib/goal';
import { changeMinGoal } from '@/lib/goal-sync';
import { noteWordTotal } from '@/lib/word-pace';
import { contentCap } from '@/components/content-width';

// The daily-goal hero stays navy in both themes; these sit on it.
const ON_NAVY_LINE = 'rgba(255,255,255,0.10)';
const ON_NAVY_RAISED = 'rgba(255,255,255,0.06)';
// A3 (galaxy): white cards, gold accents, navy button. No green, no orange.
const A3 = {
  card: '#ffffff', border: '#E7EAF0', ink: '#15213B', muted: '#65718A', label: '#B98522',
  track: '#E7EAF0', gold: '#E5AD3B', flame: '#D78B29', meta: '#B98522', btn: '#182A60', btnText: '#ffffff',
  chip: '#FFF4DC', line: '#EEF0F4',
};

const TYPE_LABEL: Record<string, string> = {
  dialogue: 'Conversation', vocab: 'Vocabulary', grammar: 'Grammar', cloze: 'Listening dictation',
  clutter: 'Sentence builder', quiz: 'Practice drill', fill: 'Listen & choose', seqquiz: 'Quiz',
  possessive: 'Suffix tap', swipe: 'Swipe cards', conjugation: 'Conjugation', video: 'Video', choose: 'Choose',
};

function greeting(d = new Date()) {
  const h = d.getHours();
  if (h < 5) return 'Good night';
  if (h < 12) return 'Good morning';
  if (h < 18) return 'Good afternoon';
  return 'Good evening';
}

function dateLine(locale: string, d = new Date()) {
  return d.toLocaleDateString(locale, { weekday: 'long', day: 'numeric', month: 'long' });
}

/** Block size ("10 lines") in English; keys for t(). */
const SIZE_KEYS: Record<string, [string, string]> = {
  lines: ['1 line', '{n} lines'],
  words: ['1 word', '{n} words'],
  examples: ['1 example', '{n} examples'],
  sentences: ['1 sentence', '{n} sentences'],
  questions: ['1 question', '{n} questions'],
  items: ['1 item', '{n} items'],
};

export default function TodayScreen() {
  const pop = usePop();
  const { c } = useTheme();
  const styles = useStyles();
  const a3 = c.scheme !== 'light';
  const router = useRouter();
  const { session, loading: authLoading, progressVersion } = useAuth();
  const userId = session?.user?.id;
  const { t, ct, locale } = useLang();

  const sizeText = (b: Block) => {
    const keys = b.size ? SIZE_KEYS[b.size.unit] : undefined;
    if (!b.size || !keys) return blockSizeLabel(b);
    return b.size.count === 1 ? t(keys[0]) : t(keys[1], { n: b.size.count });
  };

  const [lastUnit, setLast] = useState<LastUnit | null>(null);
  const [streak, setStreak] = useState(0);
  const [xp, setXp] = useState(0);
  /** Daily goal in minutes, and active seconds learned today. */
  const [goal, setGoal] = useState(DEFAULT_MIN_GOAL);
  const [daySecs, setDaySecs] = useState(0);
  const [hist, setHist] = useState<Record<string, number>>({});
  const [picking, setPicking] = useState(false);
  const [completed, setCompleted] = useState<CompletedMap>({});
  const [allowed, setAllowed] = useState(true);
  const [welcome, setWelcome] = useState(false);
  // Where the star rests in the header, so the sheet can fly it in and back.
  const starRef = useRef<View>(null);
  const [starAt, setStarAt] = useState<StarPoint | null>(null);
  const measureStar = useCallback(() => {
    starRef.current?.measureInWindow((x, y, w, h) => {
      if (w > 0) setStarAt({ x: x + w / 2, y: y + h / 2, size: w });
    });
  }, []);
  // The header keeps its star until the sheet's star is actually in the air,
  // so the gold star is never missing from the screen.
  const [starAway, setStarAway] = useState(false);
  useEffect(() => {
    if (!welcome) {
      setStarAway(false);
      return;
    }
    const id = setTimeout(() => setStarAway(true), Math.max(0, WELCOME_FLY_AT - 40));
    return () => clearTimeout(id);
  }, [welcome]);
  // A welcome-back is on its way (sheet about to open): hold the star's greeting.
  const [welcomeHold, setWelcomeHold] = useState(false);
  const [loaded, setLoaded] = useState(false);
  // Asked once per learner, after sign-in: email reminders once a month (consent).
  const [askEmail, setAskEmail] = useState(false);
  const [reload, setReload] = useState(0);

  // First-run gate. Until the flag has been read (null) and the stored
  // session is back (authLoading) only the backdrop is drawn, so a fresh
  // install never flashes Today before landing and a signed-in learner never
  // sees the guest state for a frame. Re-read on every focus, so coming back
  // from onboarding lifts the gate; the redirect itself never runs during
  // render.
  const [seenLanding, setSeenLanding] = useState<boolean | null>(null);
  useFocusEffect(
    useCallback(() => {
      let active = true;
      getHasSeenLanding().then((seen) => {
        if (!active) return;
        setSeenLanding(seen);
        if (!seen) router.replace('/landing');
      });
      return () => {
        active = false;
      };
    }, [router])
  );
  const ready = !authLoading && seenLanding === true;

  // Re-loads on focus, after the welcome-back sheet, and whenever a cloud pull
  // (or a sign-out) changed the mirror behind our back.
  useFocusEffect(
    useCallback(() => {
      let active = true;
      Promise.all([getLastUnit(), getEngineProgress(), getMinGoal(), getTodaySecs(), getMinutesHistory()]).then(async ([last, snap, g, secs, h]) => {
        await getTodayXp(snap.xp); // keeps the weekly XP history current
        // Keeps circle boards fresh — only with this learner's own numbers (a
        // fresh install holds an empty mirror until the cloud pull lands).
        if (snap.uid === userId) reportXp();
        // Keeps today's learned baseline current (used by the lesson celebration).
        await getLearnedToday(completedFromProg(snap.prog));
        const unitId = last?.unitId ?? MODULES[0]?.units[0]?.id;
        const ok = unitId ? await canAccessUnit(unitId) : true;
        if (!active) return;
        setLast(last);
        setStreak(snap.streak);
        setXp(snap.xp);
        setGoal(g);
        setDaySecs(secs);
        setHist(h);
        setCompleted(completedFromProg(snap.prog));
        setAllowed(ok);
        setLoaded(true);
      });
      return () => {
        active = false;
      };
    // eslint-disable-next-line react-hooks/exhaustive-deps -- re-run on a cloud pull / account change
    }, [reload, progressVersion, userId])
  );

  // Back after a long break: refresh the numbers and slide up the welcome sheet.
  useFocusEffect(
    useCallback(() => {
      const show = () => {
        if (!takeWelcomeBack()) return;
        // The sheet already says how today is going, so the star skips its greeting.
        markGreeted('today');
        setWelcomeHold(true);
        getHasSeenLanding().then((seen) => {
          setWelcomeHold(false);
          if (!seen) return;
          setReload((n) => n + 1);
          measureStar();
          // Both kinds ('newday' and 'return') show the same sheet.
          setWelcome(true);
        });
      };
      show();
      return onWelcomeBack(show);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
  );

  const totals = useMemo(() => countLearned(completed), [completed]);
  useEffect(() => {
    if (loaded) noteWordTotal(totals.words);
  }, [loaded, totals.words]);

  const doneCount = Object.keys(completed).length;
  const coursePct = Math.round((doneCount / Math.max(1, TOTAL_BLOCKS)) * 100);
  const resumeUnit = lastUnit ? getUnit(lastUnit.unitId) : undefined;
  const target = resumeUnit ?? MODULES[0]?.units[0];
  const targetModule = target ? getModuleForUnit(target.id) : undefined;
  const targetDone = target ? target.blocks.filter((b) => completed[`${target.id}:${b.id}`]).length : 0;
  const unitComplete = !!target && targetDone >= target.blocks.length;
  const nextId = target ? nextBlockFor(target, completed) : undefined;
  const next = target ? target.blocks.find((b) => b.id === nextId) ?? target.blocks[0] : undefined;

  // This week, Monday → Sunday: a day counts once there was any learning time.
  const week = useMemo(() => {
    const now = new Date();
    const monday = new Date(now);
    monday.setDate(now.getDate() - ((now.getDay() + 6) % 7));
    const today = localDay(now);
    return ['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((label, i) => {
      const d = new Date(monday);
      d.setDate(monday.getDate() + i);
      const day = localDay(d);
      const on = (day === today ? daySecs : hist[day] ?? 0) > 0;
      return { label, on, today: day === today };
    });
  }, [hist, daySecs]);
  const weekDays = week.filter((d) => d.on).length;

  // Minutes goal: whole minutes shown, the goal counts to the second.
  const goalSecs = goal * 60;
  const mins = Math.floor(daySecs / 60);
  const goalPct = Math.min(1, daySecs / Math.max(1, goalSecs));
  const reached = daySecs >= goalSecs;
  const left = Math.max(1, Math.ceil((goalSecs - daySecs) / 60));

  // The star: greets once per app session with today's progress, then tips on tap.
  const tips = useMemo(() => {
    const list = [t('Tap Continue to jump straight into your next part.')];
    if (streak >= 2) list.push(t('{n} days in a row — keep your streak going!', { n: streak }));
    list.push(t('Daily review brings back words from parts you’ve finished.'));
    list.push(t('Tap the ring to change your daily goal.'));
    return list;
  }, [t, streak]);
  const greet =
    !loaded || !ready || welcome || welcomeHold
      ? null
      : reached
        ? t('Welcome back! {m} minutes of Arabic today — keep it going!', { m: mins })
        : mins === 0
          ? doneCount === 0 && xp === 0
            ? // Brand-new learner: nothing done yet, anywhere.
              t('Welcome! Your {goal} minutes of Arabic start with one part.', { goal })
            : // Returning learner, first visit today: straight back to where they stopped.
              t('Welcome back! Let’s pick up where you left off — {unit}.', { unit: target ? `${target.id} · ${ct(target.title)}` : '' })
          : t('Welcome back! {m} min done today — {left} more to reach your goal.', { m: mins, left });
  const guide = useStarGuide(tips, { greet, greetKey: 'today', delay: 800 });

  useEffect(() => {
    if (!ready || !loaded || !userId) return;
    let live = true;
    // A short pause so it never lands on top of the screen's own opening.
    const id = setTimeout(() => {
      shouldAskEmail(userId).then((ask) => {
        if (live && ask) setAskEmail(true);
      });
    }, 1500);
    return () => {
      live = false;
      clearTimeout(id);
    };
  }, [ready, loaded, userId]);

  const openNext = () => {
    if (!target) return;
    if (!allowed) {
      router.push(session ? { pathname: '/unit/[id]', params: { id: target.id } } : '/sign-in');
      return;
    }
    if (unitComplete) {
      router.push({ pathname: '/unit/[id]', params: { id: target.id } });
      return;
    }
    setLastUnit(target.id);
    router.push({ pathname: '/lesson/[unit]', params: { unit: target.id, block: String(next?.id ?? '') } });
  };

  // Tapping the card opens the lesson page (continue, start over, replay a part);
  // the gold arrow jumps straight into the next part.
  const openLessonPage = () => {
    if (!target) return;
    router.push({ pathname: '/unit/[id]', params: { id: target.id } });
  };

  const pickGoal = () => setPicking(true);
  const chooseGoal = (g: number) => {
    setPicking(false);
    setGoal(g);
    changeMinGoal(g);
    guide.say(
      daySecs >= g * 60
        ? t('Your goal is now {g} minutes. Great work today — keep going!', { g })
        : t('Your goal is now {g} minutes. You can do it!', { g })
    );
  };

  // Cold start / first run: the backdrop alone until we know what to show.
  if (!ready) {
    return (
      <SafeAreaView style={styles.screen} edges={['top', 'left', 'right']}>
        <SpaceBackdrop />
      </SafeAreaView>
    );
  }

  const goalCard = (
      <>
        {/* Daily goal */}
        <LinearGradient colors={a3 ? [A3.card, A3.card] : c.navyGrad} start={{ x: 0.2, y: 0 }} end={{ x: 0.8, y: 1 }} style={[pop.rest, styles.goalCard]}>
          <View style={styles.goalTop}>
            <Text style={styles.eyebrow}>{t('DAILY GOAL')}</Text>
            <Pressable onPress={pickGoal} hitSlop={10} style={styles.goalEdit}>
              <Text style={styles.goalEditText}>{t('{n} min', { n: goal })}</Text>
              <Icon name="expand_more" size={16} color={a3 ? A3.muted : c.onNavyMuted} />
            </Pressable>
          </View>

          <View style={styles.goalBody}>
            <Pressable
              onPress={pickGoal}
              style={styles.ringWrap}
              accessibilityRole="button"
              accessibilityLabel={t('{m} of {g} min', { m: mins, g: goal })}>
              <GoalRing value={goalPct} done={false} a3={a3} />
              <View style={styles.ringMid}>
                <Text style={styles.ringNum}>{mins}</Text>
                <Text style={styles.ringLbl}>{t('of {g} min', { g: goal })}</Text>
              </View>
            </Pressable>
            <View style={styles.goalSide}>
              <Text style={styles.goalMsg}>
                {reached ? t('Great work today — keep going!') : t('{n} min to go today', { n: left })}
              </Text>
              <View style={styles.stats}>
                <Stat icon="local_fire_department" color={a3 ? A3.flame : c.orange} value={String(streak)} label={streak === 1 ? t('day streak') : t('days streak')} />
                <Stat icon="bolt" color={c.gold} value={String(xp)} label={t('total XP')} />
                <Stat icon="auto_stories" color={c.gold} value={`${coursePct}%`} label={t('of course')} />
              </View>
            </View>
          </View>
        </LinearGradient>

      </>
  );

  return (
    <SafeAreaView style={styles.screen} edges={['top', 'left', 'right']}>
      <SpaceBackdrop />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.head}>
          <View style={{ flex: 1 }}>
            <Text style={styles.date}>{dateLine(locale)}</Text>
            <View style={styles.helloRow}>
              <Text style={styles.hello} numberOfLines={2}>{t(greeting())}</Text>
              {a3 ? (
                <View ref={starRef} collapsable={false} onLayout={measureStar} style={{ opacity: starAway ? 0 : 1 }}>
                  <StarSlot guide={guide} />
                </View>
              ) : null}
            </View>
            {a3 ? <Text style={styles.helloSub}>{t('Let’s keep learning Arabic!')}</Text> : null}
          </View>
          {a3 ? null : (
            <View ref={starRef} collapsable={false} onLayout={measureStar} style={{ opacity: starAway ? 0 : 1 }}>
              <StarSlot guide={guide} />
            </View>
          )}
          <View style={styles.streakPill}>
            <Icon name="local_fire_department" size={17} color={a3 ? A3.flame : c.orange} />
            <Text style={styles.streakNum}>{streak}</Text>
          </View>
          {a3 ? (
            <Pressable onPress={() => router.push('/profile')} style={styles.avatar} accessibilityLabel={t('Profile')}>
              <Icon name="account_circle" size={24} color="#E5AD3B" />
            </Pressable>
          ) : null}
        </View>
        <StarTalk guide={guide} />

        {a3 ? null : goalCard}

        {/* Up next */}
        {target && next ? (
          <>
            {a3 ? <View style={{ height: 6 }} /> : <Text style={styles.section}>{doneCount ? t('UP NEXT') : t('START HERE')}</Text>}
            <PopPressable onPress={openLessonPage} style={styles.nextCard}>
              {a3 ? null : <CardFill radius={22} />}
              {a3 ? (
                <>
                  <View style={styles.nextTopA}>
                    <Text style={styles.nextLblA} numberOfLines={1}>
                      {t(doneCount ? 'Continue' : 'Start')} · {t('Unit')} {target.id}
                    </Text>
                    {!unitComplete ? (
                      <Text style={styles.nextChipA}>
                        {t('Part {n} of {total}', { n: Math.max(1, target.blocks.findIndex((b) => b.id === next.id) + 1), total: target.blocks.length })}
                      </Text>
                    ) : null}
                  </View>
                  <View style={styles.nextMidA}>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.nextTitle} numberOfLines={2}>
                        {unitComplete ? t('Unit complete') : ct(next.title)}
                      </Text>
                      <Text style={styles.nextMetaA} numberOfLines={1}>
                        {unitComplete ? t('Tap to replay any part') : t(TYPE_LABEL[next.type] ?? 'Lesson')}
                      </Text>
                    </View>
                    {target.desc ? (
                      <Text style={styles.nextArA} numberOfLines={1} adjustsFontSizeToFit>
                        {String(target.desc).split(' — ').pop()}
                      </Text>
                    ) : null}
                  </View>
                </>
              ) : (
                <View style={styles.nextRow}>
                  <View style={styles.nextIcon}>
                    <Icon name={next.icon ?? 'play_arrow'} size={23} color={c.gold} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.nextUnit} numberOfLines={1}>
                      {target.id} · {ct(target.title)}
                    </Text>
                    <Text style={styles.nextTitle} numberOfLines={1}>
                      {unitComplete ? t('Unit complete') : ct(next.title)}
                    </Text>
                    <Text style={styles.nextMeta} numberOfLines={1}>
                      {unitComplete
                        ? t('Tap to replay any part')
                        : [t(TYPE_LABEL[next.type] ?? 'Lesson'), sizeText(next)].filter(Boolean).join(' · ')}
                    </Text>
                  </View>
                  <Pressable onPress={openNext} hitSlop={10} style={styles.go} accessibilityLabel={t('Continue lesson')}>
                    <Icon name={allowed ? 'arrow_forward' : 'lock'} size={20} color={c.btnText} />
                  </Pressable>
                </View>
              )}
              <View style={styles.segs}>
                {target.blocks.map((b, i) => {
                  const isDone = !!completed[`${target.id}:${b.id}`];
                  const isCur = !unitComplete && b.id === next.id;
                  return (
                    <View
                      key={b.id}
                      style={[
                        styles.seg,
                        isDone && { backgroundColor: a3 ? A3.gold : c.goldFill },
                        isCur && { backgroundColor: a3 ? 'rgba(212,162,58,0.45)' : 'rgba(214,178,90,0.45)' },
                        i === 0 && { marginLeft: 0 },
                      ]}
                    />
                  );
                })}
              </View>
              <Text style={[styles.segText, a3 && { display: 'none' }]}>
                {a3 && !unitComplete
                  ? t('Part {n} of {total}', { n: Math.max(1, target.blocks.findIndex((b) => b.id === next.id) + 1), total: target.blocks.length })
                  : t('{n} of {total} parts', { n: targetDone, total: target.blocks.length })}
                {!a3 && targetModule ? ` · ${ct(targetModule.title)}` : ''}
              </Text>
              {a3 ? (
                <View style={styles.nextFootA}>
                  <View style={styles.modIconA}>
                    <Icon name="menu_book" size={20} color="#477BDC" />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.modTitleA} numberOfLines={1}>{targetModule ? t('Module {n}', { n: targetModule.id }) : ''}</Text>
                    <Text style={styles.modSubA} numberOfLines={2}>{targetModule ? ct(targetModule.title) : ''}</Text>
                  </View>
                  <Pressable onPress={openNext} style={styles.goA} accessibilityLabel={t('Continue lesson')}>
                    <Text style={styles.goAText}>{allowed ? (unitComplete ? t('Replay') : t('Continue')) : t('Unlock')}</Text>
                    <Icon name={allowed ? 'arrow_forward' : 'lock'} size={18} color="#ffffff" />
                  </Pressable>
                </View>
              ) : null}
            </PopPressable>
          </>
        ) : null}

        {a3 ? (
          <Pressable onPress={pickGoal} style={styles.goalRowA}>
            <View style={styles.goalRowRing}>
              <GoalRing value={goalPct} done={false} a3 small />
              <View style={styles.ringMid}>
                <Text style={styles.goalRowNum}>{mins}</Text>
                <Text style={styles.goalRowMin}>{t('min')}</Text>
              </View>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.goalRowTitle}>
                {reached ? t('Great work today — keep going!') : t('{n} min to go today', { n: left })}
              </Text>
              <Text style={styles.goalRowSub} numberOfLines={2}>
                {t('Goal: {n} min', { n: goal })} · 🔥 {streak === 1 ? t('1 day streak') : t('{n} day streak', { n: streak })} · ⚡ {xp} XP
              </Text>
            </View>
            <Icon name="expand_more" size={18} color={A3.muted} />
          </Pressable>
        ) : null}

        {/* Practice */}
        {a3 ? (
          <View style={styles.secRow}>
            <Text style={[styles.section, { marginTop: 0, marginBottom: 0 }]}>{t('PRACTICE')}</Text>
            <Pressable onPress={() => router.push({ pathname: '/lesson/[unit]', params: { unit: 'reviewBuilder' } })} hitSlop={8} style={styles.seeAll}>
              <Text style={styles.seeAllText}>{t('See all')}</Text>
              <Icon name="arrow_forward" size={15} color="#8FB4FF" />
            </Pressable>
          </View>
        ) : (
          <Text style={styles.section}>{t('PRACTICE')}</Text>
        )}
        {a3 ? (
          <View style={styles.tiles}>
            <Tile
              tone="sun"
              icon="event_available"
              title={t('Daily review')}
              sub={t('Words from your finished blocks')}
              onPress={() => router.push({ pathname: '/lesson/[unit]', params: { unit: 'srsreview' } })}
            />
            <Tile
              tone="sky"
              icon="style"
              title={t('Review session')}
              sub={t('Pick a lesson and a drill')}
              onPress={() => router.push({ pathname: '/lesson/[unit]', params: { unit: 'reviewBuilder' } })}
            />
            <Tile
              tone="mint"
              icon="track_changes"
              title={t('Weak spots')}
              sub={t('Focus on your mistakes')}
              onPress={() => router.push({ pathname: '/lesson/[unit]', params: { unit: 'reviewBuilder' } })}
            />
          </View>
        ) : (
          <>
            <Row
              icon="autorenew"
              title={t('Daily review')}
              sub={t('Words from your finished blocks')}
              onPress={() => router.push({ pathname: '/lesson/[unit]', params: { unit: 'srsreview' } })}
            />
            <Row
              icon="style"
              title={t('Review session')}
              sub={t('Pick a lesson and a drill')}
              onPress={() => router.push({ pathname: '/lesson/[unit]', params: { unit: 'reviewBuilder' } })}
            />
          </>
        )}

        {!session ? (
          a3 ? (
            <PopPressable onPress={() => router.push('/sign-in')} style={styles.saveCard}>
              <View style={styles.saveIcon}>
                <Icon name="trophy" size={22} color="#D78B29" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.saveTitle} numberOfLines={1}>
                  {xp > 0 ? t('Don’t lose your {n} XP', { n: xp }) : t('Save your progress')}
                </Text>
                <Text style={styles.saveSub} numberOfLines={2}>{t('Free account · your streak on every device')}</Text>
              </View>
              <View style={styles.saveBtn}>
                <Text style={styles.saveBtnText}>{t('Save')}</Text>
              </View>
            </PopPressable>
          ) : (
            <Pressable onPress={() => router.push('/sign-in')} style={styles.signIn}>
              <Icon name="cloud_done" size={18} color={c.gold} />
              <Text style={styles.signInText}>{t('Sign in to keep your progress on every device')}</Text>
              <Icon name="chevron_right" size={18} color={c.gold} />
            </Pressable>
          )
        ) : null}

        {a3 ? (
          <>
            <View style={styles.secRow}>
              <Text style={[styles.section, { marginTop: 0, marginBottom: 0 }]}>{t('YOUR PROGRESS')}</Text>
              <Text style={styles.seeAllText}>{t('This week')}</Text>
            </View>
            <View style={styles.weekCard}>
              <View style={styles.weekIcon}>
                <Icon name="bar_chart" size={22} color="#6b7cf6" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.weekTitle}>{t('{n}/7 days', { n: weekDays })}</Text>
                <Text style={styles.weekSub} numberOfLines={2}>{weekDays >= 5 ? t('Amazing week!') : t('Keep going this week!')}</Text>
              </View>
              <View style={styles.weekDots}>
                {week.map((d, i) => (
                  <View key={i} style={styles.weekDay}>
                    <View style={[styles.weekDot, d.on && styles.weekDotOn, d.today && !d.on && styles.weekDotToday]}>
                      {d.on ? <Icon name="check" size={13} color="#ffffff" /> : null}
                    </View>
                    <Text style={styles.weekLbl}>{d.label}</Text>
                  </View>
                ))}
              </View>
            </View>
          </>
        ) : null}
      </ScrollView>
      <EmailAskSheet
        visible={askEmail && !welcome && !welcomeHold}
        onAnswer={(yes) => {
          setAskEmail(false);
          if (userId) void answerEmailAsk(userId, yes);
        }}
      />
      <GoalPickerSheet visible={picking} goal={goal} onPick={chooseGoal} onClose={() => setPicking(false)} />
      <WelcomeBackSheet
        visible={welcome}
        onClose={() => setWelcome(false)}
        onContinue={() => {
          setWelcome(false);
          openNext();
        }}
        words={totals.words}
        starFrom={starAt}
        next={
          target && next
            ? {
                kicker: `${target.id} · ${ct(target.title)}`,
                title: unitComplete ? t('Unit complete') : ct(next.title),
                icon: next.icon ?? 'play_arrow',
                locked: !allowed,
              }
            : undefined
        }
      />
    </SafeAreaView>
  );
}

function GoalRing({ value, done, a3, small }: { value: number; done: boolean; a3?: boolean; small?: boolean }) {
  const size = small ? 58 : 112;
  const stroke = small ? 6 : 9;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const pct = Math.max(0, Math.min(1, value));
  return (
    <Svg width={size} height={size} style={{ transform: [{ rotate: '-90deg' }] }}>
      <Defs>
        <SvgGradient id="goal" x1="0" y1="0" x2="1" y2="1">
          <Stop offset="0" stopColor={a3 ? '#E5AD3B' : done ? '#7fe0a4' : '#FFD84A'} />
          <Stop offset="1" stopColor={a3 ? A3.gold : done ? '#3fae6c' : '#D6B25A'} />
        </SvgGradient>
      </Defs>
      <Circle cx={size / 2} cy={size / 2} r={r} stroke={a3 ? A3.track : 'rgba(255,255,255,0.1)'} strokeWidth={stroke} fill="none" />
      {true ? (
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke="url(#goal)"
          strokeWidth={stroke}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={`${c} ${c}`}
          strokeDashoffset={c * (1 - Math.max(pct, 0.004))}
        />
      ) : null}
    </Svg>
  );
}

function Stat({ icon, color, value, label }: { icon: string; color: string; value: string; label: string }) {
  const styles = useStyles();
  return (
    <View style={styles.stat}>
      <View style={styles.statTop}>
        <Icon name={icon} size={16} color={color} />
        <Text style={styles.statVal}>{value}</Text>
      </View>
      <Text style={styles.statLbl}>{label}</Text>
    </View>
  );
}

const TONES = {
  sun: { bg: '#ffffff', icon: '#D78B29', iconBg: '#FFF4DC', edge: '#F7E2B8', title: '#15213B', go: '#FFF4DC' },
  sky: { bg: '#ffffff', icon: '#477BDC', iconBg: '#EEF4FF', edge: '#D8E4FB', title: '#15213B', go: '#EEF4FF' },
  mint: { bg: '#ffffff', icon: '#348967', iconBg: '#ECF8F1', edge: '#CFEBDB', title: '#15213B', go: '#ECF8F1' },
};

function Tile({ icon, title, sub, onPress, tone = 'sun' }: { icon: string; title: string; sub: string; onPress: () => void; tone?: keyof typeof TONES }) {
  const styles = useStyles();
  const k = TONES[tone];
  return (
    <View style={styles.tileCol}>
      <PopPressable onPress={onPress} style={[styles.tile, { backgroundColor: k.bg }]}>
        <View style={[styles.tileIcon, { backgroundColor: k.iconBg, borderWidth: 1, borderColor: k.edge }]}>
          <Icon name={icon} size={22} color={k.icon} />
        </View>
        <Text style={[styles.tileTitle, { color: k.title }]} numberOfLines={2}>{title}</Text>
        <Text style={styles.tileSub} numberOfLines={3}>{sub}</Text>
        <View style={[styles.tileGo, { backgroundColor: k.go }]}>
          <Icon name="arrow_forward" size={16} color={k.icon} />
        </View>
      </PopPressable>
    </View>
  );
}

function Row({ icon, title, sub, onPress }: { icon: string; title: string; sub: string; onPress: () => void }) {
  const { c } = useTheme();
  const styles = useStyles();
  return (
    <PopPressable onPress={onPress} style={styles.row}>
      <CardFill radius={18} />
      <View style={styles.rowIcon}>
        <Icon name={icon} size={21} color={c.gold} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.rowTitle}>{title}</Text>
        <Text style={styles.rowSub} numberOfLines={1}>
          {sub}
        </Text>
      </View>
      <Icon name="chevron_right" size={20} color={c.gold} />
    </PopPressable>
  );
}

const useStyles = makeStyles((c) => {
  const a3 = c.scheme !== 'light';
  return {
  screen: { flex: 1, backgroundColor: c.bg },
  content: { paddingHorizontal: Spacing.lg, paddingTop: 10, paddingBottom: 36 , ...contentCap },

  head: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 14 },
  date: { fontFamily: Fonts.body, fontSize: 13, color: c.muted },
  hello: a3 ? { fontFamily: Fonts.bodyBold, fontSize: 23, lineHeight: 29, flexShrink: 1, color: '#ffffff', marginTop: 2 } : { fontFamily: Fonts.display, fontSize: 22, lineHeight: 28, color: c.text, marginTop: 2 },
  streakPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 12,
    height: 36,
    borderRadius: 18,
    backgroundColor: a3 ? 'rgba(255,255,255,0.10)' : 'rgba(240,149,90,0.12)',
    borderWidth: 1,
    borderColor: a3 ? 'rgba(233,196,106,0.45)' : 'rgba(240,149,90,0.3)',
  },
  streakNum: { fontFamily: Fonts.bodyBold, fontSize: 15, color: c.text },

  goalCard: {
    borderRadius: 26,
    borderWidth: 1,
    borderColor: a3 ? A3.border : 'rgba(214,178,90,0.28)',
    borderTopColor: a3 ? A3.border : 'rgba(214,178,90,0.28)',
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 16,
    overflow: 'hidden',
  },
  goalTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  eyebrow: { fontFamily: Fonts.bodyBold, fontSize: 10.5, letterSpacing: 2.2, color: a3 ? A3.label : c.gold },
  goalEdit: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    paddingLeft: 10,
    paddingRight: 6,
    height: 28,
    borderRadius: 14,
    backgroundColor: a3 ? A3.chip : ON_NAVY_RAISED,
  },
  goalEditText: { fontFamily: Fonts.bodySemi, fontSize: 12, color: a3 ? A3.ink : c.onNavy },
  goalBody: { flexDirection: 'row', alignItems: 'center', gap: 18, marginTop: 12 },
  goalSide: { flex: 1 },
  ringWrap: { width: 112, height: 112 },
  ringMid: { ...StyleSheet.absoluteFill, alignItems: 'center', justifyContent: 'center' },
  ringNum: { fontFamily: Fonts.bodyBold, fontSize: 32, color: a3 ? A3.ink : c.onNavy, lineHeight: 36 },
  ringOf: { fontFamily: Fonts.bodySemi, fontSize: 18, color: a3 ? A3.muted : c.onNavyMuted },
  ringLbl: { fontFamily: Fonts.bodySemi, fontSize: 12, color: a3 ? A3.muted : c.onNavyMuted, marginTop: 2 },
  goalMsg: { fontFamily: Fonts.bodyMedium, fontSize: 14, color: a3 ? A3.ink : c.onNavy },
  stats: { marginTop: 10, gap: 7 },
  stat: { flexDirection: 'row', alignItems: 'center' },
  statTop: { flexDirection: 'row', alignItems: 'center', gap: 6, width: 54 },
  statVal: { fontFamily: Fonts.bodyBold, fontSize: 15, color: a3 ? A3.ink : c.onNavy },
  statLbl: { fontFamily: Fonts.body, fontSize: 12.5, color: a3 ? A3.muted : c.onNavyMuted },

  section: { fontFamily: Fonts.bodyBold, fontSize: 10.5, letterSpacing: 2.2, color: c.muted, marginTop: 20, marginBottom: 8 },

  // Up next is the current part: space card with the gold "current" ring.
  nextCard: a3
    ? { backgroundColor: A3.card, borderWidth: 1, borderColor: A3.border, borderRadius: 20, padding: 16 }
    : {
        ...spaceCard(c),
        ...currentCard(c),
        borderRadius: 22,
        padding: 16,
      },
  nextRow: { flexDirection: 'row', alignItems: 'center', gap: 13 },
  nextIcon: {
    width: 50,
    height: 50,
    borderRadius: 15,
    backgroundColor: c.goldTint,
    alignItems: 'center',
    justifyContent: 'center',
  },
  nextUnit: { fontFamily: a3 ? Fonts.bodySemi : Fonts.body, fontSize: a3 ? 12.5 : 11.5, color: a3 ? A3.muted : c.muted },
  nextTitle: { fontFamily: Fonts.bodyBold, fontSize: a3 ? 18 : 17.5, lineHeight: a3 ? 23 : undefined, color: a3 ? A3.ink : c.text, marginTop: a3 ? 4 : 2 },
  nextMeta: { fontFamily: a3 ? Fonts.bodySemi : Fonts.body, fontSize: 12.5, color: a3 ? A3.meta : c.gold, marginTop: a3 ? 6 : 2 },
  go: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: c.btnBg, borderWidth: 1.2, borderColor: c.btnBorder,
    alignItems: 'center',
    justifyContent: 'center',
  },
  segs: { flexDirection: 'row', marginTop: 12 },
  seg: { flex: 1, height: 5, borderRadius: 3, marginLeft: 4, backgroundColor: a3 ? A3.track : c.track },
  segText: { fontFamily: Fonts.body, fontSize: 11.5, color: a3 ? A3.muted : c.muted, marginTop: 8 },

  row: {
    ...spaceCard(c),
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    borderRadius: 18,
    padding: 14,
    marginBottom: 10,
  },
  rowIcon: {
    width: 42,
    height: 42,
    borderRadius: 13,
    backgroundColor: c.goldTint,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rowTitle: { fontFamily: Fonts.bodyBold, fontSize: 15, color: c.text },
  rowSub: { fontFamily: Fonts.body, fontSize: 12, color: c.muted, marginTop: 2 },

  nextTopA: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 },
  nextLblA: { flexShrink: 1, fontFamily: Fonts.bodyBold, fontSize: 11.5, letterSpacing: 1.2, textTransform: 'uppercase', color: '#B98522', backgroundColor: '#FFF4DC', borderWidth: 1, borderColor: '#F3E3BD', borderRadius: 999, paddingHorizontal: 11, paddingVertical: 4, overflow: 'hidden' },
  nextChipA: { fontFamily: Fonts.bodyBold, fontSize: 12, color: '#65718A', backgroundColor: '#F1F3F7', borderRadius: 999, paddingHorizontal: 10, paddingVertical: 4, overflow: 'hidden' },
  nextArA: { fontFamily: Fonts.arabic, fontSize: 34, lineHeight: 58, color: A3.ink, textAlign: 'right', writingDirection: 'rtl', marginTop: 4 },
  goalRowA: { flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: A3.card, borderWidth: 1, borderColor: A3.border, borderRadius: 20, paddingVertical: 12, paddingHorizontal: 14, marginTop: 12 },
  goalRowRing: { width: 58, height: 58 },
  goalRowNum: { fontFamily: Fonts.bodyBold, fontSize: 18, lineHeight: 20, color: A3.ink },
  goalRowMin: { fontFamily: Fonts.body, fontSize: 10, color: A3.muted },
  goalRowTitle: { fontFamily: Fonts.bodyBold, fontSize: 14.5, color: A3.ink },
  goalRowSub: { fontFamily: Fonts.body, fontSize: 12.5, color: A3.muted, marginTop: 2 },
  tiles: { flexDirection: 'row', gap: 10 },
  helloRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  helloSub: { fontFamily: Fonts.body, fontSize: 14.5, color: '#AEBBD5', marginTop: 2 },
  avatar: { width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.10)', borderWidth: 1, borderColor: '#344363', alignItems: 'center', justifyContent: 'center' },
  nextMidA: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 6 },
  nextMetaA: { fontFamily: Fonts.bodySemi, fontSize: 14, color: A3.muted, marginTop: 2 },
  nextFootA: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 14 },
  modIconA: { width: 42, height: 42, borderRadius: 12, backgroundColor: '#F1F6FF', alignItems: 'center', justifyContent: 'center' },
  modTitleA: { fontFamily: Fonts.bodyBold, fontSize: 13.5, color: A3.ink },
  modSubA: { fontFamily: Fonts.body, fontSize: 12.5, color: A3.muted },
  goA: { height: 46, paddingHorizontal: 18, borderRadius: 14, backgroundColor: '#182A60', flexDirection: 'row', alignItems: 'center', gap: 6 },
  goAText: { fontFamily: Fonts.bodyBold, fontSize: 15.5, color: '#ffffff' },
  secRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 22, marginBottom: 10 },
  seeAll: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  seeAllText: { fontFamily: Fonts.bodyBold, fontSize: 14, color: '#8FB4FF' },
  weekCard: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: A3.card, borderWidth: 1, borderColor: A3.border, borderRadius: 20, paddingVertical: 12, paddingHorizontal: 12 },
  weekIcon: { width: 42, height: 42, borderRadius: 12, backgroundColor: '#eef0ff', alignItems: 'center', justifyContent: 'center' },
  weekTitle: { fontFamily: Fonts.bodyBold, fontSize: 16, color: A3.ink },
  weekSub: { fontFamily: Fonts.body, fontSize: 12.5, color: A3.muted, marginTop: 1 },
  weekDots: { flexDirection: 'row', gap: 3 },
  weekDay: { alignItems: 'center', gap: 3 },
  weekDot: { width: 18, height: 18, borderRadius: 9, backgroundColor: '#E7EAF0', alignItems: 'center', justifyContent: 'center' },
  weekDotOn: { backgroundColor: '#477BDC' },
  weekDotToday: { borderWidth: 2, borderColor: '#477BDC', backgroundColor: '#ffffff' },
  weekLbl: { fontFamily: Fonts.bodySemi, fontSize: 11, color: A3.muted },
  tileCol: { flex: 1, minWidth: 0 },
  tile: { flex: 1, height: 188, borderRadius: 20, padding: 12, paddingBottom: 50, borderWidth: 1, borderColor: '#E7EAF0' },
  tileIcon: { width: 42, height: 42, borderRadius: 13, backgroundColor: A3.chip, alignItems: 'center', justifyContent: 'center', marginBottom: 12 },
  tileTitle: { minHeight: 38, fontFamily: Fonts.bodyBold, fontSize: 15, lineHeight: 19, color: A3.ink },
  tileSub: { minHeight: 51, fontFamily: Fonts.body, fontSize: 12.5, lineHeight: 17, color: A3.muted, marginTop: 3, marginBottom: 12 },
  tileGo: { position: 'absolute', left: 12, bottom: 12, width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  saveCard: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: '#ffffff', borderWidth: 1, borderColor: '#E7EAF0', borderRadius: 20, paddingVertical: 14, paddingHorizontal: 14, marginTop: 14 },
  saveIcon: { width: 44, height: 44, borderRadius: 12, backgroundColor: '#FFF4DC', borderWidth: 1, borderColor: '#F7E2B8', alignItems: 'center', justifyContent: 'center' },
  saveTitle: { fontFamily: Fonts.bodyBold, fontSize: 15, color: '#15213B' },
  saveSub: { fontFamily: Fonts.body, fontSize: 12.5, color: '#65718A', marginTop: 1 },
  saveBtn: { backgroundColor: '#182A60', borderRadius: 12, paddingHorizontal: 18, paddingVertical: 10 },
  saveBtnText: { fontFamily: Fonts.bodyBold, fontSize: 14, color: '#ffffff' },
  signInA3: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7, marginTop: 18, paddingVertical: 6 },
  signInA3Text: { fontFamily: Fonts.bodySemi, fontSize: 13, color: A3.btnText },
  signIn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginTop: 14,
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(214,178,90,0.35)',
    borderStyle: 'dashed',
  },
  signInText: { flex: 1, fontFamily: Fonts.bodyMedium, fontSize: 13, color: c.text },
  goWide: {
    marginTop: 12,
    height: 44,
    borderRadius: 14,
    backgroundColor: A3.btn,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  goWideText: { fontFamily: Fonts.bodyBold, fontSize: 15.5, color: A3.btnText, letterSpacing: 0.3 },
  };
});
