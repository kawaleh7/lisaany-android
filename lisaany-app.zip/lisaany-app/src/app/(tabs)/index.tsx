import { LinearGradient } from 'expo-linear-gradient';
import { useFocusEffect, useRouter } from 'expo-router';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Svg, { Circle, Defs, LinearGradient as SvgGradient, Stop } from 'react-native-svg';

import { GoalPickerSheet } from '@/components/goal-controls';
import { Icon } from '@/components/icon';
import { PopPressable, usePop } from '@/components/pop-card';
import { SpaceBackdrop } from '@/components/space-backdrop';
import { markGreeted, StarSlot, StarTalk, useStarGuide } from '@/components/star-guide';
import { CardFill, currentCard, spaceCard } from '@/components/ui';
import { WelcomeBackSheet, WELCOME_FLY_AT, type StarPoint } from '@/components/welcome-back-sheet';
import { Fonts, Spacing } from '@/constants/lisaany';
import { useAuth } from '@/lib/auth-context';
import { blockSizeLabel, getModuleForUnit, getUnit, MODULES, TOTAL_BLOCKS, type Block } from '@/lib/curriculum';
import { useLang } from '@/lib/i18n';
import { getHasSeenLanding } from '@/lib/onboarding';
import { canAccessUnit } from '@/lib/plan';
import {
  completedFromProg,
  countLearned,
  getEngineProgress,
  getLastUnit,
  getLearnedToday,
  getTodayXp,
  nextBlockFor,
  setLastUnit,
  type CompletedMap,
  type LastUnit,
} from '@/lib/progress';
import { makeStyles, useTheme } from '@/theme';
import { onWelcomeBack, takeWelcomeBack } from '@/lib/welcome-back';
import { reportXp } from '@/lib/circles';
import { DEFAULT_MIN_GOAL, getMinGoal, getTodaySecs } from '@/lib/goal';
import { changeMinGoal } from '@/lib/goal-sync';
import { noteWordTotal } from '@/lib/word-pace';

// The daily-goal hero stays navy in both themes; these sit on it.
const ON_NAVY_LINE = 'rgba(255,255,255,0.10)';
const ON_NAVY_RAISED = 'rgba(255,255,255,0.06)';
const ON_NAVY_GREEN = '#5fd08a';

const TYPE_LABEL: Record<string, string> = {
  dialogue: 'Conversation', vocab: 'Vocabulary', grammar: 'Grammar', cloze: 'Listening dictation',
  clutter: 'Sentence builder', quiz: 'Practice drill', fill: 'Listen & choose', seqquiz: 'Quiz',
  possessive: 'Suffix tap', swipe: 'Swipe cards', conjugation: 'Conjugation', video: 'Video', choose: 'Choose',
};

function greeting(d = new Date()) {
  const h = d.getHours();
  if (h < 5) return 'Good night';
  if (h < 12) return 'Good morning';
  if (h < 18) return 'Good afternoon';
  return 'Good evening';
}

function dateLine(locale: string, d = new Date()) {
  return d.toLocaleDateString(locale, { weekday: 'long', day: 'numeric', month: 'long' });
}

/** Block size ("10 lines") in English; keys for t(). */
const SIZE_KEYS: Record<string, [string, string]> = {
  lines: ['1 line', '{n} lines'],
  words: ['1 word', '{n} words'],
  examples: ['1 example', '{n} examples'],
  sentences: ['1 sentence', '{n} sentences'],
  questions: ['1 question', '{n} questions'],
  items: ['1 item', '{n} items'],
};

export default function TodayScreen() {
  const pop = usePop();
  const { c } = useTheme();
  const styles = useStyles();
  const router = useRouter();
  const { session } = useAuth();
  const { t, ct, locale } = useLang();

  const sizeText = (b: Block) => {
    const keys = b.size ? SIZE_KEYS[b.size.unit] : undefined;
    if (!b.size || !keys) return blockSizeLabel(b);
    return b.size.count === 1 ? t(keys[0]) : t(keys[1], { n: b.size.count });
  };

  const [lastUnit, setLast] = useState<LastUnit | null>(null);
  const [streak, setStreak] = useState(0);
  const [xp, setXp] = useState(0);
  /** Daily goal in minutes, and active seconds learned today. */
  const [goal, setGoal] = useState(DEFAULT_MIN_GOAL);
  const [daySecs, setDaySecs] = useState(0);
  const [picking, setPicking] = useState(false);
  const [completed, setCompleted] = useState<CompletedMap>({});
  const [allowed, setAllowed] = useState(true);
  const [welcome, setWelcome] = useState(false);
  // Where the star rests in the header, so the sheet can fly it in and back.
  const starRef = useRef<View>(null);
  const [starAt, setStarAt] = useState<StarPoint | null>(null);
  const measureStar = useCallback(() => {
    starRef.current?.measureInWindow((x, y, w, h) => {
      if (w > 0) setStarAt({ x: x + w / 2, y: y + h / 2, size: w });
    });
  }, []);
  // The header keeps its star until the sheet's star is actually in the air,
  // so the gold star is never missing from the screen.
  const [starAway, setStarAway] = useState(false);
  useEffect(() => {
    if (!welcome) {
      setStarAway(false);
      return;
    }
    const id = setTimeout(() => setStarAway(true), Math.max(0, WELCOME_FLY_AT - 40));
    return () => clearTimeout(id);
  }, [welcome]);
  // A welcome-back is on its way (sheet about to open): hold the star's greeting.
  const [welcomeHold, setWelcomeHold] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [reload, setReload] = useState(0);

  // Cold start only: a fresh install goes to the landing screen once.
  useEffect(() => {
    getHasSeenLanding().then((seen) => {
      if (!seen) router.replace('/landing');
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useFocusEffect(
    useCallback(() => {
      let active = true;
      Promise.all([getLastUnit(), getEngineProgress(), getMinGoal(), getTodaySecs()]).then(async ([last, snap, g, secs]) => {
        await getTodayXp(snap.xp); // keeps the weekly XP history current
        reportXp(); // keeps circle boards fresh (signed-in only)
        // Keeps today's learned baseline current (used by the lesson celebration).
        await getLearnedToday(completedFromProg(snap.prog));
        const unitId = last?.unitId ?? MODULES[0]?.units[0]?.id;
        const ok = unitId ? await canAccessUnit(unitId) : true;
        if (!active) return;
        setLast(last);
        setStreak(snap.streak);
        setXp(snap.xp);
        setGoal(g);
        setDaySecs(secs);
        setCompleted(completedFromProg(snap.prog));
        setAllowed(ok);
        setLoaded(true);
      });
      return () => {
        active = false;
      };
    }, [reload])
  );

  // Back after a long break: refresh the numbers and slide up the welcome sheet.
  useFocusEffect(
    useCallback(() => {
      const show = () => {
        if (!takeWelcomeBack()) return;
        // The sheet already says how today is going, so the star skips its greeting.
        markGreeted('today');
        setWelcomeHold(true);
        getHasSeenLanding().then((seen) => {
          setWelcomeHold(false);
          if (!seen) return;
          setReload((n) => n + 1);
          measureStar();
          // Both kinds ('newday' and 'return') show the same sheet.
          setWelcome(true);
        });
      };
      show();
      return onWelcomeBack(show);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
  );

  const totals = useMemo(() => countLearned(completed), [completed]);
  useEffect(() => {
    if (loaded) noteWordTotal(totals.words);
  }, [loaded, totals.words]);

  const doneCount = Object.keys(completed).length;
  const coursePct = Math.round((doneCount / Math.max(1, TOTAL_BLOCKS)) * 100);
  const resumeUnit = lastUnit ? getUnit(lastUnit.unitId) : undefined;
  const target = resumeUnit ?? MODULES[0]?.units[0];
  const targetModule = target ? getModuleForUnit(target.id) : undefined;
  const targetDone = target ? target.blocks.filter((b) => completed[`${target.id}:${b.id}`]).length : 0;
  const unitComplete = !!target && targetDone >= target.blocks.length;
  const nextId = target ? nextBlockFor(target, completed) : undefined;
  const next = target ? target.blocks.find((b) => b.id === nextId) ?? target.blocks[0] : undefined;

  // Minutes goal: whole minutes shown, the goal counts to the second.
  const goalSecs = goal * 60;
  const mins = Math.floor(daySecs / 60);
  const goalPct = Math.min(1, daySecs / Math.max(1, goalSecs));
  const reached = daySecs >= goalSecs;
  const left = Math.max(1, Math.ceil((goalSecs - daySecs) / 60));

  // The star: greets once per app session with today's progress, then tips on tap.
  const tips = useMemo(() => {
    const list = [t('Tap Continue to jump straight into your next part.')];
    if (streak >= 2) list.push(t('{n} days in a row — keep your streak going!', { n: streak }));
    list.push(t('Daily review brings back words from parts you’ve finished.'));
    list.push(t('Tap the ring to change your daily goal.'));
    return list;
  }, [t, streak]);
  const greet =
    !loaded || welcome || welcomeHold
      ? null
      : reached
        ? t('Welcome back! {m} minutes of Arabic today — keep it going!', { m: mins })
        : mins === 0
          ? t('Welcome! Your {goal} minutes of Arabic start with one part.', { goal })
          : t('Welcome back! {m} min done today — {left} more to reach your goal.', { m: mins, left });
  const guide = useStarGuide(tips, { greet, greetKey: 'today', delay: 800 });

  const openNext = () => {
    if (!target) return;
    if (!allowed) {
      router.push(session ? { pathname: '/unit/[id]', params: { id: target.id } } : '/sign-in');
      return;
    }
    if (unitComplete) {
      router.push({ pathname: '/unit/[id]', params: { id: target.id } });
      return;
    }
    setLastUnit(target.id);
    router.push({ pathname: '/lesson/[unit]', params: { unit: target.id, block: String(next?.id ?? '') } });
  };

  // Tapping the card opens the lesson page (continue, start over, replay a part);
  // the gold arrow jumps straight into the next part.
  const openLessonPage = () => {
    if (!target) return;
    router.push({ pathname: '/unit/[id]', params: { id: target.id } });
  };

  const pickGoal = () => setPicking(true);
  const chooseGoal = (g: number) => {
    setPicking(false);
    setGoal(g);
    changeMinGoal(g);
    guide.say(
      daySecs >= g * 60
        ? t('Your goal is now {g} minutes. Great work today — keep going!', { g })
        : t('Your goal is now {g} minutes. You can do it!', { g })
    );
  };

  return (
    <SafeAreaView style={styles.screen} edges={['top', 'left', 'right']}>
      <SpaceBackdrop />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.head}>
          <View style={{ flex: 1 }}>
            <Text style={styles.date}>{dateLine(locale)}</Text>
            <Text style={styles.hello}>{t(greeting())}</Text>
          </View>
          <View ref={starRef} collapsable={false} onLayout={measureStar} style={{ opacity: starAway ? 0 : 1 }}>
            <StarSlot guide={guide} />
          </View>
          <View style={styles.streakPill}>
            <Icon name="local_fire_department" size={17} color={c.orange} />
            <Text style={styles.streakNum}>{streak}</Text>
          </View>
        </View>
        <StarTalk guide={guide} />

        {/* Daily goal */}
        <LinearGradient colors={c.navyGrad} start={{ x: 0.2, y: 0 }} end={{ x: 0.8, y: 1 }} style={[pop.rest, styles.goalCard]}>
          <View style={styles.goalTop}>
            <Text style={styles.eyebrow}>{t('DAILY GOAL')}</Text>
            <Pressable onPress={pickGoal} hitSlop={10} style={styles.goalEdit}>
              <Text style={styles.goalEditText}>{t('{n} min', { n: goal })}</Text>
              <Icon name="expand_more" size={16} color={c.onNavyMuted} />
            </Pressable>
          </View>

          <Pressable
            onPress={pickGoal}
            style={styles.ringWrap}
            accessibilityRole="button"
            accessibilityLabel={t('{m} of {g} min', { m: mins, g: goal })}>
            <GoalRing value={goalPct} done={false} />
            <View style={styles.ringMid}>
              <Text style={styles.ringNum}>{mins}</Text>
              <Text style={styles.ringLbl}>{t('of {g} min', { g: goal })}</Text>
            </View>
          </Pressable>

          <Text style={styles.goalMsg}>
            {reached ? t('Great work today — keep going!') : t('{n} min to go today', { n: left })}
          </Text>

          <View style={styles.stats}>
            <Stat icon="local_fire_department" color={c.orange} value={String(streak)} label={streak === 1 ? t('day streak') : t('days streak')} />
            <View style={styles.statRule} />
            <Stat icon="bolt" color={c.gold} value={String(xp)} label={t('total XP')} />
            <View style={styles.statRule} />
            <Stat icon="auto_stories" color={c.gold} value={`${coursePct}%`} label={t('of course')} />
          </View>
        </LinearGradient>

        {/* Up next */}
        {target && next ? (
          <>
            <Text style={styles.section}>{doneCount ? t('UP NEXT') : t('START HERE')}</Text>
            <PopPressable onPress={openLessonPage} style={styles.nextCard}>
              <CardFill radius={22} />
              <View style={styles.nextRow}>
                <View style={styles.nextIcon}>
                  <Icon name={next.icon ?? 'play_arrow'} size={23} color={c.gold} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.nextUnit} numberOfLines={1}>
                    {target.id} · {ct(target.title)}
                  </Text>
                  <Text style={styles.nextTitle} numberOfLines={1}>
                    {unitComplete ? t('Unit complete') : ct(next.title)}
                  </Text>
                  <Text style={styles.nextMeta} numberOfLines={1}>
                    {unitComplete
                      ? t('Tap to replay any part')
                      : [t(TYPE_LABEL[next.type] ?? 'Lesson'), sizeText(next)].filter(Boolean).join(' · ')}
                  </Text>
                </View>
                <Pressable onPress={openNext} hitSlop={10} style={styles.go} accessibilityLabel={t('Continue lesson')}>
                  <Icon name={allowed ? 'arrow_forward' : 'lock'} size={20} color={c.btnText} />
                </Pressable>
              </View>
              <View style={styles.segs}>
                {target.blocks.map((b, i) => {
                  const isDone = !!completed[`${target.id}:${b.id}`];
                  const isCur = !unitComplete && b.id === next.id;
                  return (
                    <View
                      key={b.id}
                      style={[styles.seg, isDone && { backgroundColor: c.goldFill }, isCur && { backgroundColor: 'rgba(214,178,90,0.45)' }, i === 0 && { marginLeft: 0 }]}
                    />
                  );
                })}
              </View>
              <Text style={styles.segText}>
                {t('{n} of {total} parts', { n: targetDone, total: target.blocks.length })}
                {targetModule ? ` · ${ct(targetModule.title)}` : ''}
              </Text>
            </PopPressable>
          </>
        ) : null}

        {/* Practice */}
        <Text style={styles.section}>{t('PRACTICE')}</Text>
        <Row
          icon="autorenew"
          title={t('Daily review')}
          sub={t('Words from your finished blocks')}
          onPress={() => router.push({ pathname: '/lesson/[unit]', params: { unit: 'srsreview' } })}
        />
        <Row
          icon="style"
          title={t('Review session')}
          sub={t('Pick a lesson and a drill')}
          onPress={() => router.push({ pathname: '/lesson/[unit]', params: { unit: 'reviewBuilder' } })}
        />

        {!session ? (
          <Pressable onPress={() => router.push('/sign-in')} style={styles.signIn}>
            <Icon name="cloud_done" size={18} color={c.gold} />
            <Text style={styles.signInText}>{t('Sign in to keep your progress on every device')}</Text>
            <Icon name="chevron_right" size={18} color={c.gold} />
          </Pressable>
        ) : null}
      </ScrollView>
      <GoalPickerSheet visible={picking} goal={goal} onPick={chooseGoal} onClose={() => setPicking(false)} />
      <WelcomeBackSheet
        visible={welcome}
        onClose={() => setWelcome(false)}
        onContinue={() => {
          setWelcome(false);
          openNext();
        }}
        words={totals.words}
        starFrom={starAt}
        next={
          target && next
            ? {
                kicker: `${target.id} · ${ct(target.title)}`,
                title: unitComplete ? t('Unit complete') : ct(next.title),
                icon: next.icon ?? 'play_arrow',
                locked: !allowed,
              }
            : undefined
        }
      />
    </SafeAreaView>
  );
}

function GoalRing({ value, done }: { value: number; done: boolean }) {
  const size = 184;
  const stroke = 11;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const pct = Math.max(0, Math.min(1, value));
  return (
    <Svg width={size} height={size} style={{ transform: [{ rotate: '-90deg' }] }}>
      <Defs>
        <SvgGradient id="goal" x1="0" y1="0" x2="1" y2="1">
          <Stop offset="0" stopColor={done ? '#7fe0a4' : '#FFD84A'} />
          <Stop offset="1" stopColor={done ? '#3fae6c' : '#D6B25A'} />
        </SvgGradient>
      </Defs>
      <Circle cx={size / 2} cy={size / 2} r={r} stroke="rgba(255,255,255,0.1)" strokeWidth={stroke} fill="none" />
      {true ? (
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke="url(#goal)"
          strokeWidth={stroke}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={`${c} ${c}`}
          strokeDashoffset={c * (1 - Math.max(pct, 0.004))}
        />
      ) : null}
    </Svg>
  );
}

function Stat({ icon, color, value, label }: { icon: string; color: string; value: string; label: string }) {
  const styles = useStyles();
  return (
    <View style={styles.stat}>
      <View style={styles.statTop}>
        <Icon name={icon} size={16} color={color} />
        <Text style={styles.statVal}>{value}</Text>
      </View>
      <Text style={styles.statLbl}>{label}</Text>
    </View>
  );
}

function Row({ icon, title, sub, onPress }: { icon: string; title: string; sub: string; onPress: () => void }) {
  const { c } = useTheme();
  const styles = useStyles();
  return (
    <PopPressable onPress={onPress} style={styles.row}>
      <CardFill radius={18} />
      <View style={styles.rowIcon}>
        <Icon name={icon} size={21} color={c.gold} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.rowTitle}>{title}</Text>
        <Text style={styles.rowSub} numberOfLines={1}>
          {sub}
        </Text>
      </View>
      <Icon name="chevron_right" size={20} color={c.gold} />
    </PopPressable>
  );
}

const useStyles = makeStyles((c) => ({
  screen: { flex: 1, backgroundColor: c.bg },
  content: { paddingHorizontal: Spacing.lg, paddingTop: 10, paddingBottom: 36 },

  head: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 14 },
  date: { fontFamily: Fonts.body, fontSize: 13, color: c.muted },
  hello: { fontFamily: Fonts.display, fontSize: 26, lineHeight: 32, color: c.text, marginTop: 2 },
  streakPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 12,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(240,149,90,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(240,149,90,0.3)',
  },
  streakNum: { fontFamily: Fonts.bodyBold, fontSize: 15, color: c.text },

  goalCard: {
    borderRadius: 26,
    borderWidth: 1,
    borderColor: c.scheme === 'dark' ? c.line : 'rgba(214,178,90,0.28)',
    borderTopColor: c.scheme === 'dark' ? c.line : 'rgba(214,178,90,0.28)',
    paddingHorizontal: 20,
    paddingTop: 18,
    paddingBottom: 18,
    overflow: 'hidden',
  },
  goalTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  eyebrow: { fontFamily: Fonts.bodyBold, fontSize: 10.5, letterSpacing: 2.2, color: c.gold },
  goalEdit: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    paddingLeft: 10,
    paddingRight: 6,
    height: 28,
    borderRadius: 14,
    backgroundColor: ON_NAVY_RAISED,
  },
  goalEditText: { fontFamily: Fonts.bodySemi, fontSize: 12, color: c.onNavy },
  ringWrap: { alignSelf: 'center', marginTop: 14, width: 184, height: 184 },
  ringMid: { ...StyleSheet.absoluteFill, alignItems: 'center', justifyContent: 'center' },
  ringNum: { fontFamily: Fonts.bodyBold, fontSize: 46, color: c.onNavy, lineHeight: 52 },
  ringOf: { fontFamily: Fonts.bodySemi, fontSize: 18, color: c.onNavyMuted },
  ringLbl: { fontFamily: Fonts.bodySemi, fontSize: 13, color: c.onNavyMuted, marginTop: 2 },
  goalMsg: { fontFamily: Fonts.bodyMedium, fontSize: 13.5, color: c.onNavy, textAlign: 'center', marginTop: 14 },
  stats: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 18,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: ON_NAVY_LINE,
  },
  stat: { flex: 1, alignItems: 'center' },
  statTop: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  statVal: { fontFamily: Fonts.bodyBold, fontSize: 18, color: c.onNavy },
  statLbl: { fontFamily: Fonts.body, fontSize: 11.5, color: c.onNavyMuted, marginTop: 3 },
  statRule: { width: 1, height: 30, backgroundColor: ON_NAVY_LINE },

  section: { fontFamily: Fonts.bodyBold, fontSize: 10.5, letterSpacing: 2.2, color: c.muted, marginTop: 26, marginBottom: 10 },

  // Up next is the current part: space card with the gold "current" ring.
  nextCard: {
    ...spaceCard(c),
    ...currentCard(c),
    borderRadius: 22,
    padding: 16,
  },
  nextRow: { flexDirection: 'row', alignItems: 'center', gap: 13 },
  nextIcon: {
    width: 50,
    height: 50,
    borderRadius: 15,
    backgroundColor: c.goldTint,
    alignItems: 'center',
    justifyContent: 'center',
  },
  nextUnit: { fontFamily: Fonts.body, fontSize: 11.5, color: c.muted },
  nextTitle: { fontFamily: Fonts.bodyBold, fontSize: 17.5, color: c.text, marginTop: 2 },
  nextMeta: { fontFamily: Fonts.body, fontSize: 12.5, color: c.gold, marginTop: 2 },
  go: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: c.btnBg, borderWidth: 1.2, borderColor: c.btnBorder,
    alignItems: 'center',
    justifyContent: 'center',
  },
  segs: { flexDirection: 'row', marginTop: 16 },
  seg: { flex: 1, height: 5, borderRadius: 3, marginLeft: 4, backgroundColor: c.track },
  segText: { fontFamily: Fonts.body, fontSize: 11.5, color: c.muted, marginTop: 8 },

  row: {
    ...spaceCard(c),
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    borderRadius: 18,
    padding: 14,
    marginBottom: 10,
  },
  rowIcon: {
    width: 42,
    height: 42,
    borderRadius: 13,
    backgroundColor: c.goldTint,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rowTitle: { fontFamily: Fonts.bodyBold, fontSize: 15, color: c.text },
  rowSub: { fontFamily: Fonts.body, fontSize: 12, color: c.muted, marginTop: 2 },

  signIn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginTop: 14,
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(214,178,90,0.35)',
    borderStyle: 'dashed',
  },
  signInText: { flex: 1, fontFamily: Fonts.bodyMedium, fontSize: 13, color: c.text },
}));
