import { LinearGradient } from 'expo-linear-gradient';
import { useFocusEffect, useRouter } from 'expo-router';
import { useCallback, useEffect, useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Svg, { Circle, Defs, LinearGradient as SvgGradient, Stop } from 'react-native-svg';

import { Icon } from '@/components/icon';
import { PopPressable, usePop } from '@/components/pop-card';
import { Fonts, Spacing } from '@/constants/lisaany';
import { useAuth } from '@/lib/auth-context';
import { blockSizeLabel, getModuleForUnit, getUnit, MODULES, TOTAL_BLOCKS } from '@/lib/curriculum';
import { getHasSeenLanding } from '@/lib/onboarding';
import { canAccessUnit } from '@/lib/plan';
import {
  completedFromProg,
  getDailyGoal,
  getEngineProgress,
  getLastUnit,
  getTodayXp,
  nextBlockFor,
  setDailyGoal,
  setLastUnit,
  type CompletedMap,
  type LastUnit,
} from '@/lib/progress';
import { makeStyles, useTheme } from '@/theme';

// The daily-goal hero stays navy in both themes; these sit on it.
const ON_NAVY_LINE = 'rgba(255,255,255,0.10)';
const ON_NAVY_RAISED = 'rgba(255,255,255,0.06)';

const TYPE_LABEL: Record<string, string> = {
  dialogue: 'Conversation', vocab: 'Vocabulary', grammar: 'Grammar', cloze: 'Listening dictation',
  clutter: 'Sentence builder', quiz: 'Practice drill', fill: 'Listen & choose', seqquiz: 'Quiz',
  possessive: 'Suffix tap', swipe: 'Swipe cards', conjugation: 'Conjugation', video: 'Video', choose: 'Choose',
};

function greeting(d = new Date()) {
  const h = d.getHours();
  if (h < 5) return 'Good night';
  if (h < 12) return 'Good morning';
  if (h < 18) return 'Good afternoon';
  return 'Good evening';
}

function dateLine(d = new Date()) {
  return d.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' });
}

export default function TodayScreen() {
  const pop = usePop();
  const { c } = useTheme();
  const styles = useStyles();
  const router = useRouter();
  const { session } = useAuth();

  const [lastUnit, setLast] = useState<LastUnit | null>(null);
  const [streak, setStreak] = useState(0);
  const [xp, setXp] = useState(0);
  const [todayXp, setTodayXp] = useState(0);
  const [goal, setGoal] = useState(20);
  const [completed, setCompleted] = useState<CompletedMap>({});
  const [allowed, setAllowed] = useState(true);

  // Cold start only: a fresh install goes to the landing screen once.
  useEffect(() => {
    getHasSeenLanding().then((seen) => {
      if (!seen) router.replace('/landing');
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useFocusEffect(
    useCallback(() => {
      let active = true;
      Promise.all([getLastUnit(), getEngineProgress(), getDailyGoal()]).then(async ([last, snap, g]) => {
        const tXp = await getTodayXp(snap.xp);
        const unitId = last?.unitId ?? MODULES[0]?.units[0]?.id;
        const ok = unitId ? await canAccessUnit(unitId) : true;
        if (!active) return;
        setLast(last);
        setStreak(snap.streak);
        setXp(snap.xp);
        setTodayXp(tXp);
        setGoal(g);
        setCompleted(completedFromProg(snap.prog));
        setAllowed(ok);
      });
      return () => {
        active = false;
      };
    }, [])
  );

  const doneCount = Object.keys(completed).length;
  const coursePct = Math.round((doneCount / Math.max(1, TOTAL_BLOCKS)) * 100);
  const resumeUnit = lastUnit ? getUnit(lastUnit.unitId) : undefined;
  const target = resumeUnit ?? MODULES[0]?.units[0];
  const targetModule = target ? getModuleForUnit(target.id) : undefined;
  const targetDone = target ? target.blocks.filter((b) => completed[`${target.id}:${b.id}`]).length : 0;
  const unitComplete = !!target && targetDone >= target.blocks.length;
  const nextId = target ? nextBlockFor(target, completed) : undefined;
  const next = target ? target.blocks.find((b) => b.id === nextId) ?? target.blocks[0] : undefined;

  const goalPct = Math.min(1, todayXp / Math.max(1, goal));
  const reached = todayXp >= goal;
  const left = Math.max(0, goal - todayXp);

  const openNext = () => {
    if (!target) return;
    if (!allowed) {
      router.push(session ? { pathname: '/unit/[id]', params: { id: target.id } } : '/sign-in');
      return;
    }
    if (unitComplete) {
      router.push({ pathname: '/unit/[id]', params: { id: target.id } });
      return;
    }
    setLastUnit(target.id);
    router.push({ pathname: '/lesson/[unit]', params: { unit: target.id, block: String(next?.id ?? '') } });
  };

  // Tapping the card opens the lesson page (continue, start over, replay a part);
  // the gold arrow jumps straight into the next part.
  const openLessonPage = () => {
    if (!target) return;
    router.push({ pathname: '/unit/[id]', params: { id: target.id } });
  };

  const pickGoal = () => {
    const choose = (g: number) => {
      setGoal(g);
      setDailyGoal(g);
    };
    Alert.alert('Daily goal', 'How much XP do you want to earn each day?', [
      { text: 'Casual · 10 XP', onPress: () => choose(10) },
      { text: 'Regular · 20 XP', onPress: () => choose(20) },
      { text: 'Serious · 40 XP', onPress: () => choose(40) },
      { text: 'Cancel', style: 'cancel' },
    ]);
  };

  return (
    <SafeAreaView style={styles.screen} edges={['top', 'left', 'right']}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.head}>
          <View style={{ flex: 1 }}>
            <Text style={styles.date}>{dateLine()}</Text>
            <Text style={styles.hello}>{greeting()}</Text>
          </View>
          <View style={styles.streakPill}>
            <Icon name="local_fire_department" size={17} color={c.orange} />
            <Text style={styles.streakNum}>{streak}</Text>
          </View>
        </View>

        {/* Daily goal */}
        <LinearGradient colors={c.navyGrad} start={{ x: 0.2, y: 0 }} end={{ x: 0.8, y: 1 }} style={[pop.rest, styles.goalCard]}>
          <View style={styles.goalTop}>
            <Text style={styles.eyebrow}>DAILY GOAL</Text>
            <Pressable onPress={pickGoal} hitSlop={10} style={styles.goalEdit}>
              <Text style={styles.goalEditText}>{goal} XP</Text>
              <Icon name="expand_more" size={16} color={c.onNavyMuted} />
            </Pressable>
          </View>

          <Pressable onPress={pickGoal} style={styles.ringWrap} accessibilityLabel={`${todayXp} of ${goal} XP today`}>
            <GoalRing value={goalPct} done={reached} />
            <View style={styles.ringMid}>
              {reached ? <Icon name="check_circle" size={26} color={c.gold} /> : null}
              <Text style={styles.ringNum}>
                {todayXp}
                <Text style={styles.ringOf}> / {goal}</Text>
              </Text>
              <Text style={styles.ringLbl}>XP TODAY</Text>
            </View>
          </Pressable>

          <Text style={[styles.goalMsg, reached && { color: c.gold }]}>
            {reached
              ? 'Goal reached — great work today'
              : todayXp === 0
                ? 'One block gets you most of the way'
                : `${left} XP to go — keep it up`}
          </Text>

          <View style={styles.stats}>
            <Stat icon="local_fire_department" color={c.orange} value={String(streak)} label={streak === 1 ? 'day streak' : 'days streak'} />
            <View style={styles.statRule} />
            <Stat icon="bolt" color={c.gold} value={String(xp)} label="total XP" />
            <View style={styles.statRule} />
            <Stat icon="auto_stories" color={c.gold} value={`${coursePct}%`} label="of course" />
          </View>
        </LinearGradient>

        {/* Up next */}
        {target && next ? (
          <>
            <Text style={styles.section}>{doneCount ? 'UP NEXT' : 'START HERE'}</Text>
            <PopPressable onPress={openLessonPage} style={styles.nextCard}>
              <View style={styles.nextRow}>
                <View style={styles.nextIcon}>
                  <Icon name={next.icon ?? 'play_arrow'} size={23} color={c.gold} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.nextUnit} numberOfLines={1}>
                    {target.id} · {target.title}
                  </Text>
                  <Text style={styles.nextTitle} numberOfLines={1}>
                    {unitComplete ? 'Unit complete' : next.title}
                  </Text>
                  <Text style={styles.nextMeta} numberOfLines={1}>
                    {unitComplete
                      ? 'Tap to replay any part'
                      : [TYPE_LABEL[next.type] ?? 'Lesson', blockSizeLabel(next)].filter(Boolean).join(' · ')}
                  </Text>
                </View>
                <Pressable onPress={openNext} hitSlop={10} style={styles.go} accessibilityLabel="Continue lesson">
                  <Icon name={allowed ? 'arrow_forward' : 'lock'} size={20} color={c.onGold} />
                </Pressable>
              </View>
              <View style={styles.segs}>
                {target.blocks.map((b, i) => {
                  const isDone = !!completed[`${target.id}:${b.id}`];
                  const isCur = !unitComplete && b.id === next.id;
                  return (
                    <View
                      key={b.id}
                      style={[styles.seg, isDone && { backgroundColor: c.gold }, isCur && { backgroundColor: "rgba(230,184,90,0.4)" }, i === 0 && { marginLeft: 0 }]}
                    />
                  );
                })}
              </View>
              <Text style={styles.segText}>
                {targetDone} of {target.blocks.length} parts{targetModule ? ` · ${targetModule.title}` : ''}
              </Text>
            </PopPressable>
          </>
        ) : null}

        {/* Practice */}
        <Text style={styles.section}>PRACTICE</Text>
        <Row
          icon="autorenew"
          title="Daily review"
          sub="Words from your finished blocks"
          onPress={() => router.push({ pathname: '/lesson/[unit]', params: { unit: 'srsreview' } })}
        />
        <Row
          icon="style"
          title="Review session"
          sub="Pick a lesson and a drill"
          onPress={() => router.push({ pathname: '/lesson/[unit]', params: { unit: 'reviewBuilder' } })}
        />

        {!session ? (
          <Pressable onPress={() => router.push('/sign-in')} style={styles.signIn}>
            <Icon name="cloud_done" size={18} color={c.gold} />
            <Text style={styles.signInText}>Sign in to keep your progress on every device</Text>
            <Icon name="chevron_right" size={18} color={c.muted} />
          </Pressable>
        ) : null}
      </ScrollView>
    </SafeAreaView>
  );
}

function GoalRing({ value, done }: { value: number; done: boolean }) {
  const size = 184;
  const stroke = 11;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const pct = Math.max(0, Math.min(1, value));
  return (
    <Svg width={size} height={size} style={{ transform: [{ rotate: '-90deg' }] }}>
      <Defs>
        <SvgGradient id="goal" x1="0" y1="0" x2="1" y2="1">
          <Stop offset="0" stopColor="#f6d98c" />
          <Stop offset="1" stopColor="#d4a34a" />
        </SvgGradient>
      </Defs>
      <Circle cx={size / 2} cy={size / 2} r={r} stroke="rgba(255,255,255,0.07)" strokeWidth={stroke} fill="none" />
      {true ? (
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke="url(#goal)"
          strokeWidth={stroke}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={`${c} ${c}`}
          strokeDashoffset={c * (1 - Math.max(pct, 0.004))}
        />
      ) : null}
    </Svg>
  );
}

function Stat({ icon, color, value, label }: { icon: string; color: string; value: string; label: string }) {
  const styles = useStyles();
  return (
    <View style={styles.stat}>
      <View style={styles.statTop}>
        <Icon name={icon} size={16} color={color} />
        <Text style={styles.statVal}>{value}</Text>
      </View>
      <Text style={styles.statLbl}>{label}</Text>
    </View>
  );
}

function Row({ icon, title, sub, onPress }: { icon: string; title: string; sub: string; onPress: () => void }) {
  const { c } = useTheme();
  const styles = useStyles();
  return (
    <PopPressable onPress={onPress} style={styles.row}>
      <View style={styles.rowIcon}>
        <Icon name={icon} size={21} color={c.gold} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.rowTitle}>{title}</Text>
        <Text style={styles.rowSub} numberOfLines={1}>
          {sub}
        </Text>
      </View>
      <Icon name="chevron_right" size={20} color={c.muted} />
    </PopPressable>
  );
}

const useStyles = makeStyles((c) => ({
  screen: { flex: 1, backgroundColor: c.bg },
  content: { paddingHorizontal: Spacing.lg, paddingTop: 10, paddingBottom: 36 },

  head: { flexDirection: 'row', alignItems: 'center', marginBottom: 18 },
  date: { fontFamily: Fonts.body, fontSize: 13, color: c.muted },
  hello: { fontFamily: Fonts.display, fontSize: 26, lineHeight: 32, color: c.text, marginTop: 2 },
  streakPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 12,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(240,149,90,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(240,149,90,0.3)',
  },
  streakNum: { fontFamily: Fonts.bodyBold, fontSize: 15, color: c.text },

  goalCard: {
    borderRadius: 28,
    borderWidth: 1,
    borderColor: 'rgba(230,184,90,0.28)',
    paddingHorizontal: 20,
    paddingTop: 18,
    paddingBottom: 18,
    overflow: 'hidden',
  },
  goalTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  eyebrow: { fontFamily: Fonts.bodyBold, fontSize: 10.5, letterSpacing: 2.2, color: c.gold },
  goalEdit: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    paddingLeft: 10,
    paddingRight: 6,
    height: 28,
    borderRadius: 14,
    backgroundColor: ON_NAVY_RAISED,
  },
  goalEditText: { fontFamily: Fonts.bodySemi, fontSize: 12, color: c.onNavy },
  ringWrap: { alignSelf: 'center', marginTop: 14, width: 184, height: 184 },
  ringMid: { ...StyleSheet.absoluteFill, alignItems: 'center', justifyContent: 'center' },
  ringNum: { fontFamily: Fonts.bodyBold, fontSize: 46, color: c.onNavy, lineHeight: 52 },
  ringOf: { fontFamily: Fonts.bodySemi, fontSize: 18, color: c.onNavyMuted },
  ringLbl: { fontFamily: Fonts.bodyBold, fontSize: 10.5, letterSpacing: 2, color: c.onNavyMuted, marginTop: 2 },
  goalMsg: { fontFamily: Fonts.bodyMedium, fontSize: 13.5, color: c.onNavy, textAlign: 'center', marginTop: 14 },
  stats: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 18,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: ON_NAVY_LINE,
  },
  stat: { flex: 1, alignItems: 'center' },
  statTop: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  statVal: { fontFamily: Fonts.bodyBold, fontSize: 18, color: c.onNavy },
  statLbl: { fontFamily: Fonts.body, fontSize: 11.5, color: c.onNavyMuted, marginTop: 3 },
  statRule: { width: 1, height: 30, backgroundColor: ON_NAVY_LINE },

  section: { fontFamily: Fonts.bodyBold, fontSize: 10.5, letterSpacing: 2.2, color: c.muted, marginTop: 26, marginBottom: 10 },

  nextCard: {
    borderRadius: 22,
    backgroundColor: c.card,
    padding: 16,
  },
  nextRow: { flexDirection: 'row', alignItems: 'center', gap: 13 },
  nextIcon: {
    width: 50,
    height: 50,
    borderRadius: 15,
    backgroundColor: c.goldTint,
    alignItems: 'center',
    justifyContent: 'center',
  },
  nextUnit: { fontFamily: Fonts.body, fontSize: 11.5, color: c.muted },
  nextTitle: { fontFamily: Fonts.bodyBold, fontSize: 16.5, color: c.text, marginTop: 2 },
  nextMeta: { fontFamily: Fonts.body, fontSize: 12, color: c.gold, marginTop: 2 },
  go: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: c.goldFill,
    alignItems: 'center',
    justifyContent: 'center',
  },
  segs: { flexDirection: 'row', marginTop: 16 },
  seg: { flex: 1, height: 5, borderRadius: 3, marginLeft: 4, backgroundColor: c.track },
  segText: { fontFamily: Fonts.body, fontSize: 11.5, color: c.muted, marginTop: 8 },

  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    borderRadius: 18,
    backgroundColor: c.card,
    padding: 14,
    marginBottom: 10,
  },
  rowIcon: {
    width: 42,
    height: 42,
    borderRadius: 13,
    backgroundColor: c.goldTint,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rowTitle: { fontFamily: Fonts.bodyBold, fontSize: 15, color: c.text },
  rowSub: { fontFamily: Fonts.body, fontSize: 12, color: c.muted, marginTop: 2 },

  signIn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginTop: 14,
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(230,184,90,0.25)',
    borderStyle: 'dashed',
  },
  signInText: { flex: 1, fontFamily: Fonts.bodyMedium, fontSize: 13, color: c.text },
}));
