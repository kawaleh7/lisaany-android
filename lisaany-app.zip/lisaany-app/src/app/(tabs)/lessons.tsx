import { useFocusEffect, useRouter } from 'expo-router';
import { useCallback, useMemo, useState } from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { Icon } from '@/components/icon';
import { PopPressable } from '@/components/pop-card';
import { SpaceBackdrop } from '@/components/space-backdrop';
import { StarSlot, StarTalk, useStarGuide } from '@/components/star-guide';
import { CardFill, ContinuePill, currentCard, LATER_STYLE, spaceCard } from '@/components/ui';
import { Fonts, Spacing } from '@/constants/lisaany';
import { useAuth } from '@/lib/auth-context';
import { getModule, LEVELS, levelForModule, MODULE_META, type Module } from '@/lib/curriculum';
import { useLang } from '@/lib/i18n';
import { canAccessUnit } from '@/lib/plan';
import { getCompletedBlocks, unitDoneCount, type CompletedMap } from '@/lib/progress';
import { makeStyles, useTheme } from '@/theme';

const QUOTES: Record<string, string> = {
  Beginner: 'A new language.\nA brighter you.',
  Intermediate: 'Real words.\nReal conversations.',
  Advanced: 'Speak with\nconfidence.',
  Expert: 'Arabic of the\nheadlines.',
};

type ModState = { unitsDone: number; total: number; complete: boolean; started: boolean; locked: boolean };

export default function LessonsScreen() {
  const router = useRouter();
  const { plan } = useAuth();
  const { c } = useTheme();
  const styles = useStyles();
  const { t, ct } = useLang();

  const [done, setDone] = useState<CompletedMap>({});
  const [access, setAccess] = useState<Record<string, boolean>>({});
  const [levelIdx, setLevelIdx] = useState<number | null>(null);

  useFocusEffect(
    useCallback(() => {
      let active = true;
      const ids = LEVELS.flatMap((l) => l.moduleIds).flatMap((m) => getModule(m)?.units.map((u) => u.id) ?? []);
      Promise.all([getCompletedBlocks(), Promise.all(ids.map((id) => canAccessUnit(id)))]).then(
        ([map, ok]) => {
          if (!active) return;
          setDone(map);
          setAccess(Object.fromEntries(ids.map((id, i) => [id, ok[i]])));
        }
      );
      return () => {
        active = false;
      };
    }, [plan])
  );

  const state = useCallback(
    (mod: Module): ModState => {
      const total = mod.units.length;
      const unitsDone = mod.units.filter((u) => u.blocks.length > 0 && unitDoneCount(u, done) >= u.blocks.length).length;
      const started = mod.units.some((u) => unitDoneCount(u, done) > 0);
      const locked = !mod.units.some((u) => access[u.id] !== false);
      return { unitsDone, total, complete: total > 0 && unitsDone >= total, started, locked };
    },
    [done, access]
  );

  // Modules open one at a time, in course order: the current one is the first unfinished.
  const ORDER = useMemo(() => LEVELS.flatMap((l) => l.moduleIds), []);
  const currentModule = useMemo(() => {
    for (const id of ORDER) {
      const m = getModule(id);
      if (m && !state(m).complete) return id;
    }
    return ORDER[ORDER.length - 1] ?? 1;
  }, [ORDER, state]);
  const curIdx = ORDER.indexOf(currentModule);
  const curTitle = getModule(currentModule)?.title ?? '';

  const defaultLevel = Math.max(0, LEVELS.findIndex((l) => l === levelForModule(currentModule)));
  const li = levelIdx ?? defaultLevel;
  const level = LEVELS[li];
  const mods = level.moduleIds.map((id) => getModule(id)).filter(Boolean) as Module[];
  const levelUnits = mods.reduce((n, m) => n + m.units.length, 0);
  const levelUnitsDone = mods.reduce((n, m) => n + state(m).unitsDone, 0);

  const tips = useMemo(
    () => [
      t('Your current module is outlined in gold — tap Continue to pick up where you left off.'),
      t('Later modules open as you finish the ones before.'),
      t('New to the Arabic letters? Norania teaches you to read first.'),
    ],
    [t]
  );
  const guide = useStarGuide(tips, { greet: tips[0], greetKey: 'lessons' });

  return (
    <SafeAreaView style={styles.screen} edges={['top', 'left', 'right']}>
      <SpaceBackdrop />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Hero */}
        <View style={styles.hero}>
          <View style={styles.headRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.eyebrow}>{t('LEARN ARABIC')}</Text>
              <Text style={styles.levelTitle} numberOfLines={1} adjustsFontSizeToFit>
                {t(level.label)}
              </Text>
            </View>
            <StarSlot guide={guide} />
          </View>
          <StarTalk guide={guide} />
          <View style={styles.heroRow}>
            <Text style={styles.levelAr}>{level.ar}</Text>
            <View style={styles.quoteBox}>
              <Text style={styles.quote}>“{QUOTES[level.label] ? t(QUOTES[level.label]) : ''}”</Text>
              <View style={styles.quoteRule} />
            </View>
          </View>
        </View>

        {/* Learn to read first (Norania) */}
        <PopPressable onPress={() => router.push('/norania')} style={styles.readWrap} scaleTo={1.02}>
          <View style={styles.readCard}>
            <CardFill radius={19} />
            <View style={styles.readIcon}>
              <Text style={styles.readIconAr}>أ ب</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.readKick}>{t('CAN’T READ ARABIC YET?')}</Text>
              <Text style={styles.readTitle}>{t('Learn to read · Norania')}</Text>
              <Text style={styles.readSub}>{t('Letters, vowels and joining · 33 short lessons')}</Text>
            </View>
            <Icon name="chevron_right" size={20} color={c.gold} />
          </View>
        </PopPressable>

        {/* Level tabs */}
        <View style={styles.tabs}>
          {LEVELS.map((l, i) => {
            const on = i === li;
            return (
              <Pressable key={l.label} onPress={() => setLevelIdx(i)} style={[styles.tab, on && styles.tabOn]}>
                <Text style={[styles.tabText, on && styles.tabTextOn]}>{t(l.label)}</Text>
              </Pressable>
            );
          })}
        </View>

        <Text style={styles.levelDesc}>{t(level.desc)}</Text>
        <View style={styles.levelBarRow}>
          <View style={styles.levelBar}>
            <View style={[styles.levelFill, { width: `${Math.round((levelUnitsDone / Math.max(1, levelUnits)) * 100)}%` }]} />
          </View>
          <Text style={styles.levelBarText}>
            {t('{done}/{total} units', { done: levelUnitsDone, total: levelUnits })}
          </Text>
        </View>

        {/* Modules */}
        {(() => {
          const firstIdx = ORDER.indexOf(level.moduleIds[0]);
          // Whole level still ahead: one locked card, no list.
          if (firstIdx > curIdx && !mods.some((m) => state(m).complete)) {
            const prev = LEVELS[li - 1];
            return (
              <View style={styles.levelLock}>
                <View style={styles.levelLockIc}>
                  <Icon name="lock" size={22} color={c.gold} />
                </View>
                <Text style={styles.levelLockTitle}>
                  {prev
                    ? t('Finish {prev} to unlock {level}', { prev: t(prev.label), level: t(level.label) })
                    : t('Finish the level before to unlock {level}', { level: t(level.label) })}
                </Text>
                <Text style={styles.levelLockSub}>
                  {mods.length === 1
                    ? t('1 module · {units} units waiting for you', { units: levelUnits })
                    : t('{n} modules · {units} units waiting for you', { n: mods.length, units: levelUnits })}
                </Text>
                <Pressable onPress={() => setLevelIdx(null)} style={styles.levelLockBtn}>
                  <Text style={styles.levelLockBtnText}>{t('Back to my level')}</Text>
                </Pressable>
              </View>
            );
          }
          const out: React.ReactNode[] = [];
          let hidden = 0;
          mods.forEach((mod) => {
            const s = state(mod);
            const idx = ORDER.indexOf(mod.id);
            const meta = MODULE_META[mod.id];
            const open = () => router.push({ pathname: '/module/[id]', params: { id: String(mod.id) } });
            if (s.complete) {
              out.push(
                <PopPressable key={mod.id} onPress={open} style={styles.doneRow}>
                  <CardFill radius={18} />
                  <View style={[styles.badge, styles.badgeDone, { marginTop: 0 }]}>
                    <Icon name="check" size={18} color="#ffffff" />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.doneTitle} numberOfLines={2}>{ct(mod.title)}</Text>
                    {meta ? <Text style={styles.doneAr}>{meta.ar}</Text> : null}
                  </View>
                  <Text style={styles.doneLink}>{t('Review')}</Text>
                  <Icon name="chevron_right" size={18} color={c.gold} />
                </PopPressable>
              );
            } else if (mod.id === currentModule) {
              out.push(
                <PopPressable key={mod.id} onPress={open} style={styles.curWrap} scaleTo={1.02}>
                  <CardFill radius={22} />
                  <View style={styles.curInner}>
                    <View style={styles.modTop}>
                      <View style={[styles.badge, styles.badgeCur]}>
                        <Text style={[styles.badgeNum, { color: c.onGold }]}>{mod.id}</Text>
                      </View>
                      <View style={{ flex: 1 }}>
                        <Text style={styles.modTitle}>{ct(mod.title)}</Text>
                        {meta ? <Text style={styles.modAr}>{meta.ar}</Text> : null}
                      </View>
                      {s.locked ? (
                        <View style={styles.lockPill}>
                          <Icon name="lock" size={13} color={c.gold} />
                          <Text style={styles.lockText}>Premium</Text>
                        </View>
                      ) : null}
                    </View>
                    {meta ? <Text style={styles.modBlurb}>{t(meta.blurb)}</Text> : null}
                    <View style={styles.modFoot}>
                      <View style={styles.modSegs}>
                        {mod.units.map((u, i) => {
                          const n = unitDoneCount(u, done);
                          const full = u.blocks.length > 0 && n >= u.blocks.length;
                          return (
                            <View
                              key={u.id}
                              style={[styles.modSeg, i === 0 && { marginLeft: 0 }, full ? { backgroundColor: c.goldFill } : n > 0 ? { backgroundColor: 'rgba(214,178,90,0.45)' } : null]}
                            />
                          );
                        })}
                      </View>
                      <Text style={styles.modCount}>
                        {t('{done}/{total} units', { done: s.unitsDone, total: s.total })}
                      </Text>
                    </View>
                    <ContinuePill
                      label={s.locked ? t('Unlock') : s.started ? t('Continue') : t('Start here')}
                      icon={s.locked ? 'lock_open' : 'skip_next'}
                      style={{ marginTop: 16 }}
                    />
                  </View>
                </PopPressable>
              );
            } else if (idx === curIdx + 1) {
              out.push(
                <View key={mod.id} style={[styles.nextRow, LATER_STYLE]}>
                  <CardFill radius={18} />
                  <View style={[styles.badge, { marginTop: 0 }]}>
                    <Icon name="lock" size={16} color={c.muted} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.nextTitle} numberOfLines={1}>{ct(mod.title)}</Text>
                    <Text style={styles.nextSub} numberOfLines={2}>{t('Unlocks when you finish {title}', { title: ct(curTitle) })}</Text>
                  </View>
                </View>
              );
            } else {
              hidden++;
            }
          });
          if (hidden) {
            out.push(
              <View key="more" style={styles.more}>
                <Icon name="lock" size={14} color={c.muted} />
                <Text style={styles.moreText}>
                  {hidden === 1
                    ? t('+ 1 more module — they open one at a time')
                    : t('+ {n} more modules — they open one at a time', { n: hidden })}
                </Text>
              </View>
            );
          }
          return out;
        })()}
      </ScrollView>
    </SafeAreaView>
  );
}

const useStyles = makeStyles((c) => ({
  screen: { flex: 1, backgroundColor: c.bg },
  content: { paddingHorizontal: Spacing.lg, paddingTop: 14, paddingBottom: 36 },

  hero: { marginBottom: 18 },
  headRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  readWrap: { ...spaceCard(c), borderRadius: 20, marginBottom: 18 },
  readCard: { flexDirection: 'row', alignItems: 'center', gap: 14, padding: 14, borderRadius: 19 },
  readIcon: { width: 52, height: 52, borderRadius: 16, backgroundColor: c.goldTint, alignItems: 'center', justifyContent: 'center' },
  readIconAr: { fontFamily: Fonts.arabic, fontSize: 20, lineHeight: 34, color: c.gold },
  readKick: { fontFamily: Fonts.bodyBold, fontSize: 10.5, letterSpacing: 1.3, color: c.gold },
  readTitle: { fontFamily: Fonts.bodyBold, fontSize: 16, color: c.text, marginTop: 2 },
  readSub: { fontFamily: Fonts.body, fontSize: 12.5, color: c.muted, marginTop: 1 },
  heroRow: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between' },
  eyebrow: { fontFamily: Fonts.bodyBold, fontSize: 10.5, letterSpacing: 2.2, color: c.gold },
  levelTitle: { fontFamily: Fonts.displayBold, fontSize: 32, lineHeight: 40, color: c.text, marginTop: 4 },
  levelAr: { fontFamily: Fonts.arabic, fontSize: 24, lineHeight: 38, color: c.gold, textAlign: 'left', alignSelf: 'flex-start' },
  quoteBox: { alignItems: 'flex-end', paddingBottom: 6, marginLeft: 10 },
  quote: { fontFamily: Fonts.body, fontStyle: 'italic', fontSize: 12.5, lineHeight: 18, color: c.muted, textAlign: 'right' },
  quoteRule: { width: 26, height: 2, borderRadius: 1, backgroundColor: c.gold, marginTop: 8 },

  tabs: { flexDirection: 'row', gap: 6 },
  tab: {
    flexGrow: 1,
    alignItems: 'center',
    height: 38,
    paddingHorizontal: 10,
    borderRadius: 19,
    borderWidth: 1,
    borderColor: c.line,
    justifyContent: 'center',
  },
  tabOn: { backgroundColor: c.goldFill, borderColor: c.goldFill },
  tabText: { fontFamily: Fonts.bodySemi, fontSize: 12.5, color: c.text },
  tabTextOn: { fontFamily: Fonts.bodyBold, color: c.onGold },

  levelDesc: { fontFamily: Fonts.body, fontSize: 13.5, color: c.muted, marginTop: 18 },
  levelBarRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginTop: 10, marginBottom: 18 },
  levelBar: { flex: 1, height: 6, borderRadius: 3, backgroundColor: c.track, overflow: 'hidden' },
  levelFill: { height: '100%', borderRadius: 3, backgroundColor: c.gold },
  levelBarText: { fontFamily: Fonts.bodySemi, fontSize: 12, color: c.muted },

  modTop: { flexDirection: 'row', alignItems: 'flex-start', gap: 13 },
  badge: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: c.raised,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 2,
  },
  badgeDone: { backgroundColor: c.green },
  badgeCur: { backgroundColor: c.goldFill },
  badgeNum: { fontFamily: Fonts.bodyBold, fontSize: 15, color: c.text },
  modTitle: { fontFamily: Fonts.display, fontSize: 19.5, lineHeight: 25, color: c.text },
  modAr: { fontFamily: Fonts.arabic, fontSize: 17, lineHeight: 28, color: c.gold, marginTop: 1, textAlign: 'left', alignSelf: 'flex-start' },
  modBlurb: { fontFamily: Fonts.body, fontSize: 13, lineHeight: 19, color: c.muted, marginTop: 8, marginLeft: 51 },
  modFoot: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 12, marginLeft: 51 },
  modSegs: { flex: 1, flexDirection: 'row' },
  modSeg: { flex: 1, height: 5, borderRadius: 3, marginLeft: 3, backgroundColor: c.track },
  modCount: { fontFamily: Fonts.body, fontSize: 11.5, color: c.muted },
  lockPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 9,
    height: 24,
    borderRadius: 12,
    backgroundColor: c.goldTint,
  },
  lockText: { fontFamily: Fonts.bodySemi, fontSize: 11, color: c.gold },
  // The current module: space card with the gold ring, bigger title, Continue pill.
  curWrap: { ...spaceCard(c), ...currentCard(c), borderRadius: 22, marginTop: 4, marginBottom: 14 },
  curInner: { padding: 18 },
  // Finished modules: normal card, slightly dimmed, green check.
  doneRow: {
    ...spaceCard(c),
    opacity: 0.88,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderRadius: 18,
    paddingVertical: 12,
    paddingHorizontal: 14,
    marginBottom: 10,
  },
  doneTitle: { fontFamily: Fonts.display, fontSize: 15, color: c.text },
  doneAr: { fontFamily: Fonts.arabic, fontSize: 14, lineHeight: 22, color: c.gold, textAlign: 'left', alignSelf: 'flex-start' },
  doneLink: { fontFamily: Fonts.bodySemi, fontSize: 12, color: c.muted },

  // Not reached yet: a faded card (LATER_STYLE adds the fade and scale).
  nextRow: {
    ...spaceCard(c),
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderRadius: 18,
    paddingVertical: 14,
    paddingHorizontal: 14,
    marginBottom: 10,
  },
  nextTitle: { fontFamily: Fonts.display, fontSize: 15, color: c.text },
  nextSub: { fontFamily: Fonts.body, fontSize: 12, color: c.muted, marginTop: 2 },
  more: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 10 },
  moreText: { fontFamily: Fonts.body, fontSize: 12.5, color: c.muted },

  levelLock: {
    alignItems: 'center',
    borderRadius: 24,
    borderWidth: 1,
    borderStyle: 'dashed',
    borderColor: 'rgba(230,184,90,0.35)',
    paddingVertical: 30,
    paddingHorizontal: 22,
    marginTop: 4,
  },
  levelLockIc: {
    width: 54,
    height: 54,
    borderRadius: 27,
    backgroundColor: c.goldTint,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 14,
  },
  levelLockTitle: { fontFamily: Fonts.display, fontSize: 18, lineHeight: 25, color: c.text, textAlign: 'center' },
  levelLockSub: { fontFamily: Fonts.body, fontSize: 13, color: c.muted, marginTop: 6, textAlign: 'center' },
  levelLockBtn: { marginTop: 18, height: 42, paddingHorizontal: 20, borderRadius: 21, backgroundColor: c.raised, justifyContent: 'center' },
  levelLockBtnText: { fontFamily: Fonts.bodySemi, fontSize: 13.5, color: c.text },
}));
