import Constants from 'expo-constants';
import { LinearGradient } from 'expo-linear-gradient';
import { useFocusEffect, useRouter } from 'expo-router';
import { useCallback, useEffect, useMemo, useState, type ReactNode } from 'react';
import { Alert, LayoutAnimation, Linking, Pressable, ScrollView, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { TimeChips } from '@/components/goal-controls';
import { Icon } from '@/components/icon';
import { GoldSwitch } from '@/components/gold-switch';
import { PopPressable } from '@/components/pop-card';
import { SpaceBackdrop } from '@/components/space-backdrop';
import { StarSlot, StarTalk, useStarGuide } from '@/components/star-guide';
import { CardFill, currentCard, spaceCard } from '@/components/ui';
import { Fonts, WEB_BASE } from '@/constants/lisaany';
import { useAuth } from '@/lib/auth-context';
import { MODULE_META, MODULES, type Module } from '@/lib/curriculum';
import { PLAN_LABELS } from '@/lib/plan';
import { IS_ANDROID, IS_IOS, manageSubscriptionUrl, restore, STORE_ENABLED, storeSubscriptionInfo } from '@/lib/store';
import { supabase } from '@/lib/supabase';
import {
  getCompletedBlocks,
  getEngineProgress,
  getFirstSeen,
  getLastUnit,
  getWeekXp,
  unitDoneCount,
  type CompletedMap,
  type WeekDay,
} from '@/lib/progress';
import { useLang } from '@/lib/i18n';
import { getEmailOptIn, setEmailOptIn } from '@/lib/email-reminders';
import { DEFAULT_MIN_GOAL, GOAL_CHOICES, getMinGoal, getMinutesHistory } from '@/lib/goal';
import { changeMinGoal, changeReminderPrefs } from '@/lib/goal-sync';
import { DEFAULT_REMINDER, getReminderPrefs, NOTIFICATIONS_SUPPORTED, requestPermission, type ReminderPrefs } from '@/lib/reminders';
import { DEFAULT_SOUNDS, getSoundsOn, LESSON_LANG_LABELS, setSoundsOn, type LessonLang } from '@/lib/settings';
import { LIGHT_MODE_ENABLED, makeStyles, useTheme } from '@/theme';
import { contentCap } from '@/components/content-width';

/** react-native-web colours the "on" thumb with its own prop. */
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const DAY_NAMES = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

type Panel = 'week' | 'learning' | 'account' | null;

/** Profile: your journey and numbers first; the week, learning settings and
 *  account fold open when tapped. */
export default function ProfileScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { session, plan, signOut, afterAccountDeleted, refreshPlan, progressVersion } = useAuth();
  const { c, scheme, setMode } = useTheme();
  const styles = useStyles();
  const { t, ct, lang, setLang } = useLang();
  const W = c.scheme !== 'light';

  const [done, setDone] = useState<CompletedMap>({});
  const [xp, setXp] = useState(0);
  const [streak, setStreak] = useState(0);
  const [week, setWeek] = useState<WeekDay[]>([]);
  /** Daily goal in minutes. */
  const [goal, setGoal] = useState(DEFAULT_MIN_GOAL);
  const [minHist, setMinHist] = useState<Record<string, number>>({});
  const [reminder, setReminder] = useState<ReminderPrefs>(DEFAULT_REMINDER);
  const [emailOn, setEmailOn] = useState(false);
  const [soundsOn, setSounds] = useState(DEFAULT_SOUNDS);
  const [since, setSince] = useState<Date | null>(null);
  const [lastUnit, setLastUnitId] = useState<string | null>(null);
  const [open, setOpen] = useState<Panel>(null);

  // The star only talks here when tapped.
  const tips = useMemo(
    () => [
      t('Your daily goal, reminders, sounds, language and account are all in Settings.'),
      t('Your journey card shows the module you’re on — tap it to jump back in.'),
    ],
    [t]
  );
  const guide = useStarGuide(tips);

  useFocusEffect(
    useCallback(() => {
      let active = true;
      Promise.all([
        getCompletedBlocks(),
        getEngineProgress(),
        getWeekXp(),
        getMinGoal(),
        getFirstSeen(),
        getLastUnit(),
        getMinutesHistory(),
        getReminderPrefs(),
        getEmailOptIn(),
        getSoundsOn(),
      ]).then(([map, snap, wk, g, first, last, hist, rem, mail, sfx]) => {
        if (!active) return;
        setDone(map);
        setXp(snap.xp);
        setStreak(snap.streak);
        setWeek(wk);
        setGoal(g);
        setSince(first);
        setLastUnitId(last?.unitId ?? null);
        setMinHist(hist);
        setReminder(rem);
        setEmailOn(mail);
        setSounds(sfx);
      });
      return () => {
        active = false;
      };
      // progressVersion: a cloud pull (or a sign-out) changed the mirror.
    // eslint-disable-next-line react-hooks/exhaustive-deps -- deliberate re-run trigger
    }, [progressVersion])
  );

  const toggle = (p: Panel) => {
    LayoutAnimation.configureNext(LayoutAnimation.create(220, 'easeInEaseOut', 'opacity'));
    setOpen((cur) => (cur === p ? null : p));
  };

  /* ── numbers ─────────────────────────────────────────────── */
  const user = session?.user;
  const meta = (user?.user_metadata ?? {}) as Record<string, unknown>;
  const email = user?.email ?? '';
  const name =
    (typeof meta.full_name === 'string' && meta.full_name) ||
    (typeof meta.name === 'string' && meta.name) ||
    (email ? email.split('@')[0] : '') ||
    t('Guest');
  const displayName = name.charAt(0).toUpperCase() + name.slice(1);
  const joined = user?.created_at ? new Date(user.created_at) : since;

  const partsDone = Object.keys(done).length;
  let words = 0;
  for (const m of MODULES)
    for (const u of m.units)
      for (const b of u.blocks)
        if (done[`${u.id}:${b.id}`] && b.size?.unit === 'words') words += b.size.count;

  const moduleDone = (m: Module) => m.units.length > 0 && m.units.every((u) => u.blocks.length > 0 && unitDoneCount(u, done) >= u.blocks.length);
  const currentModule =
    MODULES.find((m) => lastUnit && m.units.some((u) => u.id === lastUnit) && !moduleDone(m)) ??
    MODULES.find((m) => !moduleDone(m)) ??
    MODULES[MODULES.length - 1];
  const lessonsDone = currentModule
    ? currentModule.units.filter((u) => u.blocks.length > 0 && unitDoneCount(u, done) >= u.blocks.length).length
    : 0;
  const lessonsTotal = currentModule?.units.length ?? 0;
  const modulesLeft = MODULES.filter((m) => !moduleDone(m) && m !== currentModule).length;
  const curMeta = currentModule ? MODULE_META[currentModule.id] : undefined;

  const weekTotal = week.reduce((a, d) => a + d.xp, 0);
  const todayIdx = Math.max(0, week.findIndex((d) => d.isToday));
  const daysSoFar = todayIdx + 1;
  // A day counts as "goal met" when its active minutes reached the daily goal.
  const metOn = (day: string) => (minHist[day] ?? 0) >= goal * 60;
  const metDays = week.slice(0, daysSoFar).filter((d) => metOn(d.day)).length;
  const best = week.reduce<{ i: number; xp: number }>((b, d, i) => (d.xp > b.xp ? { i, xp: d.xp } : b), { i: -1, xp: 0 });
  const maxBar = Math.max(...week.map((d) => d.xp), 10);

  const paid = plan !== 'free';

  /* ── actions ─────────────────────────────────────────────── */
  const chooseGoal = (g: number) => {
    setGoal(g);
    changeMinGoal(g);
  };
  const toggleReminders = async (on: boolean) => {
    if (on && NOTIFICATIONS_SUPPORTED && !(await requestPermission())) {
      Alert.alert(t('Notifications are off'), t('Allow notifications for Lisaany in your phone’s settings to get reminders.'), [
        { text: t('Cancel'), style: 'cancel' },
        { text: t('Open settings'), onPress: () => Linking.openSettings().catch(() => {}) },
      ]);
      return;
    }
    setReminder(await changeReminderPrefs({ enabled: on }));
  };
  const pickReminderTime = async (hour: number, minute: number) => {
    setReminder((r) => ({ ...r, hour, minute }));
    setReminder(await changeReminderPrefs({ hour, minute }));
  };
  // Read when a lesson opens, so a change applies to the next lesson.
  const toggleSounds = (on: boolean) => {
    setSounds(on);
    setSoundsOn(on);
  };
  const toggleEmail = (on: boolean) => {
    setEmailOn(on);
    setEmailOptIn(on);
  };
  // Signing out turns the switch back to what this device knows.
  useEffect(() => {
    if (!session) getEmailOptIn().then(setEmailOn);
  }, [session]);
  const chooseLang = (l: LessonLang) => setLang(l);
  // Both stores sell Premium in-app without an account; the plans screen offers sign-in itself.
  const openPlans = () => router.push('/plans');
  const openBilling = async () => {
    if (!paid) return openPlans();
    // Staff access comes from the account role, not a subscription.
    if (plan === 'staff') {
      Alert.alert(t('Staff access'), t('Every lesson is open on this account through staff access. There is no subscription to manage.'));
      return;
    }
    // A store subscription is managed by that store; a plan bought on the
    // website is managed there (neither store allows linking out to it).
    const info = await storeSubscriptionInfo();
    if (info) {
      Linking.openURL(manageSubscriptionUrl()).catch(() => {});
      return;
    }
    Alert.alert(t('Manage subscription'), t('Your subscription was set up on lisaany.com. Manage or cancel it from your account there.'));
  };
  const restorePurchases = async () => {
    try {
      if (await restore()) {
        await refreshPlan();
        Alert.alert(t('Restored'), t('Lisaany Premium is active on this device.'));
      } else {
        Alert.alert(
          t('No purchases found'),
          IS_IOS ? t('There is no Lisaany Premium subscription on this Apple ID.') : t('There is no Lisaany Premium subscription on this Google account.')
        );
      }
    } catch (e) {
      Alert.alert(t('Could not restore'), e instanceof Error ? e.message : t('Please try again.'));
    }
  };
  // Apple and Google both require deleting the account from inside the app.
  // The delete_user() database function removes the signed-in user and their
  // data (supabase/delete_user.sql). Subscriptions are not cancelled by it:
  // a store subscription belongs to the store account, and a website one is
  // cancelled on the website.
  const deleteWarning = [
    t('This permanently deletes your Lisaany account and the progress saved to it. This cannot be undone.'),
    IS_IOS
      ? t('An App Store subscription is not cancelled automatically — cancel it in Settings → Apple ID → Subscriptions.')
      : IS_ANDROID
        ? t('A Google Play subscription is not cancelled automatically — cancel it in Google Play → Subscriptions.')
        : null,
    t('If you subscribed on lisaany.com, cancel the subscription there first.'),
  ]
    .filter(Boolean)
    .join('\n\n');
  const confirmDelete = () =>
    Alert.alert(t('Delete your account?'), deleteWarning, [
      { text: t('Cancel'), style: 'cancel' },
      {
        text: t('Delete account'),
        style: 'destructive',
        onPress: async () => {
          const { error } = await supabase.rpc('delete_user');
          if (error) {
            Alert.alert(t('Could not delete the account'), `${t('Please try again, or email admin@lisaany.com and we will delete it for you.')}\n\n(${error.message})`);
            return;
          }
          // The account is gone: drop the session on this device and every
          // trace of the learner (progress, plan, Norania, opt-ins), then
          // start over from the landing screen.
          await afterAccountDeleted();
          router.replace('/landing');
          Alert.alert(t('Account deleted'), t('Your Lisaany account has been deleted.'));
        },
      },
    ]);
  const confirmSignOut = () =>
    Alert.alert(t('Sign out?'), t('Your progress stays saved to your account.'), [
      { text: t('Cancel'), style: 'cancel' },
      { text: t('Sign out'), style: 'destructive', onPress: () => signOut() },
    ]);

  return (
    <View style={styles.screen}>
      <SpaceBackdrop />
      <ScrollView
        contentContainerStyle={[styles.content, { paddingTop: insets.top + 14 }]}
        showsVerticalScrollIndicator={false}>
        {/* Who */}
        <View style={styles.who}>
          <LinearGradient colors={['#f6d98c', c.goldFill]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.avatar}>
            <Text style={styles.avatarText}>{displayName.charAt(0)}</Text>
          </LinearGradient>
          <View style={{ flex: 1 }}>
            <Text style={styles.name} numberOfLines={1}>
              {displayName}
            </Text>
            <Text style={styles.whoSub} numberOfLines={2}>
              {joined
                ? t('{plan} plan · since {month} {year}', { plan: t(PLAN_LABELS[plan]), month: t(MONTHS[joined.getMonth()]), year: joined.getFullYear() })
                : t('{plan} plan', { plan: t(PLAN_LABELS[plan]) })}
            </Text>
            {/* Sign in / sign out right under the name, so nobody has to scroll for it. */}
            <Pressable
              onPress={session ? confirmSignOut : () => router.push('/sign-in')}
              hitSlop={8}
              style={({ pressed }) => [styles.whoBtn, !session && styles.whoBtnGold, pressed && { opacity: 0.8 }]}
              accessibilityRole="button">
              <Icon name={session ? 'logout' : 'login'} size={16} color={W ? (session ? '#65718A' : '#B98522') : session ? c.text : c.gold} />
              <Text style={[styles.whoBtnText, !session && { color: W ? '#B98522' : c.gold }]}>{session ? t('Sign out') : t('Sign in')}</Text>
            </Pressable>
          </View>
          <StarSlot guide={guide} />
        </View>
        <StarTalk guide={guide} />

        {/* Journey */}
        {currentModule ? (
          <PopPressable
            onPress={() => router.push({ pathname: '/module/[id]', params: { id: String(currentModule.id) } })}
            style={styles.cardWrap}
            scaleTo={1.02}>
            {W ? null : <CardFill radius={21} />}
            <View style={styles.journey}>
              <Text style={styles.eyebrow}>{t('YOUR JOURNEY')}</Text>
              <Text style={styles.journeyTitle} numberOfLines={2}>
                {t('Module {n}', { n: currentModule.id })} · {ct(currentModule.title)}
              </Text>
              {curMeta ? <Text style={styles.journeyAr}>{curMeta.ar}</Text> : null}
              <View style={styles.track}>
                <View style={[styles.fill, { width: `${lessonsTotal ? Math.round((lessonsDone / lessonsTotal) * 100) : 0}%` }]} />
              </View>
              <View style={styles.journeyFoot}>
                <Text style={styles.journeyFootText}>
                  {t('{done} of {total} lessons', { done: lessonsDone, total: lessonsTotal })}
                </Text>
                <Text style={styles.journeyFootText}>
                  {modulesLeft === 0 ? t('Last module') : modulesLeft === 1 ? t('1 module to go') : t('{n} modules to go', { n: modulesLeft })}
                </Text>
              </View>
            </View>
          </PopPressable>
        ) : null}

        {/* Numbers */}
        <View style={styles.stats}>
          <Stat icon="local_fire_department" color={W ? '#D78B29' : c.orange} value={streak} label={t('day streak')} />
          <Stat icon="bolt" value={xp} label={t('total XP')} />
          <Stat icon="translate" value={words} label={t('words')} />
          <Stat icon="check_circle" value={partsDone} label={t('parts done')} />
        </View>

        {/* Upgrade (free plan only) */}
        {!paid ? (
          <PopPressable onPress={openPlans} style={styles.plainWrap} scaleTo={1.02}>
            {W ? null : <CardFill radius={21} />}
            <View style={styles.unlock}>
              <Icon name="crown" size={28} color={c.gold} />
              <View style={{ flex: 1 }}>
                <Text style={styles.unlockTitle}>{t('Unlock all 47 lessons')}</Text>
                <Text style={styles.unlockSub}>{t('Lessons 1.1, 1.2 and 1.3 are free')}</Text>
              </View>
              <View style={styles.pill}>
                <Text style={styles.pillText}>{t('See plans')}</Text>
              </View>
            </View>
          </PopPressable>
        ) : null}

        {/* Progress */}
        <Text style={styles.section}>{t('PROGRESS')}</Text>
        <Fold
          icon="bolt"
          title={t('This week')}
          summary={t(daysSoFar === 1 ? '{xp} XP · goal met {met} of {days} day' : '{xp} XP · goal met {met} of {days} days', { xp: weekTotal, met: metDays, days: daysSoFar })}
          open={open === 'week'}
          onToggle={() => toggle('week')}>
          <View style={styles.weekBody}>
            <View style={styles.bars}>
              {week.map((d, i) => {
                const h = Math.max(4, Math.round((d.xp / maxBar) * 78));
                const met = metOn(d.day);
                return (
                  <View key={d.day} style={styles.barCol}>
                    <View style={styles.barBox}>
                      <View
                        style={[
                          styles.bar,
                          { height: h },
                          met && { backgroundColor: 'rgba(214,178,90,0.55)' },
                          d.isToday && { backgroundColor: c.goldFill },
                        ]}
                      />
                    </View>
                    <Text style={[styles.barLabel, d.isToday && { color: c.gold }]}>{DAY_NAMES[i] ? t(DAY_NAMES[i]).charAt(0).toUpperCase() : d.label}</Text>
                  </View>
                );
              })}
            </View>
            <View style={styles.weekFoot}>
              <Text style={styles.footText}>
                {best.i >= 0 ? t('Best day: {day} · {xp} XP', { day: t(DAY_NAMES[best.i]), xp: best.xp }) : t('No XP yet this week')}
              </Text>
              <Text style={styles.footText}>{t('Goal {n} min a day', { n: goal })}</Text>
            </View>
          </View>
        </Fold>

        {/* Settings */}
        <Text style={styles.section}>{t('SETTINGS')}</Text>
        <Fold
          icon="school"
          title={t('Learning')}
          summary={`${t('{n} min a day', { n: goal })} · ${reminder.enabled ? t('Reminders on') : t('Reminders off')}`}
          open={open === 'learning'}
          onToggle={() => toggle('learning')}>
          <View style={styles.setting}>
            <Text style={styles.settingLabel}>{t('Daily goal')}</Text>
            <Text style={styles.settingHint}>{t('Minutes of Arabic a day. Today’s ring fills as you learn.')}</Text>
            <View style={styles.segment}>
              {GOAL_CHOICES.map((g) => (
                <Pressable
                  key={g}
                  onPress={() => chooseGoal(g)}
                  accessibilityRole="radio"
                  accessibilityState={{ selected: goal === g }}
                  style={[styles.segItem, goal === g && styles.segOn]}>
                  <Text style={[styles.segText, goal === g && styles.segTextOn]}>{t('{n} min', { n: g })}</Text>
                </Pressable>
              ))}
            </View>
          </View>
          <View style={styles.setting}>
            <View style={styles.switchRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.settingLabel}>{t('Reminders')}</Text>
                <Text style={styles.settingHint}>{t('A nudge if you have been away for a few days. Nothing while you keep learning.')}</Text>
              </View>
              <GoldSwitch
                blue={c.scheme !== 'light'}
                value={reminder.enabled}
                onValueChange={toggleReminders}
                accessibilityLabel={t('Reminders')}
              />
            </View>
            <View style={{ marginTop: 12 }}>
              <TimeChips hour={reminder.hour} minute={reminder.minute} onPick={pickReminderTime} disabled={!reminder.enabled} onWhite={c.scheme !== 'light'} />
            </View>
          </View>
          <View style={styles.setting}>
            <View style={styles.switchRow}>
              <View style={{ flex: 1 }}>
                <Text style={[styles.settingLabel, !session && { color: c.muted }]}>{t('Email reminders')}</Text>
                <Text style={styles.settingHint}>
                  {t('One email a month if you have been away. You can unsubscribe at any time.')}
                </Text>
              </View>
              <GoldSwitch
                blue={c.scheme !== 'light'}
                value={!!session && emailOn}
                onValueChange={toggleEmail}
                disabled={!session}
                accessibilityLabel={t('Email reminders')}
              />
            </View>
            {!session ? (
              <Pressable onPress={() => router.push('/sign-in')} hitSlop={6} style={styles.signInLine} accessibilityRole="link">
                <Icon name="login" size={16} color={c.gold} />
                <Text style={styles.signInLineText}>{t('Sign in to get email reminders')}</Text>
                <Icon name="chevron_right" size={16} color={c.gold} />
              </Pressable>
            ) : null}
          </View>
          {LIGHT_MODE_ENABLED ? (
          <View style={styles.setting}>
            <Text style={styles.settingLabel}>{t('Appearance')}</Text>
            <Text style={styles.settingHint}>{t('Galaxy is dark with stars. Light is white and bright.')}</Text>
            <View style={styles.segment}>
              {([['dark', t('Galaxy')], ['light', t('Light')]] as const).map(([m, label]) => (
                <Pressable key={m} onPress={() => setMode(m)} style={[styles.segItem, scheme === m && styles.segOn]}>
                  <Text style={[styles.segText, scheme === m && styles.segTextOn]}>{label}</Text>
                </Pressable>
              ))}
            </View>
          </View>
          ) : null}
          <View style={[styles.setting, { borderBottomWidth: 0 }]}>
            <View style={styles.switchRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.settingLabel}>{t('Sounds')}</Text>
                <Text style={styles.settingHint}>{t('Coin and answer sounds in lessons. The star is always silent.')}</Text>
              </View>
              <GoldSwitch
                blue={c.scheme !== 'light'}
                value={soundsOn}
                onValueChange={toggleSounds}
                accessibilityLabel={t('Sounds')}
              />
            </View>
          </View>
        </Fold>

        <Fold
          icon="person"
          title={t('Account')}
          summary={`${email || t('Not signed in')} · ${t(PLAN_LABELS[plan])} · ${LESSON_LANG_LABELS[lang]}`}
          open={open === 'account'}
          onToggle={() => toggle('account')}>
          <View style={styles.setting}>
            <Text style={styles.settingLabel}>{t('Language')}</Text>
            <Text style={styles.settingHint}>{t('Instructions and translations. The course itself is always Arabic.')}</Text>
            <View style={styles.segment}>
              {(Object.keys(LESSON_LANG_LABELS) as LessonLang[]).map((code) => (
                <Pressable key={code} onPress={() => chooseLang(code)} style={[styles.segItem, lang === code && styles.segOn]}>
                  <Text style={[styles.segText, lang === code && styles.segTextOn]}>{LESSON_LANG_LABELS[code]}</Text>
                </Pressable>
              ))}
            </View>
          </View>
          {session ? (
            <>
              <Row icon="mail" title={t('Email')} value={email} />
              <Row icon="credit_card" title={t('Plan & billing')} value={t(PLAN_LABELS[plan])} onPress={openBilling} />
              <Row icon="sync" title={t('Refresh plan')} onPress={refreshPlan} />
            </>
          ) : (
            <Row icon="login" title={t('Sign in')} gold onPress={() => router.push('/sign-in')} />
          )}
          <Row icon="replay" title={t('Replay onboarding')} onPress={() => router.push('/landing')} />
          <Row icon="shield" title={t('Privacy policy')} onPress={() => Linking.openURL(`${WEB_BASE}/privacy.html`).catch(() => {})} />
          <Row icon="description" title={t('Terms of use')} onPress={() => Linking.openURL(`${WEB_BASE}/terms.html`).catch(() => {})} />
          {/* Only when this build can buy through the store (key set); otherwise there is nothing to restore. */}
          {STORE_ENABLED ? <Row icon="settings_backup_restore" title={t('Restore purchases')} onPress={restorePurchases} /> : null}
          <Row
            icon="help"
            title={t('Help & contact')}
            value="admin@lisaany.com"
            onPress={() => Linking.openURL('mailto:admin@lisaany.com?subject=Lisaany%20app').catch(() => {})}
            last={!session}
          />
          {session ? <Row icon="logout" title={t('Sign out')} danger onPress={confirmSignOut} /> : null}
          {session ? <Row icon="delete" title={t('Delete account')} danger onPress={confirmDelete} last /> : null}
        </Fold>

        <Text style={styles.version}>{t('Lisaany · version {v}', { v: Constants.expoConfig?.version ?? '1.0.0' })}</Text>
      </ScrollView>
    </View>
  );
}

/** Soft coloured tile behind each settings icon (white cards). */
const TINTS: Record<string, { bg: string; fg: string }> = {
  school: { bg: '#FFF4DC', fg: '#D78B29' },
  bolt: { bg: '#FFF4DC', fg: '#D78B29' },
  person: { bg: '#E8F0FF', fg: '#477BDC' },
  mail: { bg: '#E8F0FF', fg: '#477BDC' },
  login: { bg: '#E6F5EC', fg: '#348967' },
  credit_card: { bg: '#FFF4DC', fg: '#D78B29' },
  sync: { bg: '#E8F0FF', fg: '#477BDC' },
  replay: { bg: '#F0EAFE', fg: '#7A56D8' },
  shield: { bg: '#FDECEC', fg: '#D64545' },
  description: { bg: '#FFF1E2', fg: '#D78B29' },
  settings_backup_restore: { bg: '#E6F5EC', fg: '#348967' },
  help: { bg: '#EEF0F4', fg: '#4A5568' },
  logout: { bg: '#EEF0F4', fg: '#4A5568' },
};
const tintOf = (icon: string) => TINTS[icon] ?? { bg: '#EEF0F4', fg: '#4A5568' };

function Stat({ icon, value, label, color }: { icon: string; value: number; label: string; color?: string }) {
  const { c } = useTheme();
  const styles = useStyles();
  return (
    <View style={styles.stat}>
      {c.scheme !== 'light' ? null : <CardFill radius={16} />}
      <Icon name={icon} size={19} color={color ?? c.gold} />
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel} numberOfLines={1}>
        {label}
      </Text>
    </View>
  );
}

function Fold({
  icon,
  title,
  summary,
  open,
  onToggle,
  children,
}: {
  icon: string;
  title: string;
  summary: string;
  open: boolean;
  onToggle: () => void;
  children: ReactNode;
}) {
  const { c } = useTheme();
  const styles = useStyles();
  const W = c.scheme !== 'light';
  return (
    <View style={[styles.fold, open && styles.foldOpen]}>
      {c.scheme !== 'light' ? null : <CardFill radius={18} />}
      <Pressable onPress={onToggle} style={({ pressed }) => [styles.foldHead, pressed && { opacity: 0.8 }]} accessibilityRole="button" accessibilityState={{ expanded: open }}>
        <View style={[styles.foldIcon, W && { backgroundColor: tintOf(icon).bg }]}>
          <Icon name={icon} size={20} color={W ? tintOf(icon).fg : c.gold} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.foldTitle}>{title}</Text>
          <Text style={styles.foldSummary} numberOfLines={1}>
            {summary}
          </Text>
        </View>
        <View style={W ? styles.foldChev : null}>
          <Icon name={open ? 'expand_less' : 'expand_more'} size={22} color={W ? '#477BDC' : c.gold} />
        </View>
      </Pressable>
      {open ? <View style={styles.foldBody}>{children}</View> : null}
    </View>
  );
}

function Row({
  icon,
  title,
  value,
  onPress,
  last,
  danger,
  gold,
}: {
  icon: string;
  title: string;
  value?: string;
  onPress?: () => void;
  last?: boolean;
  danger?: boolean;
  gold?: boolean;
}) {
  const { c } = useTheme();
  const styles = useStyles();
  const W = c.scheme !== 'light';
  const tone = tintOf(icon);
  const tint = danger ? (W ? '#D64545' : c.red) : W ? tone.fg : c.gold;
  return (
    <Pressable
      onPress={onPress}
      disabled={!onPress}
      style={({ pressed }) => [styles.row, !last && styles.rowLine, pressed && { backgroundColor: W ? '#F6F7FA' : c.raised }]}>
      <View style={[styles.rowIcon, W && { backgroundColor: danger ? '#FDECEC' : tone.bg }, !W && danger && styles.rowIconDanger]}>
        <Icon name={icon} size={18} color={tint} />
      </View>
      {W ? (
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={[styles.rowTitle, danger && { color: '#D64545' }]}>{title}</Text>
          {value ? (
            <Text style={styles.rowSub} numberOfLines={1}>
              {value}
            </Text>
          ) : null}
        </View>
      ) : (
        <Text style={[styles.rowTitle, danger && { color: c.red }, gold && { color: c.gold }]}>{title}</Text>
      )}
      {value && !W ? (
        <Text style={styles.rowValue} numberOfLines={1}>
          {value}
        </Text>
      ) : null}
      {onPress && !danger ? <Icon name="chevron_right" size={20} color={W ? '#65718A' : c.gold} /> : null}
    </Pressable>
  );
}

const useStyles = makeStyles((c) => {
  const light = c.scheme === 'light';
  // Galaxy: plain white cards with a grey hairline (the app's colour system).
  const box = light ? spaceCard(c) : { backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E7EAF0' };
  const ink = light ? c.text : '#15213B';
  const sub = light ? c.muted : '#65718A';
  const line = light ? c.line : '#EEF0F4';
  const goldEdge = light ? c.goldFill : 'rgba(214,178,90,0.45)';
  return {
    screen: { flex: 1, backgroundColor: c.bg },
    content: { paddingHorizontal: 20, paddingBottom: 40 , ...contentCap },

    who: light ? { flexDirection: 'row', alignItems: 'center', gap: 14 } : { flexDirection: 'row', alignItems: 'center', gap: 14, ...box, borderRadius: 18, padding: 16 },
    avatar: {
      width: 56,
      height: 56,
      borderRadius: 28,
      alignItems: 'center',
      justifyContent: 'center',
      borderWidth: 2,
      borderColor: 'rgba(230,184,90,0.45)',
    },
    avatarText: { fontFamily: Fonts.displayBold, fontSize: 24, color: c.onGold },
    name: { fontFamily: Fonts.bodyBold, fontSize: 20, color: ink },
    whoSub: { fontFamily: Fonts.body, fontSize: 14, color: sub, marginTop: 2 },
    whoBtn: {
      flexDirection: 'row',
      alignItems: 'center',
      alignSelf: 'flex-start',
      gap: 6,
      marginTop: 8,
      paddingHorizontal: 12,
      paddingVertical: 6,
      borderRadius: 16,
      borderWidth: 1.3,
      borderColor: light ? 'rgba(255,255,255,0.45)' : '#D5DAE3',
      backgroundColor: light ? 'rgba(255,255,255,0.08)' : '#FFFFFF',
    },
    whoBtnGold: light ? { borderColor: 'rgba(214,178,90,0.85)', backgroundColor: 'rgba(214,178,90,0.12)' } : { borderColor: '#E5AD3B', backgroundColor: '#FFFFFF' },
    whoBtnText: { fontFamily: Fonts.bodySemi, fontSize: 14, color: ink },

    // "Your journey" is the module you're on: space card with the gold ring.
    cardWrap: light ? { ...box, ...currentCard(c), borderRadius: 22, marginTop: 16 } : { ...box, borderRadius: 18, marginTop: 14 },
    plainWrap: { ...box, borderRadius: 18, marginTop: 14 },
    journey: { padding: 18 },
    eyebrow: { fontFamily: Fonts.bodyBold, fontSize: 11.5, letterSpacing: 1.6, color: light ? c.gold : '#B98522' },
    journeyTitle: { fontFamily: light ? Fonts.displayBold : Fonts.bodyBold, fontSize: 19, color: ink, marginTop: 6 },
    journeyAr: { fontFamily: Fonts.arabic, fontSize: 22, lineHeight: 36, color: light ? c.gold : ink, textAlign: 'right', writingDirection: 'rtl' },
    track: { height: 6, borderRadius: 3, backgroundColor: light ? c.track : '#E7EAF0', marginTop: 10, overflow: 'hidden' },
    fill: { height: 6, borderRadius: 3, backgroundColor: light ? c.goldFill : '#E5AD3B' },
    journeyFoot: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 8 },
    journeyFootText: { fontFamily: Fonts.body, fontSize: 13, color: sub },
    footText: { fontFamily: Fonts.body, fontSize: 13, color: sub },

    stats: { flexDirection: 'row', gap: 8, marginTop: 14 },
    stat: {
      flex: 1,
      alignItems: 'center',
      paddingVertical: 12,
      borderRadius: 16,
      ...box,
    },
    statValue: { fontFamily: Fonts.bodyBold, fontSize: 19, color: ink, marginTop: 3 },
    statLabel: { fontFamily: Fonts.bodyMedium, fontSize: 12.5, color: sub },

    unlock: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
      padding: 16,
    },
    unlockTitle: { fontFamily: Fonts.bodyBold, fontSize: 15.5, color: ink },
    unlockSub: { fontFamily: Fonts.body, fontSize: 13, color: sub, marginTop: 2 },
    // "See plans": solid gold, so the one way to Premium is unmistakable.
    pill: { paddingVertical: 10, paddingHorizontal: 14, borderRadius: 12, backgroundColor: light ? c.goldFill : '#182A60' },
    pillText: { fontFamily: Fonts.bodyBold, fontSize: 13.5, color: light ? c.onGold : '#FFFFFF' },

    section: { fontFamily: Fonts.bodyBold, fontSize: 12, letterSpacing: 1.8, color: light ? c.muted : '#AEBBD5', marginTop: 24, marginBottom: 4 },

    fold: { marginTop: 10, borderRadius: 18, ...box, overflow: 'hidden' },
    foldOpen: light ? { borderColor: goldEdge, borderTopColor: c.edge } : {},
    foldHead: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14 },
    foldIcon: {
      width: 38,
      height: 38,
      borderRadius: 12,
      backgroundColor: c.goldTint,
      alignItems: 'center',
      justifyContent: 'center',
    },
    foldTitle: { fontFamily: Fonts.bodyBold, fontSize: 17, color: ink },
    foldChev: { width: 34, height: 34, borderRadius: 17, backgroundColor: '#F1F3F7', alignItems: 'center', justifyContent: 'center', marginRight: 2 },
    foldSummary: { fontFamily: Fonts.body, fontSize: 13, color: sub, marginTop: 1 },
    foldBody: { borderTopWidth: 1, borderTopColor: line },

    weekBody: { padding: 14 },
    bars: { flexDirection: 'row', gap: 8 },
    barCol: { flex: 1, alignItems: 'center', gap: 6 },
    barBox: { height: 80, width: '100%', justifyContent: 'flex-end' },
    // Dark keeps its original, slightly brighter empty bar.
    bar: { width: '100%', borderRadius: 6, backgroundColor: light ? c.track : '#E7EAF0' },
    barLabel: { fontFamily: Fonts.bodyBold, fontSize: 12, color: sub },
    weekFoot: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 12 },

    setting: { padding: 14, borderBottomWidth: 1, borderBottomColor: line },
    settingLabel: { fontFamily: Fonts.bodyBold, fontSize: 15.5, color: ink },
    settingHint: { fontFamily: Fonts.body, fontSize: 13.5, lineHeight: 19, color: sub, marginTop: 2 },
    segment: { flexDirection: 'row', gap: 6, marginTop: 10 },
    switchRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
    signInLine: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 10, alignSelf: 'flex-start' },
    signInLineText: { fontFamily: Fonts.bodySemi, fontSize: 13.5, color: light ? c.gold : '#B98522' },
    segItem: {
      flex: 1,
      alignItems: 'center',
      paddingVertical: 10,
      borderRadius: 11,
      backgroundColor: light ? c.raised : '#F1F3F7',
    },
    segOn: { backgroundColor: light ? c.goldFill : '#FFE3A1' },
    // Dark keeps its original lighter grey label.
    segText: { fontFamily: Fonts.bodyBold, fontSize: 14, color: light ? c.muted : '#4A5568' },
    segTextOn: { color: light ? c.onGold : '#15213B' },

    row: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 13, paddingHorizontal: 14 },
    rowLine: { borderBottomWidth: 1, borderBottomColor: line },
    rowIcon: {
      width: 34,
      height: 34,
      borderRadius: 10,
      backgroundColor: c.goldTint,
      alignItems: 'center',
      justifyContent: 'center',
    },
    rowIconDanger: { backgroundColor: light ? 'rgba(208,76,76,0.1)' : 'rgba(224,112,112,0.12)' },
    rowTitle: { flex: light ? 1 : undefined, fontFamily: Fonts.bodyBold, fontSize: 15, color: ink },
    rowSub: { fontFamily: Fonts.body, fontSize: 13, color: sub, marginTop: 1 },
    rowValue: { flexShrink: 1, maxWidth: light ? 150 : 190, fontFamily: Fonts.body, fontSize: 13, color: sub },

    version: { fontFamily: Fonts.body, fontSize: 12.5, color: light ? c.faint : '#AEBBD5', textAlign: 'center', marginTop: 22 },
  };
});
