import Constants from 'expo-constants';
import { LinearGradient } from 'expo-linear-gradient';
import { useFocusEffect, useRouter } from 'expo-router';
import { useCallback, useState, type ReactNode } from 'react';
import { Alert, LayoutAnimation, Linking, Pressable, ScrollView, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Icon } from '@/components/icon';
import { PopPressable } from '@/components/pop-card';
import { Fonts, WEB_BASE } from '@/constants/lisaany';
import { billingPortal } from '@/lib/api';
import { useAuth } from '@/lib/auth-context';
import { MODULE_META, MODULES, type Module } from '@/lib/curriculum';
import { PLAN_LABELS } from '@/lib/plan';
import {
  getCompletedBlocks,
  getDailyGoal,
  getEngineProgress,
  getFirstSeen,
  getLastUnit,
  getWeekXp,
  setDailyGoal,
  unitDoneCount,
  type CompletedMap,
  type WeekDay,
} from '@/lib/progress';
import { getLessonLang, LESSON_LANG_LABELS, setLessonLang, type LessonLang } from '@/lib/settings';
import { cardSurface, makeStyles, useTheme, type ThemeMode } from '@/theme';

const GOALS = [10, 20, 40];
const MODES: { mode: ThemeMode; label: string }[] = [
  { mode: 'light', label: 'Light' },
  { mode: 'dark', label: 'Dark' },
  { mode: 'system', label: 'Match phone' },
];
const MODE_SUMMARY: Record<ThemeMode, string> = { light: 'Light', dark: 'Dark', system: 'Auto' };
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const DAY_NAMES = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

type Panel = 'week' | 'learning' | 'account' | null;

/** Profile: your journey and numbers first; the week, learning settings and
 *  account fold open when tapped. */
export default function ProfileScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { session, plan, signOut, refreshPlan } = useAuth();
  const { c, mode, setMode } = useTheme();
  const styles = useStyles();

  const [done, setDone] = useState<CompletedMap>({});
  const [xp, setXp] = useState(0);
  const [streak, setStreak] = useState(0);
  const [week, setWeek] = useState<WeekDay[]>([]);
  const [goal, setGoal] = useState(20);
  const [lang, setLang] = useState<LessonLang>('en');
  const [since, setSince] = useState<Date | null>(null);
  const [lastUnit, setLastUnitId] = useState<string | null>(null);
  const [open, setOpen] = useState<Panel>(null);

  useFocusEffect(
    useCallback(() => {
      let active = true;
      Promise.all([
        getCompletedBlocks(),
        getEngineProgress(),
        getWeekXp(),
        getDailyGoal(),
        getLessonLang(),
        getFirstSeen(),
        getLastUnit(),
      ]).then(([map, snap, wk, g, l, first, last]) => {
        if (!active) return;
        setDone(map);
        setXp(snap.xp);
        setStreak(snap.streak);
        setWeek(wk);
        setGoal(g);
        setLang(l);
        setSince(first);
        setLastUnitId(last?.unitId ?? null);
      });
      return () => {
        active = false;
      };
    }, [])
  );

  const toggle = (p: Panel) => {
    LayoutAnimation.configureNext(LayoutAnimation.create(220, 'easeInEaseOut', 'opacity'));
    setOpen((cur) => (cur === p ? null : p));
  };

  /* ── numbers ─────────────────────────────────────────────── */
  const user = session?.user;
  const meta = (user?.user_metadata ?? {}) as Record<string, unknown>;
  const email = user?.email ?? '';
  const name =
    (typeof meta.full_name === 'string' && meta.full_name) ||
    (typeof meta.name === 'string' && meta.name) ||
    (email ? email.split('@')[0] : '') ||
    'Guest';
  const displayName = name.charAt(0).toUpperCase() + name.slice(1);
  const joined = user?.created_at ? new Date(user.created_at) : since;

  const partsDone = Object.keys(done).length;
  let words = 0;
  for (const m of MODULES)
    for (const u of m.units)
      for (const b of u.blocks)
        if (done[`${u.id}:${b.id}`] && b.size?.unit === 'words') words += b.size.count;

  const moduleDone = (m: Module) => m.units.length > 0 && m.units.every((u) => u.blocks.length > 0 && unitDoneCount(u, done) >= u.blocks.length);
  const currentModule =
    MODULES.find((m) => lastUnit && m.units.some((u) => u.id === lastUnit) && !moduleDone(m)) ??
    MODULES.find((m) => !moduleDone(m)) ??
    MODULES[MODULES.length - 1];
  const lessonsDone = currentModule
    ? currentModule.units.filter((u) => u.blocks.length > 0 && unitDoneCount(u, done) >= u.blocks.length).length
    : 0;
  const lessonsTotal = currentModule?.units.length ?? 0;
  const modulesLeft = MODULES.filter((m) => !moduleDone(m) && m !== currentModule).length;
  const curMeta = currentModule ? MODULE_META[currentModule.id] : undefined;

  const weekTotal = week.reduce((a, d) => a + d.xp, 0);
  const todayIdx = Math.max(0, week.findIndex((d) => d.isToday));
  const daysSoFar = todayIdx + 1;
  const metDays = week.slice(0, daysSoFar).filter((d) => d.xp >= goal).length;
  const best = week.reduce<{ i: number; xp: number }>((b, d, i) => (d.xp > b.xp ? { i, xp: d.xp } : b), { i: -1, xp: 0 });
  const maxBar = Math.max(goal, ...week.map((d) => d.xp), 1);

  const paid = plan !== 'free';

  /* ── actions ─────────────────────────────────────────────── */
  const chooseGoal = (g: number) => {
    setGoal(g);
    setDailyGoal(g);
  };
  const chooseLang = (l: LessonLang) => {
    setLang(l);
    setLessonLang(l);
  };
  const openPlans = () =>
    session ? router.push('/plans') : router.push({ pathname: '/sign-in', params: { next: 'plans' } });
  const openBilling = async () => {
    if (!paid) return openPlans();
    try {
      const { url } = await billingPortal();
      await Linking.openURL(url);
    } catch (e) {
      Alert.alert('Could not open billing', e instanceof Error ? e.message : 'Please try again from lisaany.com.');
    }
  };
  const confirmSignOut = () =>
    Alert.alert('Sign out?', 'Your progress stays saved to your account.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Sign out', style: 'destructive', onPress: () => signOut() },
    ]);

  return (
    <View style={styles.screen}>
      <ScrollView
        contentContainerStyle={[styles.content, { paddingTop: insets.top + 14 }]}
        showsVerticalScrollIndicator={false}>
        {/* Who */}
        <View style={styles.who}>
          <LinearGradient colors={['#f6d98c', c.goldFill]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.avatar}>
            <Text style={styles.avatarText}>{displayName.charAt(0)}</Text>
          </LinearGradient>
          <View style={{ flex: 1 }}>
            <Text style={styles.name} numberOfLines={1}>
              {displayName}
            </Text>
            <Text style={styles.whoSub} numberOfLines={1}>
              {PLAN_LABELS[plan]} plan{joined ? ` · since ${MONTHS[joined.getMonth()]} ${joined.getFullYear()}` : ''}
            </Text>
          </View>
        </View>

        {/* Journey */}
        {currentModule ? (
          <PopPressable
            onPress={() => router.push({ pathname: '/module/[id]', params: { id: String(currentModule.id) } })}
            style={styles.cardWrap}
            scaleTo={1.02}>
            <LinearGradient colors={c.navyGrad} start={{ x: 0.2, y: 0 }} end={{ x: 0.8, y: 1 }} style={styles.journey}>
              <Text style={styles.eyebrow}>YOUR JOURNEY</Text>
              <Text style={styles.journeyTitle} numberOfLines={1}>
                Module {currentModule.id} · {currentModule.title}
              </Text>
              {curMeta ? <Text style={styles.journeyAr}>{curMeta.ar}</Text> : null}
              <View style={styles.track}>
                <View style={[styles.fill, { width: `${lessonsTotal ? Math.round((lessonsDone / lessonsTotal) * 100) : 0}%` }]} />
              </View>
              <View style={styles.journeyFoot}>
                <Text style={styles.journeyFootText}>
                  {lessonsDone} of {lessonsTotal} lessons
                </Text>
                <Text style={styles.journeyFootText}>
                  {modulesLeft === 0 ? 'Last module' : `${modulesLeft} module${modulesLeft === 1 ? '' : 's'} to go`}
                </Text>
              </View>
            </LinearGradient>
          </PopPressable>
        ) : null}

        {/* Numbers */}
        <View style={styles.stats}>
          <Stat icon="local_fire_department" color={c.orange} value={streak} label="day streak" />
          <Stat icon="bolt" value={xp} label="total XP" />
          <Stat icon="translate" value={words} label="words" />
          <Stat icon="check_circle" value={partsDone} label="parts done" />
        </View>

        {/* Upgrade (free plan only) */}
        {!paid ? (
          <PopPressable onPress={openPlans} style={styles.cardWrap} scaleTo={1.02}>
            <View style={styles.unlock}>
              <Icon name="crown" size={28} color={c.gold} />
              <View style={{ flex: 1 }}>
                <Text style={styles.unlockTitle}>Unlock all 47 lessons</Text>
                <Text style={styles.unlockSub}>Lessons 1.1, 1.2 and 1.3 are free</Text>
              </View>
              <View style={styles.pill}>
                <Text style={styles.pillText}>See plans</Text>
              </View>
            </View>
          </PopPressable>
        ) : null}

        {/* Progress */}
        <Text style={styles.section}>PROGRESS</Text>
        <Fold
          icon="bolt"
          title="This week"
          summary={`${weekTotal} XP · goal met ${metDays} of ${daysSoFar} day${daysSoFar === 1 ? '' : 's'}`}
          open={open === 'week'}
          onToggle={() => toggle('week')}>
          <View style={styles.weekBody}>
            <View style={styles.bars}>
              {week.map((d) => {
                const h = Math.max(4, Math.round((d.xp / maxBar) * 78));
                const met = d.xp >= goal;
                return (
                  <View key={d.day} style={styles.barCol}>
                    <View style={styles.barBox}>
                      <View
                        style={[
                          styles.bar,
                          { height: h },
                          met && { backgroundColor: 'rgba(230,184,90,0.55)' },
                          d.isToday && { backgroundColor: c.goldFill },
                        ]}
                      />
                    </View>
                    <Text style={[styles.barLabel, d.isToday && { color: c.gold }]}>{d.label}</Text>
                  </View>
                );
              })}
            </View>
            <View style={styles.weekFoot}>
              <Text style={styles.footText}>
                {best.i >= 0 ? `Best day: ${DAY_NAMES[best.i]} · ${best.xp} XP` : 'No XP yet this week'}
              </Text>
              <Text style={styles.footText}>Goal {goal} XP</Text>
            </View>
          </View>
        </Fold>

        {/* Settings */}
        <Text style={styles.section}>SETTINGS</Text>
        <Fold
          icon="track_changes"
          title="Learning"
          summary={`${goal} XP a day · ${LESSON_LANG_LABELS[lang]} · ${MODE_SUMMARY[mode]}`}
          open={open === 'learning'}
          onToggle={() => toggle('learning')}>
          <View style={styles.setting}>
            <Text style={styles.settingLabel}>Appearance</Text>
            <View style={styles.segment}>
              {MODES.map((m) => (
                <Pressable key={m.mode} onPress={() => setMode(m.mode)} style={[styles.segItem, mode === m.mode && styles.segOn]}>
                  <Text style={[styles.segText, mode === m.mode && styles.segTextOn]}>{m.label}</Text>
                </Pressable>
              ))}
            </View>
          </View>
          <View style={styles.setting}>
            <Text style={styles.settingLabel}>Daily goal</Text>
            <View style={styles.segment}>
              {GOALS.map((g) => (
                <Pressable key={g} onPress={() => chooseGoal(g)} style={[styles.segItem, goal === g && styles.segOn]}>
                  <Text style={[styles.segText, goal === g && styles.segTextOn]}>{g} XP</Text>
                </Pressable>
              ))}
            </View>
          </View>
          <View style={styles.setting}>
            <Text style={styles.settingLabel}>Lesson language</Text>
            <Text style={styles.settingHint}>Instructions and translations. The course itself is always Arabic.</Text>
            <View style={styles.segment}>
              {(Object.keys(LESSON_LANG_LABELS) as LessonLang[]).map((code) => (
                <Pressable key={code} onPress={() => chooseLang(code)} style={[styles.segItem, lang === code && styles.segOn]}>
                  <Text style={[styles.segText, lang === code && styles.segTextOn]}>{LESSON_LANG_LABELS[code]}</Text>
                </Pressable>
              ))}
            </View>
          </View>
          <Row icon="replay" title="Replay onboarding" onPress={() => router.push('/landing')} last />
        </Fold>

        <Fold
          icon="person"
          title="Account"
          summary={`${email || 'Not signed in'} · ${PLAN_LABELS[plan]}`}
          open={open === 'account'}
          onToggle={() => toggle('account')}>
          {session ? (
            <>
              <Row icon="mail" title="Email" value={email} />
              <Row icon="credit_card" title="Plan & billing" value={PLAN_LABELS[plan]} onPress={openBilling} />
              <Row icon="sync" title="Refresh plan" onPress={refreshPlan} />
            </>
          ) : (
            <Row icon="login" title="Sign in" gold onPress={() => router.push('/sign-in')} />
          )}
          <Row icon="shield" title="Privacy policy" onPress={() => Linking.openURL(`${WEB_BASE}/privacy.html`).catch(() => {})} />
          <Row icon="description" title="Terms of use" onPress={() => Linking.openURL(`${WEB_BASE}/terms.html`).catch(() => {})} />
          <Row icon="help" title="Help & contact" onPress={() => Linking.openURL(WEB_BASE).catch(() => {})} last={!session} />
          {session ? <Row icon="logout" title="Sign out" danger onPress={confirmSignOut} last /> : null}
        </Fold>

        <Text style={styles.version}>Lisaany · version {Constants.expoConfig?.version ?? '1.0.0'}</Text>
      </ScrollView>
    </View>
  );
}

function Stat({ icon, value, label, color }: { icon: string; value: number; label: string; color?: string }) {
  const { c } = useTheme();
  const styles = useStyles();
  return (
    <View style={styles.stat}>
      <Icon name={icon} size={19} color={color ?? c.gold} />
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel} numberOfLines={1}>
        {label}
      </Text>
    </View>
  );
}

function Fold({
  icon,
  title,
  summary,
  open,
  onToggle,
  children,
}: {
  icon: string;
  title: string;
  summary: string;
  open: boolean;
  onToggle: () => void;
  children: ReactNode;
}) {
  const { c } = useTheme();
  const styles = useStyles();
  return (
    <View style={[styles.fold, open && styles.foldOpen]}>
      <Pressable onPress={onToggle} style={({ pressed }) => [styles.foldHead, pressed && { opacity: 0.8 }]} accessibilityRole="button" accessibilityState={{ expanded: open }}>
        <View style={styles.foldIcon}>
          <Icon name={icon} size={20} color={c.gold} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.foldTitle}>{title}</Text>
          <Text style={styles.foldSummary} numberOfLines={1}>
            {summary}
          </Text>
        </View>
        <Icon name={open ? 'expand_less' : 'expand_more'} size={22} color={open ? c.gold : c.muted} />
      </Pressable>
      {open ? <View style={styles.foldBody}>{children}</View> : null}
    </View>
  );
}

function Row({
  icon,
  title,
  value,
  onPress,
  last,
  danger,
  gold,
}: {
  icon: string;
  title: string;
  value?: string;
  onPress?: () => void;
  last?: boolean;
  danger?: boolean;
  gold?: boolean;
}) {
  const { c } = useTheme();
  const styles = useStyles();
  const tint = danger ? c.red : c.gold;
  return (
    <Pressable
      onPress={onPress}
      disabled={!onPress}
      style={({ pressed }) => [styles.row, !last && styles.rowLine, pressed && { backgroundColor: c.raised }]}>
      <View style={[styles.rowIcon, danger && styles.rowIconDanger]}>
        <Icon name={icon} size={18} color={tint} />
      </View>
      <Text style={[styles.rowTitle, danger && { color: c.red }, gold && { color: c.gold }]}>{title}</Text>
      {value ? (
        <Text style={styles.rowValue} numberOfLines={1}>
          {value}
        </Text>
      ) : null}
      {onPress && !danger ? <Icon name="chevron_right" size={18} color={c.faint} /> : null}
    </Pressable>
  );
}

const useStyles = makeStyles((c) => {
  const light = c.scheme === 'light';
  // Stat tiles and folds: white cards with a navy top edge in light; the
  // original flat card in dark.
  const box = light ? cardSurface(c) : { backgroundColor: c.card, borderWidth: 1, borderColor: c.line };
  const goldEdge = light ? c.goldFill : 'rgba(230,184,90,0.45)';
  return {
    screen: { flex: 1, backgroundColor: c.bg },
    content: { paddingHorizontal: 20, paddingBottom: 40 },

    who: { flexDirection: 'row', alignItems: 'center', gap: 14 },
    avatar: {
      width: 56,
      height: 56,
      borderRadius: 28,
      alignItems: 'center',
      justifyContent: 'center',
      borderWidth: 2,
      borderColor: 'rgba(230,184,90,0.45)',
    },
    avatarText: { fontFamily: Fonts.displayBold, fontSize: 24, color: c.onGold },
    name: { fontFamily: Fonts.bodyBold, fontSize: 20, color: c.text },
    whoSub: { fontFamily: Fonts.body, fontSize: 13, color: c.muted, marginTop: 2 },

    cardWrap: { borderRadius: 22, marginTop: 16 },
    // "Your journey" hero stays navy in both themes.
    journey: { borderRadius: 21, padding: 18 },
    eyebrow: { fontFamily: Fonts.bodyBold, fontSize: 11, letterSpacing: 1.6, color: c.goldFill },
    journeyTitle: { fontFamily: Fonts.displayBold, fontSize: 19, color: c.onNavy, marginTop: 6 },
    journeyAr: { fontFamily: Fonts.arabic, fontSize: 19, lineHeight: 32, color: c.goldFill, textAlign: 'right', writingDirection: 'rtl' },
    // The track sits on the navy card in both themes, so it stays white-alpha.
    track: { height: 6, borderRadius: 3, backgroundColor: 'rgba(255,255,255,0.08)', marginTop: 10, overflow: 'hidden' },
    fill: { height: 6, borderRadius: 3, backgroundColor: c.goldFill },
    journeyFoot: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 8 },
    journeyFootText: { fontFamily: Fonts.body, fontSize: 12, color: light ? c.onNavyMuted : c.muted },
    footText: { fontFamily: Fonts.body, fontSize: 12, color: c.muted },

    stats: { flexDirection: 'row', gap: 8, marginTop: 14 },
    stat: {
      flex: 1,
      alignItems: 'center',
      paddingVertical: 12,
      borderRadius: 16,
      ...box,
    },
    statValue: { fontFamily: Fonts.bodyBold, fontSize: 19, color: c.text, marginTop: 3 },
    statLabel: { fontFamily: Fonts.body, fontSize: 11, color: c.muted },

    unlock: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
      padding: 16,
      borderRadius: 21,
      backgroundColor: c.card,
    },
    unlockTitle: { fontFamily: Fonts.bodyBold, fontSize: 15, color: c.text },
    unlockSub: { fontFamily: Fonts.body, fontSize: 12.5, color: c.muted, marginTop: 2 },
    pill: { paddingVertical: 9, paddingHorizontal: 14, borderRadius: 16, backgroundColor: c.goldFill },
    pillText: { fontFamily: Fonts.bodyBold, fontSize: 13, color: c.onGold },

    section: { fontFamily: Fonts.bodyBold, fontSize: 11.5, letterSpacing: 1.6, color: c.muted, marginTop: 24, marginBottom: 2 },

    fold: { marginTop: 10, borderRadius: 18, ...box, overflow: 'hidden' },
    foldOpen: { borderColor: goldEdge, borderTopColor: light ? c.edge : goldEdge },
    foldHead: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14 },
    foldIcon: {
      width: 38,
      height: 38,
      borderRadius: 12,
      backgroundColor: c.goldTint,
      alignItems: 'center',
      justifyContent: 'center',
    },
    foldTitle: { fontFamily: Fonts.bodyBold, fontSize: 16, color: c.text },
    foldSummary: { fontFamily: Fonts.body, fontSize: 12.5, color: c.muted, marginTop: 1 },
    foldBody: { borderTopWidth: 1, borderTopColor: c.line },

    weekBody: { padding: 14 },
    bars: { flexDirection: 'row', gap: 8 },
    barCol: { flex: 1, alignItems: 'center', gap: 6 },
    barBox: { height: 80, width: '100%', justifyContent: 'flex-end' },
    // Dark keeps its original, slightly brighter empty bar.
    bar: { width: '100%', borderRadius: 6, backgroundColor: light ? c.track : 'rgba(255,255,255,0.12)' },
    barLabel: { fontFamily: Fonts.bodyBold, fontSize: 11, color: c.muted },
    weekFoot: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 12 },

    setting: { padding: 14, borderBottomWidth: 1, borderBottomColor: c.line },
    settingLabel: { fontFamily: Fonts.bodySemi, fontSize: 14, color: c.text },
    settingHint: { fontFamily: Fonts.body, fontSize: 12, color: c.muted, marginTop: 2 },
    segment: { flexDirection: 'row', gap: 6, marginTop: 10 },
    segItem: {
      flex: 1,
      alignItems: 'center',
      paddingVertical: 10,
      borderRadius: 11,
      backgroundColor: c.raised,
    },
    segOn: { backgroundColor: c.goldFill },
    // Dark keeps its original lighter grey label.
    segText: { fontFamily: Fonts.bodyBold, fontSize: 13.5, color: light ? c.muted : '#c9d0dd' },
    segTextOn: { color: c.onGold },

    row: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 13, paddingHorizontal: 14 },
    rowLine: { borderBottomWidth: 1, borderBottomColor: c.line },
    rowIcon: {
      width: 34,
      height: 34,
      borderRadius: 10,
      backgroundColor: c.goldTint,
      alignItems: 'center',
      justifyContent: 'center',
    },
    rowIconDanger: { backgroundColor: light ? 'rgba(208,76,76,0.1)' : 'rgba(224,112,112,0.12)' },
    rowTitle: { flex: 1, fontFamily: Fonts.bodySemi, fontSize: 14.5, color: c.text },
    rowValue: { maxWidth: 150, fontFamily: Fonts.body, fontSize: 13, color: c.muted },

    version: { fontFamily: Fonts.body, fontSize: 11.5, color: c.faint, textAlign: 'center', marginTop: 22 },
  };
});
