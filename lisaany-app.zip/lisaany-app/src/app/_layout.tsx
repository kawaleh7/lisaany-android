// Deep imports, one per weight: importing from a package index pulls every
// weight it ships, which added ~11 MB of unused fonts to the bundle.
import { Amiri_400Regular } from '@expo-google-fonts/amiri/400Regular';
import { Amiri_700Bold } from '@expo-google-fonts/amiri/700Bold';
import { Cinzel_400Regular } from '@expo-google-fonts/cinzel/400Regular';
import { Cinzel_600SemiBold } from '@expo-google-fonts/cinzel/600SemiBold';
import { Cinzel_700Bold } from '@expo-google-fonts/cinzel/700Bold';
import { Inter_400Regular } from '@expo-google-fonts/inter/400Regular';
import { Inter_500Medium } from '@expo-google-fonts/inter/500Medium';
import { Inter_600SemiBold } from '@expo-google-fonts/inter/600SemiBold';
import { Inter_700Bold } from '@expo-google-fonts/inter/700Bold';
import { NotoNaskhArabic_400Regular } from '@expo-google-fonts/noto-naskh-arabic/400Regular';
import { MaterialSymbolsOutlined_400Regular } from '@expo-google-fonts/material-symbols-outlined/400Regular';
import { useFonts } from 'expo-font';
import { DarkTheme, ThemeProvider } from 'expo-router';
import { Stack } from 'expo-router/stack';
import * as SplashScreen from 'expo-splash-screen';
import { StatusBar } from 'expo-status-bar';
import { useEffect } from 'react';
import { View } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';

import { Colors, Fonts } from '@/constants/lisaany';
import { AppThemeProvider, useTheme } from '@/theme';
import { AuthProvider } from '@/lib/auth-context';

SplashScreen.preventAutoHideAsync().catch(() => {
  /* already hidden */
});

const LisaanyTheme = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    background: Colors.bg,
    card: Colors.s1,
    text: Colors.text,
    border: Colors.border,
    primary: Colors.gold,
  },
};

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Cinzel_400Regular,
    Cinzel_600SemiBold,
    Cinzel_700Bold,
    Amiri_400Regular,
    Amiri_700Bold,
    NotoNaskhArabic_400Regular,
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
    MaterialSymbolsOutlined_400Regular,
  });

  useEffect(() => {
    // Show the app once the faces are ready — or anyway if they failed, so a
    // font problem never leaves the user staring at a splash screen.
    if (fontsLoaded || fontError) SplashScreen.hideAsync().catch(() => {});
  }, [fontsLoaded, fontError]);

  if (!fontsLoaded && !fontError) {
    return <View style={{ flex: 1, backgroundColor: Colors.bg }} />;
  }

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <AuthProvider>
        <AppThemeProvider>
          <ThemedStack />
        </AppThemeProvider>
      </AuthProvider>
    </GestureHandlerRootView>
  );
}

function ThemedStack() {
  const { c, scheme } = useTheme();
  return (
        <ThemeProvider value={{ ...LisaanyTheme, dark: scheme === 'dark', colors: { ...LisaanyTheme.colors, background: c.bg, card: c.bg, text: c.text, border: c.line } }}>
          <StatusBar style={scheme === 'light' ? 'dark' : 'light'} />
          <Stack
            screenOptions={{
              headerStyle: { backgroundColor: c.bg },
              headerTintColor: c.text,
              headerTitleStyle: { fontFamily: Fonts.display, fontSize: 17 },
              headerShadowVisible: false,
              contentStyle: { backgroundColor: c.bg },
            }}>
            <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
            <Stack.Screen name="landing" options={{ headerShown: false }} />
            <Stack.Screen name="landing-alt" options={{ headerShown: false }} />
            <Stack.Screen name="onboarding/goal" options={{ headerShown: false }} />
            <Stack.Screen name="onboarding/reader-check" options={{ headerShown: false }} />
            <Stack.Screen name="onboarding/confirm" options={{ headerShown: false }} />
            <Stack.Screen name="module/[id]" options={{ headerShown: false }} />
            <Stack.Screen name="sign-in" options={{ title: 'Sign in', presentation: 'modal' }} />
            <Stack.Screen name="plans" options={{ headerShown: false, presentation: 'modal' }} />
            <Stack.Screen name="premium-welcome" options={{ headerShown: false, animation: 'fade' }} />
            <Stack.Screen name="unit/[id]" options={{ headerShown: false }} />
            <Stack.Screen name="norania/index" options={{ headerShown: false }} />
            <Stack.Screen name="norania/[step]" options={{ headerShown: false }} />
            <Stack.Screen name="norania-reward/[i]" options={{ headerShown: false, animation: 'fade' }} />
            <Stack.Screen name="norania-certificate/[step]" options={{ headerShown: false }} />
            <Stack.Screen
              name="norania-lesson/[i]"
              options={{ headerShown: false, presentation: 'fullScreenModal', animation: 'fade' }}
            />
            <Stack.Screen
              name="lesson/[unit]"
              options={{ headerShown: false, presentation: 'fullScreenModal', animation: 'fade' }}
            />
          </Stack>
        </ThemeProvider>
  );
}
