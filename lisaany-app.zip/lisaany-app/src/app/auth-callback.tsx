/**
 * Landing spot for lisaany://auth-callback (Google sign-in returning to the
 * app). The sign-in screen finishes the job; this only makes sure the link
 * never shows "page not found" and steps back to where the learner was.
 */
import { useRouter } from 'expo-router';
import { useEffect } from 'react';
import { View } from 'react-native';

import { useTheme } from '@/theme';

export default function AuthCallback() {
  const router = useRouter();
  const { c } = useTheme();
  useEffect(() => {
    const id = setTimeout(() => (router.canGoBack() ? router.back() : router.replace('/')), 50);
    return () => clearTimeout(id);
  }, [router]);
  return <View style={{ flex: 1, backgroundColor: c.bg }} />;
}
