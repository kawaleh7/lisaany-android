import { LinearGradient } from 'expo-linear-gradient';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useEffect, useMemo, useRef, useState } from 'react';
import { AccessibilityInfo, Animated, Easing, Pressable, StyleSheet, Text, useWindowDimensions, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Svg, { Circle, Defs, G, Path, RadialGradient, Stop } from 'react-native-svg';

import { Icon } from '@/components/icon';
import { GoldStar } from '@/components/star-flight';
import { Fonts } from '@/constants/lisaany';
import { getObjectives, getUnit } from '@/lib/curriculum';
import { useLang } from '@/lib/i18n';
import { nextUnitAfter, unitStats } from '@/lib/lesson-summary';
import { getCompletedBlocks, nextBlockFor } from '@/lib/progress';

/**
 * "Mabrook! Lesson complete": shown once, right after the last part of a
 * lesson is finished. Gold rays, the star medal, three confetti bursts, the
 * numbers counting up, then the next lesson one tap away. Silent.
 */
const GOLD = '#E8C86A';
const MEDAL = 150;
const CONFETTI = ['#FFD84A', '#E8C86A', '#FFF1B8', '#D6A93A', '#FFFFFF'];

export default function Celebrate() {
  const { unit: unitParam } = useLocalSearchParams<{ unit: string }>();
  const unitId = String(unitParam);
  const unit = getUnit(unitId);
  const next = nextUnitAfter(unitId);
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const { t, ct, objectives: objectivesFor } = useLang();
  const stats = unit ? unitStats(unit) : { words: 0, conversations: 0 };
  const goal = objectivesFor(unitId, getObjectives(unitId))[0];

  const [calm, setCalm] = useState(false);
  useEffect(() => {
    AccessibilityInfo.isReduceMotionEnabled().then(setCalm).catch(() => {});
  }, []);

  const medalY = insets.top + 70 + MEDAL / 2;

  // Timeline (ms): medal .15s · ring .75s · text .9–1.2s · numbers 1.4s · message 2.2s · next 2.5s
  const a = useRef({
    rays: new Animated.Value(0),
    spin: new Animated.Value(0),
    glow: new Animated.Value(0),
    medal: new Animated.Value(0),
    ring: new Animated.Value(0),
    ar: new Animated.Value(0),
    title: new Animated.Value(0),
    sub: new Animated.Value(0),
    n1: new Animated.Value(0),
    n2: new Animated.Value(0),
    msg: new Animated.Value(0),
    next: new Animated.Value(0),
    beat: new Animated.Value(0),
  }).current;

  const [count, setCount] = useState({ w: 0, c: 0 });

  useEffect(() => {
    if (calm) {
      Object.values(a).forEach((v) => v.setValue(1));
      setCount({ w: stats.words, c: stats.conversations });
      return;
    }
    const tm = (v: Animated.Value, delay: number, duration = 600, easing = Easing.out(Easing.cubic)) =>
      Animated.timing(v, { toValue: 1, delay, duration, easing, useNativeDriver: true });
    const anims = [
      tm(a.rays, 200, 800),
      tm(a.glow, 0, 600),
      tm(a.medal, 150, 900, Easing.out(Easing.back(1.8))),
      tm(a.ring, 750, 1100),
      tm(a.ar, 900),
      tm(a.title, 1050),
      tm(a.sub, 1200),
      tm(a.n1, 1400, 500, Easing.out(Easing.back(2))),
      tm(a.n2, 1550, 500, Easing.out(Easing.back(2))),
      tm(a.msg, 2200),
      tm(a.next, 2500, 700, Easing.out(Easing.back(1.2))),
    ];
    Animated.parallel(anims).start();
    const spin = Animated.loop(Animated.timing(a.spin, { toValue: 1, duration: 28000, easing: Easing.linear, useNativeDriver: true }));
    spin.start();
    const beat = Animated.loop(
      Animated.sequence([
        Animated.timing(a.beat, { toValue: 1, duration: 900, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
        Animated.timing(a.beat, { toValue: 0, duration: 900, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      ])
    );
    const beatStart = setTimeout(() => beat.start(), 3300);
    // numbers count up
    const t0 = Date.now() + 1500;
    const tick = setInterval(() => {
      const k = Math.min(1, Math.max(0, (Date.now() - t0) / 900));
      const e = 1 - Math.pow(1 - k, 3);
      setCount({ w: Math.round(stats.words * e), c: Math.round(stats.conversations * e) });
      if (k >= 1) clearInterval(tick);
    }, 40);
    return () => {
      spin.stop();
      beat.stop();
      clearTimeout(beatStart);
      clearInterval(tick);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [calm]);

  const rise = (v: Animated.Value, dy = 18) => ({
    opacity: v,
    transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [dy, 0] }) }],
  });
  const pop = (v: Animated.Value) => ({
    opacity: v.interpolate({ inputRange: [0, 0.3, 1], outputRange: [0, 1, 1] }),
    transform: [{ scale: v.interpolate({ inputRange: [0, 1], outputRange: [0.4, 1] }) }],
  });

  const close = () => (router.canGoBack() ? router.back() : router.replace('/'));
  const openNext = async () => {
    if (!next) {
      router.replace('/lessons');
      return;
    }
    const done = await getCompletedBlocks().catch(() => ({}));
    router.replace({ pathname: '/lesson/[unit]', params: { unit: next.id, block: String(nextBlockFor(next, done)) } });
  };
  const again = () => {
    const first = unit?.blocks[0]?.id;
    if (first == null) return close();
    router.replace({ pathname: '/lesson/[unit]', params: { unit: unitId, block: String(first) } });
  };

  const message = goal
    ? t('Now you can {goal}.', { goal })
    : t('You finished {title}.', { title: unit ? ct(unit.title) : '' });

  return (
    <View style={s.screen}>
      <Stack.Screen options={{ headerShown: false }} />
      <StatusBar style="light" />
      <LinearGradient colors={['#2b3e6b', '#121b33', '#070c18']} locations={[0, 0.5, 1]} style={StyleSheet.absoluteFill} />

      {/* rays + glow behind the medal */}
      <Animated.View
        pointerEvents="none"
        style={[
          s.rays,
          {
            top: medalY - 450,
            left: width / 2 - 450,
            opacity: a.rays,
            transform: [{ rotate: a.spin.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] }) }],
          },
        ]}>
        <Rays />
      </Animated.View>
      <Animated.View
        pointerEvents="none"
        style={[
          s.glow,
          {
            top: medalY - 160,
            left: width / 2 - 160,
            opacity: a.glow,
            transform: [{ scale: a.beat.interpolate({ inputRange: [0, 1], outputRange: [1, 1.1] }) }],
          },
        ]}>
        <Svg width={320} height={320}>
          <Defs>
            <RadialGradient id="glow" cx="0.5" cy="0.5" r="0.5">
              <Stop offset="0" stopColor="#FFD66E" stopOpacity="0.55" />
              <Stop offset="0.65" stopColor="#FFD66E" stopOpacity="0" />
            </RadialGradient>
          </Defs>
          <Circle cx="160" cy="160" r="160" fill="url(#glow)" />
        </Svg>
      </Animated.View>

      {/* ring burst */}
      <Animated.View
        pointerEvents="none"
        style={[
          s.ring,
          {
            top: medalY - MEDAL / 2,
            left: width / 2 - MEDAL / 2,
            opacity: a.ring.interpolate({ inputRange: [0, 0.01, 1], outputRange: [0, 1, 0] }),
            transform: [{ scale: a.ring.interpolate({ inputRange: [0, 1], outputRange: [0.8, 2.6] }) }],
          },
        ]}
      />

      {/* medal */}
      <Animated.View
        style={[
          s.medal,
          {
            top: medalY - MEDAL / 2,
            left: width / 2 - MEDAL / 2,
            opacity: a.medal.interpolate({ inputRange: [0, 0.4, 1], outputRange: [0, 1, 1] }),
            transform: [
              { scale: a.medal.interpolate({ inputRange: [0, 1], outputRange: [3, 1] }) },
              { rotate: a.medal.interpolate({ inputRange: [0, 1], outputRange: ['-25deg', '0deg'] }) },
            ],
          },
        ]}>
        <LinearGradient colors={['#f7dd8e', '#c8971f']} style={s.medalRim}>
          <View style={s.medalFace}>
            <GoldStar size={112} halo={false} />
          </View>
        </LinearGradient>
      </Animated.View>

      <Pressable onPress={close} hitSlop={10} style={[s.x, { top: insets.top + 12 }]} accessibilityLabel={t('Close')}>
        <Icon name="close" size={22} color="#aab3c5" />
      </Pressable>

      {/* words */}
      <View style={[s.txt, { top: medalY + MEDAL / 2 + 26 }]}>
        <Animated.Text style={[s.mab, rise(a.ar)]}>{'مَبْرُوك!'}</Animated.Text>
        <Animated.Text style={[s.big, rise(a.title)]} adjustsFontSizeToFit numberOfLines={1}>
          {t('LESSON COMPLETE')}
        </Animated.Text>
        <Animated.Text style={[s.sub, rise(a.sub)]} numberOfLines={2}>
          {t('You finished {title}', { title: unit ? ct(unit.title) : '' })}
        </Animated.Text>
        <View style={s.nums}>
          {stats.words > 0 ? (
            <Animated.View style={[s.num, pop(a.n1)]}>
              <Text style={s.numBig}>{count.w}</Text>
              <Text style={s.numLbl}>{t('new words')}</Text>
            </Animated.View>
          ) : null}
          {stats.conversations > 0 ? (
            <Animated.View style={[s.num, pop(a.n2)]}>
              <Text style={s.numBig}>{count.c}</Text>
              <Text style={s.numLbl}>{stats.conversations === 1 ? t('conversation') : t('conversations')}</Text>
            </Animated.View>
          ) : null}
        </View>
        <Animated.Text style={[s.msg, rise(a.msg)]}>
          {message}
          {'\n'}
          {next ? t("Let's keep building your fluency!") : t('You finished the whole course!')}
        </Animated.Text>
      </View>

      {/* next */}
      <Animated.View
        style={[
          s.next,
          { bottom: insets.bottom + 16 },
          { transform: [{ translateY: a.next.interpolate({ inputRange: [0, 1], outputRange: [320, 0] }) }] },
        ]}>
        {next ? (
          <View style={s.nextCard}>
            <View style={s.nextNum}>
              <Text style={s.nextNumTxt}>{next.id}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={s.nextLbl}>{t('UP NEXT')}</Text>
              <Text style={s.nextTitle} numberOfLines={1}>
                {ct(next.title)}
              </Text>
            </View>
          </View>
        ) : null}
        <Animated.View
          style={{ transform: [{ scale: a.beat.interpolate({ inputRange: [0, 1], outputRange: [1, 1.035] }) }] }}>
          <Pressable onPress={openNext} accessibilityRole="button" style={({ pressed }) => [pressed && { opacity: 0.9 }]}>
            <LinearGradient colors={['#f3d27a', '#d6a93a']} style={s.cta}>
              <Text style={s.ctaTxt}>{next ? t('Start lesson {id}', { id: next.id }) : t('Back to lessons')}</Text>
              <Icon name="arrow_forward" size={20} color="#1d1400" />
            </LinearGradient>
          </Pressable>
        </Animated.View>
        <Pressable onPress={again} hitSlop={6} style={s.again}>
          <Icon name="replay" size={17} color={GOLD} />
          <Text style={s.againTxt}>{t('Start from the beginning')}</Text>
        </Pressable>
      </Animated.View>

      {calm ? null : <Confetti originY={medalY} />}
    </View>
  );
}

/** Soft gold wedges fading out from the centre. */
function Rays() {
  const wedges = useMemo(() => {
    const out: string[] = [];
    const n = 20;
    for (let i = 0; i < n; i++) {
      const a0 = ((i * 360) / n) * (Math.PI / 180);
      const a1 = a0 + 6 * (Math.PI / 180);
      out.push(`M450 450 L${450 + Math.cos(a0) * 450} ${450 + Math.sin(a0) * 450} L${450 + Math.cos(a1) * 450} ${450 + Math.sin(a1) * 450} Z`);
    }
    return out;
  }, []);
  return (
    <Svg width={900} height={900}>
      <Defs>
        <RadialGradient id="ray" cx="0.5" cy="0.5" r="0.5">
          <Stop offset="0" stopColor="#E8C86A" stopOpacity="0.3" />
          <Stop offset="0.35" stopColor="#E8C86A" stopOpacity="0.18" />
          <Stop offset="1" stopColor="#E8C86A" stopOpacity="0" />
        </RadialGradient>
      </Defs>
      <G>
        {wedges.map((d, i) => (
          <Path key={i} d={d} fill="url(#ray)" />
        ))}
      </G>
    </Svg>
  );
}

type Bit = { v: Animated.Value; x: number[]; y: number[]; rot: string; color: string; star: boolean; size: number; delay: number; dur: number };

/** Three bursts of gold stars and ribbons, falling under a little gravity. */
function Confetti({ originY }: { originY: number }) {
  const { width, height } = useWindowDimensions();
  const bits = useMemo(() => {
    const make = (cx: number, cy: number, n: number, speed: number, delay: number, lift: number): Bit[] =>
      Array.from({ length: n }, (_, i) => {
        const ang = Math.random() * Math.PI * 2;
        const v = speed * (0.4 + Math.random());
        const vx = Math.cos(ang) * v;
        const vy = Math.sin(ang) * v - lift;
        const steps = [0, 0.2, 0.4, 0.6, 0.8, 1];
        const T = 90; // frames
        const x = steps.map((k) => cx + vx * T * k * (1 - 0.25 * k));
        const y = steps.map((k) => cy + vy * T * k + 0.5 * 0.18 * (T * k) * (T * k));
        return {
          v: new Animated.Value(0),
          x,
          y,
          rot: `${(Math.random() - 0.5) * 900}deg`,
          color: CONFETTI[i % CONFETTI.length],
          star: Math.random() < 0.45,
          size: 6 + Math.random() * 9,
          delay,
          dur: 1900 + Math.random() * 700,
        };
      });
    return [
      ...make(width / 2, originY, 46, 8, 700, 3),
      ...make(34, originY - 110, 20, 6.5, 1300, 3),
      ...make(width - 34, originY - 110, 20, 6.5, 1300, 3),
      ...make(width / 2, -10, 24, 3.5, 2100, 0),
    ];
  }, [width, originY]);

  useEffect(() => {
    Animated.parallel(
      bits.map((b) =>
        Animated.timing(b.v, { toValue: 1, delay: b.delay, duration: b.dur, easing: Easing.linear, useNativeDriver: true })
      )
    ).start();
  }, [bits]);

  const steps = [0, 0.2, 0.4, 0.6, 0.8, 1];
  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill}>
      {bits.map((b, i) => (
        <Animated.View
          key={i}
          style={{
            position: 'absolute',
            left: 0,
            top: 0,
            opacity: b.v.interpolate({ inputRange: [0, 0.01, 0.75, 1], outputRange: [0, 1, 1, 0] }),
            transform: [
              { translateX: b.v.interpolate({ inputRange: steps, outputRange: b.x }) },
              { translateY: b.v.interpolate({ inputRange: steps, outputRange: b.y.map((y) => Math.min(y, height + 40)) }) },
              { rotate: b.v.interpolate({ inputRange: [0, 1], outputRange: ['0deg', b.rot] }) },
            ],
          }}>
          {b.star ? (
            <Text style={{ color: b.color, fontSize: b.size + 6, lineHeight: b.size + 8 }}>★</Text>
          ) : (
            <View style={{ width: b.size * 1.6, height: b.size * 0.55, backgroundColor: b.color, borderRadius: 1 }} />
          )}
        </Animated.View>
      ))}
    </View>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#070c18', overflow: 'hidden' },
  rays: { position: 'absolute', width: 900, height: 900 },
  glow: { position: 'absolute', width: 320, height: 320 },
  ring: { position: 'absolute', width: MEDAL, height: MEDAL, borderRadius: MEDAL / 2, borderWidth: 3, borderColor: 'rgba(255,220,120,0.9)' },
  medal: {
    position: 'absolute',
    width: MEDAL,
    height: MEDAL,
    shadowColor: '#FFC850',
    shadowOpacity: 0.6,
    shadowRadius: 26,
    shadowOffset: { width: 0, height: 8 },
    elevation: 14,
  },
  medalRim: { flex: 1, borderRadius: MEDAL / 2, padding: 9 },
  medalFace: { flex: 1, borderRadius: MEDAL / 2, backgroundColor: '#1a2440', alignItems: 'center', justifyContent: 'center' },
  x: {
    position: 'absolute',
    right: 16,
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 5,
  },
  txt: { position: 'absolute', left: 0, right: 0, alignItems: 'center', paddingHorizontal: 22 },
  mab: { fontFamily: Fonts.naskh, fontSize: 40, lineHeight: 64, color: GOLD, textShadowColor: 'rgba(232,200,106,0.55)', textShadowRadius: 18 },
  big: { fontFamily: Fonts.displayBold, fontSize: 28, letterSpacing: 1, color: '#FFF6DA', marginTop: -2, textAlign: 'center' },
  sub: { fontFamily: Fonts.body, fontSize: 15, color: '#dfe5f0', marginTop: 6, textAlign: 'center' },
  nums: { flexDirection: 'row', gap: 10, marginTop: 18 },
  num: {
    minWidth: 104,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.07)',
    borderWidth: 1,
    borderColor: 'rgba(232,200,106,0.35)',
    alignItems: 'center',
  },
  numBig: { fontFamily: Fonts.bodyBold, fontSize: 28, color: GOLD, fontVariant: ['tabular-nums'] },
  numLbl: { fontFamily: Fonts.body, fontSize: 12, color: '#aab3c5' },
  msg: { fontFamily: Fonts.bodySemi, fontSize: 16, lineHeight: 23, color: '#ffffff', textAlign: 'center', marginTop: 18 },
  next: { position: 'absolute', left: 18, right: 18 },
  nextCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 12,
    borderRadius: 18,
    backgroundColor: '#2c3a5d',
    borderWidth: 1,
    borderColor: 'rgba(214,178,90,0.45)',
  },
  nextNum: { width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(214,178,90,0.2)', alignItems: 'center', justifyContent: 'center' },
  nextNumTxt: { fontFamily: Fonts.bodyBold, fontSize: 13, color: GOLD },
  nextLbl: { fontFamily: Fonts.bodyBold, fontSize: 10.5, letterSpacing: 1.6, color: '#aab3c5' },
  nextTitle: { fontFamily: Fonts.bodyBold, fontSize: 16, color: '#ffffff', marginTop: 2 },
  cta: { marginTop: 12, height: 58, borderRadius: 29, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10 },
  ctaTxt: { fontFamily: Fonts.bodyBold, fontSize: 17, color: '#1d1400' },
  again: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 12 },
  againTxt: { fontFamily: Fonts.bodyBold, fontSize: 14, color: GOLD },
});
