import { useRouter } from 'expo-router';
import { StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Icon } from '@/components/icon';
import { ArabicLine, Body, Button, Card } from '@/components/ui';
import { Colors, Fonts, Radius, Spacing, Tracking } from '@/constants/lisaany';
import { setHasSeenLanding } from '@/lib/onboarding';

/**
 * Alternate landing screen — simpler than `landing.tsx`'s mosque hero: a
 * wordmark, headline, one CTA, and a live-looking vocabulary card that shows
 * off the actual lesson experience instead of an illustration. Reachable
 * from Profile → "Preview landing (alt)" for comparison; not wired into the
 * real first-launch redirect yet.
 */
export default function LandingAltScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const go = () => {
    setHasSeenLanding();
    router.replace('/');
  };

  return (
    <View style={[styles.screen, { paddingTop: insets.top + 32, paddingBottom: insets.bottom + 24 }]}>
      <View style={styles.brand}>
        <Text style={styles.star}>✦</Text>
        <Text style={styles.brandName}>Lisaany</Text>
      </View>

      <View style={styles.headlineWrap}>
        <Text style={styles.headline}>
          Learn Arabic.{'\n'}
          <Text style={styles.headlineGold}>Connect to a bigger world.</Text>
        </Text>
        <Body style={styles.sub}>
          Audio-first lessons, 47 units, and every word explained — free to begin.
        </Body>
      </View>

      <Button label="Start learning" icon="arrow_forward" onPress={go} />

      {/* A live-looking taste of a lesson, right on the landing screen. */}
      <Card variant="hero" style={styles.previewCard}>
        <View style={styles.previewRow}>
          <View style={styles.previewChip}>
            <Icon name="volume_up" size={18} color={Colors.gold} />
          </View>
          <Text style={styles.previewLabel}>Today's word</Text>
        </View>
        <ArabicLine size={38} style={styles.previewArabic}>
          مرحبا
        </ArabicLine>
        <Text style={styles.previewTranslit}>Marhaban</Text>
        <Text style={styles.previewEnglish}>Hello</Text>
      </Card>

      <Body style={styles.fine}>Free to begin · No card required</Body>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Colors.bg, paddingHorizontal: Spacing.lg },

  brand: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginBottom: 40 },
  star: { color: Colors.gold, fontSize: 18 },
  brandName: {
    fontFamily: Fonts.display,
    fontSize: 16,
    letterSpacing: Tracking.heading,
    textTransform: 'uppercase',
    color: Colors.cream,
  },

  headlineWrap: { marginBottom: Spacing.lg },
  headline: {
    fontFamily: Fonts.display,
    fontSize: 32,
    lineHeight: 40,
    color: Colors.cream,
    textAlign: 'center',
    letterSpacing: Tracking.tight,
  },
  headlineGold: { color: Colors.gold },
  sub: {
    textAlign: 'center',
    marginTop: 14,
    fontSize: 14.5,
    lineHeight: 22,
    maxWidth: 300,
    alignSelf: 'center',
  },

  previewCard: { marginTop: Spacing.xl, alignItems: 'center', paddingVertical: 26 },
  previewRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 18 },
  previewChip: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: 'rgba(242,190,98,0.10)',
    borderWidth: 1,
    borderColor: Colors.goldGlow,
    alignItems: 'center',
    justifyContent: 'center',
  },
  previewLabel: {
    fontFamily: Fonts.bodySemi,
    fontSize: 10,
    letterSpacing: Tracking.meta,
    textTransform: 'uppercase',
    color: Colors.dim,
    opacity: 0.75,
  },
  previewArabic: { marginBottom: 6 },
  previewTranslit: { fontFamily: Fonts.bodySemi, fontSize: 16, color: Colors.text },
  previewEnglish: { fontFamily: Fonts.body, fontSize: 13.5, color: Colors.dim, marginTop: 2, opacity: 0.8 },

  fine: {
    textAlign: 'center',
    fontSize: 12.5,
    marginTop: 'auto',
    paddingTop: Spacing.lg,
    opacity: 0.75,
  },
});
