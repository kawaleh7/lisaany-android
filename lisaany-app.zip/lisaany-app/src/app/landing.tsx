import { useFocusEffect, useRouter } from 'expo-router';
import { useCallback, useState } from 'react';
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import Svg, { Circle, Defs, RadialGradient, Stop } from 'react-native-svg';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { ArabicLine, Button } from '@/components/ui';
import { Colors, Fonts, Spacing, Tracking } from '@/constants/lisaany';
import { setHasSeenLanding } from '@/lib/onboarding';
import { getLessonLang, LESSON_LANG_LABELS, setLessonLang, type LessonLang } from '@/lib/settings';

/**
 * First screen a new install ever sees — built from the user's own approved
 * design (sample #1: dark, icon top, tagline, two CTAs, language toggle).
 * See `(tabs)/index.tsx` for the redirect that gets a fresh install here.
 */
export default function LandingScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [lang, setLang] = useState<LessonLang>('en');

  useFocusEffect(
    useCallback(() => {
      getLessonLang().then(setLang);
    }, [])
  );

  const chooseLang = (next: LessonLang) => {
    setLang(next);
    setLessonLang(next);
  };

  // No forced sign-in: "Get started" leads into the (account-free) goal +
  // reader-check onboarding, which itself drops into the app as a guest at
  // the end. "I already have an account" is the one path to real sign-in —
  // someone asking for it explicitly, not a gate everyone has to pass
  // through — so it skips onboarding and marks landing seen right away.
  const getStarted = () => {
    router.push('/onboarding/goal');
  };
  const signIn = () => {
    setHasSeenLanding();
    router.push('/sign-in');
  };

  return (
    <View style={[styles.screen, { paddingTop: insets.top + 24, paddingBottom: insets.bottom + 20 }]}>
      <View style={styles.top}>
        <View style={styles.markWrap}>
          <Svg width={220} height={220} style={StyleSheet.absoluteFill}>
            <Defs>
              <RadialGradient id="penGlow" cx="50%" cy="50%" r="50%">
                <Stop offset="0" stopColor={Colors.gold} stopOpacity={0.26} />
                <Stop offset="0.45" stopColor={Colors.gold} stopOpacity={0.1} />
                <Stop offset="1" stopColor={Colors.gold} stopOpacity={0} />
              </RadialGradient>
            </Defs>
            <Circle cx={110} cy={110} r={110} fill="url(#penGlow)" />
          </Svg>
          <Image source={require('@/assets/images/pen-mark.png')} style={styles.mark} />
        </View>
        <Text style={styles.wordmark}>LISAANY</Text>
        <ArabicLine size={20} style={styles.arabicSub}>
          تَعَلَّمِ العَرَبِيَة
        </ArabicLine>
        <Text style={styles.tagline}>
          Real Arabic.{'\n'}Real conversations.{'\n'}A wider world.
        </Text>
      </View>

      <View style={styles.bottom}>
        <View style={styles.actions}>
          <Button label="Get started →" onPress={getStarted} />
          <Button label="I already have an account" variant="ghost" onPress={signIn} />
        </View>

        <View style={styles.langRow}>
          {(Object.keys(LESSON_LANG_LABELS) as LessonLang[]).map((code, i) => (
            <View key={code} style={styles.langItem}>
              {i > 0 ? <Text style={styles.langDivider}>|</Text> : null}
              <Pressable onPress={() => chooseLang(code)} hitSlop={8}>
                <Text style={[styles.langText, code === lang && styles.langTextActive]}>
                  {LESSON_LANG_LABELS[code]}
                </Text>
              </Pressable>
            </View>
          ))}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Colors.bg, paddingHorizontal: Spacing.lg },

  top: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  markWrap: { width: 220, height: 220, alignItems: 'center', justifyContent: 'center', marginBottom: 18 },
  mark: { width: 176, height: 176 },
  wordmark: {
    fontFamily: Fonts.displayBold,
    fontSize: 24,
    letterSpacing: Tracking.heading,
    color: Colors.text,
    marginBottom: 10,
  },
  arabicSub: { textAlign: 'center', marginBottom: 18 },
  tagline: {
    fontFamily: Fonts.body,
    fontSize: 14.5,
    lineHeight: 23,
    color: Colors.dim,
    textAlign: 'center',
    opacity: 0.85,
  },

  bottom: {},
  actions: { gap: 2 },
  langRow: { flexDirection: 'row', justifyContent: 'center', marginTop: 22 },
  langItem: { flexDirection: 'row', alignItems: 'center' },
  langDivider: { fontSize: 12, color: Colors.dim, opacity: 0.4, marginHorizontal: 10 },
  langText: {
    fontFamily: Fonts.bodySemi,
    fontSize: 12.5,
    color: Colors.dim,
    opacity: 0.55,
  },
  langTextActive: { color: Colors.gold, opacity: 1 },
});
