import type { Session } from '@supabase/supabase-js';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  AppState,
  BackHandler,
  Linking,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Icon } from '@/components/icon';
import { LessonHost, type LessonHostHandle } from '@/components/lesson-host';
import { SpaceBackdrop } from '@/components/space-backdrop';
import { Button, ErrorNote } from '@/components/ui';
import { Colors, Fonts, WEB_BASE } from '@/constants/lisaany';
import { useTheme } from '@/theme';
import { useAuth } from '@/lib/auth-context';
import { flushCloudProgress, scheduleCloudPush } from '@/lib/cloud-progress';
import { getModuleForUnit, getUnit } from '@/lib/curriculum';
import { useLang } from '@/lib/i18n';
import {
  FLUSH_SCRIPT,
  LESSON_ORIGIN,
  setSessionScript,
  type BridgeMessage,
  type BridgeProgress,
  type HostFailure,
  type LessonConfig,
  type LessonView,
} from '@/lib/lesson-bridge';
import { canAccessUnit, getLastKnownUserId, getPlan } from '@/lib/plan';
import {
  applyEngineProgress,
  completedFromProg,
  getDailyGoal,
  getEngineProgress,
  getLastUnit,
  getTodayXp,
  getWeekXp,
  nextBlockFor,
  setLastUnit,
} from '@/lib/progress';
import { reportError, reportMessage } from '@/lib/report';
import { getLessonLang, getSoundsOn } from '@/lib/settings';
import { getMinGoal, getTodaySecs } from '@/lib/goal';
import { changeMinGoal, recordActiveSecs } from '@/lib/goal-sync';
import { supabase } from '@/lib/supabase';
import { contentCap } from '@/components/content-width';

const REVIEW_VIEWS: Record<string, LessonView> = {
  srsreview: 'srsreview',
  reviewBuilder: 'reviewBuilder',
  review: 'review',
};

/** After this long without the page's `opened`, offer a way out. */
const OPEN_TIMEOUT_MS = 8000;
/** The most the screen waits for the last progress upload before leaving. */
const FLUSH_WAIT_MS = 1500;
/** Time for the page's final `progress` message (after FLUSH_SCRIPT) to land. */
const SETTLE_MS = 200;

const wait = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

/** The two tokens the page needs, or null for a guest. */
const tokensOf = (s: Session | null | undefined): LessonConfig['session'] =>
  s ? { access_token: s.access_token, refresh_token: s.refresh_token } : null;

/** Is a CSS colour light enough to need dark status-bar icons? */
function isLight(color: string): boolean {
  const m = color.match(/(\d+(?:\.\d+)?)/g);
  if (!m || m.length < 3) return false;
  const [r, g, b] = m.map(Number);
  return 0.2126 * r + 0.7152 * g + 0.0722 * b > 150;
}

/**
 * A lesson, full screen: the website's lesson engine in a web view, framed by
 * the app. `unit` is a unit id ("1.1") with an optional `block`, or one of the
 * review views (srsreview, reviewBuilder).
 */
export default function LessonScreen() {
  const params = useLocalSearchParams<{ unit: string; block?: string }>();
  const unitParam = String(params.unit ?? '');
  const blockParam = params.block ? Number(params.block) : undefined;
  const reviewView = REVIEW_VIEWS[unitParam];

  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { session } = useAuth();
  const { c } = useTheme();
  const { t } = useLang();
  const host = useRef<LessonHostHandle>(null);

  const [cfg, setCfg] = useState<LessonConfig | null>(null);
  const [missing, setMissing] = useState(false);
  const [ready, setReady] = useState(false);
  /** The page has not said `opened` within OPEN_TIMEOUT_MS. */
  const [slow, setSlow] = useState(false);
  /** The web view gave up (load error, second crash): show the error state. */
  const [failed, setFailed] = useState(false);
  /** Bumped by "Try again": rebuilds the config and mounts a fresh web view. */
  const [attempt, setAttempt] = useState(0);
  /** Bumped whenever a page boot starts, to restart the "taking longer" timer. */
  const [boot, setBoot] = useState(0);
  const [edges, setEdges] = useState<{ top: string; bottom: string }>({ top: c.bg, bottom: c.bg });

  const leaving = useRef(false);
  const departing = useRef(false);
  const crashRetried = useRef(false);
  const sessionRef = useRef<Session | null>(null);
  /** The learner the open lesson belongs to (see the config effect). */
  const knownUid = useRef<string | null>(null);
  /** Snapshots are merged one after the other, in the order the page sent them. */
  const queue = useRef<Promise<void>>(Promise.resolve());

  useEffect(() => {
    sessionRef.current = session;
  }, [session]);

  // Build the page config once per screen (and again on "Try again"). The
  // session is read fresh from the client, which refreshes an expired token
  // natively first: if the page were handed an expired one, its own client
  // would refresh it and rotate the refresh token the app still holds, and the
  // app would find itself signed out a moment later. Later refreshes are
  // pushed in below without reloading the page.
  useEffect(() => {
    let active = true;
    (async () => {
      const [snapshot, lang, last, goal, weekDays, minGoal, daySecs, sfx, plan] = await Promise.all([
        getEngineProgress(),
        getLessonLang(),
        getLastUnit(),
        getDailyGoal(),
        getWeekXp(),
        getMinGoal(),
        getTodaySecs(),
        getSoundsOn(),
        getPlan(),
      ]);
      const dayXp = await getTodayXp(snapshot.xp);
      const unitId = reviewView ? (last?.unitId ?? '1.1') : unitParam;
      const unit = getUnit(unitId);
      const mod = getModuleForUnit(unitId);
      if (!unit || !mod) {
        if (active) setMissing(true);
        return;
      }
      // The paywall lives on the unit screen; a deep link straight to a paid
      // lesson goes there instead of into the lesson.
      if (!reviewView && !(await canAccessUnit(unitId))) {
        if (active) router.replace({ pathname: '/unit/[id]', params: { id: unitId } });
        return;
      }
      let fresh: Session | null;
      try {
        fresh = (await supabase.auth.getSession()).data.session;
      } catch (e) {
        reportError(e, { where: 'lesson open session' });
        fresh = session;
      }
      // Who this progress belongs to, even when no usable token exists right
      // now (offline with an expired one): the context session, or the last
      // signed-in learner this device resolved a plan for.
      const uid = fresh?.user?.id ?? session?.user?.id ?? (await getLastKnownUserId()) ?? undefined;
      knownUid.current = uid ?? null;
      const bId = reviewView ? undefined : (blockParam ?? nextBlockFor(unit, completedFromProg(snapshot.prog)));
      const config: LessonConfig = {
        view: reviewView ?? 'lesson',
        mId: mod.id,
        uId: unit.id,
        bId,
        premium: plan !== 'free',
        session: tokensOf(fresh),
        uid,
        prog: snapshot.prog,
        pos: snapshot.pos,
        lang,
        // Read at open: turning Sounds on or off takes effect next lesson.
        sfx,
        // Light mode is off app-wide (see LIGHT_MODE_ENABLED in src/theme).
        theme: 'dark',
        day: { goal, dayXp, weekXp: weekDays.reduce((n, d) => n + d.xp, 0), xp: snapshot.xp, minGoal, daySecs },
      };
      if (!reviewView) setLastUnit(unit.id);
      if (active) setCfg(config);
    })().catch((e) => reportError(e, { where: 'lesson open', unit: unitParam }));
    return () => {
      active = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [unitParam, blockParam, attempt]);

  // The page has a fixed time to say `opened`; after that the overlay offers
  // "Try again" and "Back" so nobody is left with a spinner (iPhone has no
  // hardware back).
  useEffect(() => {
    if (ready || failed) return;
    const id = setTimeout(() => setSlow(true), OPEN_TIMEOUT_MS);
    return () => clearTimeout(id);
  }, [boot, ready, failed]);

  /** Read the session again (refreshing it natively if needed) and hand it to the page. */
  const pushFreshSession = useCallback(async () => {
    try {
      const { data } = await supabase.auth.getSession();
      host.current?.inject(setSessionScript(tokensOf(data.session)));
    } catch (e) {
      reportError(e, { where: 'lesson session refresh' });
    }
  }, []);

  // Keep the page's token fresh while a long lesson runs: this is how a
  // native refresh reaches the page.
  useEffect(() => {
    if (!cfg || !ready) return;
    host.current?.inject(setSessionScript(tokensOf(session)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session?.access_token]);

  // Back from the background: the token may have expired meanwhile. Read it
  // here (refreshing natively) before the page's own client gets the idea.
  useEffect(() => {
    const sub = AppState.addEventListener('change', (state) => {
      if (state === 'active') void pushFreshSession();
    });
    return () => sub.remove();
  }, [pushFreshSession]);

  const close = useCallback(() => {
    if (leaving.current) return;
    leaving.current = true;
    if (router.canGoBack()) router.back();
    else router.replace('/');
  }, [router]);

  /** Merge a page snapshot into the local mirror and queue it for the cloud. */
  const applySnapshot = useCallback((p: BridgeProgress) => {
    queue.current = queue.current
      .then(async () => {
        // A snapshot the page could only save as a guest (its session did not
        // apply) still belongs to the signed-in learner.
        const uid = p.uid === 'guest' && knownUid.current ? knownUid.current : p.uid;
        const snap = await applyEngineProgress({
          prog: p.prog,
          pos: p.pos,
          xp: p.xp,
          streak: p.streak,
          uid,
          lastDay: p.last_day ?? undefined,
        });
        scheduleCloudPush(snap);
      })
      .catch((e) => reportError(e, { where: 'lesson progress' }));
  }, []);

  /** Whatever the page has not uploaded yet goes now, then the screen closes. */
  const flushAndClose = useCallback(async () => {
    try {
      await queue.current;
      await Promise.race([flushCloudProgress(), wait(FLUSH_WAIT_MS)]);
    } catch (e) {
      reportError(e, { where: 'lesson flush' });
    }
    close();
  }, [close]);

  /** Leave on the learner's own initiative (back, the close button): ask the
   *  page for its last snapshot, upload it, go. */
  const leave = useCallback(async () => {
    if (departing.current) return;
    departing.current = true;
    host.current?.inject(FLUSH_SCRIPT);
    await wait(SETTLE_MS);
    await flushAndClose();
  }, [flushAndClose]);

  /**
   * Start over: a fresh config (a fresh token — the first one may be hours
   * old by now — and the latest local progress) in a fresh web view. Unmounting
   * the host is what a WebView needs after a renderer crash anyway.
   */
  const restart = useCallback(() => {
    setFailed(false);
    setSlow(false);
    setReady(false);
    setCfg(null);
    setAttempt((a) => a + 1);
    setBoot((b) => b + 1);
  }, []);

  const onFailure = useCallback(
    (kind: HostFailure, detail?: string) => {
      reportMessage(`lesson web view ${kind}`, { where: 'lesson host', kind, detail, unit: unitParam, block: blockParam });
      setReady(false);
      setSlow(false);
      if (kind === 'crashed' && !crashRetried.current) {
        // One quiet restart: the page is bundled, so this usually just works.
        crashRetried.current = true;
        restart();
        return;
      }
      setFailed(true);
    },
    [blockParam, restart, unitParam]
  );

  // Hardware back leaves the lesson; progress is saved step by step, the last
  // step is uploaded on the way out.
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      void leave();
      return true;
    });
    return () => sub.remove();
  }, [leave]);

  // Whatever is still queued for the cloud when the screen goes away is sent
  // in the background.
  useEffect(
    () => () => {
      void flushCloudProgress();
    },
    []
  );

  const onMessage = useCallback(
    (m: BridgeMessage) => {
      switch (m.type) {
        case 'opened':
          setReady(true);
          setSlow(false);
          break;
        case 'progress':
          applySnapshot(m);
          break;
        case 'minutes':
          // Adds to today's total; meeting the goal drops today's reminder.
          if (typeof m.secs === 'number') recordActiveSecs(m.secs);
          break;
        case 'setGoal':
          if (typeof m.minutes === 'number') changeMinGoal(m.minutes);
          break;
        case 'view':
          setEdges({ top: m.top, bottom: m.bottom });
          break;
        case 'navigate':
          if (m.progress) applySnapshot(m.progress);
          void flushAndClose();
          break;
        case 'needSession':
          void pushFreshSession();
          break;
        case 'session':
          // The page's client rotated the tokens; the app adopts the new pair
          // (its own refresh token is no longer valid).
          if (m.access_token && m.refresh_token && m.access_token !== sessionRef.current?.access_token) {
            supabase.auth
              .setSession({ access_token: m.access_token, refresh_token: m.refresh_token })
              .then(({ error }) => {
                if (error) reportError(error, { where: 'lesson adopt session' });
              })
              .catch((e) => reportError(e, { where: 'lesson adopt session' }));
          }
          break;
        case 'error':
          reportMessage(m.message, { where: 'lesson page error', unit: unitParam, block: blockParam });
          Alert.alert(t('Lesson'), m.message, [{ text: t('OK'), onPress: close }]);
          break;
        case 'jserror':
          reportMessage(m.message, { where: 'lesson page', source: m.source, line: m.line, unit: unitParam });
          break;
      }
    },
    [applySnapshot, blockParam, close, flushAndClose, pushFreshSession, t, unitParam]
  );

  const onExternal = useCallback(
    (url: string) => {
      // Links inside the page are relative to the website.
      const target = url.startsWith(LESSON_ORIGIN) ? WEB_BASE + '/' + url.slice(LESSON_ORIGIN.length) : url;
      if (/auth\.html/.test(target)) {
        router.push('/sign-in');
        return;
      }
      // Upgrade links inside a lesson open the app's own plans screen (on iPhone
      // Apple only allows its in-app purchase for this), remembering the unit.
      if (/pricing(\.html)?/.test(target)) {
        router.push({ pathname: '/plans', params: reviewView ? {} : { unit: unitParam } });
        return;
      }
      Linking.openURL(target).catch(() => {});
    },
    [reviewView, router, unitParam]
  );

  if (missing) {
    return (
      <View style={[styles.screen, { backgroundColor: c.bg, paddingTop: insets.top + 24, paddingHorizontal: 20 }]}>
        <SpaceBackdrop />
        <ErrorNote message={t('No lesson found for "{unit}".', { unit: unitParam })} />
      </View>
    );
  }

  const covered = !ready || failed;

  return (
    <View style={[styles.screen, { backgroundColor: edges.bottom }]}>
      <StatusBar style={!covered && isLight(edges.top) ? 'dark' : 'light'} animated />
      <View style={{ height: insets.top, backgroundColor: covered ? c.bg : edges.top }} />

      <View style={styles.body}>
        {cfg ? <LessonHost ref={host} cfg={cfg} onMessage={onMessage} onExternal={onExternal} onFailure={onFailure} /> : null}

        {covered ? (
          // The overlay itself lets touches through; only its controls take them.
          <View style={[styles.overlay, { backgroundColor: c.bg }]} pointerEvents="box-none">
            <SpaceBackdrop />
            {failed ? (
              <View style={styles.panel}>
                <ErrorNote message={t('The lesson could not be opened.')} />
                <Button label={t('Try again')} onPress={restart} icon="refresh" />
                <Button label={t('Back')} variant="ghost" onPress={() => void leave()} />
              </View>
            ) : (
              <View style={styles.panel} pointerEvents={slow ? 'auto' : 'none'}>
                <ActivityIndicator color={c.gold} size="large" />
                <Text style={styles.overlayText}>{t('Opening lesson…')}</Text>
                {slow ? (
                  <>
                    <Text style={[styles.slowText, { color: c.muted }]}>{t('This is taking longer than usual.')}</Text>
                    <Button label={t('Try again')} onPress={restart} icon="refresh" />
                    <Button label={t('Back')} variant="ghost" onPress={() => void leave()} />
                  </>
                ) : null}
              </View>
            )}
            <Pressable
              onPress={() => void leave()}
              hitSlop={12}
              accessibilityRole="button"
              accessibilityLabel={t('Close')}
              style={({ pressed }) => [styles.closeBtn, { borderColor: c.line }, pressed && styles.closePressed]}>
              <Icon name="close" size={20} color={c.text} />
            </Pressable>
          </View>
        ) : null}
      </View>

      <View style={{ height: insets.bottom, backgroundColor: covered ? c.bg : edges.bottom }} />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Colors.bg },
  body: { flex: 1, ...contentCap },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: Colors.bg,
    alignItems: 'center',
    justifyContent: 'center',
  },
  panel: { alignItems: 'center', gap: 14, paddingHorizontal: 28, maxWidth: 420, width: '100%' },
  overlayText: {
    fontFamily: Fonts.bodySemi,
    fontSize: 11,
    letterSpacing: 2,
    textTransform: 'uppercase',
    color: Colors.gold,
  },
  slowText: { fontFamily: Fonts.body, fontSize: 14, lineHeight: 20, textAlign: 'center', marginTop: 6 },
  closeBtn: {
    position: 'absolute',
    top: 10,
    left: 14,
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  closePressed: { opacity: 0.7 },
});
