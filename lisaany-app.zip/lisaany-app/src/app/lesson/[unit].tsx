import { useLocalSearchParams, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Alert, BackHandler, Linking, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { LessonHost, type LessonHostHandle } from '@/components/lesson-host';
import { ErrorNote } from '@/components/ui';
import { Colors, Fonts, WEB_BASE } from '@/constants/lisaany';
import { useTheme } from '@/theme';
import { useAuth } from '@/lib/auth-context';
import { getModuleForUnit, getUnit } from '@/lib/curriculum';
import {
  FLUSH_SCRIPT,
  LESSON_ORIGIN,
  setSessionScript,
  type BridgeMessage,
  type LessonConfig,
  type LessonView,
} from '@/lib/lesson-bridge';
import {
  applyEngineProgress,
  completedFromProg,
  getEngineProgress,
  getLastUnit,
  nextBlockFor,
  setLastUnit,
} from '@/lib/progress';
import { getLessonLang } from '@/lib/settings';

const REVIEW_VIEWS: Record<string, LessonView> = {
  srsreview: 'srsreview',
  reviewBuilder: 'reviewBuilder',
  review: 'review',
};

/** Is a CSS colour light enough to need dark status-bar icons? */
function isLight(color: string): boolean {
  const m = color.match(/(\d+(?:\.\d+)?)/g);
  if (!m || m.length < 3) return false;
  const [r, g, b] = m.map(Number);
  return 0.2126 * r + 0.7152 * g + 0.0722 * b > 150;
}

/**
 * A lesson, full screen: the website's lesson engine in a web view, framed by
 * the app. `unit` is a unit id ("1.1") with an optional `block`, or one of the
 * review views (srsreview, reviewBuilder).
 */
export default function LessonScreen() {
  const params = useLocalSearchParams<{ unit: string; block?: string }>();
  const unitParam = String(params.unit ?? '');
  const blockParam = params.block ? Number(params.block) : undefined;

  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { session, plan } = useAuth();
  const { scheme, c } = useTheme();
  const host = useRef<LessonHostHandle>(null);

  const [cfg, setCfg] = useState<LessonConfig | null>(null);
  const [missing, setMissing] = useState(false);
  const [ready, setReady] = useState(false);
  const [edges, setEdges] = useState<{ top: string; bottom: string }>({ top: c.bg, bottom: c.bg });
  const leaving = useRef(false);

  // Build the page config once per screen. Session and plan are read at open;
  // later session refreshes are pushed in below without reloading the page.
  useEffect(() => {
    let active = true;
    (async () => {
      const [snapshot, lang, last] = await Promise.all([getEngineProgress(), getLessonLang(), getLastUnit()]);
      const reviewView = REVIEW_VIEWS[unitParam];
      const unitId = reviewView ? (last?.unitId ?? '1.1') : unitParam;
      const unit = getUnit(unitId);
      const mod = getModuleForUnit(unitId);
      if (!unit || !mod) {
        if (active) setMissing(true);
        return;
      }
      const bId = reviewView ? undefined : (blockParam ?? nextBlockFor(unit, completedFromProg(snapshot.prog)));
      const config: LessonConfig = {
        view: reviewView ?? 'lesson',
        mId: mod.id,
        uId: unit.id,
        bId,
        premium: plan !== 'free',
        session: session
          ? { access_token: session.access_token, refresh_token: session.refresh_token }
          : null,
        prog: snapshot.prog,
        pos: snapshot.pos,
        lang,
        theme: scheme,
      };
      if (!reviewView) setLastUnit(unit.id);
      if (active) setCfg(config);
    })();
    return () => {
      active = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [unitParam, blockParam]);

  // Keep the page's token fresh while a long lesson runs.
  useEffect(() => {
    if (!cfg || !ready) return;
    host.current?.inject(
      setSessionScript(
        session ? { access_token: session.access_token, refresh_token: session.refresh_token } : null
      )
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session?.access_token]);

  const close = useCallback(() => {
    if (leaving.current) return;
    leaving.current = true;
    if (router.canGoBack()) router.back();
    else router.replace('/');
  }, [router]);

  // Hardware back leaves the lesson; progress is already saved step by step.
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      host.current?.inject(FLUSH_SCRIPT);
      setTimeout(close, 120);
      return true;
    });
    return () => sub.remove();
  }, [close]);

  const onMessage = useCallback(
    (m: BridgeMessage) => {
      switch (m.type) {
        case 'opened':
          setReady(true);
          break;
        case 'progress':
          applyEngineProgress(m);
          break;
        case 'view':
          setEdges({ top: m.top, bottom: m.bottom });
          break;
        case 'navigate':
          if (m.progress) applyEngineProgress(m.progress);
          close();
          break;
        case 'error':
          Alert.alert('Lesson', m.message, [{ text: 'OK', onPress: close }]);
          break;
        case 'jserror':
          console.warn('[lesson page]', m.message, m.source ?? '', m.line ?? '');
          break;
      }
    },
    [close]
  );

  const onExternal = useCallback(
    (url: string) => {
      // Links inside the page are relative to the website.
      const target = url.startsWith(LESSON_ORIGIN) ? WEB_BASE + '/' + url.slice(LESSON_ORIGIN.length) : url;
      if (/auth\.html/.test(target)) {
        router.push('/sign-in');
        return;
      }
      Linking.openURL(target).catch(() => {});
    },
    [router]
  );

  if (missing) {
    return (
      <View style={[styles.screen, { paddingTop: insets.top + 24, paddingHorizontal: 20 }]}>
        <ErrorNote message={`No lesson found for "${unitParam}".`} />
      </View>
    );
  }

  return (
    <View style={[styles.screen, { backgroundColor: edges.bottom }]}>
      <StatusBar style={isLight(edges.top) ? 'dark' : 'light'} animated />
      <View style={{ height: insets.top, backgroundColor: edges.top }} />

      <View style={styles.body}>
        {cfg ? <LessonHost ref={host} cfg={cfg} onMessage={onMessage} onExternal={onExternal} /> : null}

        {!ready ? (
          <View style={[styles.overlay, { backgroundColor: c.bg }]} pointerEvents="none">
            <ActivityIndicator color={c.gold} size="large" />
            <Text style={styles.overlayText}>Opening lesson…</Text>
          </View>
        ) : null}
      </View>

      <View style={{ height: insets.bottom, backgroundColor: edges.bottom }} />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Colors.bg },
  body: { flex: 1 },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: Colors.bg,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 14,
  },
  overlayText: {
    fontFamily: Fonts.bodySemi,
    fontSize: 11,
    letterSpacing: 2,
    textTransform: 'uppercase',
    color: Colors.gold,
  },
});
