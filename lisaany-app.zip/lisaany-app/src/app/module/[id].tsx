import { LinearGradient } from 'expo-linear-gradient';
import { useFocusEffect, useLocalSearchParams, useRouter } from 'expo-router';
import { useCallback, useState } from 'react';
import { Alert, Linking, Pressable, ScrollView, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Icon } from '@/components/icon';
import { usePop } from '@/components/pop-card';
import { ProgressRing } from '@/components/progress-ring';
import { ArabicLine, ErrorNote } from '@/components/ui';
import { UnitSheet, type SheetUnit } from '@/components/unit-sheet';
import { Fonts, Spacing, WEB_BASE } from '@/constants/lisaany';
import { useAuth } from '@/lib/auth-context';
import { blockSizeLabel, getModule, levelForModule, type Unit } from '@/lib/curriculum';
import { canAccessUnit } from '@/lib/plan';
import {
  getCompletedBlocks,
  nextBlockFor,
  setLastUnit,
  unitDoneCount,
  type CompletedMap,
} from '@/lib/progress';
import { cardSurface, makeStyles, useTheme } from '@/theme';

type Row = {
  unit: Unit;
  doneCount: number;
  complete: boolean;
  /** Opens in order, as on the website: the unit before it must be finished. */
  inOrder: boolean;
  /** The learner's plan includes it. */
  allowed: boolean;
};

/**
 * A module's units. The unit to work on next gets the big card with a
 * one-tap Resume; tapping any unit opens its card (UnitSheet) instead of a
 * separate page.
 */
export default function ModuleScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { session, plan } = useAuth();
  const { c } = useTheme();
  const styles = useStyles();

  const mod = getModule(String(id));
  const level = mod ? levelForModule(mod.id) : undefined;

  const [done, setDone] = useState<CompletedMap>({});
  const [allowed, setAllowed] = useState<Record<string, boolean>>({});
  const [sheet, setSheet] = useState<SheetUnit | null>(null);

  // Progress changes while a lesson is open, so re-read it on every return.
  useFocusEffect(
    useCallback(() => {
      if (!mod) return;
      let active = true;
      Promise.all([getCompletedBlocks(), Promise.all(mod.units.map((u) => canAccessUnit(u.id)))]).then(
        ([map, access]) => {
          if (!active) return;
          setDone(map);
          setAllowed(Object.fromEntries(mod.units.map((u, i) => [u.id, access[i]])));
        }
      );
      return () => {
        active = false;
      };
    }, [mod, plan])
  );

  if (!mod) {
    return (
      <View style={[styles.screen, { paddingTop: insets.top + 20, paddingHorizontal: Spacing.lg }]}>
        <ErrorNote message={`No module with id ${id}.`} />
      </View>
    );
  }

  const rows: Row[] = mod.units.map((unit, i) => {
    const doneCount = unitDoneCount(unit, done);
    const prev = mod.units[i - 1];
    return {
      unit,
      doneCount,
      complete: unit.blocks.length > 0 && doneCount >= unit.blocks.length,
      inOrder: !prev || unitDoneCount(prev, done) >= prev.blocks.length,
      allowed: allowed[unit.id] ?? true,
    };
  });

  const unitsDone = rows.filter((r) => r.complete).length;
  const current = rows.find((r) => !r.complete && r.inOrder);
  const others = rows.filter((r) => r !== current);

  const openLesson = (unit: Unit, blockId: number) => {
    setSheet(null);
    setLastUnit(unit.id);
    router.push({ pathname: '/lesson/[unit]', params: { unit: unit.id, block: String(blockId) } });
  };

  const unlock = () => {
    setSheet(null);
    if (!session) router.push({ pathname: '/sign-in', params: { next: 'plans' } });
    else router.push('/plans');
  };

  const sheetFor = (row: Row): SheetUnit => {
    if (!row.inOrder) {
      // Point at the unit to actually work on, not just the one before it
      // (which may itself be locked).
      const i = mod.units.indexOf(row.unit);
      const before = current?.unit ?? mod.units[i - 1];
      const direct = before === mod.units[i - 1];
      return {
        unit: row.unit,
        state: 'locked',
        before,
        blocksLeft: direct ? before.blocks.length - unitDoneCount(before, done) : 0,
      };
    }
    if (!row.allowed) return { unit: row.unit, state: 'premium' };
    return { unit: row.unit, state: 'open' };
  };

  // Open lessons go to their own page; locked ones explain why in the sheet.
  const openUnit = (row: Row) => {
    const target = sheetFor(row);
    if (target.state === 'open' || target.state === 'premium') router.push({ pathname: '/unit/[id]', params: { id: row.unit.id } });
    else setSheet(target);
  };

  const resume = (row: Row) => {
    if (!row.allowed) return unlock();
    openLesson(row.unit, nextBlockFor(row.unit, done));
  };

  return (
    <View style={styles.screen}>
      <ScrollView
        contentContainerStyle={[styles.content, { paddingTop: insets.top + 12, paddingBottom: insets.bottom + 32 }]}
        showsVerticalScrollIndicator={false}>
        <View style={styles.topbar}>
          <Pressable
            onPress={() => (router.canGoBack() ? router.back() : router.replace('/lessons'))}
            style={styles.back}
            hitSlop={8}
            accessibilityLabel="Back">
            <Icon name="arrow_back" size={20} color={c.text} />
          </Pressable>
          <Text style={styles.topCount}>
            {unitsDone} of {rows.length} units
          </Text>
        </View>

        <Text style={styles.eyebrow}>
          MODULE {mod.id}
          {level ? ` · ${level.label.toUpperCase()}` : ''}
        </Text>
        <Text style={styles.title}>{mod.title}</Text>
        {level ? (
          <ArabicLine size={19} color={c.gold} style={styles.levelAr}>
            {level.ar}
          </ArabicLine>
        ) : null}

        {current ? (
          <Spotlight row={current} done={done} onOpen={() => openUnit(current)} onResume={() => resume(current)} />
        ) : (
          <View style={styles.completeCard}>
            <Icon name="workspace_premium" size={30} color={c.gold} />
            <Text style={styles.completeTitle}>Module complete</Text>
            <Text style={styles.completeSub}>Every unit is done. Tap any unit to review it.</Text>
          </View>
        )}

        {others.length ? (
          <>
            <Text style={styles.listLabel}>{current ? 'IN THIS MODULE' : 'UNITS'}</Text>
            {others.map((row) => {
              const lockCol = c.scheme === 'light' ? c.navy : c.locked;
              const locked = !row.inOrder || !row.allowed;
              return (
                <Pressable
                  key={row.unit.id}
                  onPress={() => openUnit(row)}
                  style={({ pressed }) => [styles.row, pressed && { opacity: 0.7 }]}>
                  <View style={styles.rowIcon}>
                    <Icon
                      name={row.unit.icon ?? 'menu_book'}
                      size={19}
                      color={row.complete ? c.gold : locked ? lockCol : c.gold}
                    />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.rowTitle, locked && { color: c.muted }]} numberOfLines={1}>
                      {row.unit.title}
                    </Text>
                    <Text style={[styles.rowSub, row.complete && { color: c.gold }]}>
                      {row.complete ? 'Complete' : `Unit ${row.unit.id} · ${row.unit.blocks.length} blocks`}
                    </Text>
                  </View>
                  <Icon
                    name={row.complete ? 'check_circle' : locked ? 'lock' : 'chevron_right'}
                    size={row.complete ? 20 : 18}
                    color={row.complete ? c.gold : locked ? lockCol : c.text}
                  />
                </Pressable>
              );
            })}
          </>
        ) : null}
      </ScrollView>

      <UnitSheet
        target={sheet}
        done={done}
        onClose={() => setSheet(null)}
        onOpenBlock={openLesson}
        onGoToUnit={(unit) => {
          const row = rows.find((r) => r.unit.id === unit.id);
          setSheet(row ? sheetFor(row) : null);
        }}
        onUnlock={unlock}
      />
    </View>
  );
}

function Spotlight({
  row,
  done,
  onOpen,
  onResume,
}: {
  row: Row;
  done: CompletedMap;
  onOpen: () => void;
  onResume: () => void;
}) {
  const pop = usePop();
  const { c } = useTheme();
  const styles = useStyles();
  const { unit, doneCount } = row;
  const next = unit.blocks.find((b) => b.id === nextBlockFor(unit, done));
  const size = next ? blockSizeLabel(next) : null;

  return (
    <LinearGradient
      colors={c.scheme === 'dark' ? c.cardGrad : c.navyGrad}
      start={{ x: 0.1, y: 0 }}
      end={{ x: 0.8, y: 1 }}
      style={[pop.rest, styles.spot]}>
      <View style={styles.spotGlow} />
      <Text style={styles.spotLabel}>{doneCount > 0 ? 'CONTINUE WHERE YOU LEFT OFF' : 'START HERE'}</Text>

      <Pressable onPress={onOpen} style={styles.spotHead}>
        <ProgressRing
          value={unit.blocks.length ? doneCount / unit.blocks.length : 0}
          size={74}
          label={`${doneCount}/${unit.blocks.length}`}
        />
        <View style={{ flex: 1 }}>
          <Text style={styles.spotUnit}>Unit {unit.id}</Text>
          <Text style={styles.spotTitle}>{unit.title}</Text>
          {unit.desc ? (
            <ArabicLine size={14} color={c.goldFill} style={{ marginTop: 3 }}>
              {unit.desc}
            </ArabicLine>
          ) : null}
        </View>
      </Pressable>

      {next && row.allowed ? (
        <View style={styles.nextBox}>
          <Icon name={next.icon ?? 'play_arrow'} size={20} color={c.goldFill} />
          <View style={{ flex: 1 }}>
            <Text style={styles.nextSmall}>Next block</Text>
            <Text style={styles.nextTitle} numberOfLines={1}>
              {next.title}
            </Text>
          </View>
          {size ? <Text style={styles.nextSize}>{size}</Text> : null}
        </View>
      ) : null}

      <Pressable onPress={onResume} style={({ pressed }) => [styles.btn, pressed && { opacity: 0.88 }]}>
        <Text style={styles.btnLabel}>
          {!row.allowed ? 'Unlock this unit' : doneCount > 0 ? 'Resume lesson' : 'Start lesson'}
        </Text>
        <Icon name={row.allowed ? 'arrow_forward' : 'lock_open'} size={19} color={c.onGold} />
      </Pressable>
    </LinearGradient>
  );
}

const useStyles = makeStyles((c) => {
  // The Spotlight card is navy in both themes; in dark it keeps the original
  // card greys, in light it uses the on-navy tokens.
  const onNavyMuted = c.scheme === 'dark' ? c.muted : c.onNavyMuted;
  return {
    screen: { flex: 1, backgroundColor: c.bg },
    content: { paddingHorizontal: Spacing.lg },

    topbar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 22 },
    back: {
      width: 40,
      height: 40,
      borderRadius: 20,
      backgroundColor: c.track,
      alignItems: 'center',
      justifyContent: 'center',
    },
    topCount: { fontFamily: Fonts.body, fontSize: 12.5, color: c.muted },

    eyebrow: {
      fontFamily: Fonts.bodyBold,
      fontSize: 11,
      letterSpacing: 3,
      color: c.gold,
      marginBottom: 6,
    },
    title: { fontFamily: Fonts.display, fontSize: 28, lineHeight: 34, color: c.text },
    levelAr: { marginTop: 4, marginBottom: 20 },

    spot: {
      borderRadius: 24,
      padding: 22,
      borderWidth: 1,
      borderColor: 'rgba(230,184,90,0.35)',
      overflow: 'hidden',
      marginBottom: 26,
    },
    spotGlow: {
      position: 'absolute',
      right: -40,
      top: -40,
      width: 160,
      height: 160,
      borderRadius: 80,
      backgroundColor: 'rgba(230,184,90,0.08)',
    },
    spotLabel: {
      fontFamily: Fonts.bodyBold,
      fontSize: 10.5,
      letterSpacing: 2,
      color: c.goldFill,
      marginBottom: 14,
    },
    spotHead: { flexDirection: 'row', alignItems: 'center', gap: 16, marginBottom: 16 },
    spotUnit: { fontFamily: Fonts.body, fontSize: 12, color: onNavyMuted },
    spotTitle: { fontFamily: Fonts.display, fontSize: 21, lineHeight: 26, color: c.onNavy },

    nextBox: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
      borderRadius: 14,
      backgroundColor: 'rgba(0,0,0,0.22)',
      paddingVertical: 12,
      paddingHorizontal: 14,
      marginBottom: 16,
    },
    nextSmall: { fontFamily: Fonts.body, fontSize: 11, color: onNavyMuted },
    nextTitle: { fontFamily: Fonts.bodySemi, fontSize: 14, color: c.onNavy },
    nextSize: { fontFamily: Fonts.body, fontSize: 11.5, color: onNavyMuted },

    btn: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      backgroundColor: c.goldFill,
      borderRadius: 999,
      minHeight: 54,
      paddingHorizontal: 22,
    },
    btnLabel: { fontFamily: Fonts.bodyBold, fontSize: 15.5, color: c.onGold },

    completeCard: {
      alignItems: 'center',
      borderRadius: 24,
      padding: 24,
      ...(c.scheme === 'light'
        ? cardSurface(c)
        : { backgroundColor: c.card, borderWidth: 1, borderColor: 'rgba(230,184,90,0.35)' }),
      marginBottom: 26,
      gap: 6,
    },
    completeTitle: { fontFamily: Fonts.display, fontSize: 20, color: c.text, marginTop: 4 },
    completeSub: { fontFamily: Fonts.body, fontSize: 13, color: c.muted, textAlign: 'center' },

    listLabel: {
      fontFamily: Fonts.bodyBold,
      fontSize: 11,
      letterSpacing: 2.5,
      color: c.muted,
      marginBottom: 4,
    },
    row: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 14,
      paddingVertical: 13,
      borderTopWidth: 1,
      borderColor: c.line,
    },
    rowIcon: {
      width: 38,
      height: 38,
      borderRadius: 11,
      backgroundColor: c.scheme === 'light' ? 'rgba(22,33,58,0.08)' : c.raised,
      alignItems: 'center',
      justifyContent: 'center',
    },
    rowTitle: { fontFamily: Fonts.bodySemi, fontSize: 15, color: c.text },
    rowSub: { fontFamily: Fonts.body, fontSize: 12, color: c.locked, marginTop: 1 },
  };
});
