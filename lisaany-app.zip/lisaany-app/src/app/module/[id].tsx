import { useFocusEffect, useLocalSearchParams, useRouter } from 'expo-router';
import { useCallback, useMemo, useState } from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Icon } from '@/components/icon';
import { PopPressable } from '@/components/pop-card';
import { SpaceBackdrop } from '@/components/space-backdrop';
import { StarSlot, StarTalk, useStarGuide } from '@/components/star-guide';
import { ArabicLine, CardFill, ContinuePill, currentCard, ErrorNote, LATER_STYLE, spaceCard } from '@/components/ui';
import { UnitSheet, type SheetUnit } from '@/components/unit-sheet';
import { Fonts, Spacing } from '@/constants/lisaany';
import { useAuth } from '@/lib/auth-context';
import { blockSizeLabel, getModule, levelForModule, type Unit } from '@/lib/curriculum';
import { useLang } from '@/lib/i18n';
import { canAccessUnit } from '@/lib/plan';
import {
  getCompletedBlocks,
  nextBlockFor,
  setLastUnit,
  unitDoneCount,
  type CompletedMap,
} from '@/lib/progress';
import { makeStyles, useTheme } from '@/theme';
import { ContentWidth, contentCap } from '@/components/content-width';

type Row = {
  unit: Unit;
  doneCount: number;
  complete: boolean;
  /** Opens in order, as on the website: the unit before it must be finished. */
  inOrder: boolean;
  /** The learner's plan includes it. */
  allowed: boolean;
};

/**
 * A module's units. The unit to work on next gets the big card with a
 * one-tap Resume; tapping any unit opens its card (UnitSheet) instead of a
 * separate page.
 */
export default function ModuleScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { plan } = useAuth();
  const { c } = useTheme();
  const styles = useStyles();
  const { t, ct } = useLang();

  const mod = getModule(String(id));
  const level = mod ? levelForModule(mod.id) : undefined;

  const [done, setDone] = useState<CompletedMap>({});
  const [allowed, setAllowed] = useState<Record<string, boolean>>({});
  const [sheet, setSheet] = useState<SheetUnit | null>(null);

  const tips = useMemo(
    () => [
      t('The gold card is your next unit.'),
      t('Finished units have a green check — tap one to review it.'),
      t('Faded units open once you finish the one before.'),
    ],
    [t]
  );
  const guide = useStarGuide(tips, { greet: tips[0], greetKey: 'module' });

  // Progress changes while a lesson is open, so re-read it on every return.
  useFocusEffect(
    useCallback(() => {
      if (!mod) return;
      let active = true;
      Promise.all([getCompletedBlocks(), Promise.all(mod.units.map((u) => canAccessUnit(u.id)))]).then(
        ([map, access]) => {
          if (!active) return;
          setDone(map);
          setAllowed(Object.fromEntries(mod.units.map((u, i) => [u.id, access[i]])));
        }
      );
      return () => {
        active = false;
      };
    // eslint-disable-next-line react-hooks/exhaustive-deps -- plan: re-check access after a purchase
    }, [mod, plan])
  );

  if (!mod) {
    return (
      <View style={[styles.screen, { paddingTop: insets.top + 20, paddingHorizontal: Spacing.lg }]}>
        <SpaceBackdrop />
        <ContentWidth>
          <ErrorNote message={t('No module with id {id}.', { id: String(id) })} />
        </ContentWidth>
      </View>
    );
  }

  const rows: Row[] = mod.units.map((unit, i) => {
    const doneCount = unitDoneCount(unit, done);
    const prev = mod.units[i - 1];
    return {
      unit,
      doneCount,
      complete: unit.blocks.length > 0 && doneCount >= unit.blocks.length,
      inOrder: !prev || unitDoneCount(prev, done) >= prev.blocks.length,
      allowed: allowed[unit.id] ?? true,
    };
  });

  const unitsDone = rows.filter((r) => r.complete).length;
  const current = rows.find((r) => !r.complete && r.inOrder);

  const openLesson = (unit: Unit, blockId: number) => {
    setSheet(null);
    setLastUnit(unit.id);
    router.push({ pathname: '/lesson/[unit]', params: { unit: unit.id, block: String(blockId) } });
  };

  // Both stores sell Premium in-app without an account; the plans screen offers sign-in itself.
  const unlock = (unit?: Unit) => {
    const target = unit ?? sheet?.unit;
    setSheet(null);
    router.push({ pathname: '/plans', params: target ? { unit: target.id } : {} });
  };

  const sheetFor = (row: Row): SheetUnit => {
    if (!row.inOrder) {
      // Point at the unit to actually work on, not just the one before it
      // (which may itself be locked).
      const i = mod.units.indexOf(row.unit);
      const before = current?.unit ?? mod.units[i - 1];
      const direct = before === mod.units[i - 1];
      return {
        unit: row.unit,
        state: 'locked',
        before,
        blocksLeft: direct ? before.blocks.length - unitDoneCount(before, done) : 0,
      };
    }
    if (!row.allowed) return { unit: row.unit, state: 'premium' };
    return { unit: row.unit, state: 'open' };
  };

  // Open lessons go to their own page; locked ones explain why in the sheet.
  const openUnit = (row: Row) => {
    const target = sheetFor(row);
    if (target.state === 'open' || target.state === 'premium') router.push({ pathname: '/unit/[id]', params: { id: row.unit.id } });
    else setSheet(target);
  };

  const resume = (row: Row) => {
    if (!row.allowed) return unlock(row.unit);
    openLesson(row.unit, nextBlockFor(row.unit, done));
  };

  return (
    <View style={styles.screen}>
      <SpaceBackdrop />
      <ScrollView
        contentContainerStyle={[styles.content, { paddingTop: insets.top + 12, paddingBottom: insets.bottom + 32 }]}
        showsVerticalScrollIndicator={false}>
        <View style={styles.topbar}>
          <Pressable
            onPress={() => (router.canGoBack() ? router.back() : router.replace('/lessons'))}
            style={styles.back}
            hitSlop={8}
            accessibilityLabel={t('Back')}>
            <Icon name="arrow_back" size={20} color={c.text} />
          </Pressable>
          <Text style={styles.topCount}>
            {t('{done} of {total} units', { done: unitsDone, total: rows.length })}
          </Text>
          <StarSlot guide={guide} />
        </View>
        <StarTalk guide={guide} />

        <Text style={styles.eyebrow}>
          {t('MODULE {n}', { n: mod.id })}
          {level ? ` · ${t(level.label).toUpperCase()}` : ''}
        </Text>
        <Text style={styles.title}>{ct(mod.title)}</Text>
        {level ? (
          <ArabicLine size={19} color={c.gold} style={styles.levelAr}>
            {level.ar}
          </ArabicLine>
        ) : null}
        <View style={styles.modBar}>
          <View style={[styles.modFill, { width: `${Math.round((unitsDone / Math.max(1, rows.length)) * 100)}%` }]} />
        </View>

        {!current ? (
          <View style={styles.completeCard}>
            <CardFill radius={24} />
            <Icon name="workspace_premium" size={30} color={c.gold} />
            <Text style={styles.completeTitle}>{t('Module complete')}</Text>
            <Text style={styles.completeSub}>{t('Every unit is done. Tap any unit to review it.')}</Text>
          </View>
        ) : null}

        <Text style={styles.listLabel}>{current ? t('IN THIS MODULE') : t('UNITS')}</Text>
        {rows.map((row) =>
          row === current ? (
            <Spotlight key={row.unit.id} row={row} done={done} onOpen={() => openUnit(row)} onResume={() => resume(row)} />
          ) : (
            <UnitRow key={row.unit.id} row={row} onPress={() => openUnit(row)} />
          )
        )}
      </ScrollView>

      <UnitSheet
        target={sheet}
        done={done}
        onClose={() => setSheet(null)}
        onOpenBlock={openLesson}
        onGoToUnit={(unit) => {
          const row = rows.find((r) => r.unit.id === unit.id);
          setSheet(row ? sheetFor(row) : null);
        }}
        onUnlock={() => unlock()}
      />
    </View>
  );
}

/** A unit that is finished (green check) or not reached yet (faded). */
function UnitRow({ row, onPress }: { row: Row; onPress: () => void }) {
  const { c } = useTheme();
  const styles = useStyles();
  const { t, ct } = useLang();
  const locked = !row.inOrder || !row.allowed;
  return (
    <PopPressable onPress={onPress} style={[styles.row, row.complete ? styles.rowDone : LATER_STYLE]} scaleTo={1.02}>
      <CardFill radius={18} />
      {row.complete ? (
        <View style={styles.check}>
          <Icon name="check" size={18} color="#ffffff" />
        </View>
      ) : (
        <View style={styles.rowIcon}>
          <Icon name={row.unit.icon ?? 'menu_book'} size={20} color={c.gold} />
        </View>
      )}
      <View style={{ flex: 1 }}>
        <Text style={styles.rowTitle} numberOfLines={1}>
          {row.unit.id} · {ct(row.unit.title)}
        </Text>
        <Text style={styles.rowSub} numberOfLines={1}>
          {row.complete
            ? t('Complete')
            : !row.allowed
              ? t('Premium · {n} parts', { n: row.unit.blocks.length })
              : t('{n} parts', { n: row.unit.blocks.length })}
        </Text>
      </View>
      <Icon name={locked && !row.complete ? 'lock' : 'chevron_right'} size={locked && !row.complete ? 17 : 20} color={locked && !row.complete ? c.muted : c.gold} />
    </PopPressable>
  );
}

/** The unit to work on now: gold ring, bigger title, next part and a Continue pill. */
function Spotlight({
  row,
  done,
  onOpen,
  onResume,
}: {
  row: Row;
  done: CompletedMap;
  onOpen: () => void;
  onResume: () => void;
}) {
  const { c } = useTheme();
  const styles = useStyles();
  const { t, ct, lang } = useLang();
  const { unit, doneCount } = row;
  const next = unit.blocks.find((b) => b.id === nextBlockFor(unit, done));
  const size = next ? blockSizeLabel(next, lang) : null;
  const pct = unit.blocks.length ? doneCount / unit.blocks.length : 0;

  return (
    <PopPressable onPress={onOpen} style={styles.spot} scaleTo={1.02}>
      <CardFill radius={22} />
      <View style={styles.spotHead}>
        <View style={styles.spotIcon}>
          <Icon name={unit.icon ?? 'menu_book'} size={24} color={c.gold} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.spotTitle}>
            {unit.id} · {ct(unit.title)}
          </Text>
          <Text style={styles.spotSub}>
            {doneCount > 0
              ? t('You’re here · {done} of {total} parts', { done: doneCount, total: unit.blocks.length })
              : t('Start here · {n} parts', { n: unit.blocks.length })}
          </Text>
        </View>
      </View>
      <View style={styles.spotBar}>
        <View style={[styles.spotFill, { width: `${Math.round(pct * 100)}%` }]} />
      </View>

      {next && row.allowed ? (
        <View style={styles.nextBox}>
          <Icon name={next.icon ?? 'play_arrow'} size={19} color={c.gold} />
          <View style={{ flex: 1 }}>
            <Text style={styles.nextSmall}>{t('Next block')}</Text>
            <Text style={styles.nextTitle} numberOfLines={1}>
              {ct(next.title)}
            </Text>
          </View>
          {size ? <Text style={styles.nextSize}>{size}</Text> : null}
        </View>
      ) : null}

      <ContinuePill
        onPress={onResume}
        label={!row.allowed ? t('Unlock this unit') : doneCount > 0 ? t('Continue lesson') : t('Start lesson')}
        icon={row.allowed ? 'skip_next' : 'lock_open'}
      />
    </PopPressable>
  );
}

const useStyles = makeStyles((c) => ({
  screen: { flex: 1, backgroundColor: c.bg },
  content: { paddingHorizontal: Spacing.lg , ...contentCap },

  topbar: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 14 },
  back: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: c.scheme === 'dark' ? 'rgba(255,255,255,0.08)' : c.track,
    alignItems: 'center',
    justifyContent: 'center',
  },
  topCount: { flex: 1, fontFamily: Fonts.body, fontSize: 12.5, color: c.muted, textAlign: 'right' },

  eyebrow: { fontFamily: Fonts.bodyBold, fontSize: 11, letterSpacing: 3, color: c.gold, marginTop: 4, marginBottom: 6 },
  title: { fontFamily: Fonts.display, fontSize: 28, lineHeight: 34, color: c.text },
  levelAr: { marginTop: 4, textAlign: 'left', alignSelf: 'flex-start' },
  modBar: { height: 6, borderRadius: 3, backgroundColor: c.track, overflow: 'hidden', marginTop: 10, marginBottom: 20 },
  modFill: { height: '100%', borderRadius: 3, backgroundColor: c.goldFill },

  listLabel: { fontFamily: Fonts.bodyBold, fontSize: 11, letterSpacing: 2.5, color: c.muted, marginBottom: 12 },

  // Current unit.
  spot: { ...spaceCard(c), ...currentCard(c), borderRadius: 22, padding: 18, marginBottom: 14, marginTop: 2 },
  spotHead: { flexDirection: 'row', alignItems: 'center', gap: 13 },
  spotIcon: {
    width: 48,
    height: 48,
    borderRadius: 15,
    backgroundColor: c.goldTint,
    alignItems: 'center',
    justifyContent: 'center',
  },
  spotTitle: { fontFamily: Fonts.display, fontSize: 19.5, lineHeight: 25, color: c.text },
  spotSub: { fontFamily: Fonts.body, fontSize: 13, color: c.muted, marginTop: 2 },
  spotBar: { height: 6, borderRadius: 3, backgroundColor: c.track, overflow: 'hidden', marginTop: 14 },
  spotFill: { height: '100%', borderRadius: 3, backgroundColor: c.goldFill },
  nextBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderRadius: 14,
    backgroundColor: c.scheme === 'dark' ? 'rgba(0,0,0,0.22)' : c.raised,
    paddingVertical: 11,
    paddingHorizontal: 14,
    marginTop: 14,
  },
  nextSmall: { fontFamily: Fonts.body, fontSize: 11, color: c.muted },
  nextTitle: { fontFamily: Fonts.bodySemi, fontSize: 14, color: c.text },
  nextSize: { fontFamily: Fonts.body, fontSize: 11.5, color: c.muted },

  completeCard: {
    ...spaceCard(c),
    alignItems: 'center',
    borderRadius: 24,
    padding: 24,
    marginBottom: 22,
    gap: 6,
  },
  completeTitle: { fontFamily: Fonts.display, fontSize: 20, color: c.text, marginTop: 4 },
  completeSub: { fontFamily: Fonts.body, fontSize: 13, color: c.muted, textAlign: 'center' },

  // Other units.
  row: {
    ...spaceCard(c),
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderRadius: 18,
    padding: 13,
    marginBottom: 10,
  },
  rowDone: { opacity: 0.88 },
  rowIcon: {
    width: 40,
    height: 40,
    borderRadius: 13,
    backgroundColor: c.goldTint,
    alignItems: 'center',
    justifyContent: 'center',
  },
  check: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: c.green,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rowTitle: { fontFamily: Fonts.bodyBold, fontSize: 15.5, color: c.text },
  rowSub: { fontFamily: Fonts.body, fontSize: 12.5, color: c.muted, marginTop: 2 },
}));
