import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useEffect, useState } from 'react';
import { Pressable, ScrollView, Share, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Icon } from '@/components/icon';
import { Fonts } from '@/constants/lisaany';
import { useLang } from '@/lib/i18n';
import {
  NORANIA_STEPS,
  getLearnerName,
  getNoraniaDone,
  setLearnerName,
  stepDoneCount,
  type NoraniaDone,
} from '@/lib/norania';
import { NR_PALETTE, makeNrStyles } from '@/theme/norania';

/** A certificate for a finished step — with the child's name on it. */
export default function NoraniaCertificate() {
  const { step } = useLocalSearchParams<{ step: string }>();
  const k = Math.max(0, Math.min(NORANIA_STEPS.length - 1, Number(step) || 0));
  const s = NORANIA_STEPS[k];
  const { t, ct } = useLang();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const c = NR_PALETTE;
  const styles = useStyles();
  const [done, setDone] = useState<NoraniaDone>({});
  const [name, setName] = useState('');

  useEffect(() => {
    getNoraniaDone().then(setDone);
    getLearnerName().then(setName);
  }, []);

  const lessons = stepDoneCount(done, s);
  const who = name.trim() || t('Your child');
  const share = () =>
    Share.share({
      message: `${t('{who} finished “{step}” in Lisaany Norania — {n} lessons.', { who, step: ct(s.name), n: lessons })} ما شاء الله`,
    }).catch(() => {});

  return (
    <View style={styles.screen}>
      <Stack.Screen options={{ headerShown: false }} />
      <StatusBar style="dark" />
      <ScrollView contentContainerStyle={[styles.content, { paddingTop: insets.top + 12, paddingBottom: insets.bottom + 40 }]}>
        <View style={styles.top}>
          <Pressable onPress={() => (router.canGoBack() ? router.back() : router.replace('/norania'))} hitSlop={8} style={styles.backBtn} accessibilityLabel={t('Back')}>
            <Icon name="arrow_back" size={22} color={c.text} />
          </Pressable>
          <Text style={styles.eyebrow}>{t('Step {n} certificate', { n: k + 1 })}</Text>
        </View>

        <View style={styles.cert}>
          <Icon name="workspace_premium" size={44} color={c.gold} />
          <Text style={styles.certKicker}>{t('CERTIFICATE OF READING')}</Text>
          <Text style={styles.certLine}>{t('This certifies that')}</Text>
          <Text style={styles.certName}>{who}</Text>
          <Text style={styles.certLine}>
            {t('has finished')} <Text style={styles.strong}>{ct(s.name)}</Text>
            {'\n'}
            {lessons === 1 ? t('1 lesson finished') : t('{n} lessons finished', { n: lessons })}
          </Text>
          <Text style={styles.certAr}>مَا شَاءَ اللّٰه</Text>
          <Text style={styles.certFoot}>Lisaany · Norania</Text>
        </View>

        <Text style={styles.label}>{t('WHO IS LEARNING?')}</Text>
        <TextInput
          value={name}
          onChangeText={(v) => {
            setName(v);
            setLearnerName(v);
          }}
          placeholder={t('Your child’s name')}
          placeholderTextColor={c.faint}
          style={styles.input}
        />

        <Pressable onPress={share} style={({ pressed }) => [styles.cta, pressed && { opacity: 0.88 }]}>
          <Icon name="share" size={19} color={c.onGold} />
          <Text style={styles.ctaText}>{t('Share this')}</Text>
        </Pressable>
        <Text style={styles.hint}>{t('Take a screenshot to print it or put it on the fridge.')}</Text>
      </ScrollView>
    </View>
  );
}

const useStyles = makeNrStyles((c) => ({
  screen: { flex: 1, backgroundColor: c.bg },
  content: { paddingHorizontal: 20 },
  top: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  backBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: c.card, borderWidth: 1, borderColor: c.line, alignItems: 'center', justifyContent: 'center' },
  eyebrow: { fontFamily: Fonts.bodySemi, fontSize: 12.5, color: c.muted },
  cert: {
    marginTop: 20,
    borderRadius: 24,
    paddingVertical: 28,
    paddingHorizontal: 20,
    alignItems: 'center',
    backgroundColor: c.card,
    borderWidth: 3,
    borderColor: c.goldFill,
  },
  certKicker: { fontFamily: Fonts.bodyBold, fontSize: 11.5, letterSpacing: 2, color: c.gold, marginTop: 12 },
  certLine: { fontFamily: Fonts.body, fontSize: 14, lineHeight: 22, color: c.muted, textAlign: 'center', marginTop: 10 },
  strong: { fontFamily: Fonts.bodyBold, color: c.text },
  certName: { fontFamily: Fonts.displayBold, fontSize: 26, color: c.text, marginTop: 6, textAlign: 'center' },
  certAr: { fontFamily: Fonts.arabic, fontSize: 26, lineHeight: 44, color: c.gold, marginTop: 8 },
  certFoot: { fontFamily: Fonts.bodySemi, fontSize: 11.5, color: c.muted, marginTop: 6 },
  label: { fontFamily: Fonts.bodyBold, fontSize: 11.5, letterSpacing: 1.6, color: c.muted, marginTop: 26, marginBottom: 8 },
  input: {
    height: 50,
    borderRadius: 16,
    paddingHorizontal: 16,
    backgroundColor: c.card,
    borderWidth: c.scheme === 'light' ? 1.5 : 1,
    borderColor: c.scheme === 'light' ? c.navy : c.line,
    color: c.text,
    fontFamily: Fonts.body,
    fontSize: 15,
  },
  cta: { height: 54, borderRadius: 16, backgroundColor: c.goldFill, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 18 },
  ctaText: { fontFamily: Fonts.bodyBold, fontSize: 16, color: c.onGold },
  hint: { fontFamily: Fonts.body, fontSize: 12.5, color: c.muted, textAlign: 'center', marginTop: 12 },
}));
