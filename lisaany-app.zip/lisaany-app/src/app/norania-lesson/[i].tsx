import { StatusBar } from 'expo-status-bar';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, BackHandler, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { NoraniaHost, type NoraniaMessage } from '@/components/norania-host';
import { Fonts } from '@/constants/lisaany';
import { useLang } from '@/lib/i18n';
import { getNoraniaDone, markNoraniaDay, mergeNoraniaDone, setNoraniaStars, starsForWrong, type NoraniaDone } from '@/lib/norania';

const PAPER = '#f5f6fb';

/** One Norania lesson, full screen. Progress is saved as the lesson goes. */
export default function NoraniaLessonScreen() {
  const { i } = useLocalSearchParams<{ i: string }>();
  const lesson = Math.max(0, Number(i) || 0);
  const { t } = useLang();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [done, setDone] = useState<NoraniaDone | null>(null);
  const [ready, setReady] = useState(false);
  const leaving = useRef(false);

  useEffect(() => {
    getNoraniaDone().then(setDone);
  }, []);

  const close = useCallback(() => {
    if (leaving.current) return;
    leaving.current = true;
    if (router.canGoBack()) router.back();
    else router.replace('/norania');
  }, [router]);

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      close();
      return true;
    });
    return () => sub.remove();
  }, [close]);

  const onMessage = useCallback(
    (m: NoraniaMessage) => {
      if (m.type === 'norania-opened') setReady(true);
      else if (m.type === 'norania-progress') mergeNoraniaDone(m.done);
      else if (m.type === 'norania-finished') {
        if (leaving.current) return;
        leaving.current = true;
        const stars = starsForWrong(m.wrong);
        Promise.all([mergeNoraniaDone(m.done), setNoraniaStars(m.lesson, stars), markNoraniaDay()]).then(() =>
          router.replace({ pathname: '/norania-reward/[i]', params: { i: String(m.lesson), stars: String(stars) } })
        );
      }
      else if (m.type === 'norania-close') mergeNoraniaDone(m.done).then(close);
      else if (m.type === 'jserror') console.warn('[norania]', m.message);
    },
    [close]
  );

  return (
    <View style={[styles.screen, { paddingTop: insets.top, paddingBottom: insets.bottom }]}>
      <StatusBar style="dark" />
      {done ? <NoraniaHost lesson={lesson} done={done} onMessage={onMessage} /> : null}
      {!ready ? (
        <View style={styles.overlay} pointerEvents="none">
          <ActivityIndicator color="#b3842b" size="large" />
          <Text style={styles.overlayText}>{t('Opening lesson…')}</Text>
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: PAPER },
  overlay: { ...StyleSheet.absoluteFill, backgroundColor: PAPER, alignItems: 'center', justifyContent: 'center', gap: 12 },
  overlayText: { fontFamily: Fonts.bodySemi, fontSize: 14, color: '#5b6092' },
});
