import { StatusBar } from 'expo-status-bar';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, BackHandler, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Icon } from '@/components/icon';
import { NoraniaHost, type NoraniaHostHandle, type NoraniaMessage } from '@/components/norania-host';
import { Fonts } from '@/constants/lisaany';
import { useLang } from '@/lib/i18n';
import type { HostFailure } from '@/lib/lesson-bridge';
import { getNoraniaDone, markNoraniaDay, mergeNoraniaDone, setNoraniaStars, starsForWrong, type NoraniaDone } from '@/lib/norania';
import { reportMessage } from '@/lib/report';
import { ContentWidth } from '@/components/content-width';
import { NR, NR_GOLD } from '@/theme/norania';

const PAPER = '#f5f6fb';
/** After this long without the page's `norania-opened`, offer a way out. */
const OPEN_TIMEOUT_MS = 8000;

/** One Norania lesson, full screen. Progress is saved as the lesson goes. */
export default function NoraniaLessonScreen() {
  const { i } = useLocalSearchParams<{ i: string }>();
  const lesson = Math.max(0, Number(i) || 0);
  const { t } = useLang();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const host = useRef<NoraniaHostHandle>(null);
  const [done, setDone] = useState<NoraniaDone | null>(null);
  const [ready, setReady] = useState(false);
  /** No `norania-opened` within OPEN_TIMEOUT_MS. */
  const [slow, setSlow] = useState(false);
  /** The web view gave up: show the error state. */
  const [failed, setFailed] = useState(false);
  /** Bumped whenever a page boot starts, to restart the timer. */
  const [boot, setBoot] = useState(0);
  const leaving = useRef(false);
  const crashRetried = useRef(false);

  useEffect(() => {
    getNoraniaDone().then(setDone);
  }, []);

  // A fixed time to open; after that the overlay offers "Try again" and "Back".
  useEffect(() => {
    if (ready || failed) return;
    const id = setTimeout(() => setSlow(true), OPEN_TIMEOUT_MS);
    return () => clearTimeout(id);
  }, [boot, ready, failed]);

  const close = useCallback(() => {
    if (leaving.current) return;
    leaving.current = true;
    if (router.canGoBack()) router.back();
    else router.replace('/norania');
  }, [router]);

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      close();
      return true;
    });
    return () => sub.remove();
  }, [close]);

  /** Start the page again from scratch. */
  const retry = useCallback(() => {
    setFailed(false);
    setSlow(false);
    setReady(false);
    setBoot((b) => b + 1);
    host.current?.reload();
  }, []);

  const onFailure = useCallback(
    (kind: HostFailure, detail?: string) => {
      reportMessage(`norania web view ${kind}`, { where: 'norania host', kind, detail, lesson });
      setReady(false);
      setSlow(false);
      if (kind === 'crashed' && !crashRetried.current) {
        // One quiet restart: the page is bundled, so this usually just works.
        crashRetried.current = true;
        setBoot((b) => b + 1);
        host.current?.reload();
        return;
      }
      setFailed(true);
    },
    [lesson]
  );

  const onMessage = useCallback(
    (m: NoraniaMessage) => {
      if (m.type === 'norania-opened') {
        setReady(true);
        setSlow(false);
      } else if (m.type === 'norania-progress') mergeNoraniaDone(m.done);
      else if (m.type === 'norania-finished') {
        if (leaving.current) return;
        leaving.current = true;
        const stars = starsForWrong(m.wrong);
        Promise.all([mergeNoraniaDone(m.done), setNoraniaStars(m.lesson, stars), markNoraniaDay()]).then(() =>
          router.replace({ pathname: '/norania-reward/[i]', params: { i: String(m.lesson), stars: String(stars) } })
        );
      }
      else if (m.type === 'norania-close') mergeNoraniaDone(m.done).then(close);
      else if (m.type === 'jserror') reportMessage(m.message, { where: 'norania page', lesson });
    },
    [close, lesson, router]
  );

  const covered = !ready || failed;

  return (
    <View style={[styles.screen, { paddingTop: insets.top, paddingBottom: insets.bottom }]}>
      <StatusBar style="dark" />
      <ContentWidth grow>
        {done ? <NoraniaHost ref={host} lesson={lesson} done={done} onMessage={onMessage} onFailure={onFailure} /> : null}
      </ContentWidth>
      {covered ? (
        // The overlay itself lets touches through; only its controls take them.
        <View style={[styles.overlay, { paddingTop: insets.top, paddingBottom: insets.bottom }]} pointerEvents="box-none">
          {failed ? (
            <View style={styles.panel}>
              <View style={styles.errorBox}>
                <Icon name="error" size={18} color={NR.navy} />
                <Text style={styles.errorText}>{t('The lesson could not be opened.')}</Text>
              </View>
              <Actions onRetry={retry} onBack={close} />
            </View>
          ) : (
            <View style={styles.panel} pointerEvents={slow ? 'auto' : 'none'}>
              <ActivityIndicator color={NR.goldDeep} size="large" />
              <Text style={styles.overlayText}>{t('Opening lesson…')}</Text>
              {slow ? (
                <>
                  <Text style={styles.slowText}>{t('This is taking longer than usual.')}</Text>
                  <Actions onRetry={retry} onBack={close} />
                </>
              ) : null}
            </View>
          )}
          <Pressable
            onPress={close}
            hitSlop={12}
            accessibilityRole="button"
            accessibilityLabel={t('Close')}
            style={({ pressed }) => [styles.closeBtn, { top: insets.top + 10 }, pressed && styles.pressed]}>
            <Icon name="close" size={20} color={NR.navy} />
          </Pressable>
        </View>
      ) : null}
    </View>
  );
}

/** "Try again" (gold, as the Norania buttons are) and a plain "Back". */
function Actions({ onRetry, onBack }: { onRetry: () => void; onBack: () => void }) {
  const { t } = useLang();
  return (
    <View style={styles.actions}>
      <Pressable onPress={onRetry} style={({ pressed }) => [styles.cta, pressed && styles.pressed]}>
        <Icon name="refresh" size={18} color={NR.navy} />
        <Text style={styles.ctaText}>{t('Try again')}</Text>
      </Pressable>
      <Pressable onPress={onBack} hitSlop={8} style={styles.link}>
        <Text style={styles.linkText}>{t('Back')}</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: PAPER },
  overlay: { ...StyleSheet.absoluteFill, backgroundColor: PAPER, alignItems: 'center', justifyContent: 'center' },
  panel: { alignItems: 'center', gap: 12, paddingHorizontal: 28, maxWidth: 420, width: '100%' },
  overlayText: { fontFamily: Fonts.bodySemi, fontSize: 14, color: NR.dim },
  slowText: { fontFamily: Fonts.body, fontSize: 14, lineHeight: 20, color: NR.dim, textAlign: 'center', marginTop: 4 },
  errorBox: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
    backgroundColor: NR.card,
    borderColor: NR.border,
    borderWidth: 1,
    borderRadius: 14,
    padding: 14,
    alignSelf: 'stretch',
  },
  errorText: { flex: 1, fontFamily: Fonts.body, fontSize: 14, lineHeight: 20, color: NR.navy },
  actions: { alignSelf: 'stretch', alignItems: 'center', gap: 4, marginTop: 6 },
  cta: {
    alignSelf: 'stretch',
    height: 52,
    borderRadius: 16,
    backgroundColor: NR_GOLD[1],
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  ctaText: { fontFamily: Fonts.bodyBold, fontSize: 16, color: NR.navy },
  link: { alignSelf: 'center', marginTop: 10, paddingVertical: 6, paddingHorizontal: 12 },
  linkText: { fontFamily: Fonts.bodySemi, fontSize: 14, color: NR.dim },
  closeBtn: {
    position: 'absolute',
    left: 14,
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: NR.border,
    backgroundColor: NR.card,
    alignItems: 'center',
    justifyContent: 'center',
  },
  pressed: { opacity: 0.7 },
});
