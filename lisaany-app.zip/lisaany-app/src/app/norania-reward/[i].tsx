import { LinearGradient } from 'expo-linear-gradient';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useEffect, useRef } from 'react';
import { Animated, Easing, Pressable, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Stars } from '@/components/stars';
import { Icon } from '@/components/icon';
import { Fonts } from '@/constants/lisaany';
import { useLang } from '@/lib/i18n';
import { NORANIA_LESSONS, NORANIA_STEPS, lessonGlyph } from '@/lib/norania';
import { NR_GOLD, NR_PALETTE, makeNrStyles } from '@/theme/norania';
import { ContentWidth } from '@/components/content-width';

/** "Well done!" after a Norania lesson: stars and what's next. */
export default function NoraniaReward() {
  const { i, stars: starsParam } = useLocalSearchParams<{ i: string; stars?: string }>();
  const lesson = NORANIA_LESSONS[Math.max(0, Number(i) || 0)];
  const stars = Math.max(1, Math.min(3, Number(starsParam) || 1));
  const { t, ct } = useLang();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const c = NR_PALETTE;
  const styles = useStyles();
  const pop = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(pop, { toValue: 1, duration: 500, easing: Easing.out(Easing.back(2)), useNativeDriver: true }).start();
  }, [pop]);

  const step = NORANIA_STEPS[lesson?.step ?? 0];
  const pos = step ? step.lessons.indexOf(lesson?.i ?? 0) : 0;
  const nextInStep = step?.lessons[pos + 1];
  const back = () => router.replace({ pathname: '/norania/[step]', params: { step: String(lesson?.step ?? 0) } });

  return (
    <View style={[styles.screen, { paddingTop: insets.top + 20, paddingBottom: insets.bottom + 24 }]}>
      <Stack.Screen options={{ headerShown: false }} />
      <StatusBar style="dark" />
      <ContentWidth grow>
      <View style={styles.middle}>
        <Animated.View style={{ transform: [{ scale: pop }] }}>
          <LinearGradient colors={NR_GOLD} style={styles.medal}>
            <Text style={styles.medalAr}>{lessonGlyph(lesson)}</Text>
          </LinearGradient>
        </Animated.View>
        <Text style={styles.title}>{stars === 3 ? t('Perfect!') : t('Well done!')}</Text>
        <Text style={styles.sub}>{lesson ? ct(lesson.title) : ''}</Text>
        <View style={styles.stars}>
          <Stars n={stars} size={40} on={c.goldFill} off={c.line} gap={6} />
        </View>
        {stars < 3 ? <Text style={styles.hint}>{t('Try again with no mistakes for 3 stars')}</Text> : null}
      </View>

      <View>
        {nextInStep != null ? (
          <Pressable
            onPress={() => router.replace({ pathname: '/norania-lesson/[i]', params: { i: String(nextInStep) } })}
            style={({ pressed }) => [styles.cta, pressed && { opacity: 0.88 }]}>
            <Text style={styles.ctaText}>{t('Next lesson')}</Text>
            <Icon name="arrow_forward" size={20} color={c.onGold} />
          </Pressable>
        ) : (
          <Pressable onPress={back} style={({ pressed }) => [styles.cta, pressed && { opacity: 0.88 }]}>
            <Text style={styles.ctaText}>{t('Back to the path')}</Text>
          </Pressable>
        )}
        <Pressable onPress={back} hitSlop={8} style={styles.link}>
          <Text style={styles.linkText}>{t('See my path')}</Text>
        </Pressable>
      </View>
      </ContentWidth>
    </View>
  );
}

const useStyles = makeNrStyles((c) => ({
  screen: { flex: 1, backgroundColor: c.bg, paddingHorizontal: 22 },
  middle: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  medal: { width: 110, height: 110, borderRadius: 55, alignItems: 'center', justifyContent: 'center' },
  medalAr: { fontFamily: Fonts.naskh, fontSize: 50, lineHeight: 86, color: c.onGold },
  title: { fontFamily: Fonts.displayBold, fontSize: 30, color: c.text, marginTop: 20 },
  sub: { fontFamily: Fonts.body, fontSize: 14.5, color: c.muted, marginTop: 4 },
  stars: { flexDirection: 'row', gap: 6, marginTop: 14 },
  hint: { fontFamily: Fonts.body, fontSize: 13, color: c.muted, marginTop: 20, textAlign: 'center' },
  cta: { height: 54, borderRadius: 16, backgroundColor: c.goldFill, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  ctaText: { fontFamily: Fonts.bodyBold, fontSize: 16, color: c.onGold },
  link: { alignSelf: 'center', marginTop: 14 },
  linkText: { fontFamily: Fonts.bodySemi, fontSize: 14, color: c.muted },
}));
