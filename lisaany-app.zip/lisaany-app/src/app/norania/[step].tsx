import { LinearGradient } from 'expo-linear-gradient';
import { Stack, useFocusEffect, useLocalSearchParams, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useCallback, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Icon } from '@/components/icon';
import { Stars } from '@/components/stars';
import { Fonts } from '@/constants/lisaany';
import { useLang } from '@/lib/i18n';
import {
  NORANIA_LESSONS,
  NORANIA_STEPS,
  NORANIA_TYPE_LABELS,
  getNoraniaDone,
  getNoraniaStars,
  isLessonDone,
  lessonGlyph,
  starsFor,
  type NoraniaDone,
  type NoraniaStars,
} from '@/lib/norania';
import { NR, NR_GOLD, NR_SHADOW } from '@/theme/norania';
import { contentCap } from '@/components/content-width';

/**
 * One Norania step: a list of its lessons. Finished ones show their stars, the
 * next one is highlighted with a Start button, later ones are faded. Every
 * lesson stays open — a parent can jump ahead or go back any time.
 */
export default function NoraniaStepScreen() {
  const { step } = useLocalSearchParams<{ step: string }>();
  const k = Math.max(0, Math.min(NORANIA_STEPS.length - 1, Number(step) || 0));
  const s = NORANIA_STEPS[k];
  const { t, ct } = useLang();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [done, setDone] = useState<NoraniaDone>({});
  const [stars, setStars] = useState<NoraniaStars>({});

  useFocusEffect(
    useCallback(() => {
      getNoraniaDone().then(setDone);
      getNoraniaStars().then(setStars);
    }, [])
  );

  const ids = s.lessons;
  const total = ids.length;
  const doneCount = ids.filter((i) => isLessonDone(done, i)).length;
  const complete = total > 0 && doneCount >= total;
  const nextPos = ids.findIndex((i) => !isLessonDone(done, i));

  const open = (i: number) => router.push({ pathname: '/norania-lesson/[i]', params: { i: String(i) } });
  const back = () => (router.canGoBack() ? router.back() : router.replace('/norania'));

  return (
    <View style={styles.screen}>
      <Stack.Screen options={{ headerShown: false }} />
      <StatusBar style="dark" />
      <ScrollView contentContainerStyle={[styles.content, { paddingTop: insets.top + 12, paddingBottom: insets.bottom + 40 }]} showsVerticalScrollIndicator={false}>
        <View style={styles.top}>
          <Pressable onPress={back} hitSlop={8} style={styles.backBtn} accessibilityLabel={t('Back')}>
            <Icon name="arrow_back" size={22} color={NR.navy} />
          </Pressable>
          <Text style={styles.eyebrow} numberOfLines={1}>
            {t('Learn to read · Step {n} of {total}', { n: k + 1, total: NORANIA_STEPS.length })}
          </Text>
        </View>

        <Text style={styles.title}>{ct(s.name)}</Text>
        <Text style={styles.desc}>{ct(s.desc)}</Text>

        <View style={styles.track}>
          <View style={[styles.fill, { width: `${Math.round((doneCount / Math.max(1, total)) * 100)}%` }]} />
        </View>
        <Text style={styles.count}>{complete ? t('All {total} lessons done', { total }) : t('{n} of {total} done', { n: doneCount, total })}</Text>

        {ids.map((id, p) => {
          const l = NORANIA_LESSONS[id];
          if (!l) return null;
          const isDone = isLessonDone(done, id);
          const isNext = p === nextPos;
          const later = !isDone && !isNext;
          const kind = NORANIA_TYPE_LABELS[l.type] ?? 'Lesson';
          return (
            <Pressable
              key={id}
              onPress={() => open(id)}
              style={({ pressed }) => [styles.row, isNext && styles.rowNext, later && styles.rowLater, pressed && { transform: [{ scale: 0.98 }] }]}
              accessibilityLabel={isDone ? t('{title}, done', { title: ct(l.title) }) : isNext ? t('{title}, up next', { title: ct(l.title) }) : ct(l.title)}>
              {isNext ? (
                <LinearGradient colors={NR_GOLD} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.tile}>
                  <Text style={[styles.tileAr, { color: NR.navy }]}>{lessonGlyph(l)}</Text>
                </LinearGradient>
              ) : (
                <View style={[styles.tile, styles.tileIdle]}>
                  <Text style={[styles.tileAr, later && { color: NR.lock }]}>{lessonGlyph(l)}</Text>
                </View>
              )}
              <View style={{ flex: 1 }}>
                <Text style={styles.kick} numberOfLines={1}>
                  {t('Lesson {n} · {type}', { n: p + 1, type: t(kind) })}
                </Text>
                <Text style={styles.name} numberOfLines={2}>
                  {ct(l.title)}
                </Text>
              </View>
              {isDone ? (
                <Stars n={starsFor(stars, id)} size={16} on={NR.gold} off={NR.border} gap={2} />
              ) : isNext ? (
                <LinearGradient colors={NR_GOLD} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.start}>
                  <Text style={styles.startText}>{doneCount ? t('Start') : t('Begin')}</Text>
                </LinearGradient>
              ) : (
                <Icon name="chevron_right" size={20} color={NR.goldDeep} />
              )}
            </Pressable>
          );
        })}

        {doneCount > 0 ? (
          <Pressable onPress={() => open(ids[0])} style={({ pressed }) => [styles.again, pressed && { opacity: 0.8 }]}>
            <Icon name="replay" size={17} color={NR.navy} />
            <Text style={styles.againText}>{t('Start again from lesson 1')}</Text>
          </Pressable>
        ) : null}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: NR.bg },
  content: { paddingHorizontal: 20 , ...contentCap },
  top: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  backBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: NR.card, borderWidth: 1, borderColor: NR.border, alignItems: 'center', justifyContent: 'center' },
  eyebrow: { flex: 1, fontFamily: Fonts.bodySemi, fontSize: 12.5, color: NR.dim },
  title: { fontFamily: Fonts.displayBold, fontSize: 28, lineHeight: 34, color: NR.navy, marginTop: 18 },
  desc: { fontFamily: Fonts.body, fontSize: 14, lineHeight: 20, color: NR.dim, marginTop: 4 },
  track: { height: 6, borderRadius: 3, backgroundColor: NR.track, marginTop: 16, overflow: 'hidden' },
  fill: { height: 6, borderRadius: 3, backgroundColor: NR.gold },
  count: { fontFamily: Fonts.body, fontSize: 12.5, color: NR.dim, marginTop: 6, marginBottom: 12 },

  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    paddingVertical: 12,
    paddingHorizontal: 12,
    borderRadius: 20,
    backgroundColor: NR.card,
    borderWidth: 1,
    borderColor: NR.border,
    marginBottom: 10,
    ...NR_SHADOW,
  },
  rowNext: { borderWidth: 2.5, borderColor: NR.gold, ...NR_SHADOW },
  rowLater: { opacity: 0.62 },
  tile: { width: 62, height: 62, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  tileIdle: { backgroundColor: NR.bg, borderWidth: 1, borderColor: NR.border },
  tileAr: { fontFamily: Fonts.naskh, fontSize: 30, lineHeight: 52, color: NR.goldDeep },
  kick: { fontFamily: Fonts.body, fontSize: 12, color: NR.dim },
  name: { fontFamily: Fonts.bodyBold, fontSize: 16.5, lineHeight: 21, color: NR.navy, marginTop: 2 },
  start: { paddingHorizontal: 16, paddingVertical: 9, borderRadius: 999 },
  startText: { fontFamily: Fonts.bodyBold, fontSize: 14, color: NR.navy },

  again: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    height: 50,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: NR.border,
    backgroundColor: NR.card,
    marginTop: 8,
  },
  againText: { fontFamily: Fonts.bodyBold, fontSize: 15, color: NR.navy },
});
