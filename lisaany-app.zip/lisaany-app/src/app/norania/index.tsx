import { LinearGradient } from 'expo-linear-gradient';
import { Stack, useFocusEffect, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useCallback, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Icon } from '@/components/icon';
import { PopPressable } from '@/components/pop-card';
import { Fonts } from '@/constants/lisaany';
import { useLang } from '@/lib/i18n';
import {
  NORANIA_LESSONS,
  NORANIA_STEPS,
  getNoraniaDone,
  getNoraniaWeek,
  lessonGlyph,
  nextNoraniaLesson,
  stepDoneCount,
  stepGlyph,
  type NoraniaDone,
  type NoraniaWeekDay,
} from '@/lib/norania';
import { NR, NR_GOLD, NR_SHADOW } from '@/theme/norania';

/** Weekday initials, Monday first (French). */
const FR_DAYS = ['L', 'M', 'M', 'J', 'V', 'S', 'D'];

/** Learn to read (Norania): continue card, this week, then the ten steps. */
export default function NoraniaHome() {
  const { t, ct, lang } = useLang();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [done, setDone] = useState<NoraniaDone>({});
  const [week, setWeek] = useState<NoraniaWeekDay[]>([]);

  useFocusEffect(
    useCallback(() => {
      getNoraniaDone().then(setDone);
      getNoraniaWeek().then(setWeek);
    }, [])
  );

  const total = NORANIA_LESSONS.length;
  const doneCount = NORANIA_LESSONS.filter((l) => done[l.title]).length;
  const next = nextNoraniaLesson(done);
  const nextLesson = NORANIA_LESSONS[next];
  const nextStep = NORANIA_STEPS[nextLesson?.step ?? 0];
  // Newest finished step, for the certificate card.
  const certStep = NORANIA_STEPS.reduce((acc, s, k) => (s.lessons.length > 0 && stepDoneCount(done, s) >= s.lessons.length ? k : acc), -1);
  const open = (i: number) => router.push({ pathname: '/norania-lesson/[i]', params: { i: String(i) } });
  const back = () => (router.canGoBack() ? router.back() : router.replace('/lessons'));

  return (
    <View style={styles.screen}>
      <Stack.Screen options={{ headerShown: false }} />
      <StatusBar style="dark" />
      <ScrollView contentContainerStyle={[styles.content, { paddingTop: insets.top + 12, paddingBottom: insets.bottom + 40 }]} showsVerticalScrollIndicator={false}>
        <View style={styles.top}>
          <Pressable onPress={back} hitSlop={8} style={styles.backBtn} accessibilityLabel={t('Back')}>
            <Icon name="arrow_back" size={22} color={NR.navy} />
          </Pressable>
          <Text style={styles.eyebrow}>{t('Quran Norania')}</Text>
        </View>

        <Text style={styles.title}>{t('Learn to read')}</Text>
        <Text style={styles.titleAr}>نُورَانِيَّة</Text>
        <Text style={styles.sub}>{t('Letters, vowels and joining — step by step, until you can read the Qur’an.')}</Text>

        {nextLesson ? (
          <View style={styles.hero}>
            <Text style={styles.heroEyebrow}>{doneCount ? t('CONTINUE WHERE YOU LEFT OFF') : t('START HERE')}</Text>
            <View style={styles.heroRow}>
              <LinearGradient colors={NR_GOLD} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.heroIcon}>
                <Text style={styles.heroIconAr}>{lessonGlyph(nextLesson)}</Text>
              </LinearGradient>
              <View style={{ flex: 1 }}>
                <Text style={styles.heroStep} numberOfLines={1}>
                  {t('Step {n} · {name}', { n: (nextLesson.step ?? 0) + 1, name: ct(nextStep?.name ?? '') })}
                </Text>
                <Text style={styles.heroTitle} numberOfLines={2}>
                  {ct(nextLesson.title)}
                </Text>
              </View>
            </View>
            <View style={styles.track}>
              <View style={[styles.fill, { width: `${Math.round((doneCount / Math.max(1, total)) * 100)}%` }]} />
            </View>
            <Text style={styles.heroCount}>
              {t('{n} of {total} lessons done', { n: doneCount, total })}
            </Text>
            <Pressable onPress={() => open(next)} style={({ pressed }) => [pressed && { opacity: 0.88 }]}>
              <LinearGradient colors={NR_GOLD} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.cta}>
                <Text style={styles.ctaText}>{doneCount ? t('Continue') : t('Start lesson 1')}</Text>
                <Icon name="arrow_forward" size={20} color={NR.navy} />
              </LinearGradient>
            </Pressable>
          </View>
        ) : null}

        {/* This week */}
        <View style={styles.weekCard}>
          <View style={styles.weekHead}>
            <Text style={styles.weekTitle}>{t('This week')}</Text>
            <Text style={styles.weekStars}>{week.filter((d) => d.star).length} ★</Text>
          </View>
          <View style={styles.weekRow}>
            {week.map((d, k) => (
              <View key={k} style={styles.day}>
                <View style={[styles.dayDot, d.star && styles.dayDotOn, d.isToday && !d.star && styles.dayToday]}>
                  {d.star ? <Text style={styles.dayStar}>★</Text> : null}
                </View>
                <Text style={[styles.dayLabel, d.isToday && { color: NR.goldDeep }]}>{lang === 'fr' ? FR_DAYS[k] : d.label}</Text>
              </View>
            ))}
          </View>
          <Text style={styles.weekFoot}>{t('One lesson a day earns a star.')}</Text>
        </View>

        {certStep >= 0 ? (
          <PopPressable onPress={() => router.push({ pathname: '/norania-certificate/[step]', params: { step: String(certStep) } })} style={styles.certWrap} scaleTo={1.02} plain>
            <View style={styles.certCard}>
              <Icon name="workspace_premium" size={30} color={NR.goldDeep} />
              <View style={{ flex: 1 }}>
                <Text style={styles.certTitle}>{t('Certificate ready')}</Text>
                <Text style={styles.certSub}>{t('{step} · all lessons finished', { step: ct(NORANIA_STEPS[certStep].name) })}</Text>
              </View>
              <Icon name="chevron_right" size={20} color={NR.goldDeep} />
            </View>
          </PopPressable>
        ) : null}

        <Text style={styles.section}>{t('THE PATH · {n} STEPS', { n: NORANIA_STEPS.length })}</Text>
        {NORANIA_STEPS.map((s, k) => {
          const n = stepDoneCount(done, s);
          const full = n >= s.lessons.length && s.lessons.length > 0;
          const current = !full && k === (nextLesson?.step ?? -1);
          return (
            <PopPressable key={s.name} onPress={() => router.push({ pathname: '/norania/[step]', params: { step: String(k) } })} style={styles.stepWrap} scaleTo={1.02} plain>
              <View style={[styles.stepCard, current && styles.stepCardCurrent]}>
                {full || current ? (
                  <LinearGradient colors={NR_GOLD} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.stepIcon}>
                    <Text style={[styles.stepIconAr, { color: NR.navy }]}>{stepGlyph(s)}</Text>
                  </LinearGradient>
                ) : (
                  <View style={[styles.stepIcon, styles.stepIconIdle]}>
                    <Text style={styles.stepIconAr}>{stepGlyph(s)}</Text>
                  </View>
                )}
                <View style={{ flex: 1 }}>
                  <Text style={styles.stepKick}>
                    {s.lessons.length === 1
                      ? t('Step {n} · 1 lesson', { n: k + 1 })
                      : t('Step {n} · {count} lessons', { n: k + 1, count: s.lessons.length })}
                  </Text>
                  <Text style={styles.stepName}>{ct(s.name)}</Text>
                  <Text style={styles.stepDesc} numberOfLines={2}>
                    {ct(s.desc)}
                  </Text>
                  <View style={[styles.track, styles.stepTrack]}>
                    <View style={[styles.fill, { width: `${Math.round((n / Math.max(1, s.lessons.length)) * 100)}%` }]} />
                  </View>
                </View>
                <Icon name={full ? 'check_circle' : 'chevron_right'} size={full ? 22 : 20} color={NR.goldDeep} />
              </View>
            </PopPressable>
          );
        })}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: NR.bg },
  content: { paddingHorizontal: 20 },
  top: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  backBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: NR.card, borderWidth: 1, borderColor: NR.border, alignItems: 'center', justifyContent: 'center' },
  eyebrow: { fontFamily: Fonts.bodySemi, fontSize: 12.5, color: NR.dim },
  title: { fontFamily: Fonts.displayBold, fontSize: 30, lineHeight: 36, color: NR.navy, marginTop: 18 },
  titleAr: { fontFamily: Fonts.naskh, fontSize: 24, lineHeight: 44, color: NR.goldDeep, textAlign: 'left', writingDirection: 'rtl' },
  sub: { fontFamily: Fonts.body, fontSize: 14, lineHeight: 21, color: NR.dim, marginTop: 2 },

  hero: { borderRadius: 24, padding: 18, marginTop: 18, backgroundColor: NR.card, borderWidth: 1, borderColor: NR.border, ...NR_SHADOW },
  heroEyebrow: { fontFamily: Fonts.bodyBold, fontSize: 11, letterSpacing: 1.6, color: NR.goldDeep },
  heroRow: { flexDirection: 'row', alignItems: 'center', gap: 14, marginTop: 12 },
  heroIcon: { width: 62, height: 62, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  heroIconAr: { fontFamily: Fonts.naskh, fontSize: 30, lineHeight: 52, color: NR.navy },
  heroStep: { fontFamily: Fonts.body, fontSize: 12.5, color: NR.dim },
  heroTitle: { fontFamily: Fonts.displayBold, fontSize: 20, lineHeight: 25, color: NR.navy, marginTop: 2 },
  heroCount: { fontFamily: Fonts.body, fontSize: 12, color: NR.dim, marginTop: 6 },
  track: { height: 6, borderRadius: 3, backgroundColor: NR.track, marginTop: 14, overflow: 'hidden' },
  fill: { height: 6, borderRadius: 3, backgroundColor: NR.gold },
  cta: { height: 52, borderRadius: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 14 },
  ctaText: { fontFamily: Fonts.bodyBold, fontSize: 16, color: NR.navy },

  weekCard: { marginTop: 14, borderRadius: 20, padding: 16, backgroundColor: NR.card, borderWidth: 1, borderColor: NR.border, ...NR_SHADOW },
  weekHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  weekTitle: { fontFamily: Fonts.bodyBold, fontSize: 15, color: NR.navy },
  weekStars: { fontFamily: Fonts.bodyBold, fontSize: 14, color: NR.goldDeep },
  weekRow: { flexDirection: 'row', gap: 6, marginTop: 12 },
  day: { flex: 1, alignItems: 'center' },
  dayDot: { width: 34, height: 34, borderRadius: 17, backgroundColor: NR.bg, borderWidth: 1, borderColor: NR.border, alignItems: 'center', justifyContent: 'center' },
  dayDotOn: { backgroundColor: NR.gold, borderColor: NR.gold },
  dayToday: { borderWidth: 1.5, borderColor: NR.gold },
  dayStar: { fontSize: 16, lineHeight: 20, color: NR.navy },
  dayLabel: { fontFamily: Fonts.bodyBold, fontSize: 11, color: NR.dim, marginTop: 4 },
  weekFoot: { fontFamily: Fonts.body, fontSize: 12, color: NR.dim, marginTop: 10 },

  certWrap: { borderRadius: 20, marginTop: 14 },
  certCard: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14, borderRadius: 19, backgroundColor: NR.card, borderWidth: 1.5, borderColor: NR.gold },
  certTitle: { fontFamily: Fonts.bodyBold, fontSize: 15, color: NR.navy },
  certSub: { fontFamily: Fonts.body, fontSize: 12.5, color: NR.dim, marginTop: 1 },

  section: { fontFamily: Fonts.bodyBold, fontSize: 11.5, letterSpacing: 1.6, color: NR.dim, marginTop: 26, marginBottom: 4 },
  stepWrap: { borderRadius: 20, marginTop: 10 },
  stepCard: { flexDirection: 'row', alignItems: 'center', gap: 14, padding: 14, borderRadius: 19, backgroundColor: NR.card, borderWidth: 1, borderColor: NR.border, ...NR_SHADOW },
  stepCardCurrent: { borderWidth: 2, borderColor: NR.gold },
  stepIcon: { width: 56, height: 56, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  stepIconIdle: { backgroundColor: NR.bg, borderWidth: 1, borderColor: NR.border },
  stepIconAr: { fontFamily: Fonts.naskh, fontSize: 26, lineHeight: 46, color: NR.goldDeep },
  stepKick: { fontFamily: Fonts.bodySemi, fontSize: 11.5, color: NR.dim },
  stepName: { fontFamily: Fonts.bodyBold, fontSize: 16, color: NR.navy, marginTop: 1 },
  stepDesc: { fontFamily: Fonts.body, fontSize: 12.5, lineHeight: 17, color: NR.dim, marginTop: 2 },
  stepTrack: { marginTop: 8, height: 4 },
});
