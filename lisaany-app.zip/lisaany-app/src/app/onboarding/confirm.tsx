import { useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import { Text, View } from 'react-native';

import {
  OnboardCard,
  OnboardingFooter,
  OnboardingGhost,
  OnboardingHeader,
  OnboardingScreen,
} from '@/components/onboarding-nav';
import { OnboardingTalk, resetOnboardingTalk } from '@/components/onboarding-talk';
import { Fonts } from '@/constants/lisaany';
import { useLang } from '@/lib/i18n';
import { getCanReadArabic, setHasSeenLanding } from '@/lib/onboarding';
import { makeStyles } from '@/theme';

/**
 * Onboarding step 4 of 4 — the last screen before the app.
 *
 * Deliberately quiet: the star (still where it landed on step 1) says one
 * line, and under it a single standard card names the path the reading answer
 * chose — "yes" → the Arabic platform, "not yet" → Norania — with the Arabic
 * name set very faint behind the text. What the learner picked on steps 1–3 is
 * not repeated back; they just chose it. One gold button starts, and the quiet
 * button underneath goes back to step 2 to change the reading answer.
 *
 * Everything fits one screen: no scroll view, the space left over split above
 * and below the card.
 */
const PATHS = {
  arabic: {
    ar: 'اللُّغَةُ العَرَبِيَّة',
    title: 'Arabic Platform',
    sub: 'Conversations, words and grammar.',
    cta: 'Start learning',
  },
  nornia: {
    ar: 'نُورَانِيَّة',
    title: 'Norania',
    sub: 'Learn to read, letter by letter.',
    cta: 'Start Norania',
  },
} as const;

export default function ConfirmScreen() {
  const router = useRouter();
  const { t } = useLang();
  const s = useStyles();
  const [canRead, setCanRead] = useState<boolean | null | undefined>(undefined);

  useEffect(() => {
    getCanReadArabic().then(setCanRead);
  }, []);

  const leave = async () => {
    resetOnboardingTalk();
    await setHasSeenLanding();
  };
  const enterApp = async () => {
    await leave();
    router.replace('/');
  };
  const openNornia = async () => {
    await leave();
    router.replace('/');
    router.push('/norania');
  };

  const key = canRead === false ? 'nornia' : 'arabic';
  const p = PATHS[key];
  const go = key === 'nornia' ? openNornia : enterApp;

  return (
    <OnboardingScreen>
      <OnboardingHeader step={4} total={4} eyebrow={t('STEP 4 · YOUR PATH')} title={t('You’re all set')} />

      <View style={s.body}>
        <OnboardingTalk
          line={t(
            'You’re ready to learn Arabic. Work through this course and you’ll be speaking it fluently — I’ll be with you the whole way.',
          )}
        />

        <View style={s.stack}>
          {canRead === undefined ? null : (
            <OnboardCard>
              <View style={s.path}>
                <Text style={s.watermark} numberOfLines={1}>
                  {p.ar}
                </Text>
                <Text style={s.kicker}>{t('YOUR PATH')}</Text>
                <Text style={s.name}>{t(p.title)}</Text>
                <Text style={s.desc}>{t(p.sub)}</Text>
              </View>
            </OnboardCard>
          )}
        </View>

        <Text style={s.note}>{t('You can change any of this later in Settings.')}</Text>
      </View>

      <OnboardingFooter onNext={go} label={t(p.cta)} />
      <OnboardingGhost
        label={key === 'nornia' ? t('Actually, I can read Arabic') : t('Actually, I can’t read Arabic yet')}
        onPress={() => router.dismissTo('/onboarding/reader-check')}
      />
    </OnboardingScreen>
  );
}

const useStyles = makeStyles((c) => ({
  body: { flex: 1, paddingTop: 20 },
  /** The card sits in the middle of what is left, so no gap piles up. */
  stack: { flex: 1, justifyContent: 'center' },
  note: { fontFamily: Fonts.body, fontSize: 12.5, lineHeight: 18, color: c.muted, textAlign: 'center', marginBottom: 14 },

  path: { paddingHorizontal: 18, paddingTop: 16, paddingBottom: 18 },
  /** The path's Arabic name, very faint behind the text and clipped by the card. */
  watermark: {
    position: 'absolute',
    right: -6,
    top: -16,
    fontFamily: Fonts.arabicBold,
    fontSize: 56,
    lineHeight: 96,
    color: c.gold,
    opacity: 0.09,
    writingDirection: 'rtl',
  },
  kicker: { fontFamily: Fonts.bodyBold, fontSize: 10.5, letterSpacing: 2, color: c.gold },
  name: { fontFamily: Fonts.display, fontSize: 24, lineHeight: 32, color: c.text, marginTop: 5 },
  desc: { fontFamily: Fonts.body, fontSize: 13.5, lineHeight: 19, color: c.muted, marginTop: 5 },
}));
