import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Icon } from '@/components/icon';
import { PopPressable } from '@/components/pop-card';
import { Onboard, OnboardingFooter, OnboardingHeader, onboardText } from '@/components/onboarding-nav';
import { Fonts, Spacing } from '@/constants/lisaany';
import { useLang } from '@/lib/i18n';
import { getCanReadArabic, setHasSeenLanding } from '@/lib/onboarding';

/**
 * Onboarding step 3 of 3 — shows only the path that fits the reading answer:
 * "yes" → the Arabic platform (this app), "not yet" → Norania (the
 * reading course inside the app). Going back to step 2 changes the answer.
 */
const PATHS = {
  arabic: {
    icon: 'menu_book',
    ar: 'اللُّغَةُ العَرَبِيَّة',
    title: 'Arabic Platform',
    sub: 'Real conversations, vocabulary and grammar — from your first hello to the news.',
    points: ['14 modules, one step at a time', 'Listen, speak and practise every day'],
    cta: 'Start learning',
  },
  nornia: {
    icon: 'edit_note',
    ar: 'نُورَانِيَّة',
    title: 'Norania',
    sub: 'Learn to read Arabic from the very first letter, the way children learn the Qur’an.',
    points: ['Letters, sounds and vowels — 33 short lessons', 'Right here in the app'],
    cta: 'Start Norania',
  },
} as const;

export default function ConfirmScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { t } = useLang();
  const [canRead, setCanRead] = useState<boolean | null | undefined>(undefined);

  useEffect(() => {
    getCanReadArabic().then(setCanRead);
  }, []);

  const enterApp = async () => {
    await setHasSeenLanding();
    router.replace('/');
  };
  const openNornia = async () => {
    await setHasSeenLanding();
    router.replace('/');
    router.push('/norania');
  };

  const key = canRead === false ? 'nornia' : 'arabic';
  const p = PATHS[key];
  const go = key === 'nornia' ? openNornia : enterApp;

  return (
    <View style={[styles.screen, { paddingTop: insets.top + 14, paddingBottom: insets.bottom + 20 }]}>
      <OnboardingHeader step={3} total={3} eyebrow={t('STEP 3 · YOUR PATH')} />
      <Text style={onboardText.title}>{t('You’re all set')}</Text>
      <Text style={onboardText.sub}>{t('Here’s where you’ll start.')}</Text>

      {canRead === undefined ? null : (
        <PopPressable onPress={go} style={styles.cardWrap}>
          <LinearGradient colors={['#253149', '#1e2a42']} start={{ x: 0.2, y: 0 }} end={{ x: 0.8, y: 1 }} style={styles.card}>
            <View style={styles.cardTop}>
              <View style={styles.icon}>
                <Icon name={p.icon} size={26} color={Onboard.onGold} />
              </View>
              <Text style={styles.cardAr}>{p.ar}</Text>
            </View>
            <Text style={styles.cardTitle}>{t(p.title)}</Text>
            <Text style={styles.cardSub}>{t(p.sub)}</Text>
            {p.points.map((pt) => (
              <View key={pt} style={styles.point}>
                <Icon name="check" size={16} color={Onboard.gold} />
                <Text style={styles.pointText}>{t(pt)}</Text>
              </View>
            ))}
          </LinearGradient>
        </PopPressable>
      )}

      <View style={{ flex: 1 }} />
      <OnboardingFooter onNext={go} label={t(p.cta)} tagline={t('SAME GOAL · YOUR OWN PATH')}>
        <Pressable onPress={() => router.back()} hitSlop={8} style={styles.change}>
          <Text style={styles.changeText}>
            {key === 'nornia' ? t('Actually, I can read Arabic') : t('Actually, I can’t read Arabic yet')}
          </Text>
        </Pressable>
      </OnboardingFooter>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Onboard.bg, paddingHorizontal: Spacing.lg },
  cardWrap: { borderRadius: 26, marginTop: 6, borderColor: 'rgba(230,184,90,0.5)' },
  card: { borderRadius: 25, padding: 20, overflow: 'hidden' },
  cardTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 },
  icon: {
    width: 54,
    height: 54,
    borderRadius: 16,
    backgroundColor: Onboard.gold,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cardAr: { fontFamily: Fonts.arabic, fontSize: 26, lineHeight: 40, color: Onboard.gold },
  cardTitle: { fontFamily: Fonts.displayBold, fontSize: 24, lineHeight: 30, color: '#fff' },
  cardSub: { fontFamily: Fonts.body, fontSize: 14, lineHeight: 21, color: '#c9d3e6', marginTop: 6, marginBottom: 12 },
  point: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 6 },
  pointText: { fontFamily: Fonts.bodyMedium, fontSize: 13.5, color: '#e8ebf1' },
  change: { alignSelf: 'center', paddingTop: 14 },
  changeText: { fontFamily: Fonts.bodySemi, fontSize: 13.5, color: Onboard.inkDim },
});
