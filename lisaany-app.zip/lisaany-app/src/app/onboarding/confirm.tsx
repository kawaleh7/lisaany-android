import { useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import { Pressable, Text, View } from 'react-native';

import { OnboardCard, OnboardingFooter, OnboardingHeader, OnboardingScreen } from '@/components/onboarding-nav';
import { Fonts } from '@/constants/lisaany';
import { useLang } from '@/lib/i18n';
import { getCanReadArabic, setHasSeenLanding } from '@/lib/onboarding';
import { makeStyles } from '@/theme';

/**
 * Onboarding step 4 of 4 — shows only the path that fits the reading answer:
 * "yes" → the Arabic platform (this app), "not yet" → Norania (the
 * reading course inside the app). The link under the card goes back to
 * step 2 to change the answer.
 */
const PATHS = {
  arabic: {
    ar: 'اللُّغَةُ العَرَبِيَّة',
    title: 'Arabic Platform',
    sub: 'Conversations, words and grammar.',
    cta: 'Start learning',
  },
  nornia: {
    ar: 'نُورَانِيَّة',
    title: 'Norania',
    sub: 'Learn to read, letter by letter.',
    cta: 'Start Norania',
  },
} as const;

export default function ConfirmScreen() {
  const router = useRouter();
  const { t } = useLang();
  const s = useStyles();
  const [canRead, setCanRead] = useState<boolean | null | undefined>(undefined);

  useEffect(() => {
    getCanReadArabic().then(setCanRead);
  }, []);

  const enterApp = async () => {
    await setHasSeenLanding();
    router.replace('/');
  };
  const openNornia = async () => {
    await setHasSeenLanding();
    router.replace('/');
    router.push('/norania');
  };

  const key = canRead === false ? 'nornia' : 'arabic';
  const p = PATHS[key];
  const go = key === 'nornia' ? openNornia : enterApp;

  return (
    <OnboardingScreen>
      <OnboardingHeader step={4} total={4} eyebrow={t('STEP 4 · YOUR PATH')} title={t('You’re all set')} />

      {canRead === undefined ? null : (
        <>
          <OnboardCard selected style={s.card}>
            <View style={s.cardBody}>
              <Text style={s.cardAr}>{p.ar}</Text>
              <Text style={s.cardTitle}>{t(p.title)}</Text>
              <Text style={s.cardSub}>{t(p.sub)}</Text>
            </View>
          </OnboardCard>
          <Pressable onPress={() => router.dismissTo('/onboarding/reader-check')} hitSlop={8} style={s.change} accessibilityRole="link">
            <Text style={s.changeText}>
              {key === 'nornia' ? t('Actually, I can read Arabic') : t('Actually, I can’t read Arabic yet')}
            </Text>
          </Pressable>
        </>
      )}

      <View style={{ flex: 1 }} />
      <OnboardingFooter onNext={go} label={t(p.cta)} />
    </OnboardingScreen>
  );
}

const useStyles = makeStyles((c) => ({
  card: { marginTop: 16 },
  cardBody: { paddingHorizontal: 20, paddingTop: 16, paddingBottom: 20 },
  cardAr: { fontFamily: Fonts.arabic, fontSize: 30, lineHeight: 50, color: c.gold, textAlign: 'left' },
  cardTitle: { fontFamily: Fonts.bodyBold, fontSize: 23, lineHeight: 29, color: c.text, marginTop: 2 },
  cardSub: { fontFamily: Fonts.body, fontSize: 15, lineHeight: 21, color: c.muted, marginTop: 6 },
  change: { alignSelf: 'center', paddingVertical: 14 },
  changeText: { fontFamily: Fonts.bodySemi, fontSize: 14, color: c.muted, textDecorationLine: 'underline' as const },
}));
