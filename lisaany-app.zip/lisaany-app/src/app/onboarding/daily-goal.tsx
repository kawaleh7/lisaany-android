import { useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import { BackHandler, Text, View } from 'react-native';

import { TimeChips } from '@/components/goal-controls';
import {
  OnboardingBody,
  OnboardingFooter,
  OnboardingGhost,
  OnboardingHeader,
  OnboardingScreen,
  OptionCard,
} from '@/components/onboarding-nav';
import { StarSlot, StarTalk, useStarGuide } from '@/components/star-guide';
import { Fonts } from '@/constants/lisaany';
import { changeMinGoal, changeReminderPrefs } from '@/lib/goal-sync';
import { useLang } from '@/lib/i18n';
import { DEFAULT_REMINDER, getReminderPrefs, requestPermission } from '@/lib/reminders';
import { makeStyles } from '@/theme';

type Phase = 'ask' | 'pick' | 'remind';

const SMALLER: { m: number; title: string; sub: string; popular?: boolean }[] = [
  { m: 5, title: 'Quick start', sub: 'A little every day' },
  { m: 10, title: 'Steady', sub: 'A steady habit', popular: true },
  { m: 15, title: 'Serious', sub: 'Real progress' },
];

/**
 * Onboarding step 3 of 4 — the daily goal, then reminders. Everyone is asked
 * for 30 minutes a day first; "Not yet" offers 5, 10 or 15 (one must be
 * picked). Then the star asks when to remind them, only on days the goal
 * isn't reached yet.
 */
export default function DailyGoalScreen() {
  const router = useRouter();
  const { t } = useLang();
  const s = useStyles();
  const [phase, setPhase] = useState<Phase>('ask');
  const [pick, setPick] = useState<number | null>(null);
  const [cameFromPick, setCameFromPick] = useState(false);
  const [time, setTime] = useState({ hour: DEFAULT_REMINDER.hour, minute: DEFAULT_REMINDER.minute });
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    getReminderPrefs().then((p) => setTime({ hour: p.hour, minute: p.minute }));
  }, []);

  const line =
    phase === 'ask'
      ? t('People who give Arabic 30 minutes a day make real progress. Can you commit to that?')
      : phase === 'pick'
        ? t('No problem — starting small is how habits stick. Pick one and I’ll hold you to it.')
        : t('If you’re away for a few days, I’ll send you a gentle reminder. When suits you best?');
  const guide = useStarGuide([line]);
  const { say } = guide;
  useEffect(() => {
    // The star keeps its line up while the learner decides (tap to hide it).
    const id = setTimeout(() => say(line, 10 * 60 * 1000), 450);
    return () => clearTimeout(id);
  }, [line, say]);

  const yes30 = async () => {
    await changeMinGoal(30);
    setCameFromPick(false);
    setPhase('remind');
  };
  const commit = async () => {
    if (!pick) return;
    await changeMinGoal(pick);
    setCameFromPick(true);
    setPhase('remind');
  };
  const finish = () => router.push('/onboarding/confirm');
  const turnOn = async () => {
    if (busy) return;
    setBusy(true);
    const granted = await requestPermission();
    await changeReminderPrefs({ enabled: granted, ...time });
    setBusy(false);
    finish();
  };
  const notNow = async () => {
    await changeReminderPrefs({ enabled: false, ...time });
    finish();
  };
  const back = () => {
    if (phase === 'remind') setPhase(cameFromPick ? 'pick' : 'ask');
    else if (phase === 'pick') setPhase('ask');
    else if (router.canGoBack()) router.back();
    else router.replace('/landing');
  };

  // Android back steps back inside this screen first.
  useEffect(() => {
    if (phase === 'ask') return;
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      setPhase(phase === 'remind' && cameFromPick ? 'pick' : 'ask');
      return true;
    });
    return () => sub.remove();
  }, [phase, cameFromPick]);

  const eyebrow = phase === 'remind' ? t('STEP 3 · REMINDERS') : t('STEP 3 · YOUR DAILY GOAL');
  const title =
    phase === 'ask' ? t('30 minutes a day?') : phase === 'pick' ? t('Pick your goal') : t('When should I remind you?');

  return (
    <OnboardingScreen>
      <OnboardingHeader step={3} total={4} eyebrow={eyebrow} title={title} onBack={back} right={<StarSlot guide={guide} size={38} />} />
      <OnboardingBody>
        <View style={s.talk}>
          <StarTalk guide={guide} />
        </View>

        {phase === 'ask' ? (
          <View style={s.big}>
            <Text style={s.bigNum}>30</Text>
            <Text style={s.bigUnit}>{t('min / day')}</Text>
          </View>
        ) : null}

        {phase === 'pick'
          ? SMALLER.map((o) => (
              <OptionCard
                key={o.m}
                lead={String(o.m)}
                title={t(o.title)}
                badge={o.popular ? t('Most popular') : undefined}
                sub={`${t('{n} min a day', { n: o.m })} · ${t(o.sub)}`}
                selected={pick === o.m}
                onPress={() => setPick(o.m)}
              />
            ))
          : null}

        {phase === 'remind' ? (
          <View style={{ marginTop: 14 }}>
            <TimeChips hour={time.hour} minute={time.minute} onPick={(hour, minute) => setTime({ hour, minute })} />
            <Text style={s.note}>{t('Only when you haven’t opened the app for a few days. You can change this in Settings.')}</Text>
          </View>
        ) : null}
      </OnboardingBody>

      {phase === 'ask' ? (
        <>
          <OnboardingFooter onNext={yes30} label={t('Yes, I can do 30')} />
          <OnboardingGhost label={t('Not yet')} onPress={() => setPhase('pick')} />
        </>
      ) : phase === 'pick' ? (
        <OnboardingFooter onNext={commit} nextDisabled={!pick} label={t('Commit to this goal')} />
      ) : (
        <>
          <OnboardingFooter onNext={turnOn} nextDisabled={busy} label={t('Turn on reminders')} />
          <OnboardingGhost label={t('Not now')} onPress={notNow} />
        </>
      )}
    </OnboardingScreen>
  );
}

const useStyles = makeStyles((c) => ({
  talk: { minHeight: 8 },
  big: { flexDirection: 'row', alignItems: 'baseline', justifyContent: 'center', gap: 8, marginTop: 30 },
  bigNum: { fontFamily: Fonts.bodyBold, fontSize: 76, lineHeight: 84, color: c.gold },
  bigUnit: { fontFamily: Fonts.bodySemi, fontSize: 18, color: c.muted },
  note: { fontFamily: Fonts.body, fontSize: 13, lineHeight: 19, color: c.muted, marginTop: 14, textAlign: 'center' },
}));
