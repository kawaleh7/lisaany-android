import { useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Onboard, OnboardingFooter, OnboardingHeader, onboardText, RadioRow } from '@/components/onboarding-nav';
import { Spacing } from '@/constants/lisaany';
import { getGoal, setGoal, type LearningGoal } from '@/lib/onboarding';

const OPTIONS: { id: LearningGoal; title: string; sub: string; ar: string }[] = [
  { id: 'quran', title: 'Faith', sub: 'To understand the Qur’an and Islamic knowledge', ar: 'إِيمَان' },
  { id: 'people', title: 'Communication', sub: 'To speak with family, friends or others', ar: 'تَوَاصُل' },
  { id: 'curious', title: 'Personal growth', sub: 'To challenge myself and open new opportunities', ar: 'نُمُوّ' },
];

/**
 * Onboarding step 1 of 3 — collected before any account exists (no forced
 * sign-in). A personalization signal only; it doesn't gate content.
 */
export default function GoalScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [picked, setPicked] = useState<LearningGoal | null>(null);

  useEffect(() => {
    getGoal().then((g) => g && setPicked(g));
  }, []);

  const choose = (id: LearningGoal) => {
    setPicked(id);
    setGoal(id);
  };

  return (
    <View style={[styles.screen, { paddingTop: insets.top + 14, paddingBottom: insets.bottom + 20 }]}>
      <OnboardingHeader step={1} total={3} eyebrow="STEP 1 · YOUR REASON" />
      <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
        <Text style={onboardText.title}>Why Arabic?</Text>
        <Text style={onboardText.sub}>Choose what inspires you most.</Text>
        {OPTIONS.map((o, i) => (
          <RadioRow
            key={o.id}
            title={o.title}
            sub={o.sub}
            arabic={o.ar}
            selected={picked === o.id}
            onPress={() => choose(o.id)}
            last={i === OPTIONS.length - 1}
          />
        ))}
      </ScrollView>
      <OnboardingFooter
        onNext={() => router.push('/onboarding/reader-check')}
        nextDisabled={!picked}
        tagline="A RICHER YOU · A BRIGHTER TOMORROW"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Onboard.bg, paddingHorizontal: Spacing.lg },
});
