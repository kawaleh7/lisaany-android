import { useRouter } from 'expo-router';
import { useEffect, useState } from 'react';

import { OnboardingBody, OnboardingFooter, OnboardingHeader, OnboardingScreen, OptionCard } from '@/components/onboarding-nav';
import { useLang } from '@/lib/i18n';
import { getGoal, setGoal, type LearningGoal } from '@/lib/onboarding';

const OPTIONS: { id: LearningGoal; title: string; sub: string; ar: string; icon: string }[] = [
  { id: 'quran', title: 'Faith', sub: 'Understand the Qur’an', ar: 'إِيمَان', icon: 'menu_book' },
  { id: 'people', title: 'Communication', sub: 'Talk with family and friends', ar: 'تَوَاصُل', icon: 'chat' },
  { id: 'curious', title: 'Personal growth', sub: 'Challenge myself', ar: 'نُمُوّ', icon: 'auto_awesome' },
];

/**
 * Onboarding step 1 of 4 — collected before any account exists (no forced
 * sign-in). A personalization signal only; it doesn't gate content.
 */
export default function GoalScreen() {
  const router = useRouter();
  const { t } = useLang();
  const [picked, setPicked] = useState<LearningGoal | null>(null);

  useEffect(() => {
    getGoal().then((g) => g && setPicked(g));
  }, []);

  const choose = (id: LearningGoal) => {
    setPicked(id);
    setGoal(id);
  };

  return (
    <OnboardingScreen>
      <OnboardingHeader step={1} total={4} eyebrow={t('STEP 1 · YOUR REASON')} title={t('Why Arabic?')} />
      <OnboardingBody>
        {OPTIONS.map((o) => (
          <OptionCard
            key={o.id}
            title={t(o.title)}
            sub={t(o.sub)}
            arabic={o.ar}
            icon={o.icon}
            selected={picked === o.id}
            onPress={() => choose(o.id)}
          />
        ))}
      </OnboardingBody>
      <OnboardingFooter onNext={() => router.push('/onboarding/reader-check')} nextDisabled={!picked} />
    </OnboardingScreen>
  );
}
