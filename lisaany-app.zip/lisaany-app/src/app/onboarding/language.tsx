import { useRouter } from 'expo-router';
import { View } from 'react-native';

import { OnboardingBody, OnboardingFooter, OnboardingHeader, OnboardingScreen, OptionCard } from '@/components/onboarding-nav';
import { OnboardingTalk } from '@/components/onboarding-talk';
import { useLang } from '@/lib/i18n';
import type { LessonLang } from '@/lib/settings';

const OPTIONS: { id: LessonLang; title: string; sub: string; ar: string; icon: string }[] = [
  { id: 'en', title: 'English', sub: 'Lessons explained in English', ar: 'إِنْجِلِيزِي', icon: 'translate' },
  { id: 'fr', title: 'Français', sub: 'Leçons expliquées en français', ar: 'فَرَنْسِي', icon: 'translate' },
];

/**
 * Onboarding step 1 of 5 — the language the lessons are explained in.
 * The course itself is always Arabic. Picking a language switches the app
 * right away, so the rest of onboarding is already in that language.
 * This is the step the star flies in on and greets with the salam.
 */
export default function LanguageScreen() {
  const router = useRouter();
  const { t, lang, setLang } = useLang();

  return (
    <OnboardingScreen>
      <OnboardingHeader step={1} total={5} eyebrow={t('STEP 1 · LANGUAGE')} title={t('Your language')} />
      <OnboardingBody>
        <OnboardingTalk greet line={t('Which language should I explain things in? The lessons themselves are always in Arabic.')} />
        <View style={{ flex: 1, justifyContent: 'center' }}>
          {OPTIONS.map((o) => (
            <OptionCard
              key={o.id}
              title={o.title}
              sub={o.sub}
              arabic={o.ar}
              icon={o.icon}
              selected={lang === o.id}
              onPress={() => setLang(o.id)}
            />
          ))}
        </View>
      </OnboardingBody>
      <OnboardingFooter onNext={() => router.push('/onboarding/goal')} />
    </OnboardingScreen>
  );
}
