import { useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Onboard, OnboardingFooter, OnboardingHeader, onboardText, RadioRow } from '@/components/onboarding-nav';
import { Fonts, Spacing } from '@/constants/lisaany';
import { getCanReadArabic, setCanReadArabic } from '@/lib/onboarding';

/**
 * Onboarding step 2 of 3 — the answer decides the next screen: "yes" shows
 * only the Arabic platform, "not yet" shows only Nornia.
 */
export default function ReaderCheckScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [picked, setPicked] = useState<boolean | null>(null);

  useEffect(() => {
    getCanReadArabic().then((v) => v !== null && setPicked(v));
  }, []);

  const choose = (canRead: boolean) => {
    setPicked(canRead);
    setCanReadArabic(canRead);
  };

  return (
    <View style={[styles.screen, { paddingTop: insets.top + 14, paddingBottom: insets.bottom + 20 }]}>
      <OnboardingHeader step={2} total={3} eyebrow="STEP 2 · READING" />
      <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
        <Text style={onboardText.title}>Can you read it?</Text>
        <Text style={onboardText.sub}>This helps us start you in the right place.</Text>

        <View style={styles.sample}>
          <Text style={styles.sampleLbl}>CAN YOU READ THIS?</Text>
          <Text style={styles.sampleAr}>مَرْحَبًا بِكَ</Text>
        </View>

        <RadioRow
          title="Yes, I can read"
          sub="I can read Arabic letters and words"
          arabic="نَعَم"
          selected={picked === true}
          onPress={() => choose(true)}
        />
        <RadioRow
          title="Not yet"
          sub="I’m starting from the alphabet"
          arabic="لَيْسَ بَعْد"
          selected={picked === false}
          onPress={() => choose(false)}
          last
        />
      </ScrollView>
      <OnboardingFooter
        onNext={() => router.push('/onboarding/confirm')}
        nextDisabled={picked === null}
        tagline="A RICHER YOU · A BRIGHTER TOMORROW"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Onboard.bg, paddingHorizontal: Spacing.lg },
  sample: {
    alignItems: 'center',
    borderRadius: 20,
    borderWidth: 1,
    borderStyle: 'dashed',
    borderColor: 'rgba(230,184,90,0.4)',
    paddingVertical: 16,
    marginBottom: 14,
  },
  sampleLbl: { fontFamily: Fonts.bodyBold, fontSize: 10.5, letterSpacing: 2, color: Onboard.inkDim },
  sampleAr: { fontFamily: Fonts.arabic, fontSize: 34, lineHeight: 58, color: Onboard.gold, marginTop: 8 },
});
