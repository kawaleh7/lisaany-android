import { useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import { Text } from 'react-native';

import { OnboardCard, OnboardingBody, OnboardingFooter, OnboardingHeader, OnboardingScreen, OptionCard } from '@/components/onboarding-nav';
import { Fonts } from '@/constants/lisaany';
import { useLang } from '@/lib/i18n';
import { getCanReadArabic, setCanReadArabic } from '@/lib/onboarding';
import { makeStyles } from '@/theme';

/**
 * Onboarding step 2 of 4 — the answer decides the last screen: "yes" shows
 * only the Arabic platform, "not yet" shows only Norania. Next comes the
 * daily goal.
 */
export default function ReaderCheckScreen() {
  const router = useRouter();
  const { t } = useLang();
  const s = useStyles();
  const [picked, setPicked] = useState<boolean | null>(null);

  useEffect(() => {
    getCanReadArabic().then((v) => v !== null && setPicked(v));
  }, []);

  const choose = (canRead: boolean) => {
    setPicked(canRead);
    setCanReadArabic(canRead);
  };

  return (
    <OnboardingScreen>
      <OnboardingHeader step={2} total={4} eyebrow={t('STEP 2 · READING')} title={t('Can you read this?')} />
      <OnboardingBody>
        <OnboardCard style={s.sampleCard}>
          <Text style={s.sampleAr}>مَرْحَبًا بِكَ</Text>
        </OnboardCard>
        <OptionCard title={t('Yes, I can read it')} arabic="نَعَم" selected={picked === true} onPress={() => choose(true)} />
        <OptionCard title={t('Not yet')} arabic="لَيْسَ بَعْد" selected={picked === false} onPress={() => choose(false)} />
      </OnboardingBody>
      <OnboardingFooter onNext={() => router.push('/onboarding/daily-goal')} nextDisabled={picked === null} />
    </OnboardingScreen>
  );
}

const useStyles = makeStyles((c) => ({
  sampleCard: { marginTop: 6, marginBottom: 4 },
  sampleAr: {
    fontFamily: Fonts.arabic,
    fontSize: 50,
    lineHeight: 92,
    color: c.text,
    textAlign: 'center',
    paddingVertical: 18,
  },
}));
