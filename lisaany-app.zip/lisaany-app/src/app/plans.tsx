import { LinearGradient } from 'expo-linear-gradient';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Alert, AppState, Linking, Pressable, ScrollView, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Icon } from '@/components/icon';
import { SpaceBackdrop } from '@/components/space-backdrop';
import { CardFill, currentCard, spaceCard } from '@/components/ui';
import { Fonts, WEB_BASE } from '@/constants/lisaany';
import { useAuth } from '@/lib/auth-context';
import { useLang } from '@/lib/i18n';
import { IS_IOS, STORE_ENABLED, buy, getStorePackages, restore, type StorePackages } from '@/lib/store';
import { makeStyles, useTheme, type Palette } from '@/theme';

type PlanId = 'yearly' | 'monthly';
const PLANS: Record<PlanId, { name: string; price: string; per: string; sub: string; badge?: string }> = {
  yearly: { name: 'Yearly', price: '$99.99', per: 'per year', sub: '$8.33 a month · save 48%', badge: 'BEST VALUE' },
  monthly: { name: 'Monthly', price: '$15.99', per: 'per month', sub: 'Cancel anytime' },
};

/**
 * Lisaany Premium: pick a plan and pay.
 *
 * iPhone: Apple's in-app purchase (RevenueCat), with App Store prices, Restore,
 * and the subscription terms Apple asks for. No account needed to buy.
 * Android: payment runs on lisaany.com; when the learner comes back we re-check
 * their plan and, once paid, move on to the welcome screen.
 */
export default function PlansScreen() {
  const styles = useStyles();
  const { c } = useTheme();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { t } = useLang();
  const { unit } = useLocalSearchParams<{ unit?: string }>();
  const { session, plan, refreshPlan } = useAuth();
  const [pick, setPick] = useState<PlanId>('yearly');
  const [waiting, setWaiting] = useState(false);
  const leftForCheckout = useRef(false);
  const [pkgs, setPkgs] = useState<StorePackages>({});
  const [storeError, setStoreError] = useState('');

  // Android: sign in first, then come straight back here (the web checkout needs
  // the account). iPhone buys through Apple, so no account is required.
  useEffect(() => {
    if (!IS_IOS && !session) router.replace({ pathname: '/sign-in', params: { next: 'plans', ...(unit ? { unit: String(unit) } : {}) } });
  }, [session, router, unit]);

  // iPhone: load the App Store prices.
  useEffect(() => {
    if (!STORE_ENABLED) return;
    getStorePackages()
      .then((p) => {
        setPkgs(p);
        if (!p.yearly && !p.monthly) setStoreError('Plans are not available right now. Please try again later.');
      })
      .catch(() => setStoreError('Could not reach the App Store. Check your connection and try again.'));
  }, []);

  // Paid (now or on return from checkout) → welcome.
  useEffect(() => {
    if (plan !== 'free') router.replace({ pathname: '/premium-welcome', params: unit ? { unit: String(unit) } : {} });
  }, [plan, router, unit]);

  useEffect(() => {
    const sub = AppState.addEventListener('change', async (st) => {
      if (st === 'active' && leftForCheckout.current) {
        leftForCheckout.current = false;
        setWaiting(true);
        try {
          await refreshPlan();
        } finally {
          setWaiting(false);
        }
      }
    });
    return () => sub.remove();
  }, [refreshPlan]);

  const pay = async () => {
    if (IS_IOS) {
      const pkg = pkgs[pick];
      if (!STORE_ENABLED || !pkg) {
        Alert.alert(t('Not available yet'), t(storeError || 'Purchases open in the App Store version of Lisaany.'));
        return;
      }
      setWaiting(true);
      try {
        if ((await buy(pkg)) === 'purchased') await refreshPlan();
      } catch (e) {
        Alert.alert(t('Purchase failed'), e instanceof Error ? e.message : t('Please try again.'));
      } finally {
        setWaiting(false);
      }
      return;
    }
    leftForCheckout.current = true;
    Linking.openURL(`${WEB_BASE}/pricing.html?plan=${pick}`).catch(() => {
      leftForCheckout.current = false;
    });
  };

  const checkAgain = async () => {
    setWaiting(true);
    try {
      if (IS_IOS) {
        const found = await restore();
        if (found) await refreshPlan();
        else Alert.alert(t('No purchases found'), t('There is no Lisaany Premium subscription on this Apple ID.'));
      } else {
        await refreshPlan();
      }
    } catch (e) {
      Alert.alert(t('Could not restore'), e instanceof Error ? e.message : t('Please try again.'));
    } finally {
      setWaiting(false);
    }
  };

  const close = () => (router.canGoBack() ? router.back() : router.replace('/'));
  // On iPhone the App Store's own price (in the learner's currency) replaces ours.
  const priceOf = (id: PlanId) => (IS_IOS && pkgs[id] ? pkgs[id]!.product.priceString : PLANS[id].price);
  const subOf = (id: PlanId) => {
    const monthly = pkgs[id]?.product.pricePerMonthString;
    if (IS_IOS && id === 'yearly' && monthly) return t('{price} a month', { price: monthly });
    return t(PLANS[id].sub);
  };
  const p = { ...PLANS[pick], price: priceOf(pick) };

  return (
    <View style={styles.screen}>
      <SpaceBackdrop />
      <ScrollView
        contentContainerStyle={[styles.content, { paddingTop: insets.top + 12, paddingBottom: insets.bottom + 28 }]}
        showsVerticalScrollIndicator={false}>
        <View style={styles.topRow}>
          <Pressable onPress={close} hitSlop={10} style={styles.close} accessibilityLabel={t('Close')}>
            <Icon name="close" size={20} color={dk(c, '#cfd6e3', c.muted)} />
          </Pressable>
        </View>

        <View style={styles.hero}>
          <LinearGradient colors={['#f6d98c', c.goldFill]} style={styles.crown}>
            <Icon name="crown" size={32} color={c.onGold} />
          </LinearGradient>
          <Text style={styles.title}>Lisaany Premium</Text>
          <Text style={styles.sub}>{t('Every lesson, every module')}</Text>
        </View>

        <View style={styles.perks}>
          {['All 47 lessons in 14 modules', 'Dialogues with audio, grammar and drills', 'Progress saved on phone and web'].map((pk) => (
            <View key={pk} style={styles.perk}>
              <Icon name="check_circle" size={18} color={c.gold} />
              <Text style={styles.perkText}>{t(pk)}</Text>
            </View>
          ))}
        </View>

        {(Object.keys(PLANS) as PlanId[]).map((id) => {
          const pl = PLANS[id];
          const on = pick === id;
          return (
            <Pressable key={id} onPress={() => setPick(id)} style={[styles.plan, on && styles.planOn]} accessibilityRole="radio" accessibilityState={{ selected: on }}>
              <CardFill radius={20} />
              {pl.badge ? (
                <View style={styles.badge}>
                  <Text style={styles.badgeText}>{t(pl.badge)}</Text>
                </View>
              ) : null}
              <View style={[styles.radio, on && { borderColor: c.gold }]}>{on ? <View style={styles.radioDot} /> : null}</View>
              <View style={{ flex: 1 }}>
                <Text style={styles.planName}>{t(pl.name)}</Text>
                <Text style={styles.planSub}>{subOf(id)}</Text>
              </View>
              <View style={{ alignItems: 'flex-end' }}>
                <Text style={styles.price}>{priceOf(id)}</Text>
                <Text style={styles.per}>{t(pl.per)}</Text>
              </View>
            </Pressable>
          );
        })}

        <Pressable onPress={pay} disabled={waiting} style={({ pressed }) => [styles.cta, pressed && { opacity: 0.88 }]}>
          {waiting ? (
            <ActivityIndicator color={c.btnText} />
          ) : (
            <Text style={styles.ctaText}>
              {pick === 'yearly'
                ? t('Continue · {price} / year', { price: p.price })
                : t('Continue · {price} / month', { price: p.price })}
            </Text>
          )}
        </Pressable>

        {IS_IOS ? (
          <Text style={styles.fine}>
            {t(
              'Payment is charged to your Apple ID when you confirm. The subscription renews automatically at the same price unless it is cancelled at least 24 hours before the end of the current period. Manage or cancel it anytime in your App Store account settings.'
            )}
          </Text>
        ) : (
          <Text style={styles.fine}>{t('Renews automatically. Cancel anytime in your account.')}</Text>
        )}
        {IS_IOS && !session ? (
          <Pressable onPress={() => router.push({ pathname: '/sign-in', params: { next: 'plans' } })} hitSlop={6} style={{ alignSelf: 'center', marginTop: 8 }}>
            <Text style={styles.link}>{t('Sign in to keep Premium on every device')}</Text>
          </Pressable>
        ) : null}
        <View style={styles.links}>
          <Pressable onPress={checkAgain} hitSlop={6}>
            <Text style={styles.link}>{IS_IOS ? t('Restore purchases') : t('Already paid? Check again')}</Text>
          </Pressable>
          <Text style={styles.dot}>·</Text>
          <Pressable onPress={() => Linking.openURL(`${WEB_BASE}/terms.html`).catch(() => {})} hitSlop={6}>
            <Text style={styles.link}>{t('Terms')}</Text>
          </Pressable>
          <Text style={styles.dot}>·</Text>
          <Pressable onPress={() => Linking.openURL(`${WEB_BASE}/privacy.html`).catch(() => {})} hitSlop={6}>
            <Text style={styles.link}>{t('Privacy')}</Text>
          </Pressable>
        </View>
      </ScrollView>
    </View>
  );
}

/** Dark keeps its original values exactly; light uses palette tokens. */
function dk<T>(c: Palette, dark: T, light: T): T {
  return c.scheme === 'dark' ? dark : light;
}

const useStyles = makeStyles((c) => ({
  screen: { flex: 1, backgroundColor: c.bg },
  content: { paddingHorizontal: 20 },
  topRow: { flexDirection: 'row', justifyContent: 'flex-end' },
  close: { width: 40, height: 40, borderRadius: 20, backgroundColor: dk(c, c.card, c.raised), alignItems: 'center', justifyContent: 'center' },
  hero: { alignItems: 'center', marginTop: 4 },
  glow: {
    position: 'absolute',
    top: -40,
    width: 260,
    height: 260,
    borderRadius: 130,
    backgroundColor: 'rgba(230,184,90,0.08)',
  },
  crown: { width: 68, height: 68, borderRadius: 34, alignItems: 'center', justifyContent: 'center' },
  title: { fontFamily: Fonts.displayBold, fontSize: 26, color: c.text, marginTop: 14 },
  sub: { fontFamily: Fonts.body, fontSize: 14, color: dk(c, '#d9dfe9', c.muted), marginTop: 4 },
  perks: { marginTop: 20, gap: 10 },
  perk: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  perkText: { fontFamily: Fonts.bodyMedium, fontSize: 14.5, color: c.text },
  plan: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginTop: 16,
    padding: 16,
    borderRadius: 20,
    ...spaceCard(c),
  },
  planOn: currentCard(c),
  badge: { position: 'absolute', top: -10, right: 14, backgroundColor: c.goldFill, borderRadius: 9, paddingHorizontal: 9, paddingVertical: 3 },
  badgeText: { fontFamily: Fonts.bodyBold, fontSize: 10.5, color: c.onGold },
  radio: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 2,
    borderColor: dk(c, 'rgba(255,255,255,0.25)', c.faint),
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioDot: { width: 11, height: 11, borderRadius: 6, backgroundColor: c.gold },
  planName: { fontFamily: Fonts.bodyBold, fontSize: 16, color: c.text },
  planSub: { fontFamily: Fonts.body, fontSize: 12.5, color: c.muted, marginTop: 2 },
  price: { fontFamily: Fonts.bodyBold, fontSize: 19, color: c.text },
  per: { fontFamily: Fonts.body, fontSize: 11.5, color: c.muted },
  cta: {
    height: 54,
    borderRadius: 27,
    backgroundColor: c.btnBg, borderWidth: 1.2, borderColor: c.btnBorder,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 22,
  },
  ctaText: { fontFamily: Fonts.bodyBold, fontSize: 16, color: c.btnText },
  fine: { fontFamily: Fonts.body, fontSize: 12, color: c.muted, textAlign: 'center', marginTop: 12 },
  links: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 8, marginTop: 8 },
  link: { fontFamily: Fonts.bodySemi, fontSize: 12.5, color: c.gold },
  dot: { color: c.muted },
}));
