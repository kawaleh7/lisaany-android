import { LinearGradient } from 'expo-linear-gradient';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, AppState, Linking, Pressable, ScrollView, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Icon } from '@/components/icon';
import { Fonts, WEB_BASE } from '@/constants/lisaany';
import { useAuth } from '@/lib/auth-context';
import { cardSurface, makeStyles, useTheme, type Palette } from '@/theme';

type PlanId = 'yearly' | 'monthly';
const PLANS: Record<PlanId, { name: string; price: string; per: string; sub: string; badge?: string }> = {
  yearly: { name: 'Yearly', price: '$99.99', per: 'per year', sub: '$8.33 a month · save 48%', badge: 'BEST VALUE' },
  monthly: { name: 'Monthly', price: '$15.99', per: 'per month', sub: 'Cancel anytime' },
};

/**
 * Lisaany Premium: pick a plan and pay. Payment currently runs on lisaany.com;
 * when the learner comes back to the app we re-check their plan and, once it
 * is paid, move on to the welcome screen. (Swap `pay` for store billing later.)
 */
export default function PlansScreen() {
  const styles = useStyles();
  const { c } = useTheme();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { unit } = useLocalSearchParams<{ unit?: string }>();
  const { session, plan, refreshPlan } = useAuth();
  const [pick, setPick] = useState<PlanId>('yearly');
  const [waiting, setWaiting] = useState(false);
  const leftForCheckout = useRef(false);

  // No account yet: sign in first, then come straight back here.
  useEffect(() => {
    if (!session) router.replace({ pathname: '/sign-in', params: { next: 'plans', ...(unit ? { unit: String(unit) } : {}) } });
  }, [session, router, unit]);

  // Paid (now or on return from checkout) → welcome.
  useEffect(() => {
    if (plan !== 'free') router.replace({ pathname: '/premium-welcome', params: unit ? { unit: String(unit) } : {} });
  }, [plan, router, unit]);

  useEffect(() => {
    const sub = AppState.addEventListener('change', async (st) => {
      if (st === 'active' && leftForCheckout.current) {
        leftForCheckout.current = false;
        setWaiting(true);
        try {
          await refreshPlan();
        } finally {
          setWaiting(false);
        }
      }
    });
    return () => sub.remove();
  }, [refreshPlan]);

  const pay = () => {
    leftForCheckout.current = true;
    Linking.openURL(`${WEB_BASE}/pricing.html?plan=${pick}`).catch(() => {
      leftForCheckout.current = false;
    });
  };

  const checkAgain = async () => {
    setWaiting(true);
    try {
      await refreshPlan();
    } finally {
      setWaiting(false);
    }
  };

  const close = () => (router.canGoBack() ? router.back() : router.replace('/'));
  const p = PLANS[pick];

  return (
    <View style={styles.screen}>
      <ScrollView
        contentContainerStyle={[styles.content, { paddingTop: insets.top + 12, paddingBottom: insets.bottom + 28 }]}
        showsVerticalScrollIndicator={false}>
        <View style={styles.topRow}>
          <Pressable onPress={close} hitSlop={10} style={styles.close} accessibilityLabel="Close">
            <Icon name="close" size={20} color={dk(c, '#cfd6e3', c.muted)} />
          </Pressable>
        </View>

        <View style={styles.hero}>
          <LinearGradient colors={['#f6d98c', c.goldFill]} style={styles.crown}>
            <Icon name="crown" size={32} color={c.onGold} />
          </LinearGradient>
          <Text style={styles.title}>Lisaany Premium</Text>
          <Text style={styles.sub}>Every lesson, every module</Text>
        </View>

        <View style={styles.perks}>
          {['All 47 lessons in 14 modules', 'Dialogues with audio, grammar and drills', 'Progress saved on phone and web'].map((t) => (
            <View key={t} style={styles.perk}>
              <Icon name="check_circle" size={18} color={c.gold} />
              <Text style={styles.perkText}>{t}</Text>
            </View>
          ))}
        </View>

        {(Object.keys(PLANS) as PlanId[]).map((id) => {
          const pl = PLANS[id];
          const on = pick === id;
          return (
            <Pressable key={id} onPress={() => setPick(id)} style={[styles.plan, on && styles.planOn]} accessibilityRole="radio" accessibilityState={{ selected: on }}>
              {pl.badge ? (
                <View style={styles.badge}>
                  <Text style={styles.badgeText}>{pl.badge}</Text>
                </View>
              ) : null}
              <View style={[styles.radio, on && { borderColor: c.gold }]}>{on ? <View style={styles.radioDot} /> : null}</View>
              <View style={{ flex: 1 }}>
                <Text style={styles.planName}>{pl.name}</Text>
                <Text style={styles.planSub}>{pl.sub}</Text>
              </View>
              <View style={{ alignItems: 'flex-end' }}>
                <Text style={styles.price}>{pl.price}</Text>
                <Text style={styles.per}>{pl.per}</Text>
              </View>
            </Pressable>
          );
        })}

        <Pressable onPress={pay} disabled={waiting} style={({ pressed }) => [styles.cta, pressed && { opacity: 0.88 }]}>
          {waiting ? (
            <ActivityIndicator color={c.onGold} />
          ) : (
            <Text style={styles.ctaText}>
              Continue · {p.price} / {pick === 'yearly' ? 'year' : 'month'}
            </Text>
          )}
        </Pressable>

        <Text style={styles.fine}>Renews automatically. Cancel anytime in your account.</Text>
        <View style={styles.links}>
          <Pressable onPress={checkAgain} hitSlop={6}>
            <Text style={styles.link}>Already paid? Check again</Text>
          </Pressable>
          <Text style={styles.dot}>·</Text>
          <Pressable onPress={() => Linking.openURL(`${WEB_BASE}/terms.html`).catch(() => {})} hitSlop={6}>
            <Text style={styles.link}>Terms</Text>
          </Pressable>
          <Text style={styles.dot}>·</Text>
          <Pressable onPress={() => Linking.openURL(`${WEB_BASE}/privacy.html`).catch(() => {})} hitSlop={6}>
            <Text style={styles.link}>Privacy</Text>
          </Pressable>
        </View>
      </ScrollView>
    </View>
  );
}

/** Dark keeps its original values exactly; light uses palette tokens. */
function dk<T>(c: Palette, dark: T, light: T): T {
  return c.scheme === 'dark' ? dark : light;
}

const useStyles = makeStyles((c) => ({
  screen: { flex: 1, backgroundColor: c.bg },
  content: { paddingHorizontal: 20 },
  topRow: { flexDirection: 'row', justifyContent: 'flex-end' },
  close: { width: 40, height: 40, borderRadius: 20, backgroundColor: dk(c, c.card, c.raised), alignItems: 'center', justifyContent: 'center' },
  hero: { alignItems: 'center', marginTop: 4 },
  glow: {
    position: 'absolute',
    top: -40,
    width: 260,
    height: 260,
    borderRadius: 130,
    backgroundColor: 'rgba(230,184,90,0.08)',
  },
  crown: { width: 68, height: 68, borderRadius: 34, alignItems: 'center', justifyContent: 'center' },
  title: { fontFamily: Fonts.displayBold, fontSize: 26, color: c.text, marginTop: 14 },
  sub: { fontFamily: Fonts.body, fontSize: 14, color: dk(c, '#d9dfe9', c.muted), marginTop: 4 },
  perks: { marginTop: 20, gap: 10 },
  perk: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  perkText: { fontFamily: Fonts.bodyMedium, fontSize: 14.5, color: c.text },
  plan: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginTop: 16,
    padding: 16,
    borderRadius: 20,
    ...(c.scheme === 'light' ? cardSurface(c) : { backgroundColor: c.card, borderWidth: 1, borderColor: c.line }),
  },
  planOn: {
    borderWidth: 1.5,
    borderColor: c.gold,
    borderTopWidth: 1.5,
    borderTopColor: c.gold,
    backgroundColor: dk(c, 'rgba(230,184,90,0.1)', c.goldTint),
  },
  badge: { position: 'absolute', top: -10, right: 14, backgroundColor: c.goldFill, borderRadius: 9, paddingHorizontal: 9, paddingVertical: 3 },
  badgeText: { fontFamily: Fonts.bodyBold, fontSize: 10.5, color: c.onGold },
  radio: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 2,
    borderColor: dk(c, 'rgba(255,255,255,0.25)', c.faint),
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioDot: { width: 11, height: 11, borderRadius: 6, backgroundColor: c.gold },
  planName: { fontFamily: Fonts.bodyBold, fontSize: 16, color: c.text },
  planSub: { fontFamily: Fonts.body, fontSize: 12.5, color: c.muted, marginTop: 2 },
  price: { fontFamily: Fonts.bodyBold, fontSize: 19, color: c.text },
  per: { fontFamily: Fonts.body, fontSize: 11.5, color: c.muted },
  cta: {
    height: 54,
    borderRadius: 27,
    backgroundColor: c.goldFill,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 22,
  },
  ctaText: { fontFamily: Fonts.bodyBold, fontSize: 16, color: c.onGold },
  fine: { fontFamily: Fonts.body, fontSize: 12, color: c.muted, textAlign: 'center', marginTop: 12 },
  links: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 8, marginTop: 8 },
  link: { fontFamily: Fonts.bodySemi, fontSize: 12.5, color: c.gold },
  dot: { color: c.muted },
}));
