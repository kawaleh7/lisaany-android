import { LinearGradient } from 'expo-linear-gradient';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Linking, Pressable, ScrollView, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import type { PurchasesPackage } from 'react-native-purchases';

import { Icon } from '@/components/icon';
import { SpaceBackdrop } from '@/components/space-backdrop';
import { CardFill, currentCard, spaceCard } from '@/components/ui';
import { Fonts, WEB_BASE } from '@/constants/lisaany';
import { useAuth } from '@/lib/auth-context';
import { useLang } from '@/lib/i18n';
import { reportError } from '@/lib/report';
import { IS_ANDROID, IS_IOS, STORE_ENABLED, buy, getStorePackages, restore, type StorePackages } from '@/lib/store';
import { makeStyles, useTheme, type Palette } from '@/theme';
import { contentCap } from '@/components/content-width';

type PlanId = 'yearly' | 'monthly';
const PLAN_ORDER: PlanId[] = ['yearly', 'monthly'];
const PLAN_NAME: Record<PlanId, string> = { yearly: 'Yearly', monthly: 'Monthly' };
const PLAN_PER: Record<PlanId, string> = { yearly: 'per year', monthly: 'per month' };
/** The yearly plan earns its badge only when it really is a deal. */
const BEST_VALUE_MIN_PCT = 15;

/**
 * How much cheaper a month of the yearly plan is than the monthly plan, in
 * whole percent — from the store's own prices, never a hard-coded number.
 * Null when the two cannot be compared.
 */
function yearlySavingPct(yearly: PurchasesPackage, monthly: PurchasesPackage): number | null {
  const y = yearly.product;
  const m = monthly.product;
  if (y.currencyCode !== m.currencyCode) return null;
  const perMonthYearly = y.pricePerMonth ?? (y.price > 0 ? y.price / 12 : null);
  const perMonthMonthly = m.pricePerMonth ?? (m.price > 0 ? m.price : null);
  if (!perMonthYearly || !perMonthMonthly || perMonthMonthly <= perMonthYearly) return null;
  return Math.round((1 - perMonthYearly / perMonthMonthly) * 100);
}

/**
 * Lisaany Premium: pick a plan and pay.
 *
 * iPhone and Android both buy through their own store (RevenueCat), with the
 * store's prices in the learner's currency, a Restore button and the
 * subscription terms the stores ask for. No account is needed to buy; signing
 * in ties the purchase to the account so it follows the learner everywhere.
 * There is deliberately no link to the website's checkout on either platform.
 */
export default function PlansScreen() {
  const styles = useStyles();
  const { c } = useTheme();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { t } = useLang();
  const { unit } = useLocalSearchParams<{ unit?: string }>();
  const { session, plan, refreshPlan } = useAuth();
  const [pick, setPick] = useState<PlanId>('yearly');
  const [waiting, setWaiting] = useState(false);
  /** null while the store prices load. */
  const [pkgs, setPkgs] = useState<StorePackages | null>(STORE_ENABLED ? null : {});

  const loadPackages = useCallback(async () => {
    if (!STORE_ENABLED) {
      setPkgs({});
      return;
    }
    setPkgs(null);
    try {
      const p = await getStorePackages();
      setPkgs(p);
      setPick(p.yearly ? 'yearly' : 'monthly');
    } catch (e) {
      reportError(e, { where: 'plans.packages' });
      setPkgs({});
    }
  }, []);

  useEffect(() => {
    void loadPackages();
  }, [loadPackages]);

  // Paid (now or after a restore) → welcome.
  useEffect(() => {
    if (plan !== 'free') router.replace({ pathname: '/premium-welcome', params: unit ? { unit: String(unit) } : {} });
  }, [plan, router, unit]);

  const loading = pkgs === null;
  const available = !!(pkgs?.yearly || pkgs?.monthly);
  const shown = PLAN_ORDER.filter((id) => !!pkgs?.[id]);
  const saving = pkgs?.yearly && pkgs?.monthly ? yearlySavingPct(pkgs.yearly, pkgs.monthly) : null;
  // The selected card, or the first one if the selection is not on sale here.
  const pickedId: PlanId | null = pkgs?.[pick] ? pick : (shown[0] ?? null);
  const picked = pickedId ? pkgs?.[pickedId] : undefined;

  const pay = async () => {
    if (!picked) return;
    setWaiting(true);
    try {
      if ((await buy(picked)) === 'purchased') await refreshPlan();
    } catch (e) {
      reportError(e, { where: 'plans.buy' });
      Alert.alert(t('Purchase failed'), e instanceof Error ? e.message : t('Please try again.'));
    } finally {
      setWaiting(false);
    }
  };

  const restorePurchases = async () => {
    setWaiting(true);
    try {
      if (await restore()) await refreshPlan();
      else
        Alert.alert(
          t('No purchases found'),
          IS_IOS ? t('There is no Lisaany Premium subscription on this Apple ID.') : t('There is no Lisaany Premium subscription on this Google account.')
        );
    } catch (e) {
      reportError(e, { where: 'plans.restore' });
      Alert.alert(t('Could not restore'), e instanceof Error ? e.message : t('Please try again.'));
    } finally {
      setWaiting(false);
    }
  };

  // Unavailable state: try the store again and re-read the plan (a website
  // subscriber who just signed in gets through here).
  const checkAgain = async () => {
    setWaiting(true);
    try {
      await Promise.all([loadPackages(), refreshPlan()]);
    } finally {
      setWaiting(false);
    }
  };

  const signIn = () => router.push({ pathname: '/sign-in', params: { next: 'plans', ...(unit ? { unit: String(unit) } : {}) } });
  const close = () => (router.canGoBack() ? router.back() : router.replace('/'));

  const subOf = (id: PlanId): string | null => {
    if (id === 'monthly') return t('Cancel anytime');
    const perMonth = pkgs?.yearly?.product.pricePerMonthString;
    if (perMonth && saving) return t('{price} a month · save {pct}%', { price: perMonth, pct: saving });
    if (perMonth) return t('{price} a month', { price: perMonth });
    return null;
  };

  const perks = [
    'All 47 lessons in 14 modules',
    'Dialogues with audio, grammar and drills',
    session ? 'Progress saved on phone and web' : 'Sign in to keep progress on phone and web',
  ];

  return (
    <View style={styles.screen}>
      <SpaceBackdrop />
      <ScrollView
        contentContainerStyle={[styles.content, { paddingTop: insets.top + 12, paddingBottom: insets.bottom + 28 }]}
        showsVerticalScrollIndicator={false}>
        <View style={styles.topRow}>
          <Pressable onPress={close} hitSlop={10} style={styles.close} accessibilityLabel={t('Close')}>
            <Icon name="close" size={20} color={dk(c, '#cfd6e3', c.muted)} />
          </Pressable>
        </View>

        <View style={styles.hero}>
          <LinearGradient colors={['#f6d98c', c.goldFill]} style={styles.crown}>
            <Icon name="crown" size={32} color={c.onGold} />
          </LinearGradient>
          <Text style={styles.title}>Lisaany Premium</Text>
          <Text style={styles.sub}>{t('Every lesson, every module')}</Text>
        </View>

        <View style={styles.perks}>
          {perks.map((pk) => (
            <View key={pk} style={styles.perk}>
              <Icon name="check_circle" size={18} color={c.gold} />
              <Text style={styles.perkText}>{t(pk)}</Text>
            </View>
          ))}
        </View>

        {loading ? (
          <View style={styles.loading}>
            <ActivityIndicator color={c.gold} />
          </View>
        ) : !available ? (
          <View style={styles.unavailable}>
            <CardFill radius={20} />
            {STORE_ENABLED ? (
              /* A store build that could not load its prices: a connection problem, not a missing feature. */
              <>
                <Text style={styles.unavailableTitle}>{t('Prices could not be loaded')}</Text>
                <Text style={styles.unavailableText}>{t('Check your connection and tap Check again. If you already have Lisaany Premium, sign in and your lessons open here.')}</Text>
              </>
            ) : IS_ANDROID ? (
              /* Android with no Google Play key: the app sells nothing itself. Google's
                 Payments policy lets such an app say where Premium is sold — as plain
                 text, never a link or button (support.google.com/googleplay/android-developer/answer/10281818). */
              <>
                <Text style={styles.unavailableTitle}>{t('Premium is available on lisaany.com')}</Text>
                <Text style={styles.unavailableText}>{t('It is not sold in this app. Once you have it, sign in here with the same account and every lesson opens.')}</Text>
              </>
            ) : (
              <>
                <Text style={styles.unavailableTitle}>{t('Premium is not available in this version yet')}</Text>
                <Text style={styles.unavailableText}>{t('If you already have Lisaany Premium, sign in and your lessons open here.')}</Text>
              </>
            )}
            {!session ? (
              <Pressable onPress={signIn} style={({ pressed }) => [styles.cta, styles.ctaInCard, pressed && { opacity: 0.88 }]}>
                <Text style={styles.ctaText}>{t('Sign in')}</Text>
              </Pressable>
            ) : null}
            <Pressable onPress={checkAgain} disabled={waiting} style={({ pressed }) => [styles.outline, pressed && { opacity: 0.85 }]}>
              {waiting ? <ActivityIndicator color={c.gold} /> : <Text style={styles.outlineText}>{t('Check again')}</Text>}
            </Pressable>
          </View>
        ) : (
          <>
            {shown.map((id) => {
              const pkg = pkgs?.[id];
              if (!pkg) return null;
              const on = pickedId === id;
              const sub = subOf(id);
              const badge = id === 'yearly' && saving !== null && saving >= BEST_VALUE_MIN_PCT;
              return (
                <Pressable key={id} onPress={() => setPick(id)} style={[styles.plan, on && styles.planOn]} accessibilityRole="radio" accessibilityState={{ selected: on }}>
                  <CardFill radius={20} />
                  {badge ? (
                    <View style={styles.badge}>
                      <Text style={styles.badgeText}>{t('BEST VALUE')}</Text>
                    </View>
                  ) : null}
                  <View style={[styles.radio, on && { borderColor: c.gold }]}>{on ? <View style={styles.radioDot} /> : null}</View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.planName}>{t(PLAN_NAME[id])}</Text>
                    {sub ? <Text style={styles.planSub}>{sub}</Text> : null}
                  </View>
                  <View style={{ alignItems: 'flex-end' }}>
                    <Text style={styles.price}>{pkg.product.priceString}</Text>
                    <Text style={styles.per}>{t(PLAN_PER[id])}</Text>
                  </View>
                </Pressable>
              );
            })}

            <Pressable onPress={pay} disabled={waiting || !picked} style={({ pressed }) => [styles.cta, pressed && { opacity: 0.88 }]}>
              {waiting ? (
                <ActivityIndicator color={c.btnText} />
              ) : (
                <Text style={styles.ctaText}>
                  {pickedId === 'yearly'
                    ? t('Continue · {price} / year', { price: picked?.product.priceString ?? '' })
                    : t('Continue · {price} / month', { price: picked?.product.priceString ?? '' })}
                </Text>
              )}
            </Pressable>

            <Text style={styles.fine}>
              {IS_IOS
                ? t(
                    'Payment is charged to your Apple ID when you confirm. The subscription renews automatically at the same price unless it is cancelled at least 24 hours before the end of the current period. Manage or cancel it anytime in your App Store account settings.'
                  )
                : t(
                    'Payment is charged to your Google Play account when you confirm. The subscription renews automatically unless it is cancelled at least 24 hours before the end of the current period. Manage or cancel it anytime in Google Play → Subscriptions.'
                  )}
            </Text>
            {!session ? (
              <Pressable onPress={signIn} hitSlop={6} style={{ alignSelf: 'center', marginTop: 8 }}>
                <Text style={styles.link}>{t('Sign in to keep Premium on every device')}</Text>
              </Pressable>
            ) : null}
          </>
        )}

        <View style={styles.links}>
          {STORE_ENABLED ? (
            <>
              <Pressable onPress={restorePurchases} disabled={waiting} hitSlop={6}>
                <Text style={styles.link}>{t('Restore purchases')}</Text>
              </Pressable>
              <Text style={styles.dot}>·</Text>
            </>
          ) : null}
          <Pressable onPress={() => Linking.openURL(`${WEB_BASE}/terms.html`).catch(() => {})} hitSlop={6}>
            <Text style={styles.link}>{t('Terms')}</Text>
          </Pressable>
          <Text style={styles.dot}>·</Text>
          <Pressable onPress={() => Linking.openURL(`${WEB_BASE}/privacy.html`).catch(() => {})} hitSlop={6}>
            <Text style={styles.link}>{t('Privacy')}</Text>
          </Pressable>
        </View>
      </ScrollView>
    </View>
  );
}

/** Dark keeps its original values exactly; light uses palette tokens. */
function dk<T>(c: Palette, dark: T, light: T): T {
  return c.scheme === 'dark' ? dark : light;
}

const useStyles = makeStyles((c) => ({
  screen: { flex: 1, backgroundColor: c.bg },
  content: { paddingHorizontal: 20 , ...contentCap },
  topRow: { flexDirection: 'row', justifyContent: 'flex-end' },
  close: { width: 40, height: 40, borderRadius: 20, backgroundColor: dk(c, c.card, c.raised), alignItems: 'center', justifyContent: 'center' },
  hero: { alignItems: 'center', marginTop: 4 },
  glow: {
    position: 'absolute',
    top: -40,
    width: 260,
    height: 260,
    borderRadius: 130,
    backgroundColor: 'rgba(230,184,90,0.08)',
  },
  crown: { width: 68, height: 68, borderRadius: 34, alignItems: 'center', justifyContent: 'center' },
  title: { fontFamily: Fonts.displayBold, fontSize: 26, color: c.text, marginTop: 14 },
  sub: { fontFamily: Fonts.body, fontSize: 14, color: dk(c, '#d9dfe9', c.muted), marginTop: 4 },
  perks: { marginTop: 20, gap: 10 },
  perk: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  perkText: { fontFamily: Fonts.bodyMedium, fontSize: 14.5, color: c.text },
  // Where the plan cards will be while the store prices load.
  loading: { height: 220, alignItems: 'center', justifyContent: 'center' },
  unavailable: {
    marginTop: 16,
    padding: 20,
    borderRadius: 20,
    alignItems: 'center',
    ...spaceCard(c),
  },
  unavailableTitle: { fontFamily: Fonts.bodyBold, fontSize: 17, color: c.text, textAlign: 'center' },
  unavailableText: { fontFamily: Fonts.body, fontSize: 14, lineHeight: 21, color: dk(c, '#d9dfe9', c.muted), textAlign: 'center', marginTop: 8 },
  plan: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginTop: 16,
    padding: 16,
    borderRadius: 20,
    ...spaceCard(c),
  },
  planOn: currentCard(c),
  badge: { position: 'absolute', top: -10, right: 14, backgroundColor: c.goldFill, borderRadius: 9, paddingHorizontal: 9, paddingVertical: 3 },
  badgeText: { fontFamily: Fonts.bodyBold, fontSize: 10.5, color: c.onGold },
  radio: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 2,
    borderColor: dk(c, 'rgba(255,255,255,0.25)', c.faint),
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioDot: { width: 11, height: 11, borderRadius: 6, backgroundColor: c.gold },
  planName: { fontFamily: Fonts.bodyBold, fontSize: 16, color: c.text },
  planSub: { fontFamily: Fonts.body, fontSize: 12.5, color: c.muted, marginTop: 2 },
  price: { fontFamily: Fonts.bodyBold, fontSize: 19, color: c.text },
  per: { fontFamily: Fonts.body, fontSize: 11.5, color: c.muted },
  cta: {
    height: 54,
    borderRadius: 27,
    backgroundColor: c.btnBg, borderWidth: 1.2, borderColor: c.btnBorder,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 22,
  },
  ctaInCard: { alignSelf: 'stretch', marginTop: 18 },
  ctaText: { fontFamily: Fonts.bodyBold, fontSize: 16, color: c.btnText },
  outline: {
    height: 48,
    borderRadius: 24,
    borderWidth: 1.5,
    borderColor: dk(c, 'rgba(230,184,90,0.55)', c.gold),
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'stretch',
    marginTop: 10,
  },
  outlineText: { fontFamily: Fonts.bodyBold, fontSize: 14, color: c.gold },
  fine: { fontFamily: Fonts.body, fontSize: 12, color: c.muted, textAlign: 'center', marginTop: 12 },
  links: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 8, marginTop: 8 },
  link: { fontFamily: Fonts.bodySemi, fontSize: 12.5, color: c.gold },
  dot: { color: c.muted },
}));
