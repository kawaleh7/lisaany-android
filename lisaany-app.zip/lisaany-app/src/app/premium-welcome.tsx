import { LinearGradient } from 'expo-linear-gradient';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Pressable, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Icon } from '@/components/icon';
import { SpaceBackdrop } from '@/components/space-backdrop';
import { Fonts } from '@/constants/lisaany';
import { getUnit } from '@/lib/curriculum';
import { useLang } from '@/lib/i18n';
import { makeStyles, useTheme, type Palette } from '@/theme';

/** Shown once a plan becomes paid: celebrate, then open the lesson that was locked. */
export default function PremiumWelcome() {
  const styles = useStyles();
  const { c } = useTheme();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { t, ct } = useLang();
  const { unit } = useLocalSearchParams<{ unit?: string }>();
  const u = unit ? getUnit(String(unit)) : undefined;

  const start = () => {
    if (u) router.replace({ pathname: '/unit/[id]', params: { id: u.id } });
    else router.replace('/lessons');
  };

  return (
    <View style={[styles.screen, { paddingTop: insets.top, paddingBottom: insets.bottom + 30 }]}>
      <SpaceBackdrop />
      <View style={styles.center}>
        <LinearGradient colors={['#f6d98c', c.goldFill]} style={styles.crown}>
          <Icon name="crown" size={50} color={c.onGold} />
        </LinearGradient>
        <Text style={styles.title}>{t('Welcome to Premium')}</Text>
        <Text style={styles.sub}>{t('All 47 lessons are open.\nYour progress carries on.')}</Text>
      </View>
      <Pressable onPress={start} style={({ pressed }) => [styles.cta, pressed && { opacity: 0.88 }]}>
        <Text style={styles.ctaText}>{u ? t('Start {title}', { title: ct(u.title) }) : t('Go to lessons')}</Text>
      </Pressable>
      <Pressable onPress={() => router.replace('/')} hitSlop={8} style={styles.later}>
        <Text style={styles.laterText}>{t('Back to Today')}</Text>
      </Pressable>
    </View>
  );
}

/** Dark keeps its original values exactly; light uses palette tokens. */
function dk<T>(c: Palette, dark: T, light: T): T {
  return c.scheme === 'dark' ? dark : light;
}

const useStyles = makeStyles((c) => ({
  screen: { flex: 1, backgroundColor: c.bg, paddingHorizontal: 20 },
  glow: {
    position: 'absolute',
    alignSelf: 'center',
    top: '22%',
    width: 380,
    height: 380,
    borderRadius: 190,
    backgroundColor: 'rgba(230,184,90,0.08)',
  },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  crown: { width: 104, height: 104, borderRadius: 52, alignItems: 'center', justifyContent: 'center' },
  title: { fontFamily: Fonts.displayBold, fontSize: 27, color: c.text, marginTop: 24, textAlign: 'center' },
  sub: { fontFamily: Fonts.body, fontSize: 15, lineHeight: 23, color: dk(c, '#d9dfe9', c.muted), marginTop: 10, textAlign: 'center' },
  cta: { height: 54, borderRadius: 27, backgroundColor: c.btnBg, borderWidth: 1.2, borderColor: c.btnBorder, alignItems: 'center', justifyContent: 'center' },
  ctaText: { fontFamily: Fonts.bodyBold, fontSize: 16, color: c.btnText },
  later: { alignSelf: 'center', marginTop: 16 },
  laterText: { fontFamily: Fonts.bodySemi, fontSize: 14, color: dk(c, '#c9d0dd', c.muted) },
}));
