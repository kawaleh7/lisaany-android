import { useLocalSearchParams, useRouter } from 'expo-router';
import { useState } from 'react';
import { KeyboardAvoidingView, Platform, Text, TextInput, View } from 'react-native';

import { Icon } from '@/components/icon';
import { ArabicLine, Body, Button, Display, ErrorNote, Eyebrow, Screen } from '@/components/ui';
import { Colors, Fonts, Radius, Spacing, Tracking } from '@/constants/lisaany';
import { useLang } from '@/lib/i18n';
import { supabase } from '@/lib/supabase';
import { makeStyles, useTheme, type Palette } from '@/theme';

export default function SignInScreen() {
  const styles = useStyles();
  const { c } = useTheme();
  const router = useRouter();
  const { t } = useLang();
  // `next=plans` comes from a Premium lesson: after signing in, go on to the plans.
  const params = useLocalSearchParams<{ next?: string; unit?: string }>();
  const toPlans = params.next === 'plans';
  const done = () => {
    if (toPlans) router.replace({ pathname: '/plans', params: params.unit ? { unit: String(params.unit) } : {} });
    else router.back();
  };
  const [mode, setMode] = useState<'sign-in' | 'sign-up'>('sign-in');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setError(null);
    setNotice(null);

    if (!email.trim() || !password) {
      setError('Enter your email and password.');
      return;
    }

    setBusy(true);
    try {
      if (mode === 'sign-in') {
        const { error: err } = await supabase.auth.signInWithPassword({
          email: email.trim(),
          password,
        });
        if (err) throw err;
        done();
      } else {
        const { data, error: err } = await supabase.auth.signUp({
          email: email.trim(),
          password,
        });
        if (err) throw err;

        if (data.session) {
          done();
        } else {
          setNotice('Check your email to confirm the account, then sign in.');
          setMode('sign-in');
        }
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Something went wrong. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.flex}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <Screen>
        <View style={styles.head}>
          <Eyebrow>{mode === 'sign-in' ? t('Welcome back') : t('Join Lisaany')}</Eyebrow>
          <Display style={styles.title}>
            {mode === 'sign-in' ? t('Sign in') : t('Create your account')}
          </Display>
          <ArabicLine size={20} style={styles.arabic}>
            لِسَانِي
          </ArabicLine>
          <Body style={styles.sub}>
            {t('Use the same account as lisaany.com — your plan and tutor access come with it.')}
          </Body>
        </View>

        {toPlans ? (
          <View style={styles.premiumNote}>
            <Icon name="crown" size={22} color={c.gold} />
            <Text style={styles.premiumText}>
              {t('One step before Premium: sign in or create a free account so your plan and progress are saved.')}
            </Text>
          </View>
        ) : null}

        {error ? <ErrorNote message={t(error)} /> : null}
        {notice ? (
          <View style={styles.notice}>
            <Icon name="mark_email_read" size={18} color={dk(c, Colors.mint, c.green)} />
            <Text style={styles.noticeText}>{t(notice)}</Text>
          </View>
        ) : null}

        <Text style={styles.fieldLabel}>{t('Email')}</Text>
        <TextInput
          value={email}
          onChangeText={setEmail}
          placeholder={t('you@example.com')}
          placeholderTextColor={dk(c, 'rgba(243,246,252,0.35)', c.faint)}
          autoCapitalize="none"
          autoComplete="email"
          keyboardType="email-address"
          style={styles.input}
        />

        <Text style={styles.fieldLabel}>{t('Password')}</Text>
        <TextInput
          value={password}
          onChangeText={setPassword}
          placeholder="••••••••"
          placeholderTextColor={dk(c, 'rgba(243,246,252,0.35)', c.faint)}
          autoCapitalize="none"
          secureTextEntry
          style={styles.input}
          onSubmitEditing={submit}
        />

        <Button
          label={mode === 'sign-in' ? t('Sign in') : t('Create account')}
          icon={mode === 'sign-in' ? 'login' : 'person_add'}
          onPress={submit}
          loading={busy}
        />

        <Button
          label={mode === 'sign-in' ? t('I need an account') : t('I already have an account')}
          variant="ghost"
          onPress={() => {
            setMode(mode === 'sign-in' ? 'sign-up' : 'sign-in');
            setError(null);
            setNotice(null);
          }}
        />
      </Screen>
    </KeyboardAvoidingView>
  );
}

/** Dark keeps its original values exactly; light uses palette tokens. */
function dk<T>(c: Palette, dark: T, light: T): T {
  return c.scheme === 'dark' ? dark : light;
}

const useStyles = makeStyles((c) => ({
  premiumNote: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 14,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: dk(c, 'rgba(230,184,90,0.4)', 'rgba(201,146,30,0.35)'),
    backgroundColor: dk(c, 'rgba(230,184,90,0.1)', c.goldTint),
    marginBottom: 6,
  },
  premiumText: { flex: 1, fontFamily: Fonts.body, fontSize: 13.5, lineHeight: 19, color: c.text },
  flex: { flex: 1, backgroundColor: c.bg },
  head: { paddingTop: 16, paddingBottom: 26 },
  title: { fontSize: 30 },
  arabic: { textAlign: 'left', marginTop: 10 },
  sub: { marginTop: 10, fontSize: 14, lineHeight: 22, maxWidth: 340 },

  fieldLabel: {
    fontFamily: Fonts.bodySemi,
    fontSize: 10,
    letterSpacing: Tracking.meta,
    textTransform: 'uppercase',
    color: c.gold,
    marginBottom: 8,
    marginTop: 14,
  },
  input: {
    backgroundColor: dk(c, 'rgba(20,32,64,0.55)', c.card),
    borderWidth: dk(c, 1, 1.5),
    borderColor: dk(c, Colors.border, c.navy),
    borderRadius: Radius.md,
    color: dk(c, Colors.text, c.text),
    fontFamily: Fonts.body,
    paddingHorizontal: Spacing.md,
    paddingVertical: 15,
    fontSize: 16,
  },

  notice: {
    flexDirection: 'row',
    gap: 10,
    alignItems: 'flex-start',
    backgroundColor: dk(c, 'rgba(127,201,156,0.10)', 'rgba(47,157,92,0.10)'),
    borderWidth: 1,
    borderColor: dk(c, 'rgba(127,201,156,0.3)', 'rgba(47,157,92,0.3)'),
    borderRadius: Radius.sm,
    padding: Spacing.md,
    marginBottom: Spacing.sm,
  },
  noticeText: { flex: 1, fontFamily: Fonts.body, fontSize: 14, lineHeight: 20, color: dk(c, Colors.mint, c.green) },
}));
