import Svg, { Path } from 'react-native-svg';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useRef, useState } from 'react';
import { KeyboardAvoidingView, Pressable, ScrollView, Text, TextInput, View } from 'react-native';

import { Icon } from '@/components/icon';
import { Body, Button, Display, ErrorNote, Eyebrow, Screen } from '@/components/ui';
import { Colors, Fonts, Radius, Spacing, Tracking } from '@/constants/lisaany';
import { useLang } from '@/lib/i18n';
import { supabase } from '@/lib/supabase';
import { APPLE_ON, GOOGLE_ON, signInWithApple, signInWithGoogle } from '@/lib/sso';
import { makeStyles, useTheme, type Palette } from '@/theme';

/**
 * Where the "choose a new password" email link lands. The website's auth
 * page receives Supabase's `type=recovery` link and shows the new-password
 * form; the app itself has no web session to finish it in.
 */
const RESET_REDIRECT = 'https://lisaany.com/auth.html';

export default function SignInScreen() {
  const styles = useStyles();
  const { c } = useTheme();
  const router = useRouter();
  const { t } = useLang();
  // `next=plans` comes from a Premium lesson: after signing in, go on to the
  // plans. `from=landing` comes from the landing screen's "I already have an
  // account": going back would only show landing again, so head into the app.
  const params = useLocalSearchParams<{ next?: string; unit?: string; from?: string }>();
  const toPlans = params.next === 'plans';
  const fromLanding = params.from === 'landing';
  const goHome = () => {
    try {
      if (router.canDismiss()) router.dismissAll();
    } catch {
      /* nothing to dismiss */
    }
    router.replace('/');
  };
  const done = () => {
    if (toPlans) router.replace({ pathname: '/plans', params: params.unit ? { unit: String(params.unit) } : {} });
    else if (fromLanding) goHome();
    else if (router.canGoBack()) router.back();
    else router.replace('/');
  };
  const [mode, setMode] = useState<'sign-in' | 'sign-up'>('sign-in');
  // The field you are typing in turns white, so the text is always easy to read.
  const [focused, setFocused] = useState<'email' | 'password' | null>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  // Keep the field being typed in above the keyboard (Android draws edge to
  // edge, so the window no longer shrinks for the keyboard on its own).
  const scroller = useRef<ScrollView>(null);
  const fieldY = useRef<{ email: number; password: number }>({ email: 0, password: 0 });
  const showField = (which: 'email' | 'password') => {
    setFocused(which);
    setTimeout(() => scroller.current?.scrollTo({ y: Math.max(0, fieldY.current[which] - 120), animated: true }), 250);
  };

  const oneTap = async (which: 'google' | 'apple') => {
    setError(null);
    setNotice(null);
    setBusy(true);
    try {
      const r = which === 'google' ? await signInWithGoogle() : await signInWithApple();
      if (r === 'signed-in') done();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Something went wrong. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  const a3 = c.scheme !== 'light';
  const switchMode = () => {
    setMode(mode === 'sign-in' ? 'sign-up' : 'sign-in');
    setError(null);
    setNotice(null);
  };

  const submit = async () => {
    setError(null);
    setNotice(null);

    if (!email.trim() || !password) {
      setError('Enter your email and password.');
      return;
    }

    setBusy(true);
    try {
      if (mode === 'sign-in') {
        const { error: err } = await supabase.auth.signInWithPassword({
          email: email.trim(),
          password,
        });
        if (err) throw err;
        done();
      } else {
        const { data, error: err } = await supabase.auth.signUp({
          email: email.trim(),
          password,
        });
        if (err) throw err;

        // Supabase does not say "this email is taken" (so nobody can probe for
        // accounts): for an email that already has an account it returns a user
        // with no identities, creates nothing and sends no email.
        if (data.user && Array.isArray(data.user.identities) && data.user.identities.length === 0) {
          setError('There is already an account with this email. Sign in, or tap Forgot your password.');
          setMode('sign-in');
        } else if (data.session) {
          done();
        } else {
          setNotice('Check your email to confirm the account, then sign in.');
          setMode('sign-in');
        }
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Something went wrong. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  // Supabase emails a recovery link; the website's auth page takes it from there.
  const forgotPassword = async () => {
    setError(null);
    setNotice(null);
    const address = email.trim();
    if (!address) {
      setError('Enter your email first, then tap Forgot your password.');
      return;
    }
    setBusy(true);
    try {
      const { error: err } = await supabase.auth.resetPasswordForEmail(address, { redirectTo: RESET_REDIRECT });
      if (err) throw err;
      setNotice('Check your email for a link to choose a new password.');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Something went wrong. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.flex}
      behavior="padding">
      <Screen scrollRef={scroller}>
        <View style={styles.head}>
          <Eyebrow>{mode === 'sign-in' ? t('Welcome back') : t('Join Lisaany')}</Eyebrow>
          <Display style={styles.title}>
            {mode === 'sign-in' ? t('Sign in') : t('Create your account')}
          </Display>
          <Body style={styles.sub}>
            {t('Use the same account as lisaany.com — your plan and tutor access come with it.')}
          </Body>
        </View>

        {toPlans ? (
          <View style={styles.premiumNote}>
            <Icon name="crown" size={22} color={c.gold} />
            <Text style={styles.premiumText}>
              {t('One step before Premium: sign in or create a free account so your plan and progress are saved.')}
            </Text>
          </View>
        ) : null}

        <View style={a3 ? styles.card : undefined}>
        {error ? <ErrorNote message={t(error)} /> : null}
        {notice ? (
          <View style={styles.notice}>
            <Icon name="mark_email_read" size={18} color={dk(c, Colors.mint, c.green)} />
            <Text style={styles.noticeText}>{t(notice)}</Text>
          </View>
        ) : null}

        {/* One tap: Google, then Apple (iPhone). Shown once each is set up (see src/lib/sso.ts). */}
        {GOOGLE_ON || APPLE_ON ? (
          <View style={styles.sso}>
            {GOOGLE_ON ? (
              <Pressable onPress={() => oneTap('google')} disabled={busy} style={({ pressed }) => [styles.ssoBtn, pressed && { opacity: 0.85 }]} accessibilityRole="button">
                {/* Google's official "G" (from Google's sign-in button kit). */}
                <Svg width={22} height={22} viewBox="0 0 48 48">
                  <Path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
                  <Path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
                  <Path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
                  <Path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
                </Svg>
                <Text style={styles.ssoText}>{t('Continue with Google')}</Text>
              </Pressable>
            ) : null}
            {APPLE_ON ? <AppleButton onPress={() => oneTap('apple')} /> : null}
            <View style={styles.orRow}>
              <View style={styles.orLine} />
              <Text style={styles.orText}>{t('or')}</Text>
              <View style={styles.orLine} />
            </View>
          </View>
        ) : null}

        <Text style={styles.fieldLabel} onLayout={(e) => (fieldY.current.email = e.nativeEvent.layout.y)}>{t('Email')}</Text>
        <TextInput
          value={email}
          onChangeText={setEmail}
          placeholder={t('you@example.com')}
          placeholderTextColor={a3 || focused === 'email' ? 'rgba(22,33,58,0.45)' : dk(c, 'rgba(243,246,252,0.55)', c.faint)}
          autoCapitalize="none"
          autoComplete="email"
          keyboardType="email-address"
          onFocus={() => showField('email')}
          onBlur={() => setFocused(null)}
          style={[styles.input, a3 && styles.inputA3, focused === 'email' && (a3 ? styles.inputA3On : styles.inputOn)]}
        />

        <Text style={styles.fieldLabel} onLayout={(e) => (fieldY.current.password = e.nativeEvent.layout.y)}>{t('Password')}</Text>
        <TextInput
          value={password}
          onChangeText={setPassword}
          placeholder="••••••••"
          placeholderTextColor={a3 || focused === 'password' ? 'rgba(22,33,58,0.45)' : dk(c, 'rgba(243,246,252,0.55)', c.faint)}
          autoCapitalize="none"
          secureTextEntry
          onFocus={() => showField('password')}
          onBlur={() => setFocused(null)}
          style={[styles.input, a3 && styles.inputA3, focused === 'password' && (a3 ? styles.inputA3On : styles.inputOn)]}
          onSubmitEditing={submit}
        />

        {mode === 'sign-in' ? (
          <Pressable onPress={forgotPassword} disabled={busy} hitSlop={6} style={styles.forgot} accessibilityRole="link">
            <Text style={styles.link}>{t('Forgot your password?')}</Text>
          </Pressable>
        ) : null}


        {a3 ? (
          <Pressable onPress={submit} disabled={busy} style={({ pressed }) => [styles.goldBtn, (pressed || busy) && { opacity: 0.85 }]} accessibilityRole="button">
            <Text style={styles.goldBtnText}>{mode === 'sign-in' ? t('Sign in') : t('Create account')}</Text>
            <Icon name="arrow_forward" size={18} color="#15213B" />
          </Pressable>
        ) : (
          <Button
            label={mode === 'sign-in' ? t('Sign in') : t('Create account')}
            icon={mode === 'sign-in' ? 'login' : 'person_add'}
            onPress={submit}
            loading={busy}
          />
        )}
        </View>
        {a3 ? (
          <Pressable onPress={switchMode} hitSlop={8} style={styles.switchRow} accessibilityRole="button">
            <Text style={styles.switchText}>
              {mode === 'sign-in' ? t('New to Lisaany?') : t('Already have an account?')}{' '}
              <Text style={styles.switchLink}>{mode === 'sign-in' ? t('Create account') : t('Sign in')}</Text>
            </Text>
          </Pressable>
        ) : (
          <Button label={mode === 'sign-in' ? t('Create account') : t('I already have an account')} variant="ghost" onPress={switchMode} />
        )}
      </Screen>
    </KeyboardAvoidingView>
  );
}

/** Dark keeps its original values exactly; light uses palette tokens. */
function dk<T>(c: Palette, dark: T, light: T): T {
  return c.scheme === 'dark' ? dark : light;
}

/** Apple's own button (iPhone only): Apple requires its official look. */
function AppleButton({ onPress }: { onPress: () => void }) {
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const Apple = require('expo-apple-authentication') as typeof import('expo-apple-authentication');
  return (
    <Apple.AppleAuthenticationButton
      buttonType={Apple.AppleAuthenticationButtonType.CONTINUE}
      buttonStyle={Apple.AppleAuthenticationButtonStyle.BLACK}
      cornerRadius={14}
      style={{ height: 52, width: '100%' }}
      onPress={onPress}
    />
  );
}

const useStyles = makeStyles((c) => {
  const a3 = c.scheme !== 'light';
  return {
  card: { backgroundColor: '#ffffff', borderWidth: 1, borderColor: '#E7EAF0', borderRadius: 22, padding: 18, paddingTop: 16 },
  inputA3: { backgroundColor: '#f4f6fa', borderColor: '#dde2ec', borderWidth: 1.2, color: '#15213B' },
  inputA3On: { backgroundColor: '#ffffff', borderColor: '#E5AD3B', borderWidth: 1.6, color: '#15213B' },
  goldBtn: { marginTop: 14, height: 52, borderRadius: 14, backgroundColor: '#E5AD3B', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  goldBtnText: { fontFamily: Fonts.bodyBold, fontSize: 16, color: '#15213B' },
  switchRow: { alignSelf: 'center', marginTop: 20, paddingVertical: 6 },
  switchText: { fontFamily: Fonts.body, fontSize: 14.5, color: c.muted },
  switchLink: { fontFamily: Fonts.bodyBold, color: c.gold },
  sso: { gap: 14, marginTop: a3 ? 0 : 6, marginBottom: a3 ? 2 : 0 },
  ssoBtn: {
    height: a3 ? 52 : 56,
    borderRadius: a3 ? 14 : 28,
    backgroundColor: '#ffffff',
    borderWidth: 1.5,
    borderColor: a3 ? '#dde2ec' : '#c9d1d9',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 14,
  },
  ssoText: { fontFamily: Fonts.bodyBold, fontSize: a3 ? 16 : 17, color: a3 ? '#15213B' : '#000000' },
  orRow: { flexDirection: 'row', alignItems: 'center', gap: 14, marginTop: 8 },
  orLine: { flex: 1, height: 1, backgroundColor: a3 ? '#E7EAF0' : 'rgba(255,255,255,0.16)' },
  orText: { fontFamily: Fonts.body, fontSize: 14, color: a3 ? '#65718A' : c.muted },
  premiumNote: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 14,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: dk(c, 'rgba(230,184,90,0.4)', 'rgba(201,146,30,0.35)'),
    backgroundColor: dk(c, 'rgba(230,184,90,0.1)', c.goldTint),
    marginBottom: 6,
  },
  premiumText: { flex: 1, fontFamily: Fonts.body, fontSize: 13.5, lineHeight: 19, color: c.text },
  flex: { flex: 1, backgroundColor: c.bg },
  head: { paddingTop: 16, paddingBottom: a3 ? 20 : 26 },
  title: { fontSize: 30 },
  arabic: { textAlign: 'left', marginTop: 10 },
  sub: { marginTop: 10, fontSize: 15, lineHeight: 23, maxWidth: 340 },

  fieldLabel: {
    fontFamily: Fonts.bodySemi,
    fontSize: 11.5,
    letterSpacing: Tracking.meta,
    textTransform: 'uppercase',
    color: a3 ? '#B98522' : c.gold,
    marginBottom: 8,
    marginTop: 14,
  },
  input: {
    backgroundColor: dk(c, 'rgba(28,42,76,0.9)', c.card),
    borderWidth: dk(c, 1.2, 1.5),
    borderColor: dk(c, 'rgba(214,178,90,0.35)', c.navy),
    borderRadius: Radius.md,
    color: dk(c, Colors.text, c.text),
    fontFamily: Fonts.body,
    paddingHorizontal: Spacing.md,
    paddingVertical: 15,
    fontSize: 16,
  },
  // While it has the cursor: a soft grey panel, dark ink, gold edge — lighter
  // than the page so the field stands out, without the glare of white.
  inputOn: {
    backgroundColor: '#dfe4ed',
    color: '#16213a',
    borderColor: c.goldFill,
    borderWidth: 1.6,
  },
  // The quiet gold link, as on the plans screen; sits under the password field.
  forgot: { alignSelf: 'flex-end', marginTop: 10, marginBottom: 4 },
  link: { fontFamily: Fonts.bodySemi, fontSize: 13, color: a3 ? '#B98522' : c.gold },

  notice: {
    flexDirection: 'row',
    gap: 10,
    alignItems: 'flex-start',
    backgroundColor: dk(c, 'rgba(127,201,156,0.10)', 'rgba(47,157,92,0.10)'),
    borderWidth: 1,
    borderColor: dk(c, 'rgba(127,201,156,0.3)', 'rgba(47,157,92,0.3)'),
    borderRadius: Radius.sm,
    padding: Spacing.md,
    marginBottom: Spacing.sm,
  },
  noticeText: { flex: 1, fontFamily: Fonts.body, fontSize: 14, lineHeight: 20, color: dk(c, Colors.mint, c.green) },
  };
});
