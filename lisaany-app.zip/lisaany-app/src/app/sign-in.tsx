import Svg, { Path } from 'react-native-svg';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, Text, TextInput, View } from 'react-native';

import { Icon } from '@/components/icon';
import { Body, Button, Display, ErrorNote, Eyebrow, Screen } from '@/components/ui';
import { Colors, Fonts, Radius, Spacing, Tracking } from '@/constants/lisaany';
import { useLang } from '@/lib/i18n';
import { supabase } from '@/lib/supabase';
import { APPLE_ON, GOOGLE_ON, signInWithApple, signInWithGoogle } from '@/lib/sso';
import { makeStyles, useTheme, type Palette } from '@/theme';

/**
 * Where the "choose a new password" email link lands. The website's auth
 * page receives Supabase's `type=recovery` link and shows the new-password
 * form; the app itself has no web session to finish it in.
 */
const RESET_REDIRECT = 'https://lisaany.com/auth.html';

export default function SignInScreen() {
  const styles = useStyles();
  const { c } = useTheme();
  const router = useRouter();
  const { t } = useLang();
  // `next=plans` comes from a Premium lesson: after signing in, go on to the
  // plans. `from=landing` comes from the landing screen's "I already have an
  // account": going back would only show landing again, so head into the app.
  const params = useLocalSearchParams<{ next?: string; unit?: string; from?: string }>();
  const toPlans = params.next === 'plans';
  const fromLanding = params.from === 'landing';
  const goHome = () => {
    try {
      if (router.canDismiss()) router.dismissAll();
    } catch {
      /* nothing to dismiss */
    }
    router.replace('/');
  };
  const done = () => {
    if (toPlans) router.replace({ pathname: '/plans', params: params.unit ? { unit: String(params.unit) } : {} });
    else if (fromLanding) goHome();
    else if (router.canGoBack()) router.back();
    else router.replace('/');
  };
  const [mode, setMode] = useState<'sign-in' | 'sign-up'>('sign-in');
  // The field you are typing in turns white, so the text is always easy to read.
  const [focused, setFocused] = useState<'email' | 'password' | null>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const oneTap = async (which: 'google' | 'apple') => {
    setError(null);
    setNotice(null);
    setBusy(true);
    try {
      const r = which === 'google' ? await signInWithGoogle() : await signInWithApple();
      if (r === 'signed-in') done();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Something went wrong. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  const submit = async () => {
    setError(null);
    setNotice(null);

    if (!email.trim() || !password) {
      setError('Enter your email and password.');
      return;
    }

    setBusy(true);
    try {
      if (mode === 'sign-in') {
        const { error: err } = await supabase.auth.signInWithPassword({
          email: email.trim(),
          password,
        });
        if (err) throw err;
        done();
      } else {
        const { data, error: err } = await supabase.auth.signUp({
          email: email.trim(),
          password,
        });
        if (err) throw err;

        // Supabase does not say "this email is taken" (so nobody can probe for
        // accounts): for an email that already has an account it returns a user
        // with no identities, creates nothing and sends no email.
        if (data.user && Array.isArray(data.user.identities) && data.user.identities.length === 0) {
          setError('There is already an account with this email. Sign in, or tap Forgot your password.');
          setMode('sign-in');
        } else if (data.session) {
          done();
        } else {
          setNotice('Check your email to confirm the account, then sign in.');
          setMode('sign-in');
        }
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Something went wrong. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  // Supabase emails a recovery link; the website's auth page takes it from there.
  const forgotPassword = async () => {
    setError(null);
    setNotice(null);
    const address = email.trim();
    if (!address) {
      setError('Enter your email first, then tap Forgot your password.');
      return;
    }
    setBusy(true);
    try {
      const { error: err } = await supabase.auth.resetPasswordForEmail(address, { redirectTo: RESET_REDIRECT });
      if (err) throw err;
      setNotice('Check your email for a link to choose a new password.');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Something went wrong. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.flex}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <Screen>
        <View style={styles.head}>
          <Eyebrow>{mode === 'sign-in' ? t('Welcome back') : t('Join Lisaany')}</Eyebrow>
          <Display style={styles.title}>
            {mode === 'sign-in' ? t('Sign in') : t('Create your account')}
          </Display>
          <Body style={styles.sub}>
            {t('Use the same account as lisaany.com — your plan and tutor access come with it.')}
          </Body>
        </View>

        {toPlans ? (
          <View style={styles.premiumNote}>
            <Icon name="crown" size={22} color={c.gold} />
            <Text style={styles.premiumText}>
              {t('One step before Premium: sign in or create a free account so your plan and progress are saved.')}
            </Text>
          </View>
        ) : null}

        {error ? <ErrorNote message={t(error)} /> : null}
        {notice ? (
          <View style={styles.notice}>
            <Icon name="mark_email_read" size={18} color={dk(c, Colors.mint, c.green)} />
            <Text style={styles.noticeText}>{t(notice)}</Text>
          </View>
        ) : null}

        {/* One tap: Google, then Apple (iPhone). Shown once each is set up (see src/lib/sso.ts). */}
        {GOOGLE_ON || APPLE_ON ? (
          <View style={styles.sso}>
            {GOOGLE_ON ? (
              <Pressable onPress={() => oneTap('google')} disabled={busy} style={({ pressed }) => [styles.ssoBtn, pressed && { opacity: 0.85 }]} accessibilityRole="button">
                {/* Google's official "G" (from Google's sign-in button kit). */}
                <Svg width={22} height={22} viewBox="0 0 48 48">
                  <Path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
                  <Path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
                  <Path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
                  <Path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
                </Svg>
                <Text style={styles.ssoText}>{t('Continue with Google')}</Text>
              </Pressable>
            ) : null}
            {APPLE_ON ? <AppleButton onPress={() => oneTap('apple')} /> : null}
            <View style={styles.orRow}>
              <View style={styles.orLine} />
              <Text style={styles.orText}>{t('or')}</Text>
              <View style={styles.orLine} />
            </View>
          </View>
        ) : null}

        <Text style={styles.fieldLabel}>{t('Email')}</Text>
        <TextInput
          value={email}
          onChangeText={setEmail}
          placeholder={t('you@example.com')}
          placeholderTextColor={focused === 'email' ? 'rgba(22,33,58,0.5)' : dk(c, 'rgba(243,246,252,0.55)', c.faint)}
          autoCapitalize="none"
          autoComplete="email"
          keyboardType="email-address"
          onFocus={() => setFocused('email')}
          onBlur={() => setFocused(null)}
          style={[styles.input, focused === 'email' && styles.inputOn]}
        />

        <Text style={styles.fieldLabel}>{t('Password')}</Text>
        <TextInput
          value={password}
          onChangeText={setPassword}
          placeholder="••••••••"
          placeholderTextColor={focused === 'password' ? 'rgba(22,33,58,0.5)' : dk(c, 'rgba(243,246,252,0.55)', c.faint)}
          autoCapitalize="none"
          secureTextEntry
          onFocus={() => setFocused('password')}
          onBlur={() => setFocused(null)}
          style={[styles.input, focused === 'password' && styles.inputOn]}
          onSubmitEditing={submit}
        />

        {mode === 'sign-in' ? (
          <Pressable onPress={forgotPassword} disabled={busy} hitSlop={6} style={styles.forgot} accessibilityRole="link">
            <Text style={styles.link}>{t('Forgot your password?')}</Text>
          </Pressable>
        ) : null}

        <Button
          label={mode === 'sign-in' ? t('Sign in') : t('Create account')}
          icon={mode === 'sign-in' ? 'login' : 'person_add'}
          onPress={submit}
          loading={busy}
        />

        <Button
          label={mode === 'sign-in' ? t('Create account') : t('I already have an account')}
          variant="ghost"
          onPress={() => {
            setMode(mode === 'sign-in' ? 'sign-up' : 'sign-in');
            setError(null);
            setNotice(null);
          }}
        />
      </Screen>
    </KeyboardAvoidingView>
  );
}

/** Dark keeps its original values exactly; light uses palette tokens. */
function dk<T>(c: Palette, dark: T, light: T): T {
  return c.scheme === 'dark' ? dark : light;
}

/** Apple's own button (iPhone only): Apple requires its official look. */
function AppleButton({ onPress }: { onPress: () => void }) {
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const Apple = require('expo-apple-authentication') as typeof import('expo-apple-authentication');
  return (
    <Apple.AppleAuthenticationButton
      buttonType={Apple.AppleAuthenticationButtonType.CONTINUE}
      buttonStyle={Apple.AppleAuthenticationButtonStyle.WHITE}
      cornerRadius={28}
      style={{ height: 56, width: '100%' }}
      onPress={onPress}
    />
  );
}

const useStyles = makeStyles((c) => ({
  sso: { gap: 14, marginTop: 6 },
  ssoBtn: {
    height: 56,
    borderRadius: 28,
    backgroundColor: '#ffffff',
    borderWidth: 1.5,
    borderColor: '#c9d1d9',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 14,
  },
  ssoText: { fontFamily: Fonts.bodyBold, fontSize: 17, color: '#000000' },
  orRow: { flexDirection: 'row', alignItems: 'center', gap: 14, marginTop: 8 },
  orLine: { flex: 1, height: 1, backgroundColor: 'rgba(255,255,255,0.16)' },
  orText: { fontFamily: Fonts.body, fontSize: 14, color: c.muted },
  premiumNote: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 14,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: dk(c, 'rgba(230,184,90,0.4)', 'rgba(201,146,30,0.35)'),
    backgroundColor: dk(c, 'rgba(230,184,90,0.1)', c.goldTint),
    marginBottom: 6,
  },
  premiumText: { flex: 1, fontFamily: Fonts.body, fontSize: 13.5, lineHeight: 19, color: c.text },
  flex: { flex: 1, backgroundColor: c.bg },
  head: { paddingTop: 16, paddingBottom: 26 },
  title: { fontSize: 30 },
  arabic: { textAlign: 'left', marginTop: 10 },
  sub: { marginTop: 10, fontSize: 15, lineHeight: 23, maxWidth: 340 },

  fieldLabel: {
    fontFamily: Fonts.bodySemi,
    fontSize: 11.5,
    letterSpacing: Tracking.meta,
    textTransform: 'uppercase',
    color: c.gold,
    marginBottom: 8,
    marginTop: 14,
  },
  input: {
    backgroundColor: dk(c, 'rgba(28,42,76,0.9)', c.card),
    borderWidth: dk(c, 1.2, 1.5),
    borderColor: dk(c, 'rgba(214,178,90,0.35)', c.navy),
    borderRadius: Radius.md,
    color: dk(c, Colors.text, c.text),
    fontFamily: Fonts.body,
    paddingHorizontal: Spacing.md,
    paddingVertical: 15,
    fontSize: 16,
  },
  // While it has the cursor: a soft grey panel, dark ink, gold edge — lighter
  // than the page so the field stands out, without the glare of white.
  inputOn: {
    backgroundColor: '#dfe4ed',
    color: '#16213a',
    borderColor: c.goldFill,
    borderWidth: 1.6,
  },
  // The quiet gold link, as on the plans screen; sits under the password field.
  forgot: { alignSelf: 'flex-end', marginTop: 10, marginBottom: 4 },
  link: { fontFamily: Fonts.bodySemi, fontSize: 12.5, color: c.gold },

  notice: {
    flexDirection: 'row',
    gap: 10,
    alignItems: 'flex-start',
    backgroundColor: dk(c, 'rgba(127,201,156,0.10)', 'rgba(47,157,92,0.10)'),
    borderWidth: 1,
    borderColor: dk(c, 'rgba(127,201,156,0.3)', 'rgba(47,157,92,0.3)'),
    borderRadius: Radius.sm,
    padding: Spacing.md,
    marginBottom: Spacing.sm,
  },
  noticeText: { flex: 1, fontFamily: Fonts.body, fontSize: 14, lineHeight: 20, color: dk(c, Colors.mint, c.green) },
}));
