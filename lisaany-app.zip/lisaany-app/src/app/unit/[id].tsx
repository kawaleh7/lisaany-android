import { LinearGradient } from 'expo-linear-gradient';
import { Stack, useFocusEffect, useLocalSearchParams, useRouter } from 'expo-router';
import { useCallback, useState } from 'react';
import { Alert, Linking, Pressable, ScrollView, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Icon } from '@/components/icon';
import { ErrorNote } from '@/components/ui';
import { Fonts, Spacing, WEB_BASE } from '@/constants/lisaany';
import { useAuth } from '@/lib/auth-context';
import { BLOCK_TYPE_LABELS, blockSizeLabel, getModuleForUnit, getObjectives, getUnit } from '@/lib/curriculum';
import { canAccessUnit } from '@/lib/plan';
import { getCompletedBlocks, isBlockUnlocked, nextBlockFor, setLastUnit, type CompletedMap } from '@/lib/progress';
import { makeStyles, useTheme } from '@/theme';

/**
 * A lesson (unit) page: Continue where you are, start the whole lesson again
 * from part 1, or replay any part you have finished. Replaying never erases
 * progress; parts you have not reached yet stay locked.
 */
export default function UnitScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const unitId = String(id);
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { session, plan } = useAuth();
  const { c } = useTheme();
  const styles = useStyles();
  // The selected-part card is navy in both themes.
  const onNavyMuted = c.scheme === 'dark' ? c.muted : c.onNavyMuted;

  const unit = getUnit(unitId);
  const mod = getModuleForUnit(unitId);
  const objectives = getObjectives(unitId);

  const [done, setDone] = useState<CompletedMap>({});
  const [allowed, setAllowed] = useState<boolean | null>(null);
  const [goalsOpen, setGoalsOpen] = useState(false);
  const [picked, setSel] = useState<number | null>(null);

  // Progress changes while a lesson is open, so re-read it every time we return.
  useFocusEffect(
    useCallback(() => {
      let active = true;
      if (!unit) return;
      setLastUnit(unitId);
      Promise.all([getCompletedBlocks(), canAccessUnit(unitId)]).then(([map, ok]) => {
        if (!active) return;
        setDone(map);
        setAllowed(ok);
      });
      return () => {
        active = false;
      };
    }, [unitId, unit, plan])
  );

  const back = () => (router.canGoBack() ? router.back() : router.replace('/lessons'));

  if (!unit) {
    return (
      <View style={[styles.screen, { paddingTop: insets.top + 20, paddingHorizontal: Spacing.md }]}>
        <Stack.Screen options={{ headerShown: false }} />
        <ErrorNote message={`No lesson with id ${id}.`} />
      </View>
    );
  }

  const total = unit.blocks.length;
  const doneCount = unit.blocks.filter((b) => done[`${unitId}:${b.id}`]).length;
  const complete = total > 0 && doneCount >= total;
  const nextId = nextBlockFor(unit, done);
  const nextIdx = Math.max(0, unit.blocks.findIndex((b) => b.id === nextId));
  const firstId = unit.blocks[0]?.id;
  // Until a dot is tapped, show the part you would continue with.
  const selIdx = Math.min(total - 1, Math.max(0, picked ?? (complete ? 0 : nextIdx)));
  const sel = unit.blocks[selIdx];
  const selDone = sel ? !!done[`${unitId}:${sel.id}`] : false;
  const selState: 'done' | 'next' | 'open' | 'locked' = !sel
    ? 'locked'
    : selDone
      ? 'done'
      : !complete && sel.id === nextId
        ? 'next'
        : isBlockUnlocked(unit, sel.id, done)
          ? 'open'
          : 'locked';

  const seePlans = () =>
    session
      ? router.push({ pathname: '/plans', params: { unit: unitId } })
      : router.push({ pathname: '/sign-in', params: { next: 'plans', unit: unitId } });

  const openBlock = (blockId: number) => {
    if (allowed === false) {
      seePlans();
      return;
    }
    router.push({ pathname: '/lesson/[unit]', params: { unit: unitId, block: String(blockId) } });
  };

  return (
    <View style={styles.screen}>
      <Stack.Screen options={{ headerShown: false }} />
      <ScrollView
        contentContainerStyle={[styles.content, { paddingTop: insets.top + 12, paddingBottom: insets.bottom + 40 }]}
        showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.top}>
          <Pressable onPress={back} hitSlop={8} style={styles.backBtn} accessibilityLabel="Back">
            <Icon name="arrow_back" size={22} color={c.text} />
          </Pressable>
          <View style={{ flex: 1 }}>
            <Text style={styles.eyebrow} numberOfLines={1}>
              {mod ? `${mod.title} · ` : ''}Lesson {unit.id}
            </Text>
          </View>
          {!session && allowed ? (
            <Pressable onPress={() => router.push('/sign-in')} hitSlop={6} style={styles.chip}>
              <Icon name="person" size={15} color={c.gold} />
              <Text style={styles.chipText}>Sign in</Text>
            </Pressable>
          ) : null}
        </View>

        <Text style={styles.title}>{unit.title}</Text>
        {unit.desc ? <Text style={styles.titleAr}>{'⁧' + unit.desc + '⁩'}</Text> : null}

        <View style={styles.segs}>
          {unit.blocks.map((b, i) => (
            <View
              key={b.id}
              style={[
                styles.seg,
                done[`${unitId}:${b.id}`] ? { backgroundColor: c.goldFill } : null,
                !complete && i === nextIdx ? { backgroundColor: 'rgba(230,184,90,0.4)' } : null,
              ]}
            />
          ))}
        </View>
        <Text style={styles.count}>{complete ? `All ${total} parts done` : `${doneCount} of ${total} parts done`}</Text>

        {/* Actions */}
        {allowed === false ? (
          <View style={styles.locked}>
            <View style={styles.ghostRow} pointerEvents="none">
              {unit.blocks.map((b) => (
                <View key={b.id} style={styles.ghostDot} />
              ))}
            </View>
            <LinearGradient colors={c.navyGrad} start={{ x: 0.2, y: 0 }} end={{ x: 0.8, y: 1 }} style={styles.lockedFront}>
              <LinearGradient colors={['#f6d98c', c.goldFill]} style={styles.lockedCrown}>
                <Icon name="crown" size={32} color={c.onGold} />
              </LinearGradient>
              <Text style={styles.lockedTitle}>Premium lesson</Text>
              <Text style={styles.lockedSub}>
                Unlock {unit.title} and every other lesson. Lessons 1.1, 1.2 and 1.3 are free.
              </Text>
              <Pressable onPress={seePlans} style={({ pressed }) => [styles.lockedCta, pressed && { opacity: 0.88 }]}>
                <Text style={styles.ctaText}>See plans</Text>
              </Pressable>
              {!session ? (
                <Pressable onPress={() => router.push('/sign-in')} hitSlop={8}>
                  <Text style={styles.member}>
                    Already a member? <Text style={{ color: c.goldFill, fontFamily: Fonts.bodyBold }}>Sign in</Text>
                  </Text>
                </Pressable>
              ) : null}
            </LinearGradient>
          </View>
        ) : (
          <>
        <View style={styles.actions}>
          {!complete ? (
            <Pressable
              onPress={() => openBlock(nextId)}
              disabled={allowed === null}
              style={({ pressed }) => [styles.cta, { flex: 1.45 }, pressed && { opacity: 0.88 }]}>
              <Text style={styles.ctaText} numberOfLines={1}>
                {doneCount ? `Continue · Part ${nextIdx + 1}` : 'Start lesson'}
              </Text>
            </Pressable>
          ) : null}
          {(doneCount > 0 || complete) && firstId != null ? (
            <Pressable
              onPress={() => openBlock(firstId)}
              disabled={allowed === null}
              style={({ pressed }) => [complete ? styles.cta : styles.outline, { flex: 1 }, pressed && { opacity: 0.85 }]}>
              <Icon name="replay" size={17} color={complete ? c.onGold : c.gold} />
              <Text style={complete ? styles.ctaText : styles.outlineText} numberOfLines={1}>
                {complete ? 'Start from the beginning' : 'From start'}
              </Text>
            </Pressable>
          ) : null}
        </View>

        {/* Stepper: one numbered dot per part */}
        <Text style={styles.section}>TAP A LESSON</Text>
        <View style={styles.stepper}>
          {unit.blocks.map((b, i) => {
            const isDone = !!done[`${unitId}:${b.id}`];
            const isNext = !complete && b.id === nextId;
            const open = isDone || isNext || isBlockUnlocked(unit, b.id, done);
            const isSel = i === selIdx;
            const dot = total > 11 ? 22 : 26;
            return (
              <View key={b.id} style={i === total - 1 ? styles.stepLast : styles.stepCell}>
                <Pressable
                  onPress={() => setSel(i)}
                  hitSlop={6}
                  accessibilityLabel={`Part ${i + 1}: ${b.title}`}
                  style={[
                    styles.dot,
                    { width: dot, height: dot, borderRadius: dot / 2 },
                    isDone && styles.dotDone,
                    !open && styles.dotLocked,
                    isSel && styles.dotSel,
                  ]}>
                  <Text style={[styles.dotText, isSel && { color: c.onGold }]}>
                    {i + 1}
                  </Text>
                </Pressable>
                {i < total - 1 ? <View style={[styles.link, isDone && { backgroundColor: c.goldFill }]} /> : null}
              </View>
            );
          })}
        </View>

        {/* The selected part */}
        {sel ? (
          <LinearGradient colors={c.navyGrad} start={{ x: 0.2, y: 0 }} end={{ x: 0.8, y: 1 }} style={styles.partCard}>
            <View style={styles.partTop}>
              <View style={[styles.partIcon, selState === 'locked' && styles.partIconLocked]}>
                <Icon name={sel.icon ?? 'menu_book'} size={28} color={selState === 'locked' ? onNavyMuted : c.goldFill} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.partEyebrow, selState === 'locked' && { color: onNavyMuted }]}>
                  PART {selIdx + 1} · {selState === 'done' ? 'DONE ✓' : selState === 'next' ? 'UP NEXT' : selState === 'open' ? 'OPEN' : 'LOCKED'}
                </Text>
                <Text style={styles.partTitle} numberOfLines={2}>
                  {sel.title}
                </Text>
                <Text style={styles.partSub}>
                  {[BLOCK_TYPE_LABELS[sel.type] ?? sel.type, blockSizeLabel(sel)].filter(Boolean).join(' · ')}
                </Text>
              </View>
            </View>
            {sel.desc ? <Text style={[styles.partDesc, !/[؀-ۿ]/.test(sel.desc) && styles.partDescEn]}>{'⁨' + sel.desc + '⁩'}</Text> : null}
            {selState === 'locked' ? (
              <View style={styles.partLocked}>
                <Icon name="lock" size={16} color={onNavyMuted} />
                <Text style={styles.partLockedText}>Finish part {nextIdx + 1} first</Text>
              </View>
            ) : (
              <Pressable
                onPress={() => openBlock(sel.id)}
                disabled={allowed === null}
                style={({ pressed }) => [styles.cta, { marginTop: 16 }, pressed && { opacity: 0.88 }]}>
                <Icon name={selState === 'done' ? 'replay' : 'play_arrow'} size={19} color={c.onGold} />
                <Text style={styles.ctaText}>{selState === 'done' ? 'Replay this part' : 'Start this part'}</Text>
              </Pressable>
            )}
          </LinearGradient>
        ) : null}

          </>
        )}

        {objectives.length ? (
          <>
            <Pressable onPress={() => setGoalsOpen(!goalsOpen)} style={styles.goalsHead} hitSlop={6}>
              <Text style={styles.section}>BY THE END OF THIS LESSON</Text>
              <Icon name={goalsOpen ? 'expand_less' : 'expand_more'} size={20} color={c.muted} />
            </Pressable>
            {goalsOpen
              ? objectives.map((obj, k) => (
                  <View key={k} style={styles.goalRow}>
                    <Icon name="check_circle" size={17} color={c.gold} />
                    <Text style={styles.goalText}>{obj}</Text>
                  </View>
                ))
              : null}
          </>
        ) : null}
      </ScrollView>
    </View>
  );
}

const useStyles = makeStyles((c) => {
  const light = c.scheme === 'light';
  // Text on the navy part card (navy in both themes).
  const onNavyMuted = light ? c.onNavyMuted : c.muted;
  return {
    screen: { flex: 1, backgroundColor: c.bg },
    content: { paddingHorizontal: Spacing.md + 4 },

    top: { flexDirection: 'row', alignItems: 'center', gap: 12 },
    backBtn: {
      width: 44,
      height: 44,
      borderRadius: 22,
      backgroundColor: c.card,
      borderWidth: 1,
      borderColor: c.line,
      alignItems: 'center',
      justifyContent: 'center',
    },
    eyebrow: { fontFamily: Fonts.bodySemi, fontSize: 12.5, color: c.muted },
    title: { fontFamily: Fonts.displayBold, fontSize: 28, lineHeight: 34, color: c.text, marginTop: 18 },
    titleAr: { fontFamily: Fonts.arabic, fontSize: 21, lineHeight: 34, color: c.gold, marginTop: 2, writingDirection: 'rtl', textAlign: 'left' },

    segs: { flexDirection: 'row', gap: 4, marginTop: 14 },
    seg: { flex: 1, height: 6, borderRadius: 3, backgroundColor: c.track },
    count: { fontFamily: Fonts.body, fontSize: 13, color: c.muted, marginTop: 8 },

    chip: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 5,
      paddingVertical: 7,
      paddingHorizontal: 12,
      borderRadius: 14,
      backgroundColor: c.goldTint,
    },
    chipText: { fontFamily: Fonts.bodyBold, fontSize: 12.5, color: c.gold },
    locked: { marginTop: 22 },
    ghostRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 6, opacity: 0.6 },
    ghostDot: { width: 24, height: 24, borderRadius: 12, borderWidth: 1.5, borderColor: c.goldFill },
    lockedFront: {
      alignItems: 'center',
      paddingVertical: 26,
      paddingHorizontal: 18,
      marginTop: 22,
      borderRadius: 26,
      borderWidth: 1,
      borderColor: 'rgba(230,184,90,0.35)',
      shadowColor: c.shadow,
      shadowOpacity: light ? 0.18 : 0.45,
      shadowRadius: 18,
      shadowOffset: { width: 0, height: 10 },
      elevation: 8,
    },
    lockedCrown: {
      width: 70,
      height: 70,
      borderRadius: 35,
      alignItems: 'center',
      justifyContent: 'center',
      shadowColor: c.goldFill,
      shadowOpacity: 0.6,
      shadowRadius: 20,
      shadowOffset: { width: 0, height: 0 },
      elevation: 10,
    },
    lockedTitle: { fontFamily: Fonts.displayBold, fontSize: 22, color: c.onNavy, marginTop: 14 },
    // Dark keeps its original lighter grey.
    lockedSub: { fontFamily: Fonts.body, fontSize: 14, lineHeight: 20, color: '#d9dfe9', textAlign: 'center', marginTop: 6, maxWidth: 290 },
    lockedCta: {
      height: 50,
      borderRadius: 25,
      paddingHorizontal: 40,
      backgroundColor: c.goldFill,
      alignItems: 'center',
      justifyContent: 'center',
      marginTop: 18,
    },
    member: { fontFamily: Fonts.body, fontSize: 13, color: c.onNavyMuted, marginTop: 14 },
    lockCard: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
      marginTop: 16,
      padding: 14,
      borderRadius: 18,
      borderWidth: 1,
      borderColor: 'rgba(230,184,90,0.4)',
      backgroundColor: c.goldTint,
    },
    lockText: { flex: 1, fontFamily: Fonts.body, fontSize: 13.5, lineHeight: 20, color: c.text },

    actions: { flexDirection: 'row', gap: 10, marginTop: 18 },
    cta: {
      height: 52,
      borderRadius: 27,
      backgroundColor: c.goldFill,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      paddingHorizontal: 12,
    },
    ctaText: { fontFamily: Fonts.bodyBold, fontSize: 15, color: c.onGold },
    outline: {
      height: 52,
      borderRadius: 26,
      borderWidth: 1.5,
      borderColor: light ? c.gold : 'rgba(230,184,90,0.55)',
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 6,
      paddingHorizontal: 10,
    },
    outlineText: { fontFamily: Fonts.bodyBold, fontSize: 14, color: c.gold },

    section: { fontFamily: Fonts.bodyBold, fontSize: 11.5, letterSpacing: 1.6, color: c.muted, marginTop: 26, marginBottom: 10 },

    stepper: { flexDirection: 'row', alignItems: 'center', paddingVertical: 6 },
    stepCell: { flex: 1, flexDirection: 'row', alignItems: 'center' },
    stepLast: { flexDirection: 'row', alignItems: 'center' },
    dot: {
      alignItems: 'center',
      justifyContent: 'center',
      borderWidth: 1.5,
      borderColor: light ? c.gold : 'rgba(230,184,90,0.6)',
      backgroundColor: light ? c.card : 'transparent',
    },
    // Not selected: gold ring (done parts get a soft gold fill); selected: solid gold.
    dotDone: { backgroundColor: c.goldTint },
    dotLocked: { opacity: 0.45 },
    dotSel: { transform: [{ scale: 1.22 }], backgroundColor: c.goldFill, borderColor: c.goldFill, opacity: 1 },
    dotText: { fontFamily: Fonts.bodyBold, fontSize: 11, color: c.gold },
    link: { flex: 1, height: 2, minWidth: 2, backgroundColor: c.line },

    // Selected part: navy in both themes, lifted with the card shadow in light.
    partCard: {
      marginTop: 18,
      borderRadius: 26,
      padding: 18,
      borderWidth: 1,
      borderColor: 'rgba(230,184,90,0.28)',
      shadowColor: c.shadow,
      shadowOpacity: light ? 0.18 : 0,
      shadowRadius: 14,
      shadowOffset: { width: 0, height: 8 },
      elevation: light ? 4 : 0,
    },
    partTop: { flexDirection: 'row', alignItems: 'center', gap: 14 },
    // Tints on the navy card stay the same in both themes.
    partIcon: {
      width: 60,
      height: 60,
      borderRadius: 18,
      backgroundColor: 'rgba(230,184,90,0.14)',
      alignItems: 'center',
      justifyContent: 'center',
    },
    partIconLocked: { backgroundColor: 'rgba(255,255,255,0.05)' },
    partEyebrow: { fontFamily: Fonts.bodyBold, fontSize: 11, letterSpacing: 1.4, color: c.goldFill },
    partTitle: { fontFamily: Fonts.displayBold, fontSize: 20, lineHeight: 25, color: c.onNavy, marginTop: 3 },
    partSub: { fontFamily: Fonts.body, fontSize: 12.5, color: onNavyMuted, marginTop: 2 },
    partDesc: { fontFamily: Fonts.arabic, fontSize: 20, lineHeight: 34, color: c.onNavy, textAlign: 'center', marginTop: 12 },
    partDescEn: { fontFamily: Fonts.body, fontSize: 14, lineHeight: 20, color: '#c9d0dd' },
    partLocked: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      height: 48,
      borderRadius: 24,
      borderWidth: 1,
      borderColor: 'rgba(255,255,255,0.1)',
      marginTop: 16,
    },
    partLockedText: { fontFamily: Fonts.bodySemi, fontSize: 14, color: onNavyMuted },

    goalsHead: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
    goalRow: { flexDirection: 'row', gap: 10, alignItems: 'flex-start', marginBottom: 10 },
    goalText: { flex: 1, fontFamily: Fonts.body, fontSize: 14.5, lineHeight: 21, color: c.text },
  };
});
