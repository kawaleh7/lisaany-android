import { LinearGradient } from 'expo-linear-gradient';
import { Stack, useFocusEffect, useLocalSearchParams, useRouter } from 'expo-router';
import { useCallback, useMemo, useState } from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Icon } from '@/components/icon';
import { PopPressable } from '@/components/pop-card';
import { SpaceBackdrop } from '@/components/space-backdrop';
import { StarSlot, StarTalk, useStarGuide } from '@/components/star-guide';
import { CardFill, ContinuePill, currentCard, ErrorNote, LATER_STYLE, spaceCard } from '@/components/ui';
import { Fonts, Spacing } from '@/constants/lisaany';
import { useAuth } from '@/lib/auth-context';
import { BLOCK_TYPE_LABELS, blockSizeLabel, getModuleForUnit, getObjectives, getUnit } from '@/lib/curriculum';
import { useLang } from '@/lib/i18n';
import { canAccessUnit } from '@/lib/plan';
import { getCompletedBlocks, isBlockUnlocked, nextBlockFor, setLastUnit, type CompletedMap } from '@/lib/progress';
import { makeStyles, useTheme } from '@/theme';
import { ContentWidth, contentCap } from '@/components/content-width';

/**
 * A lesson (unit) page: Continue where you are, start the whole lesson again
 * from part 1, or replay any part you have finished. Replaying never erases
 * progress; parts you have not reached yet stay locked.
 */
export default function UnitScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const unitId = String(id);
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { session, plan } = useAuth();
  const { c } = useTheme();
  const styles = useStyles();
  const { t, ct, lang, objectives: objectivesFor } = useLang();

  const unit = getUnit(unitId);
  const mod = getModuleForUnit(unitId);
  const objectives = objectivesFor(unitId, getObjectives(unitId));

  const [done, setDone] = useState<CompletedMap>({});
  const [allowed, setAllowed] = useState<boolean | null>(null);
  const [goalsOpen, setGoalsOpen] = useState(false);

  const tips = useMemo(
    () => [
      t('Parts go in order — the gold one is up next.'),
      t('Green parts are done. You can replay any of them.'),
      t('Faded parts open as you finish the ones before.'),
    ],
    [t]
  );
  const guide = useStarGuide(tips, { greet: tips[0], greetKey: 'unit' });

  // Progress changes while a lesson is open, so re-read it every time we return.
  useFocusEffect(
    useCallback(() => {
      let active = true;
      if (!unit) return;
      setLastUnit(unitId);
      Promise.all([getCompletedBlocks(), canAccessUnit(unitId)]).then(([map, ok]) => {
        if (!active) return;
        setDone(map);
        setAllowed(ok);
      });
      return () => {
        active = false;
      };
    // eslint-disable-next-line react-hooks/exhaustive-deps -- plan: re-check access after a purchase
    }, [unitId, unit, plan])
  );

  const back = () => (router.canGoBack() ? router.back() : router.replace('/lessons'));

  if (!unit) {
    return (
      <View style={[styles.screen, { paddingTop: insets.top + 20, paddingHorizontal: Spacing.md }]}>
        <SpaceBackdrop />
        <Stack.Screen options={{ headerShown: false }} />
        <ContentWidth>
          <ErrorNote message={t('No lesson with id {id}.', { id: String(id) })} />
        </ContentWidth>
      </View>
    );
  }

  const total = unit.blocks.length;
  const doneCount = unit.blocks.filter((b) => done[`${unitId}:${b.id}`]).length;
  const complete = total > 0 && doneCount >= total;
  const nextId = nextBlockFor(unit, done);
  const nextIdx = Math.max(0, unit.blocks.findIndex((b) => b.id === nextId));
  const firstId = unit.blocks[0]?.id;
  const partMeta = (b: (typeof unit.blocks)[number]) =>
    [BLOCK_TYPE_LABELS[b.type] ? t(BLOCK_TYPE_LABELS[b.type]) : b.type, blockSizeLabel(b, lang)].filter(Boolean).join(' · ');

  // Both stores sell Premium in-app without an account; the plans screen offers sign-in itself.
  const seePlans = () => router.push({ pathname: '/plans', params: { unit: unitId } });

  const openBlock = (blockId: number) => {
    if (allowed === false) {
      seePlans();
      return;
    }
    router.push({ pathname: '/lesson/[unit]', params: { unit: unitId, block: String(blockId) } });
  };

  return (
    <View style={styles.screen}>
      <SpaceBackdrop />
      <Stack.Screen options={{ headerShown: false }} />
      <ScrollView
        contentContainerStyle={[styles.content, { paddingTop: insets.top + 12, paddingBottom: insets.bottom + 40 }]}
        showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.top}>
          <Pressable onPress={back} hitSlop={8} style={styles.backBtn} accessibilityLabel={t('Back')}>
            <Icon name="arrow_back" size={22} color={c.text} />
          </Pressable>
          <View style={{ flex: 1 }}>
            <Text style={styles.eyebrow} numberOfLines={1}>
              {mod ? `${ct(mod.title)} · ` : ''}{t('Lesson {id}', { id: unit.id })}
            </Text>
          </View>
          {!session && allowed ? (
            <Pressable onPress={() => router.push('/sign-in')} hitSlop={6} style={styles.chip}>
              <Icon name="login" size={15} color={c.gold} />
              <Text style={styles.chipText}>{t('Sign in')}</Text>
            </Pressable>
          ) : null}
          <StarSlot guide={guide} />
        </View>
        <StarTalk guide={guide} />

        <Text style={styles.title}>{ct(unit.title)}</Text>
        {unit.desc ? <Text style={styles.titleAr}>{'⁧' + unit.desc + '⁩'}</Text> : null}

        <View style={styles.segs}>
          {unit.blocks.map((b, i) => (
            <View
              key={b.id}
              style={[
                styles.seg,
                done[`${unitId}:${b.id}`] ? { backgroundColor: c.goldFill } : null,
                !complete && i === nextIdx ? { backgroundColor: 'rgba(214,178,90,0.45)' } : null,
              ]}
            />
          ))}
        </View>
        <Text style={styles.count}>{complete ? t('All {n} parts done', { n: total }) : t('{done} of {total} parts done', { done: doneCount, total })}</Text>

        {/* Actions */}
        {allowed === false ? (
          <View style={styles.locked}>
            <View style={styles.ghostRow} pointerEvents="none">
              {unit.blocks.map((b) => (
                <View key={b.id} style={styles.ghostDot} />
              ))}
            </View>
            <LinearGradient colors={c.navyGrad} start={{ x: 0.2, y: 0 }} end={{ x: 0.8, y: 1 }} style={styles.lockedFront}>
              <LinearGradient colors={['#f6d98c', c.goldFill]} style={styles.lockedCrown}>
                <Icon name="crown" size={32} color={c.onGold} />
              </LinearGradient>
              <Text style={styles.lockedTitle}>{t('Premium lesson')}</Text>
              <Text style={styles.lockedSub}>
                {t('Unlock {title} and every other lesson. Lessons 1.1, 1.2 and 1.3 are free.', { title: ct(unit.title) })}
              </Text>
              <Pressable onPress={seePlans} style={({ pressed }) => [styles.lockedCta, pressed && { opacity: 0.88 }]}>
                <Text style={styles.ctaText}>{t('See plans')}</Text>
              </Pressable>
              {!session ? (
                <Pressable onPress={() => router.push('/sign-in')} hitSlop={8}>
                  <Text style={styles.member}>
                    {t('Already a member?')} <Text style={{ color: c.goldFill, fontFamily: Fonts.bodyBold }}>{t('Sign in')}</Text>
                  </Text>
                </Pressable>
              ) : null}
            </LinearGradient>
          </View>
        ) : (
          <>
        {complete && firstId != null ? (
          <ContinuePill
            onPress={() => openBlock(firstId)}
            label={t('Start from the beginning')}
            icon="replay"
            style={{ marginTop: 18 }}
          />
        ) : null}

        {/* Parts, in order: done (green), up next (gold), later (faded) */}
        <Text style={styles.section}>{t('{n} PARTS', { n: total })}</Text>
        {unit.blocks.map((b, i) => {
          const isDone = !!done[`${unitId}:${b.id}`];
          const isNext = !complete && b.id === nextId;
          const open = isDone || isNext || isBlockUnlocked(unit, b.id, done);
          const label = t('Part {n}: {title}', { n: i + 1, title: ct(b.title) });
          if (isNext) {
            return (
              <PopPressable
                key={b.id}
                onPress={() => allowed !== null && openBlock(b.id)}
                style={[styles.part, styles.partCur]}
                accessibilityLabel={label}
                scaleTo={1.02}>
                <CardFill radius={18} />
                <View style={styles.partRow}>
                  <View style={[styles.num, styles.numCur]}>
                    <Text style={[styles.numText, { color: c.onGold }]}>{i + 1}</Text>
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.partTitle, styles.partTitleCur]} numberOfLines={2}>
                      {ct(b.title)}
                    </Text>
                    <Text style={styles.partSub} numberOfLines={1}>
                      {t('Up next')} · {partMeta(b)}
                    </Text>
                  </View>
                </View>
                <ContinuePill
                  onPress={() => allowed !== null && openBlock(b.id)}
                  label={doneCount ? t('Continue') : t('Start lesson')}
                  icon="skip_next"
                />
              </PopPressable>
            );
          }
          if (!open) {
            return (
              <View key={b.id} style={[styles.part, LATER_STYLE]} accessibilityLabel={label}>
                <CardFill radius={18} />
                <View style={styles.partRow}>
                  <View style={styles.num}>
                    <Text style={styles.numText}>{i + 1}</Text>
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.partTitle} numberOfLines={1}>
                      {ct(b.title)}
                    </Text>
                    <Text style={styles.partSub} numberOfLines={1}>
                      {partMeta(b)}
                    </Text>
                  </View>
                  <Icon name="lock" size={16} color={c.muted} />
                </View>
              </View>
            );
          }
          return (
            <PopPressable
              key={b.id}
              onPress={() => allowed !== null && openBlock(b.id)}
              style={[styles.part, isDone && styles.partDone]}
              accessibilityLabel={label}
              scaleTo={1.02}>
              <CardFill radius={18} />
              <View style={styles.partRow}>
                <View style={[styles.num, isDone && styles.numDone]}>
                  {isDone ? <Icon name="check" size={17} color="#ffffff" /> : <Text style={styles.numText}>{i + 1}</Text>}
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.partTitle} numberOfLines={1}>
                    {ct(b.title)}
                  </Text>
                  <Text style={styles.partSub} numberOfLines={1}>
                    {partMeta(b)}
                  </Text>
                </View>
                <Icon name={isDone ? 'replay' : 'chevron_right'} size={isDone ? 18 : 20} color={c.gold} />
              </View>
            </PopPressable>
          );
        })}

        {doneCount > 0 && !complete && firstId != null ? (
          <Pressable
            onPress={() => openBlock(firstId)}
            disabled={allowed === null}
            style={({ pressed }) => [styles.outline, { marginTop: 8 }, pressed && { opacity: 0.85 }]}>
            <Icon name="replay" size={17} color={c.gold} />
            <Text style={styles.outlineText} numberOfLines={1}>
              {t('Start from the beginning')}
            </Text>
          </Pressable>
        ) : null}

          </>
        )}

        {objectives.length ? (
          <>
            <Pressable onPress={() => setGoalsOpen(!goalsOpen)} style={styles.goalsHead} hitSlop={6}>
              <Text style={styles.section}>{t('BY THE END OF THIS LESSON')}</Text>
              <Icon name={goalsOpen ? 'expand_less' : 'expand_more'} size={20} color={c.gold} />
            </Pressable>
            {goalsOpen
              ? objectives.map((obj, k) => (
                  <View key={k} style={styles.goalRow}>
                    <Icon name="check_circle" size={17} color={c.gold} />
                    <Text style={styles.goalText}>{obj}</Text>
                  </View>
                ))
              : null}
          </>
        ) : null}
      </ScrollView>
    </View>
  );
}

const useStyles = makeStyles((c) => {
  const light = c.scheme === 'light';
  return {
    screen: { flex: 1, backgroundColor: c.bg },
    content: { paddingHorizontal: Spacing.md + 4 , ...contentCap },

    top: { flexDirection: 'row', alignItems: 'center', gap: 12 },
    backBtn: {
      width: 42,
      height: 42,
      borderRadius: 21,
      backgroundColor: light ? c.card : 'rgba(255,255,255,0.08)',
      borderWidth: 1,
      borderColor: light ? c.line : 'rgba(255,255,255,0.06)',
      alignItems: 'center',
      justifyContent: 'center',
    },
    eyebrow: { fontFamily: Fonts.bodySemi, fontSize: 12.5, color: c.muted },
    title: { fontFamily: Fonts.displayBold, fontSize: 28, lineHeight: 34, color: c.text, marginTop: 10 },
    titleAr: { fontFamily: Fonts.arabic, fontSize: 21, lineHeight: 34, color: c.gold, marginTop: 2, writingDirection: 'rtl', textAlign: 'left' },

    segs: { flexDirection: 'row', gap: 4, marginTop: 14 },
    seg: { flex: 1, height: 6, borderRadius: 3, backgroundColor: c.track },
    count: { fontFamily: Fonts.body, fontSize: 13, color: c.muted, marginTop: 8 },

    chip: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 5,
      paddingVertical: 7,
      paddingHorizontal: 12,
      borderRadius: 14,
      backgroundColor: c.goldTint,
    },
    chipText: { fontFamily: Fonts.bodyBold, fontSize: 12.5, color: c.gold },
    locked: { marginTop: 22 },
    ghostRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 6, opacity: 0.6 },
    ghostDot: { width: 24, height: 24, borderRadius: 12, borderWidth: 1.5, borderColor: c.goldFill },
    lockedFront: {
      alignItems: 'center',
      paddingVertical: 26,
      paddingHorizontal: 18,
      marginTop: 22,
      borderRadius: 26,
      borderWidth: 1,
      borderColor: 'rgba(230,184,90,0.35)',
      shadowColor: c.shadow,
      shadowOpacity: light ? 0.18 : 0.45,
      shadowRadius: 18,
      shadowOffset: { width: 0, height: 10 },
      elevation: 8,
    },
    lockedCrown: {
      width: 70,
      height: 70,
      borderRadius: 35,
      alignItems: 'center',
      justifyContent: 'center',
      shadowColor: c.goldFill,
      shadowOpacity: 0.6,
      shadowRadius: 20,
      shadowOffset: { width: 0, height: 0 },
      elevation: 10,
    },
    lockedTitle: { fontFamily: Fonts.displayBold, fontSize: 22, color: c.onNavy, marginTop: 14 },
    // Dark keeps its original lighter grey.
    lockedSub: { fontFamily: Fonts.body, fontSize: 14, lineHeight: 20, color: '#d9dfe9', textAlign: 'center', marginTop: 6, maxWidth: 290 },
    lockedCta: {
      height: 50,
      borderRadius: 25,
      paddingHorizontal: 40,
      backgroundColor: c.btnBg, borderWidth: 1.2, borderColor: c.btnBorder,
      alignItems: 'center',
      justifyContent: 'center',
      marginTop: 18,
    },
    member: { fontFamily: Fonts.body, fontSize: 13, color: c.onNavyMuted, marginTop: 14 },
    lockCard: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
      marginTop: 16,
      padding: 14,
      borderRadius: 18,
      borderWidth: 1,
      borderColor: 'rgba(230,184,90,0.4)',
      backgroundColor: c.goldTint,
    },
    lockText: { flex: 1, fontFamily: Fonts.body, fontSize: 13.5, lineHeight: 20, color: c.text },

    actions: { flexDirection: 'row', gap: 10, marginTop: 18 },
    cta: {
      height: 52,
      borderRadius: 27,
      backgroundColor: c.btnBg, borderWidth: 1.2, borderColor: c.btnBorder,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      paddingHorizontal: 12,
    },
    ctaText: { fontFamily: Fonts.bodyBold, fontSize: 15, color: c.btnText },
    outline: {
      height: 52,
      borderRadius: 26,
      borderWidth: 1.5,
      borderColor: light ? c.gold : 'rgba(230,184,90,0.55)',
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 6,
      paddingHorizontal: 10,
    },
    outlineText: { fontFamily: Fonts.bodyBold, fontSize: 14, color: c.gold },

    section: { fontFamily: Fonts.bodyBold, fontSize: 11.5, letterSpacing: 1.6, color: c.muted, marginTop: 26, marginBottom: 10 },

    // Part rows.
    part: { ...spaceCard(c), borderRadius: 18, padding: 12, marginBottom: 9 },
    partCur: { ...currentCard(c), padding: 16, marginTop: 2, marginBottom: 12 },
    partDone: { opacity: 0.88 },
    partRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
    num: {
      width: 36,
      height: 36,
      borderRadius: 18,
      backgroundColor: light ? c.raised : 'rgba(255,255,255,0.08)',
      alignItems: 'center',
      justifyContent: 'center',
    },
    numDone: { backgroundColor: c.green },
    numCur: { backgroundColor: c.goldFill },
    numText: { fontFamily: Fonts.bodyBold, fontSize: 14, color: c.muted },
    partTitle: { fontFamily: Fonts.bodyBold, fontSize: 15.5, color: c.text },
    partTitleCur: { fontSize: 18, lineHeight: 23 },
    partSub: { fontFamily: Fonts.body, fontSize: 12.5, color: c.muted, marginTop: 2 },

    goalsHead: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
    goalRow: { flexDirection: 'row', gap: 10, alignItems: 'flex-start', marginBottom: 10 },
    goalText: { flex: 1, fontFamily: Fonts.body, fontSize: 14.5, lineHeight: 21, color: c.text },
  };
});
