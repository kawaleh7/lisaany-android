/**
 * One readable column, shared by every screen.
 *
 * Phones are narrower than {@link CONTENT_MAX}, so this is a no-op there: the
 * column is simply the window. On an iPad the window is far wider than a
 * comfortable measure, so the content stops growing at 560pt and centres
 * itself, leaving the space backdrop showing either side.
 *
 * 560pt is a little wider than the widest iPhone (440pt on a 16 Pro Max), so
 * cards, headings and line lengths stay in the proportions they were designed
 * in instead of stretching into wide, empty slabs.
 *
 * Use it one of three ways:
 *
 *   contentCap                     // spread into a screen's content style
 *   <ContentWidth>…</ContentWidth> // wrap a plain View subtree
 *   sheetCap                       // spread into a bottom sheet's style
 */
import type { ReactNode } from 'react';
import { View, type StyleProp, type ViewStyle } from 'react-native';

/** The widest the readable column ever gets, in points. */
export const CONTENT_MAX = 560;

/**
 * Cap + centre, for a screen's content container (a ScrollView's
 * `contentContainerStyle`, or the padded View inside a non-scrolling screen).
 */
export const contentCap: ViewStyle = {
  width: '100%',
  maxWidth: CONTENT_MAX,
  alignSelf: 'center',
};

/**
 * The same cap for a bottom sheet. The sheet keeps its own rounded top and
 * bottom-anchored slide; on a wide window it becomes a centred panel rather
 * than a full-bleed bar. Pair it with {@link sheetHost} on the wrapper.
 */
export const sheetCap: ViewStyle = {
  width: '100%',
  maxWidth: CONTENT_MAX,
};

/** Full-screen, untouchable-in-the-gaps wrapper that bottom-anchors a sheet. */
export const sheetHost: ViewStyle = {
  position: 'absolute',
  top: 0,
  left: 0,
  right: 0,
  bottom: 0,
  justifyContent: 'flex-end',
  alignItems: 'center',
};

/** Wrapper form, for subtrees that are not a styled content container. */
export function ContentWidth({
  children,
  style,
  grow = false,
}: {
  children: ReactNode;
  style?: StyleProp<ViewStyle>;
  /** Fill the height as well (for a screen body that is not scrolling). */
  grow?: boolean;
}) {
  return <View style={[contentCap, grow && { flex: 1 }, style]}>{children}</View>;
}
