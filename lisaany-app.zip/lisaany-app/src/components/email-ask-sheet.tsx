/**
 * Asked once, after a learner signs in: "Email me once a month if I'm away?"
 * A clear Yes is the consent Canada's anti-spam law requires; Not now leaves
 * emails off (they can be turned on later in Settings).
 */
import { LinearGradient } from 'expo-linear-gradient';
import { Modal, Pressable, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { sheetCap, sheetHost } from '@/components/content-width';
import { Icon } from '@/components/icon';
import { Fonts } from '@/constants/lisaany';
import { useLang } from '@/lib/i18n';
import { makeStyles, useTheme } from '@/theme';

export function EmailAskSheet({ visible, onAnswer }: { visible: boolean; onAnswer: (yes: boolean) => void }) {
  const styles = useStyles();
  const { c } = useTheme();
  const { t } = useLang();
  const insets = useSafeAreaInsets();
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={() => onAnswer(false)} statusBarTranslucent>
      <View style={[styles.dim, sheetHost]}>
        <View style={[styles.sheet, sheetCap, { paddingBottom: insets.bottom + 22 }]}>
          <LinearGradient colors={['#223358', '#1a2946']} style={styles.fill} />
          <View style={styles.grab} />
          <View style={styles.mail}>
            <Icon name="mail" size={26} color={c.gold} />
          </View>
          <Text style={styles.title}>{t('Email me once a month if I’m away?')}</Text>
          <Text style={styles.body}>
            {t('If you stop learning, Lisaany sends one friendly email a month to help you come back. Never while you keep learning. Unsubscribe anytime.')}
          </Text>
          <Pressable onPress={() => onAnswer(true)} style={({ pressed }) => [styles.yes, pressed && { opacity: 0.88 }]} accessibilityRole="button">
            <Text style={styles.yesText}>{t('Yes, email me')}</Text>
          </Pressable>
          <Pressable onPress={() => onAnswer(false)} style={({ pressed }) => [styles.no, pressed && { opacity: 0.8 }]} accessibilityRole="button">
            <Text style={styles.noText}>{t('Not now')}</Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

const useStyles = makeStyles((c) => ({
  dim: { flex: 1, backgroundColor: 'rgba(3,8,18,0.62)', justifyContent: 'flex-end' },
  sheet: {
    borderTopLeftRadius: 26,
    borderTopRightRadius: 26,
    borderTopWidth: 1,
    borderColor: 'rgba(214,178,90,0.3)',
    paddingHorizontal: 22,
    paddingTop: 14,
    gap: 12,
    overflow: 'hidden',
  },
  fill: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 },
  grab: { alignSelf: 'center', width: 44, height: 5, borderRadius: 3, backgroundColor: 'rgba(255,255,255,0.25)', marginBottom: 4 },
  mail: { width: 52, height: 52, borderRadius: 16, backgroundColor: '#2a3346', alignItems: 'center', justifyContent: 'center' },
  title: { fontFamily: Fonts.bodyBold, fontSize: 20, lineHeight: 26, color: c.text },
  body: { fontFamily: Fonts.body, fontSize: 14.5, lineHeight: 21, color: c.muted },
  yes: { height: 52, borderRadius: 26, marginTop: 6, alignItems: 'center', justifyContent: 'center', backgroundColor: c.btnBg, borderWidth: 1.3, borderColor: c.goldFill },
  yesText: { fontFamily: Fonts.bodyBold, fontSize: 16, color: c.gold },
  no: { height: 50, borderRadius: 25, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)' },
  noText: { fontFamily: Fonts.bodySemi, fontSize: 15.5, color: c.muted },
}));
