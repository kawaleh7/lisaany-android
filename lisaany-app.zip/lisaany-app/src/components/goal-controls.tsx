/**
 * Small shared controls for the daily goal and reminders: the reminder time
 * chips (onboarding + Settings) and the goal picker sheet (Today).
 */
import { useEffect, useRef } from 'react';
import { Animated, Easing, Modal, Pressable, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { GoldStar } from '@/components/star-guide';
import { Fonts } from '@/constants/lisaany';
import { GOAL_CHOICES } from '@/lib/goal';
import { useLang } from '@/lib/i18n';
import { formatTime, REMINDER_TIMES } from '@/lib/reminders';
import { makeStyles, useTheme } from '@/theme';

import { Icon } from './icon';

/** 7:00 · 12:00 · 18:00 · 20:00, each with a short label under it. */
export function TimeChips({
  hour,
  minute,
  onPick,
  disabled,
}: {
  hour: number;
  minute: number;
  onPick: (hour: number, minute: number) => void;
  disabled?: boolean;
}) {
  const { t, locale } = useLang();
  const s = useStyles();
  return (
    <View style={[s.chips, disabled && { opacity: 0.45 }]}>
      {REMINDER_TIMES.map((r) => {
        const on = r.hour === hour && r.minute === minute;
        return (
          <Pressable
            key={r.hour}
            disabled={disabled}
            onPress={() => onPick(r.hour, r.minute)}
            accessibilityRole="radio"
            accessibilityState={{ selected: on, disabled: !!disabled }}
            style={({ pressed }) => [s.chip, on && s.chipOn, pressed && { opacity: 0.85 }]}>
            <Text style={[s.chipTime, on && s.chipTimeOn]}>{formatTime(r.hour, r.minute, locale)}</Text>
            <Text style={s.chipLabel}>{t(r.label)}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

/** Bottom sheet: pick a daily goal of 5 / 10 / 15 / 30 minutes. */
export function GoalPickerSheet({
  visible,
  goal,
  onPick,
  onClose,
}: {
  visible: boolean;
  goal: number;
  onPick: (minutes: number) => void;
  onClose: () => void;
}) {
  const { c } = useTheme();
  const s = useStyles();
  const { t } = useLang();
  const insets = useSafeAreaInsets();
  const slide = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (!visible) return;
    slide.setValue(1);
    Animated.timing(slide, { toValue: 0, duration: 260, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
  }, [visible, slide]);

  const DESC: Record<number, string> = {
    5: 'A little every day',
    10: 'A steady habit',
    15: 'Real progress',
    30: 'The full daily practice',
  };

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose} statusBarTranslucent>
      <Pressable style={s.backdrop} onPress={onClose} accessibilityLabel={t('Cancel')} />
      <Animated.View
        style={[
          s.sheet,
          { paddingBottom: insets.bottom + 18, transform: [{ translateY: slide.interpolate({ inputRange: [0, 1], outputRange: [0, 480] }) }] },
        ]}>
        <View style={s.grabber} />
        <View style={s.head}>
          <GoldStar size={42} />
          <View style={{ flex: 1 }}>
            <Text style={s.title}>{t('Daily goal')}</Text>
            <Text style={s.sub}>{t('How many minutes of Arabic a day?')}</Text>
          </View>
        </View>
        {GOAL_CHOICES.map((g) => {
          const on = g === goal;
          return (
            <Pressable
              key={g}
              onPress={() => onPick(g)}
              accessibilityRole="radio"
              accessibilityState={{ selected: on }}
              style={({ pressed }) => [s.opt, on && s.optOn, pressed && { opacity: 0.85 }]}>
              <Text style={s.optNum}>{g}</Text>
              <View style={{ flex: 1 }}>
                <Text style={s.optTitle}>{t('{n} min a day', { n: g })}</Text>
                <Text style={s.optSub}>{t(DESC[g])}</Text>
              </View>
              {on ? <Icon name="check_circle" size={22} color={c.gold} /> : null}
            </Pressable>
          );
        })}
      </Animated.View>
    </Modal>
  );
}

const useStyles = makeStyles((c) => {
  const dark = c.scheme === 'dark';
  return {
    chips: { flexDirection: 'row', gap: 8 },
    chip: {
      flex: 1,
      minHeight: 58,
      borderRadius: 16,
      borderWidth: 1,
      borderColor: dark ? 'rgba(255,255,255,0.12)' : c.line,
      backgroundColor: dark ? 'rgba(255,255,255,0.04)' : c.card,
      alignItems: 'center',
      justifyContent: 'center',
      paddingVertical: 8,
    },
    chipOn: { borderColor: c.btnBorder, backgroundColor: c.btnBg, borderWidth: 1.2 },
    chipTime: { fontFamily: Fonts.bodyBold, fontSize: 16, color: c.text },
    chipTimeOn: { color: c.btnText },
    chipLabel: { fontFamily: Fonts.bodySemi, fontSize: 11, color: c.muted, marginTop: 2 },

    backdrop: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(4,8,18,0.55)' },
    sheet: {
      position: 'absolute',
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: dark ? '#18223a' : c.card,
      borderTopLeftRadius: 26,
      borderTopRightRadius: 26,
      borderWidth: 1,
      borderColor: dark ? 'rgba(214,178,90,0.3)' : c.line,
      paddingHorizontal: 18,
      paddingTop: 10,
    },
    grabber: { alignSelf: 'center', width: 40, height: 4, borderRadius: 2, backgroundColor: c.track, marginBottom: 12 },
    head: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 8 },
    title: { fontFamily: Fonts.display, fontSize: 22, color: c.text },
    sub: { fontFamily: Fonts.body, fontSize: 13.5, color: c.muted, marginTop: 2 },
    opt: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 14,
      marginTop: 10,
      paddingVertical: 13,
      paddingHorizontal: 14,
      borderRadius: 16,
      borderWidth: 1,
      borderColor: c.line,
      backgroundColor: dark ? 'rgba(255,255,255,0.03)' : c.bg,
    },
    optOn: { borderColor: c.btnBorder, backgroundColor: c.btnBg },
    optNum: { width: 40, fontFamily: Fonts.bodyBold, fontSize: 24, color: c.gold, textAlign: 'center' },
    optTitle: { fontFamily: Fonts.bodySemi, fontSize: 15.5, color: c.text },
    optSub: { fontFamily: Fonts.body, fontSize: 12.5, color: c.muted, marginTop: 1 },
  };
});
