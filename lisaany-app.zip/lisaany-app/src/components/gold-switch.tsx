/**
 * The app's on/off switch (approved style "C · On / Off label").
 *
 * A pill that says what it is: OFF on a lighter slate track with a grey knob,
 * ON on a gold track with a dark knob. Easy to read on the dark cards (the
 * system switch nearly vanished there).
 */
import { useEffect, useRef } from 'react';
import { Animated, Easing, Pressable, StyleSheet } from 'react-native';

import { Fonts } from '@/constants/lisaany';
import { useLang } from '@/lib/i18n';

const W = 66;
const H = 30;
const KNOB = 22;
const PAD = 3;

export function GoldSwitch({
  value,
  onValueChange,
  disabled,
  accessibilityLabel,
  blue,
}: {
  /** A plain blue switch for white cards (Settings). */
  blue?: boolean;
  value: boolean;
  onValueChange: (next: boolean) => void;
  disabled?: boolean;
  accessibilityLabel?: string;
}) {
  const { t } = useLang();
  const x = useRef(new Animated.Value(value ? 1 : 0)).current;
  useEffect(() => {
    Animated.timing(x, { toValue: value ? 1 : 0, duration: 180, easing: Easing.out(Easing.quad), useNativeDriver: false }).start();
  }, [value, x]);

  const left = x.interpolate({ inputRange: [0, 1], outputRange: [PAD, W - KNOB - PAD - 3] });
  const bg = x.interpolate({ inputRange: [0, 1], outputRange: blue ? ['#D5DAE3', '#477BDC'] : ['#26324a', '#d6b25a'] });
  const edge = x.interpolate({ inputRange: [0, 1], outputRange: blue ? ['#D5DAE3', '#477BDC'] : ['rgba(255,255,255,0.22)', '#d6b25a'] });
  const knob = x.interpolate({ inputRange: [0, 1], outputRange: blue ? ['#ffffff', '#ffffff'] : ['#9aa5ba', '#2a1a00'] });

  return (
    <Pressable
      onPress={() => !disabled && onValueChange(!value)}
      disabled={disabled}
      hitSlop={8}
      accessibilityRole="switch"
      accessibilityState={{ checked: value, disabled: !!disabled }}
      accessibilityLabel={accessibilityLabel}
      style={{ opacity: disabled ? 0.4 : 1 }}>
      <Animated.View style={[styles.track, { backgroundColor: bg, borderColor: edge }]}>
        {blue ? null : <Animated.Text style={[styles.word, value ? styles.on : styles.off]}>{value ? t('ON') : t('OFF')}</Animated.Text>}
        <Animated.View style={[styles.knob, { left, backgroundColor: knob }]} />
      </Animated.View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  track: { width: W, height: H, borderRadius: H / 2, borderWidth: 1.5, justifyContent: 'center' },
  knob: { position: 'absolute', width: KNOB, height: KNOB, borderRadius: KNOB / 2 },
  word: { position: 'absolute', fontFamily: Fonts.bodyBold, fontSize: 10.5, letterSpacing: 0.6 },
  off: { right: 9, color: '#aab3c5' },
  on: { left: 10, color: '#2a1a00' },
});
