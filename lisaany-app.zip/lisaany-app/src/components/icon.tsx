import { StyleSheet, Text, type ColorValue, type StyleProp, type TextStyle } from 'react-native';

import { Colors, Fonts } from '@/constants/lisaany';
import codepoints from '@/data/icon-codepoints.json';

const CODEPOINTS = codepoints as Record<string, string>;

/** Drawn when a name has no glyph, so a typo never shows as raw text. */
const FALLBACK = CODEPOINTS.circle ?? CODEPOINTS.article;

/**
 * Renders a Material Symbols Outlined icon by name.
 *
 * Deliberately NOT called `Symbol`: that shadows the global `Symbol` in every
 * importing module, and the React Compiler emits `Symbol.for(...)` into the
 * components it compiles — which then throws "undefined is not a function".
 *
 * The curriculum carries icon names on every module, unit and block
 * (`waving_hand`, `mosque`, `forum`…) — the same names the web platform uses.
 * The web resolves those through font ligatures, but React Native on Android
 * doesn't reliably apply ligature substitution, so names are resolved to
 * codepoints instead. `src/data/icon-codepoints.json` is generated from the
 * font's own cmap, so it matches the exact file we ship.
 */
export function Icon({
  name,
  size = 22,
  color = Colors.text,
  style,
}: {
  name: string;
  size?: number;
  color?: ColorValue;
  style?: StyleProp<TextStyle>;
}) {
  const hex = CODEPOINTS[name] ?? FALLBACK;
  if (!hex) return null;

  return (
    <Text
      allowFontScaling={false}
      style={[styles.icon, { fontSize: size, lineHeight: size * 1.05, color }, style]}>
      {String.fromCodePoint(parseInt(hex, 16))}
    </Text>
  );
}

const styles = StyleSheet.create({
  icon: {
    fontFamily: Fonts.icons,
    includeFontPadding: false,
    textAlign: 'center',
  },
});
