import { useImperativeHandle, useRef, type Ref } from 'react';
import { StyleSheet } from 'react-native';
import { WebView, type WebViewMessageEvent } from 'react-native-webview';

import { LESSON_HTML } from '@/data/lesson-page';
import {
  LESSON_ORIGIN,
  openScript,
  parseBridgeMessage,
  preloadScript,
  type BridgeMessage,
  type LessonConfig,
} from '@/lib/lesson-bridge';

export type LessonHostHandle = {
  /** Run a script inside the page (see lesson-bridge for the ready-made ones). */
  inject: (js: string) => void;
};

export type LessonHostProps = {
  cfg: LessonConfig;
  onMessage: (message: BridgeMessage) => void;
  /** The page tried to leave (pricing, sign-in, an outside link). */
  onExternal: (url: string) => void;
  ref?: Ref<LessonHostHandle>;
};

/**
 * The lesson page in a native web view.
 *
 * The page is bundled as a string (src/data/lesson-page.ts) so it opens with
 * no network; audio and progress sync still need one, as on the website.
 */
export function LessonHost({ cfg, onMessage, onExternal, ref }: LessonHostProps) {
  const web = useRef<WebView>(null);

  useImperativeHandle(ref, () => ({
    inject: (js: string) => web.current?.injectJavaScript(js),
  }));

  const handleMessage = (event: WebViewMessageEvent) => {
    const message = parseBridgeMessage(event.nativeEvent.data);
    if (message) onMessage(message);
  };

  return (
    <WebView
      ref={web}
      source={{ html: LESSON_HTML, baseUrl: LESSON_ORIGIN }}
      originWhitelist={['*']}
      injectedJavaScriptBeforeContentLoaded={preloadScript(cfg)}
      // Belt and braces: if the pre-load script raced the page, open now.
      onLoadEnd={() => web.current?.injectJavaScript(openScript(cfg))}
      onMessage={handleMessage}
      onShouldStartLoadWithRequest={(request) => {
        const url = request.url;
        if (url.startsWith(LESSON_ORIGIN) || url.startsWith('about:') || url.startsWith('data:')) {
          return true;
        }
        onExternal(url);
        return false;
      }}
      javaScriptEnabled
      domStorageEnabled
      // Lines auto-play as they appear, exactly as on the website.
      mediaPlaybackRequiresUserAction={false}
      allowsInlineMediaPlayback
      allowsFullscreenVideo
      setSupportMultipleWindows={false}
      // The page sets its own type sizes; the system font scale must not stretch its layout.
      textZoom={100}
      bounces={false}
      overScrollMode="never"
      allowsBackForwardNavigationGestures={false}
      hideKeyboardAccessoryView
      keyboardDisplayRequiresUserAction={false}
      style={styles.web}
      containerStyle={styles.web}
    />
  );
}

const styles = StyleSheet.create({
  web: { flex: 1, backgroundColor: 'transparent' },
});
