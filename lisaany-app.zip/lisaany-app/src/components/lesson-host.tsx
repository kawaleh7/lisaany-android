import { useImperativeHandle, useRef, useState, type Ref } from 'react';
import { StyleSheet } from 'react-native';
import { WebView, type WebViewMessageEvent } from 'react-native-webview';

import { LESSON_HTML } from '@/data/lesson-page';
import {
  LESSON_ORIGIN,
  openScript,
  parseBridgeMessage,
  preloadScript,
  type BridgeMessage,
  type HostFailure,
  type LessonConfig,
} from '@/lib/lesson-bridge';

export type LessonHostHandle = {
  /** Run a script inside the page (see lesson-bridge for the ready-made ones). */
  inject: (js: string) => void;
  /**
   * Start the page again from scratch with the same config. The web view is
   * recreated rather than reloaded: after a renderer crash the old one is dead
   * on Android, and a fresh one is what iOS wants after a content-process kill.
   */
  reload: () => void;
};

export type LessonHostProps = {
  cfg: LessonConfig;
  onMessage: (message: BridgeMessage) => void;
  /** The page tried to leave (pricing, sign-in, an outside link). */
  onExternal: (url: string) => void;
  /**
   * The web view could not show the page: a load error, an HTTP error on the
   * page itself, or the renderer process died (crash or low memory). The page
   * is blank at this point; the screen decides whether to reload or leave.
   */
  onFailure?: (kind: HostFailure, detail?: string) => void;
  ref?: Ref<LessonHostHandle>;
};

/**
 * The lesson page in a native web view.
 *
 * The page is bundled as a string (src/data/lesson-page.ts) so it opens with
 * no network; audio and progress sync still need one, as on the website.
 */
export function LessonHost({ cfg, onMessage, onExternal, onFailure, ref }: LessonHostProps) {
  const web = useRef<WebView>(null);
  // Bumped by reload(): a new key mounts a new native web view.
  const [generation, setGeneration] = useState(0);

  useImperativeHandle(ref, () => ({
    inject: (js: string) => web.current?.injectJavaScript(js),
    reload: () => setGeneration((g) => g + 1),
  }));

  const handleMessage = (event: WebViewMessageEvent) => {
    const message = parseBridgeMessage(event.nativeEvent.data);
    if (message) onMessage(message);
  };

  return (
    <WebView
      key={generation}
      ref={web}
      source={{ html: LESSON_HTML, baseUrl: LESSON_ORIGIN }}
      originWhitelist={['*']}
      injectedJavaScriptBeforeContentLoaded={preloadScript(cfg)}
      // Belt and braces: if the pre-load script raced the page, open now.
      onLoadEnd={() => web.current?.injectJavaScript(openScript(cfg))}
      onMessage={handleMessage}
      onShouldStartLoadWithRequest={(request) => {
        const url = request.url;
        if (url.startsWith(LESSON_ORIGIN) || url.startsWith('about:') || url.startsWith('data:')) {
          return true;
        }
        onExternal(url);
        return false;
      }}
      // Failure paths — without these the screen would sit on a blank page.
      onError={(e) => onFailure?.('load', `${e.nativeEvent.code} ${e.nativeEvent.description}`)}
      onHttpError={(e) => onFailure?.('http', String(e.nativeEvent.statusCode))}
      // Android: the renderer was killed (usually memory) or crashed.
      onRenderProcessGone={(e) => onFailure?.('crashed', e.nativeEvent.didCrash ? 'crash' : 'killed')}
      // iOS: the content process was terminated.
      onContentProcessDidTerminate={() => onFailure?.('crashed', 'terminated')}
      javaScriptEnabled
      domStorageEnabled
      // Lines auto-play as they appear, exactly as on the website.
      mediaPlaybackRequiresUserAction={false}
      allowsInlineMediaPlayback
      allowsFullscreenVideo
      setSupportMultipleWindows={false}
      // The page sets its own type sizes; the system font scale must not stretch its layout.
      textZoom={100}
      bounces={false}
      overScrollMode="never"
      allowsBackForwardNavigationGestures={false}
      hideKeyboardAccessoryView
      keyboardDisplayRequiresUserAction={false}
      style={styles.web}
      containerStyle={styles.web}
    />
  );
}

const styles = StyleSheet.create({
  web: { flex: 1, backgroundColor: 'transparent' },
});
