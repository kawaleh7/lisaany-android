import { useEffect, useImperativeHandle, useRef, useState } from 'react';

import { LESSON_HTML } from '@/data/lesson-page';
import { openScript, parseBridgeMessage } from '@/lib/lesson-bridge';

import type { LessonHostProps } from './lesson-host';

export type { LessonHostHandle, LessonHostProps } from './lesson-host';

/**
 * Web build of the lesson host: the page in a same-origin iframe.
 *
 * Used when the app runs in a browser (`expo start --web`), which is how the
 * page is checked on a PC. The bridge falls back to window.postMessage when
 * there is no ReactNativeWebView, so the same page works unchanged.
 */
export function LessonHost({ cfg, onMessage, onExternal, onFailure, ref }: LessonHostProps) {
  const frame = useRef<HTMLIFrameElement>(null);
  // Bumped by reload(): a new key mounts a new frame, as the native host does.
  const [generation, setGeneration] = useState(0);

  const run = (js: string) => {
    const win = frame.current?.contentWindow as (Window & { Function: FunctionConstructor }) | null;
    if (!win) return;
    try {
      new win.Function(js)();
    } catch {
      /* page not ready */
    }
  };

  useImperativeHandle(ref, () => ({ inject: run, reload: () => setGeneration((g) => g + 1) }));

  // The engine reads the UI language from storage as it loads, and a srcdoc
  // frame shares this origin's storage.
  try {
    window.localStorage.setItem('lisaany_lang', cfg.lang);
  } catch {
    /* private mode */
  }

  useEffect(() => {
    const onWindowMessage = (event: MessageEvent) => {
      if (event.source !== frame.current?.contentWindow) return;
      const message = parseBridgeMessage(event.data);
      if (message) onMessage(message);
    };
    window.addEventListener('message', onWindowMessage);
    return () => window.removeEventListener('message', onWindowMessage);
  }, [onMessage]);

  useEffect(() => {
    const el = frame.current;
    if (!el?.contentWindow) return;
    // Outside links open in a new tab instead of replacing the lesson.
    const doc = el.contentDocument;
    const onClick = (e: Event) => {
      const a = (e.target as HTMLElement | null)?.closest?.('a[href]') as HTMLAnchorElement | null;
      if (a && !a.href.startsWith('about:') && !a.href.startsWith('javascript:')) {
        e.preventDefault();
        onExternal(a.href);
      }
    };
    doc?.addEventListener('click', onClick, true);
    return () => doc?.removeEventListener('click', onClick, true);
  }, [onExternal, generation]);

  return (
    <iframe
      key={generation}
      ref={frame}
      title="Lesson"
      srcDoc={LESSON_HTML}
      onLoad={() => run(openScript(cfg))}
      onError={() => onFailure?.('load')}
      allow="autoplay; fullscreen"
      style={{ flex: 1, width: '100%', height: '100%', border: 0, background: 'transparent' }}
    />
  );
}
