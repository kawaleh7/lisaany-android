import { useImperativeHandle, useMemo, useState, type Ref } from 'react';
import { StyleSheet } from 'react-native';
import { WebView, type WebViewMessageEvent } from 'react-native-webview';

import { LESSON_ORIGIN, type HostFailure } from '@/lib/lesson-bridge';
import { noraniaHtml, parseNorania, type NoraniaHostProps } from '@/lib/norania-page';

export type { NoraniaHostProps, NoraniaMessage } from '@/lib/norania-page';

export type NoraniaHostHandle = {
  /** Start the page again from scratch (a new web view; the old one is dead after a crash). */
  reload: () => void;
};

export type NoraniaHostViewProps = NoraniaHostProps & {
  /** The web view could not show the page (load error, HTTP error, renderer gone). */
  onFailure?: (kind: HostFailure, detail?: string) => void;
  ref?: Ref<NoraniaHostHandle>;
};

/** The Norania lesson page in a native web view, opened on one lesson. */
export function NoraniaHost({ lesson, done, onMessage, onFailure, ref }: NoraniaHostViewProps) {
  // Build the page once per lesson so progress updates don't reload it.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const html = useMemo(() => noraniaHtml(lesson, done), [lesson]);
  // Bumped by reload(): a new key mounts a new native web view.
  const [generation, setGeneration] = useState(0);

  useImperativeHandle(ref, () => ({ reload: () => setGeneration((g) => g + 1) }));

  return (
    <WebView
      key={generation}
      source={{ html, baseUrl: LESSON_ORIGIN }}
      originWhitelist={['*']}
      onMessage={(e: WebViewMessageEvent) => {
        const m = parseNorania(e.nativeEvent.data);
        if (m) onMessage(m);
      }}
      onShouldStartLoadWithRequest={(r) => r.url.startsWith(LESSON_ORIGIN) || r.url.startsWith('about:') || r.url.startsWith('data:')}
      onError={(e) => onFailure?.('load', `${e.nativeEvent.code} ${e.nativeEvent.description}`)}
      onHttpError={(e) => onFailure?.('http', String(e.nativeEvent.statusCode))}
      onRenderProcessGone={(e) => onFailure?.('crashed', e.nativeEvent.didCrash ? 'crash' : 'killed')}
      onContentProcessDidTerminate={() => onFailure?.('crashed', 'terminated')}
      javaScriptEnabled
      domStorageEnabled
      mediaPlaybackRequiresUserAction={false}
      allowsInlineMediaPlayback
      setSupportMultipleWindows={false}
      textZoom={100}
      bounces={false}
      overScrollMode="never"
      style={styles.web}
      containerStyle={styles.web}
    />
  );
}

const styles = StyleSheet.create({ web: { flex: 1, backgroundColor: '#f5f6fb' } });
