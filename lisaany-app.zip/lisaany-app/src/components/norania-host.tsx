import { useMemo } from 'react';
import { StyleSheet } from 'react-native';
import { WebView, type WebViewMessageEvent } from 'react-native-webview';

import { LESSON_ORIGIN } from '@/lib/lesson-bridge';
import { noraniaHtml, parseNorania, type NoraniaHostProps } from '@/lib/norania-page';

export type { NoraniaHostProps, NoraniaMessage } from '@/lib/norania-page';

/** The Norania lesson page in a native web view, opened on one lesson. */
export function NoraniaHost({ lesson, done, onMessage }: NoraniaHostProps) {
  // Build the page once per lesson so progress updates don't reload it.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const html = useMemo(() => noraniaHtml(lesson, done), [lesson]);
  return (
    <WebView
      source={{ html, baseUrl: LESSON_ORIGIN }}
      originWhitelist={['*']}
      onMessage={(e: WebViewMessageEvent) => {
        const m = parseNorania(e.nativeEvent.data);
        if (m) onMessage(m);
      }}
      onShouldStartLoadWithRequest={(r) => r.url.startsWith(LESSON_ORIGIN) || r.url.startsWith('about:') || r.url.startsWith('data:')}
      javaScriptEnabled
      domStorageEnabled
      mediaPlaybackRequiresUserAction={false}
      allowsInlineMediaPlayback
      setSupportMultipleWindows={false}
      textZoom={100}
      bounces={false}
      overScrollMode="never"
      style={styles.web}
      containerStyle={styles.web}
    />
  );
}

const styles = StyleSheet.create({ web: { flex: 1, backgroundColor: '#f5f6fb' } });
