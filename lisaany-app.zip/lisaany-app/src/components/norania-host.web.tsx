import { useEffect, useImperativeHandle, useMemo, useRef, useState } from 'react';

import { noraniaHtml, parseNorania } from '@/lib/norania-page';

import type { NoraniaHostViewProps } from './norania-host';

export type { NoraniaHostHandle, NoraniaHostViewProps } from './norania-host';
export type { NoraniaHostProps, NoraniaMessage } from '@/lib/norania-page';

/** Web build: the Norania page in an iframe (for checking on a PC). */
export function NoraniaHost({ lesson, done, onMessage, onFailure, ref }: NoraniaHostViewProps) {
  const frame = useRef<HTMLIFrameElement>(null);
  // Build the page once per lesson so progress updates don't reload it.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const html = useMemo(() => noraniaHtml(lesson, done), [lesson]);
  // Bumped by reload(): a new key mounts a new frame, as the native host does.
  const [generation, setGeneration] = useState(0);
  useImperativeHandle(ref, () => ({ reload: () => setGeneration((g) => g + 1) }));
  useEffect(() => {
    const on = (e: MessageEvent) => {
      if (e.source !== frame.current?.contentWindow) return;
      const m = parseNorania(e.data);
      if (m) onMessage(m);
    };
    window.addEventListener('message', on);
    return () => window.removeEventListener('message', on);
  }, [onMessage]);
  return (
    <iframe
      key={generation}
      ref={frame}
      srcDoc={html}
      title="Norania"
      onError={() => onFailure?.('load')}
      style={{ border: 0, width: '100%', height: '100%', flex: 1 }}
    />
  );
}
