import { useEffect, useMemo, useRef } from 'react';

import { noraniaHtml, parseNorania, type NoraniaHostProps } from '@/lib/norania-page';

export type { NoraniaHostProps, NoraniaMessage } from '@/lib/norania-page';

/** Web build: the Norania page in an iframe (for checking on a PC). */
export function NoraniaHost({ lesson, done, onMessage }: NoraniaHostProps) {
  const frame = useRef<HTMLIFrameElement>(null);
  // Build the page once per lesson so progress updates don't reload it.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const html = useMemo(() => noraniaHtml(lesson, done), [lesson]);
  useEffect(() => {
    const on = (e: MessageEvent) => {
      if (e.source !== frame.current?.contentWindow) return;
      const m = parseNorania(e.data);
      if (m) onMessage(m);
    };
    window.addEventListener('message', on);
    return () => window.removeEventListener('message', on);
  }, [onMessage]);
  return <iframe ref={frame} srcDoc={html} title="Norania" style={{ border: 0, width: '100%', height: '100%', flex: 1 }} />;
}
