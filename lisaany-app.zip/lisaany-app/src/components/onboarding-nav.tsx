import { useRouter } from 'expo-router';
import type { ReactNode } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { Colors, Fonts } from '@/constants/lisaany';
import { useLang } from '@/lib/i18n';

import { Icon } from './icon';

/**
 * Shared pieces for the three onboarding screens (option 5: minimal radio
 * list on the app's navy, gold accents). Same palette as the rest of the app.
 */
export const Onboard = {
  bg: Colors.bg,
  card: '#1e2a42',
  ink: '#ffffff',
  inkDim: '#8792a6',
  gold: Colors.gold,
  onGold: Colors.onGold,
  line: 'rgba(255,255,255,0.08)',
} as const;

/** Back button + three-step progress + counter, then the step eyebrow. */
export function OnboardingHeader({ step, total, eyebrow }: { step: number; total: number; eyebrow?: string }) {
  const router = useRouter();
  const { t } = useLang();
  return (
    <View style={styles.headerWrap}>
      <View style={styles.headerRow}>
        <Pressable
          onPress={() => (router.canGoBack() ? router.back() : router.replace('/landing'))}
          hitSlop={10}
          accessibilityLabel={t('Back')}
          style={styles.backBtn}>
          <Icon name="arrow_back" size={18} color={Onboard.ink} />
        </Pressable>
        <View style={styles.segs}>
          {Array.from({ length: total }, (_, i) => (
            <View key={i} style={[styles.seg, i < step && styles.segOn]} />
          ))}
        </View>
        <Text style={styles.counter}>
          {step}/{total}
        </Text>
      </View>
      {eyebrow ? <Text style={styles.eyebrow}>{eyebrow}</Text> : null}
    </View>
  );
}

/** One radio row: gold radio, Cinzel title, Arabic word on the right, a line of explanation. */
export function RadioRow({
  title,
  sub,
  arabic,
  selected,
  onPress,
  last,
}: {
  title: string;
  sub: string;
  arabic?: string;
  selected: boolean;
  onPress: () => void;
  last?: boolean;
}) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="radio"
      accessibilityState={{ selected }}
      style={({ pressed }) => [styles.row, selected && styles.rowOn, !last && !selected && styles.rowLine, pressed && { opacity: 0.85 }]}>
      <View style={[styles.radio, selected && styles.radioOn]}>{selected ? <View style={styles.radioDot} /> : null}</View>
      <View style={{ flex: 1 }}>
        <View style={styles.rowTop}>
          <Text style={[styles.rowTitle, selected && { color: Onboard.gold }]}>{title}</Text>
          {arabic ? <Text style={[styles.rowAr, selected && { opacity: 1 }]}>{arabic}</Text> : null}
        </View>
        <Text style={styles.rowSub}>{sub}</Text>
      </View>
    </Pressable>
  );
}

/** Full-width gold Continue button (grey until something is picked), with an optional tagline above. */
export function OnboardingFooter({
  onNext,
  nextDisabled,
  label,
  tagline,
  children,
}: {
  onNext: () => void;
  nextDisabled?: boolean;
  label?: string;
  tagline?: string;
  children?: ReactNode;
}) {
  const { t } = useLang();
  return (
    <View>
      {tagline ? <Text style={styles.tagline}>{tagline}</Text> : null}
      <Pressable
        onPress={onNext}
        disabled={nextDisabled}
        style={({ pressed }) => [styles.cta, nextDisabled && styles.ctaOff, pressed && { opacity: 0.9 }]}>
        <Text style={[styles.ctaText, nextDisabled && styles.ctaTextOff]}>{label ?? t('Continue')}</Text>
        <Icon name="arrow_forward" size={19} color={nextDisabled ? 'rgba(243,246,252,0.4)' : Onboard.onGold} />
      </Pressable>
      {children}
    </View>
  );
}

export const onboardText = StyleSheet.create({
  title: { fontFamily: Fonts.displayBold, fontSize: 32, lineHeight: 40, color: '#fff' },
  sub: { fontFamily: Fonts.body, fontSize: 14, lineHeight: 20, color: Onboard.inkDim, marginTop: 8, marginBottom: 18 },
});

const styles = StyleSheet.create({
  headerWrap: { marginBottom: 22 },
  headerRow: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  backBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  segs: { flex: 1, flexDirection: 'row', gap: 5 },
  seg: { flex: 1, height: 5, borderRadius: 3, backgroundColor: 'rgba(255,255,255,0.12)' },
  segOn: { backgroundColor: Onboard.gold },
  counter: { fontFamily: Fonts.bodyBold, fontSize: 12, color: Onboard.inkDim },
  eyebrow: { fontFamily: Fonts.bodyBold, fontSize: 11, letterSpacing: 2.2, color: Onboard.gold, marginTop: 26 },

  row: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 14,
    paddingVertical: 18,
    paddingHorizontal: 14,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'transparent',
    marginBottom: 4,
  },
  rowLine: { borderBottomColor: Onboard.line, borderRadius: 0 },
  rowOn: { backgroundColor: 'rgba(230,184,90,0.08)', borderColor: 'rgba(230,184,90,0.4)' },
  radio: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.3)',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 3,
  },
  radioOn: { borderColor: Onboard.gold },
  radioDot: { width: 12, height: 12, borderRadius: 6, backgroundColor: Onboard.gold },
  rowTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 },
  rowTitle: { flex: 1, fontFamily: Fonts.displayBold, fontSize: 19, lineHeight: 25, color: '#fff' },
  rowAr: { fontFamily: Fonts.arabic, fontSize: 22, lineHeight: 32, color: Onboard.gold, opacity: 0.6 },
  rowSub: { fontFamily: Fonts.body, fontSize: 13, lineHeight: 19, color: Onboard.inkDim, marginTop: 3 },

  tagline: {
    fontFamily: Fonts.bodyBold,
    fontSize: 10.5,
    letterSpacing: 2.4,
    color: Onboard.inkDim,
    textAlign: 'center',
    marginBottom: 14,
    opacity: 0.8,
  },
  cta: {
    height: 56,
    borderRadius: 28,
    backgroundColor: Onboard.gold,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  ctaOff: { backgroundColor: 'rgba(255,255,255,0.08)' },
  ctaText: { fontFamily: Fonts.bodyBold, fontSize: 16, color: Onboard.onGold },
  ctaTextOff: { color: 'rgba(243,246,252,0.4)' },
});
