import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import type { ReactNode } from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { SpaceBackdrop } from '@/components/space-backdrop';
import { Fonts, Spacing } from '@/constants/lisaany';
import { useLang } from '@/lib/i18n';
import { cardGlow, makeStyles, useTheme, type Palette } from '@/theme';

import { Icon } from './icon';

/**
 * Shared pieces for the three onboarding screens: night-sky page (dark
 * theme), thin step dashes, short titles, option cards with a gold border
 * when selected, and a gold pill button. Colours come from the app theme.
 */

/** Full-screen page: backdrop first, safe-area padding, theme background. */
export function OnboardingScreen({ children }: { children: ReactNode }) {
  const insets = useSafeAreaInsets();
  const s = useStyles();
  return (
    <View style={s.screen}>
      <SpaceBackdrop />
      <View style={[s.inner, { paddingTop: insets.top + 12, paddingBottom: insets.bottom + 20 }]}>{children}</View>
    </View>
  );
}

/**
 * Scrolling middle of a step. Bleeds to the screen edges (content keeps the
 * page gutter) so the cards' glow isn't clipped into a hard-edged band.
 */
export function OnboardingBody({ children }: { children: ReactNode }) {
  const s = useStyles();
  return (
    <ScrollView style={s.body} contentContainerStyle={s.bodyContent} showsVerticalScrollIndicator={false}>
      {children}
    </ScrollView>
  );
}

/** Back button + step dashes, then the gold step label and the title. */
export function OnboardingHeader({
  step,
  total,
  eyebrow,
  title,
  onBack,
  right,
}: {
  step: number;
  total: number;
  eyebrow?: string;
  title: string;
  /** Overrides the back button (e.g. to step back inside a multi-part step). */
  onBack?: () => void;
  /** Something for the top-right corner (40 wide), e.g. the star's slot. */
  right?: ReactNode;
}) {
  const router = useRouter();
  const { t } = useLang();
  const { c } = useTheme();
  const s = useStyles();
  return (
    <View style={s.headerWrap}>
      <View style={s.headerRow}>
        <Pressable
          onPress={onBack ?? (() => (router.canGoBack() ? router.back() : router.replace('/landing')))}
          hitSlop={10}
          accessibilityRole="button"
          accessibilityLabel={t('Back')}
          style={({ pressed }) => [s.backBtn, pressed && { opacity: 0.7 }]}>
          <Icon name="arrow_back" size={20} color={c.text} />
        </Pressable>
        <View style={s.segs} accessibilityLabel={`${step}/${total}`}>
          {Array.from({ length: total }, (_, i) => (
            <View key={i} style={[s.seg, i < step && s.segOn]} />
          ))}
        </View>
        <View style={s.backSlot}>{right}</View>
      </View>
      {eyebrow ? <Text style={s.eyebrow}>{eyebrow}</Text> : null}
      <Text style={s.title}>{title}</Text>
    </View>
  );
}

/** Card surface used by options and the path card: gradient in dark, white in light. */
export function OnboardCard({
  children,
  selected,
  style,
}: {
  children: ReactNode;
  selected?: boolean;
  style?: object;
}) {
  const { c } = useTheme();
  const s = useStyles();
  return (
    <View style={[s.cardOuter, selected ? s.cardOn : s.cardOff, style]}>
      <LinearGradient colors={c.cardGrad} start={{ x: 0.2, y: 0 }} end={{ x: 0.8, y: 1 }} style={s.cardFill}>
        {children}
      </LinearGradient>
    </View>
  );
}

/** One option: a leading icon tile (or a radio), title, optional short line, Arabic word on the right. */
export function OptionCard({
  title,
  sub,
  arabic,
  icon,
  lead,
  badge,
  selected,
  onPress,
}: {
  title: string;
  sub?: string;
  arabic?: string;
  /** Material Symbols name; without it a radio is drawn instead. */
  icon?: string;
  /** A big gold number/word in place of the icon (e.g. "10"). */
  lead?: string;
  /** Small gold tag after the title (e.g. "Most popular"). */
  badge?: string;
  selected: boolean;
  onPress: () => void;
}) {
  const { c } = useTheme();
  const s = useStyles();
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="radio"
      accessibilityState={{ selected }}
      style={({ pressed }) => [s.optWrap, pressed && { opacity: 0.88 }]}>
      <OnboardCard selected={selected}>
        <View style={s.optRow}>
          {lead ? (
            <Text style={s.lead}>{lead}</Text>
          ) : icon ? (
            <View style={[s.iconTile, selected && s.iconTileOn]}>
              <Icon name={icon} size={24} color={c.gold} />
            </View>
          ) : (
            <View style={[s.radio, selected && s.radioOn]}>{selected ? <View style={s.radioDot} /> : null}</View>
          )}
          <View style={{ flex: 1 }}>
            <View style={s.titleRow}>
              <Text style={s.optTitle}>{title}</Text>
              {badge ? (
                <View style={s.badge}>
                  <Text style={s.badgeText}>{badge}</Text>
                </View>
              ) : null}
            </View>
            {sub ? <Text style={s.optSub}>{sub}</Text> : null}
          </View>
          {arabic ? <Text style={[s.optAr, selected && { opacity: 1 }]}>{arabic}</Text> : null}
        </View>
      </OnboardCard>
    </Pressable>
  );
}

/** Full-width gold pill button (dimmed until something is picked). */
export function OnboardingFooter({
  onNext,
  nextDisabled,
  label,
  children,
}: {
  onNext: () => void;
  nextDisabled?: boolean;
  label?: string;
  children?: ReactNode;
}) {
  const { t } = useLang();
  const { c } = useTheme();
  const s = useStyles();
  return (
    <View>
      {children}
      <Pressable
        onPress={onNext}
        disabled={nextDisabled}
        accessibilityRole="button"
        accessibilityState={{ disabled: !!nextDisabled }}
        style={({ pressed }) => [s.cta, nextDisabled && s.ctaOff, pressed && { opacity: 0.9 }]}>
        <Text style={s.ctaText}>{label ?? t('Continue')}</Text>
        <Icon name="arrow_forward" size={19} color={c.btnText} />
      </Pressable>
    </View>
  );
}

/** Quiet secondary button (outline, muted text) for a second choice under the main one. */
export function OnboardingGhost({ label, onPress }: { label: string; onPress: () => void }) {
  const s = useStyles();
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      style={({ pressed }) => [s.ghost, pressed && { opacity: 0.8 }]}>
      <Text style={s.ghostText}>{label}</Text>
    </Pressable>
  );
}

const useStyles = makeStyles((c: Palette) => {
  const dark = c.scheme === 'dark';
  return {
    screen: { flex: 1, backgroundColor: c.bg },
    inner: { flex: 1, paddingHorizontal: Spacing.lg },

    body: { flex: 1, marginHorizontal: -Spacing.lg },
    bodyContent: { paddingHorizontal: Spacing.lg, paddingTop: 20, paddingBottom: 24 },

    headerWrap: { marginBottom: 0 },
    headerRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
    backBtn: {
      width: 40,
      height: 40,
      borderRadius: 12,
      borderWidth: 1,
      borderColor: dark ? 'rgba(255,255,255,0.14)' : c.line,
      backgroundColor: dark ? 'transparent' : c.card,
      alignItems: 'center',
      justifyContent: 'center',
    },
    backSlot: { width: 40, alignItems: 'center', justifyContent: 'center' },
    segs: { flex: 1, flexDirection: 'row', justifyContent: 'center', gap: 6 },
    seg: { width: 28, height: 3, borderRadius: 2, backgroundColor: c.track },
    segOn: { backgroundColor: c.goldFill },
    eyebrow: { fontFamily: Fonts.bodyBold, fontSize: 11.5, letterSpacing: 2.3, color: c.gold, marginTop: 22 },
    title: { fontFamily: Fonts.display, fontSize: 29, lineHeight: 38, color: c.text, marginTop: 6 },

    cardOuter: { borderRadius: 18, borderWidth: 1 },
    cardOff: { borderColor: c.line, ...cardGlow(c) },
    cardOn: {
      borderColor: c.goldFill,
      shadowColor: c.goldFill,
      shadowOpacity: dark ? 0.35 : 0.3,
      shadowRadius: 16,
      shadowOffset: { width: 0, height: 0 },
      elevation: 8,
    },
    cardFill: { borderRadius: 17, overflow: 'hidden' },

    optWrap: { marginTop: 12 },
    optRow: { flexDirection: 'row', alignItems: 'center', gap: 14, paddingVertical: 16, paddingHorizontal: 16 },
    iconTile: {
      width: 44,
      height: 44,
      borderRadius: 12,
      borderWidth: 1,
      borderColor: dark ? 'rgba(214,178,90,0.35)' : 'rgba(201,146,30,0.35)',
      alignItems: 'center',
      justifyContent: 'center',
    },
    iconTileOn: { backgroundColor: c.goldTint, borderColor: c.goldFill },
    radio: {
      width: 22,
      height: 22,
      borderRadius: 11,
      borderWidth: 1.5,
      borderColor: dark ? 'rgba(255,255,255,0.3)' : c.faint,
      alignItems: 'center',
      justifyContent: 'center',
    },
    radioOn: { borderColor: c.goldFill },
    radioDot: { width: 11, height: 11, borderRadius: 6, backgroundColor: c.goldFill },
    lead: { width: 50, fontFamily: Fonts.bodyBold, fontSize: 28, lineHeight: 34, color: c.gold, textAlign: 'center' },
    titleRow: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 8 },
    badge: {
      paddingHorizontal: 8,
      paddingVertical: 2,
      borderRadius: 9,
      backgroundColor: c.goldTint,
      borderWidth: 1,
      borderColor: dark ? 'rgba(214,178,90,0.45)' : 'rgba(201,146,30,0.4)',
    },
    badgeText: { fontFamily: Fonts.bodyBold, fontSize: 10.5, letterSpacing: 0.4, color: c.gold },
    optTitle: { fontFamily: Fonts.bodySemi, fontSize: 17, lineHeight: 22, color: c.text },
    optSub: { fontFamily: Fonts.body, fontSize: 13.5, lineHeight: 19, color: c.muted, marginTop: 2 },
    optAr: { fontFamily: Fonts.arabic, fontSize: 22, lineHeight: 34, color: c.gold, opacity: 0.75 },

    cta: {
      height: 54,
      borderRadius: 27,
      backgroundColor: c.btnBg, borderWidth: 1.2, borderColor: c.btnBorder,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
    },
    ctaOff: { opacity: 0.35 },
    ghost: {
      height: 48,
      marginTop: 10,
      borderRadius: 24,
      borderWidth: 1,
      borderColor: dark ? 'rgba(255,255,255,0.15)' : c.line,
      alignItems: 'center',
      justifyContent: 'center',
    },
    ghostText: { fontFamily: Fonts.bodySemi, fontSize: 15, color: c.muted },
    ctaText: { fontFamily: Fonts.bodyBold, fontSize: 16.5, letterSpacing: 0.3, color: c.btnText },
  };
});
