/**
 * The star that walks the learner through onboarding.
 *
 * One star, one flight. On the very first step it comes in from off-screen,
 * arcs down and lands beside its bubble with a sparkle burst; from then on it
 * simply *stays* in that spot for every remaining step and speaks the new
 * line. There is no star in the header during onboarding and no flight between
 * steps — the star never tucks away and never appears twice.
 *
 * Because each step is its own route, "the star has already flown" lives in a
 * module value (`flown`); `resetOnboardingTalk()` clears it for a fresh run.
 *
 * The row is a fixed height (TALK_ROW_HEIGHT), tall enough for the longest
 * line in either language, with the star pinned to its top. So the star — and
 * everything under the row — sits at exactly the same place on all four steps,
 * however long the line is; nothing shifts as the bubble grows.
 *
 * Lines reveal word by word: the Arabic greeting slowly (GREET_MS a word),
 * everything else briskly (WORD_MS a word). A word that is not lit yet is
 * drawn in `transparent` rather than left out, so the text is laid out once
 * and never re-wraps mid-reveal.
 *
 *   <OnboardingTalk line={t('Have a look…')} />        // steps 2–4
 *   <OnboardingTalk greet line={t('Welcome…')} />      // step 1, with the salam
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Animated, Dimensions, Easing, StyleSheet, Text, View, type StyleProp, type TextStyle } from 'react-native';

import { GoldStar, SparkleBurst, useFloat, useStarFlight, type StarPoint } from '@/components/star-flight';
import { Fonts } from '@/constants/lisaany';
import { useLang } from '@/lib/i18n';

/** How big the star is while it talks. */
const TALK_SIZE = 62;
/** Tall enough for the longest line (step 1's salam block, in French) at 390×844. */
export const TALK_ROW_HEIGHT = 178;

const WORD_MS = 45;
const GREET_MS = 150;
const FLY_MS = 950;
/** The star waits a beat after the step opens, then flies in. */
const FLY_DELAY = 260;
/** On a later step it is already here; a short beat before it speaks. */
const SPEAK_DELAY = 160;

const SALAM = 'السَّلامُ عَلَيْكُم';

/** True once the star has made its single flight, across onboarding routes. */
let flown = false;

/** Forget the flight, so onboarding flies the star in again from the top. */
export function resetOnboardingTalk() {
  flown = false;
}

/* ── word-by-word reveal ────────────────────────────────────────────── */

/** Lights `count` words one after another once `go` turns true. */
function useReveal(count: number, stepMs: number, startMs: number, go: boolean, key: string) {
  const [lit, setLit] = useState(0);
  useEffect(() => {
    if (!go) {
      setLit(0);
      return;
    }
    setLit(0);
    const ids = Array.from({ length: count }, (_, i) =>
      setTimeout(() => setLit(i + 1), startMs + (i + 1) * stepMs),
    );
    return () => ids.forEach(clearTimeout);
  }, [count, stepMs, startMs, go, key]);
  return lit;
}

/** The whole line is always laid out; unlit words are simply invisible. */
function Words({ text, lit, color, style }: { text: string; lit: number; color: string; style: StyleProp<TextStyle> }) {
  const words = useMemo(() => text.split(' ').filter(Boolean), [text]);
  return (
    <Text style={style}>
      {words.map((w, i) => (
        <Text key={i} style={{ color: i < lit ? color : 'transparent' }}>
          {i ? ' ' : ''}
          {w}
        </Text>
      ))}
    </Text>
  );
}

/* ── the row ────────────────────────────────────────────────────────── */

export function OnboardingTalk({ line, greet }: { line: string; greet?: boolean }) {
  const { t } = useLang();
  const fly = useStarFlight();
  const float = useFloat();
  const starRef = useRef<View>(null);
  const here = useRef<StarPoint | null>(null);
  const started = useRef(false);

  const [landed, setLanded] = useState(flown);
  const [speaking, setSpeaking] = useState(false);
  const [burst, setBurst] = useState(0);
  const bubble = useRef(new Animated.Value(0)).current;

  const salamWords = greet ? SALAM.split(' ').length : 0;
  /** When the line under the greeting starts, counted from the first word. */
  const afterAt = greet ? 60 + salamWords * GREET_MS + 120 : 60;
  const trAt = greet ? 60 + salamWords * GREET_MS + 60 : 0;

  const salamLit = useReveal(salamWords, GREET_MS, 60, speaking && !!greet, line);
  const lineWords = useMemo(() => line.split(' ').filter(Boolean).length, [line]);
  const lineLit = useReveal(lineWords, WORD_MS, afterAt, speaking, line);

  const [trLit, setTrLit] = useState(false);
  useEffect(() => {
    if (!greet || !speaking) {
      setTrLit(false);
      return;
    }
    const id = setTimeout(() => setTrLit(true), trAt);
    return () => clearTimeout(id);
  }, [greet, speaking, trAt]);

  const speak = useCallback(() => {
    setSpeaking(true);
    Animated.timing(bubble, { toValue: 1, duration: 260, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
  }, [bubble]);

  // The line can change inside a step (step 3 has three phases): re-run the
  // reveal from the top without touching the star.
  const first = useRef(true);
  useEffect(() => {
    if (first.current) {
      first.current = false;
      return;
    }
    setSpeaking(false);
    const id = setTimeout(() => setSpeaking(true), 60);
    return () => clearTimeout(id);
  }, [line]);

  /** The star's home, measured once the row is laid out. */
  const measure = useCallback(() => {
    starRef.current?.measureInWindow((x, y, w, h) => {
      if (w <= 0 || h <= 0) return;
      here.current = { x: x + w / 2, y: y + h / 2, size: TALK_SIZE };
      if (started.current) return;
      started.current = true;
      if (flown || !fly) {
        // Already home from an earlier step: no flight, just speak.
        flown = true;
        setLanded(true);
        setTimeout(speak, SPEAK_DELAY);
        return;
      }
      const to = here.current;
      setTimeout(() => {
        fly({
          // In from off the right edge, high up: the arc then curves down
          // across the page and settles beside the bubble.
          from: { x: Dimensions.get('window').width + 80, y: 34, size: 40 },
          to,
          duration: FLY_MS,
          onDone: () => {
            flown = true;
            setLanded(true);
            setBurst((b) => b + 1);
            speak();
          },
        });
      }, FLY_DELAY);
    });
  }, [fly, speak]);

  const s = styles;
  return (
    <View style={s.row} pointerEvents="box-none">
      <View ref={starRef} collapsable={false} onLayout={measure} style={s.star}>
        <View style={{ opacity: landed ? 1 : 0 }}>
          <Animated.View style={float}>
            <GoldStar size={TALK_SIZE} />
          </Animated.View>
        </View>
        <SparkleBurst trigger={burst} count={12} radius={46} />
      </View>

      <Animated.View
        style={[
          s.bubble,
          {
            opacity: bubble,
            transform: [
              { translateX: bubble.interpolate({ inputRange: [0, 1], outputRange: [-10, 0] }) },
              { scale: bubble.interpolate({ inputRange: [0, 1], outputRange: [0.94, 1] }) },
            ],
          },
        ]}>
        <View style={s.tail} />
        {greet ? (
          <>
            <Words text={SALAM} lit={salamLit} color="#16213a" style={s.salam} />
            <Text style={[s.tr, { opacity: trLit ? 1 : 0 }]}>
              {t('Assalamu alaikum')}
              {'\n'}
              <Text style={s.trEn}>{t('Peace be upon you')}</Text>
            </Text>
          </>
        ) : null}
        <Words text={line} lit={lineLit} color="#16213a" style={[s.text, greet ? s.textAfter : null]} />
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { height: TALK_ROW_HEIGHT, flexDirection: 'row', alignItems: 'flex-start', gap: 10 },
  star: { width: TALK_SIZE, height: TALK_SIZE, alignItems: 'center', justifyContent: 'center' },
  bubble: {
    flex: 1,
    alignSelf: 'flex-start',
    backgroundColor: '#ffffff',
    borderRadius: 18,
    paddingHorizontal: 15,
    paddingVertical: 13,
    shadowColor: '#000',
    shadowOpacity: 0.35,
    shadowRadius: 13,
    shadowOffset: { width: 0, height: 8 },
    elevation: 6,
  },
  tail: {
    position: 'absolute',
    left: -6,
    top: 25,
    width: 12,
    height: 12,
    backgroundColor: '#ffffff',
    transform: [{ rotate: '45deg' }],
  },
  salam: {
    fontFamily: Fonts.arabicBold,
    fontSize: 23,
    lineHeight: 34,
    color: '#16213a',
    textAlign: 'right',
    writingDirection: 'rtl',
  },
  tr: { fontFamily: Fonts.bodySemi, fontSize: 12, lineHeight: 17, color: '#5a6680', marginTop: 2 },
  trEn: { color: '#8a6d1f' },
  text: { color: '#16213a', fontFamily: Fonts.bodySemi, fontSize: 15, lineHeight: 20 },
  textAfter: { marginTop: 9 },
});
