import { useRef, useState, type ReactNode } from 'react';
import { Animated, Pressable, type StyleProp, type ViewStyle } from 'react-native';

import { useTheme, type Palette } from '@/theme';

/**
 * Card look "option 5": soft outline + lift at rest; on press the outline
 * turns gold, a gold glow appears and the card springs up a little.
 * In the light theme the resting card is white with a navy top edge.
 */
export function popStyles(c: Palette): { rest: ViewStyle; pressed: ViewStyle } {
  const light = c.scheme === 'light';
  return {
    rest: {
      borderWidth: 1,
      borderColor: light ? c.line : 'rgba(230,184,90,0.28)',
      borderTopWidth: light ? 3 : 1,
      borderTopColor: light ? c.edge : 'rgba(230,184,90,0.28)',
      shadowColor: c.shadow,
      shadowOffset: { width: 0, height: light ? 8 : 10 },
      shadowOpacity: light ? 0.08 : 0.45,
      shadowRadius: 14,
      elevation: light ? 3 : 8,
    },
    pressed: {
      borderColor: c.goldFill,
      borderTopColor: c.goldFill,
      shadowColor: c.goldFill,
      shadowOffset: { width: 0, height: 0 },
      shadowOpacity: 0.35,
      shadowRadius: 16,
      elevation: 12,
    },
  };
}

/** Theme-aware rest/pressed styles for cards that are not pressable. */
export function usePop() {
  const { c } = useTheme();
  return popStyles(c);
}

export function PopPressable({
  onPress,
  style,
  children,
  accessibilityLabel,
  scaleTo = 1.03,
  plain = false,
}: {
  onPress?: () => void;
  style?: StyleProp<ViewStyle>;
  children: ReactNode;
  accessibilityLabel?: string;
  scaleTo?: number;
  /** Keep the spring but skip the app-theme card surface (Norania has its own look). */
  plain?: boolean;
}) {
  const pop = usePop();
  const scale = useRef(new Animated.Value(1)).current;
  const [down, setDown] = useState(false);
  const to = (v: number) => Animated.spring(scale, { toValue: v, useNativeDriver: true, speed: 40, bounciness: 7 }).start();

  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel}
      onPressIn={() => {
        setDown(true);
        to(scaleTo);
      }}
      onPressOut={() => {
        setDown(false);
        to(1);
      }}>
      <Animated.View style={[!plain && pop.rest, style, !plain && down && pop.pressed, { transform: [{ scale }] }]}>{children}</Animated.View>
    </Pressable>
  );
}
