import { StyleSheet, Text, View } from 'react-native';
import Svg, { Circle } from 'react-native-svg';

import { Colors, Fonts } from '@/constants/lisaany';

/** Circular progress with a label in the middle, e.g. "9/11". */
export function ProgressRing({
  value,
  size = 72,
  stroke = 6,
  color = Colors.mint,
  label,
  labelSize = 15,
}: {
  value: number;
  size?: number;
  stroke?: number;
  color?: string;
  label?: string;
  labelSize?: number;
}) {
  const pct = Math.max(0, Math.min(1, value));
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;

  return (
    <View style={{ width: size, height: size }}>
      <Svg width={size} height={size} style={{ transform: [{ rotate: '-90deg' }] }}>
        <Circle cx={size / 2} cy={size / 2} r={r} stroke={Colors.faint} strokeWidth={stroke} fill="none" />
        {pct > 0 ? (
          <Circle
            cx={size / 2}
            cy={size / 2}
            r={r}
            stroke={color}
            strokeWidth={stroke}
            fill="none"
            strokeLinecap="round"
            strokeDasharray={`${c} ${c}`}
            strokeDashoffset={c * (1 - pct)}
          />
        ) : null}
      </Svg>
      {label ? (
        <View style={styles.center}>
          <Text style={[styles.label, { fontSize: labelSize }]}>{label}</Text>
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  center: { ...StyleSheet.absoluteFill, alignItems: 'center', justifyContent: 'center' },
  label: { fontFamily: Fonts.bodyBold, color: Colors.text },
});
