/**
 * The night-sky page background for the dark theme: a soft navy glow near the
 * top fading to deep space, with a field of small twinkling stars.
 *
 * Drop it as the first child of a full-screen view. It fills the parent,
 * ignores touches, and renders nothing in the light theme.
 */
import { memo, useEffect, useMemo, useRef, useState } from 'react';
import { Animated, Easing, StyleSheet, View, type LayoutChangeEvent } from 'react-native';
import Svg, { Circle, Defs, RadialGradient, Rect, Stop } from 'react-native-svg';

import { useTheme } from '@/theme';

type Star = { x: number; y: number; r: number; o: number };

/** Small seeded random so the sky is the same on every screen and render. */
function rng(seed: number) {
  let s = seed;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

function makeStars(w: number, h: number, seed: number): Star[][] {
  const rand = rng(seed);
  // Density, not a fixed count, so a tablet's sky is as full as a phone's —
  // capped so a very large window doesn't animate hundreds of nodes.
  const count = Math.min(Math.round((w * h) / 9000), 220);
  const groups: Star[][] = [[], [], []];
  for (let i = 0; i < count; i++) {
    groups[i % 3].push({
      x: rand() * w,
      y: rand() * h,
      r: 0.6 + rand() * 0.9,
      o: 0.35 + rand() * 0.5,
    });
  }
  return groups;
}

function Twinkle({ delay, children }: { delay: number; children: React.ReactNode }) {
  const v = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.delay(delay),
        Animated.timing(v, { toValue: 0.25, duration: 1500, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
        Animated.timing(v, { toValue: 1, duration: 1500, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [delay, v]);
  return <Animated.View style={[StyleSheet.absoluteFill, { opacity: v }]}>{children}</Animated.View>;
}

export const SpaceBackdrop = memo(function SpaceBackdrop({ seed = 7, glowY = 0.22 }: { seed?: number; glowY?: number }) {
  const { c } = useTheme();
  const [size, setSize] = useState({ w: 0, h: 0 });
  const onLayout = (e: LayoutChangeEvent) => {
    const { width, height } = e.nativeEvent.layout;
    if (Math.abs(width - size.w) > 1 || Math.abs(height - size.h) > 1) setSize({ w: width, h: height });
  };
  const groups = useMemo(() => (size.w ? makeStars(size.w, size.h, seed) : []), [size.w, size.h, seed]);

  if (c.scheme !== 'dark') return null;

  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="none" onLayout={onLayout}>
      {size.w > 0 && (
        <>
          <Svg width={size.w} height={size.h} style={StyleSheet.absoluteFill}>
            <Defs>
              <RadialGradient
                id="spaceGlow"
                cx={size.w / 2}
                cy={size.h * glowY}
                r={Math.max(size.w, size.h) * 0.75}
                gradientUnits="userSpaceOnUse">
                <Stop offset="0" stopColor="#2c3a63" />
                <Stop offset="0.5" stopColor="#16213a" />
                <Stop offset="1" stopColor="#0b1223" />
              </RadialGradient>
            </Defs>
            <Rect x={0} y={0} width={size.w} height={size.h} fill="url(#spaceGlow)" />
          </Svg>
          {groups.map((g, gi) => (
            <Twinkle key={gi} delay={gi * 1000}>
              <Svg width={size.w} height={size.h}>
                {g.map((s, i) => (
                  <Circle key={i} cx={s.x} cy={s.y} r={s.r} fill="#ffffff" opacity={s.o} />
                ))}
              </Svg>
            </Twinkle>
          ))}
        </>
      )}
    </View>
  );
});
