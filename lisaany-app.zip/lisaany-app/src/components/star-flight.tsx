/**
 * The gold star, and the flight it makes between two places on screen.
 *
 * One implementation, used by both the star guide (header slot ⇄ talk row) and
 * the welcome-back sheet (header slot ⇄ sheet title). A flight is a quadratic
 * Bézier arc whose control point sits above and to the side of the two ends:
 * the star spins from -360° to 0°, grows (or shrinks) from one resting size to
 * the other, drops a few sparkles along the way and bursts when it lands.
 *
 * Because React Native has no portals, the flying star is drawn by a host that
 * sits at the top of the screen tree in a transparent, untouchable overlay:
 *
 *   <StarFlightHost>…app…</StarFlightHost>       // once, in the root layout
 *   const fly = useStarFlight();                 // anywhere below it
 *   fly({ from, to, duration: 800, onDone });
 */
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { Animated, Easing, Modal, StyleSheet, View } from 'react-native';
import Svg, { Circle, Defs, Ellipse, Path, RadialGradient, Stop } from 'react-native-svg';

const PUFFY =
  'M50 9 C55 9 58 29 64 32 C70 35 90 32 92 38 C94 44 76 53 74 60 C72 67 83 85 78 89 C73 93 57 79 50 79 C43 79 27 93 22 89 C17 85 28 67 26 60 C24 53 6 44 8 38 C10 32 30 35 36 32 C42 29 45 9 50 9 Z';

let gradSeq = 0;

/** The glossy puffy gold star with its halo and highlight. */
export function GoldStar({ size = 44, halo = true }: { size?: number; halo?: boolean }) {
  const id = useMemo(() => `gs${++gradSeq}`, []);
  return (
    <Svg width={size} height={size} viewBox="-14 -14 128 128">
      <Defs>
        <RadialGradient id={`${id}p`} cx="0.38" cy="0.3" r="0.75">
          <Stop offset="0" stopColor="#FFF6C2" />
          <Stop offset="0.35" stopColor="#FFD84A" />
          <Stop offset="0.75" stopColor="#E6A800" />
          <Stop offset="1" stopColor="#B07A00" />
        </RadialGradient>
        <RadialGradient id={`${id}h`} cx="0.5" cy="0.5" r="0.5">
          <Stop offset="0" stopColor="#FFD84A" stopOpacity="0.55" />
          <Stop offset="0.6" stopColor="#FFD84A" stopOpacity="0.12" />
          <Stop offset="1" stopColor="#FFD84A" stopOpacity="0" />
        </RadialGradient>
        <RadialGradient id={`${id}s`} cx="0.5" cy="0.5" r="0.5">
          <Stop offset="0" stopColor="#ffffff" stopOpacity="0.95" />
          <Stop offset="1" stopColor="#ffffff" stopOpacity="0" />
        </RadialGradient>
      </Defs>
      {halo && <Circle cx="50" cy="50" r="62" fill={`url(#${id}h)`} />}
      <Path d={PUFFY} fill={`url(#${id}p)`} stroke="#C98C00" strokeWidth={1.2} />
      <Ellipse cx="40" cy="36" rx="9" ry="6" fill={`url(#${id}s)`} transform="rotate(-25 40 36)" />
    </Svg>
  );
}

/** A four-point twinkle used for sparkle bursts and flight trails. */
export function Twinkle({ size = 10 }: { size?: number }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 10 10">
      <Path d="M5 0 L6.2 3.8 L10 5 L6.2 6.2 L5 10 L3.8 6.2 L0 5 L3.8 3.8Z" fill="#FFE98A" />
    </Svg>
  );
}

/** A ring of sparkles that flies outward once each time `trigger` changes. */
export function SparkleBurst({ trigger, count = 8, radius = 40 }: { trigger: number; count?: number; radius?: number }) {
  const parts = useRef(
    Array.from({ length: 16 }, () => ({ v: new Animated.Value(0), a: 0, r: 0 })),
  ).current;
  useEffect(() => {
    if (!trigger) return;
    const anims = parts.slice(0, count).map((p, i) => {
      p.a = (i / count) * Math.PI * 2 + Math.random() * 0.5;
      p.r = radius * (0.6 + Math.random() * 0.6);
      p.v.setValue(0);
      return Animated.timing(p.v, {
        toValue: 1,
        duration: 650 + Math.random() * 300,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      });
    });
    Animated.parallel(anims).start();
  }, [trigger, count, radius, parts]);
  if (!trigger) return null;
  return (
    <View pointerEvents="none" style={styles.burst}>
      {parts.slice(0, count).map((p, i) => (
        <Animated.View
          key={i}
          style={[
            styles.spark,
            {
              opacity: p.v.interpolate({ inputRange: [0, 0.1, 1], outputRange: [0, 1, 0] }),
              transform: [
                { translateX: p.v.interpolate({ inputRange: [0, 1], outputRange: [0, Math.cos(p.a) * p.r] }) },
                { translateY: p.v.interpolate({ inputRange: [0, 1], outputRange: [0, Math.sin(p.a) * p.r] }) },
                { scale: p.v.interpolate({ inputRange: [0, 1], outputRange: [1.3, 0.3] }) },
              ],
            },
          ]}>
          <Twinkle />
        </Animated.View>
      ))}
    </View>
  );
}

/** Gentle float: bob up and down with a slow sway. */
export function useFloat() {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(v, { toValue: 1, duration: 1800, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
        Animated.timing(v, { toValue: 0, duration: 1800, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [v]);
  return {
    transform: [
      { translateY: v.interpolate({ inputRange: [0, 1], outputRange: [-3, 3] }) },
      { rotate: v.interpolate({ inputRange: [0, 1], outputRange: ['-8deg', '8deg'] }) },
    ],
  };
}

/* ── the flight ─────────────────────────────────────────────────────── */

/** A resting place for the star: its centre in window coordinates, and its size. */
export type StarPoint = { x: number; y: number; size: number };

const STEPS = 16;

/**
 * Sample the arc from `a` to `b` into the parallel arrays an Animated
 * interpolation wants. The control point sits between the two ends and above
 * them, so the star arcs over the gap instead of sliding along it.
 */
export function flightPath(a: StarPoint, b: StarPoint) {
  const mx = (a.x + b.x) / 2 + (a.x > b.x ? 64 : -64);
  // High enough to read as a flight, never so high that the star is clipped
  // off the top of the screen.
  const my = Math.max(Math.min(a.y, b.y) - 84, 24);
  const ks: number[] = [];
  const xs: number[] = [];
  const ys: number[] = [];
  for (let i = 0; i <= STEPS; i++) {
    const k = i / STEPS;
    ks.push(k);
    xs.push((1 - k) * (1 - k) * a.x + 2 * (1 - k) * k * mx + k * k * b.x);
    ys.push((1 - k) * (1 - k) * a.y + 2 * (1 - k) * k * my + k * k * b.y);
  }
  return { ks, xs, ys };
}

/** Where along the flight sparkles are dropped. */
const TRAIL = [0.22, 0.4, 0.58, 0.74, 0.88];

/**
 * The star in flight, drawn at window coordinates. Put it inside a
 * full-screen, untouchable overlay (the host below, or a Modal of your own).
 *
 * `progress` runs 0 → 1 from `from` to `to`; nothing here needs the JS thread.
 */
export function StarFlyer({
  from,
  to,
  progress,
  visible,
  trail = true,
}: {
  from: StarPoint;
  to: StarPoint;
  progress: Animated.Value;
  /** 1 while the star is in the air; hide it at both ends of the trip. */
  visible?: Animated.Value | number;
  trail?: boolean;
}) {
  const size = Math.max(from.size, to.size, 1);
  const path = useMemo(() => flightPath(from, to), [from.x, from.y, from.size, to.x, to.y, to.size]); // eslint-disable-line react-hooks/exhaustive-deps
  const opacity = visible ?? 1;
  return (
    <>
      {trail
        ? TRAIL.map((k, i) => {
            const j = Math.round(k * STEPS);
            return (
              <Animated.View
                key={i}
                pointerEvents="none"
                style={[
                  styles.trail,
                  {
                    left: path.xs[j] - 6,
                    top: path.ys[j] - 6,
                    opacity: Animated.multiply(
                      progress.interpolate({
                        inputRange: [Math.max(0, k - 0.06), k, Math.min(1, k + 0.3), 1],
                        outputRange: [0, 0.95, 0, 0],
                        extrapolate: 'clamp',
                      }),
                      opacity,
                    ),
                    transform: [
                      {
                        scale: progress.interpolate({
                          inputRange: [Math.max(0, k - 0.06), k, Math.min(1, k + 0.3), 1],
                          outputRange: [0.5, 1.15, 0.4, 0.4],
                          extrapolate: 'clamp',
                        }),
                      },
                    ],
                  },
                ]}>
                <Twinkle size={12} />
              </Animated.View>
            );
          })
        : null}
      <Animated.View
        pointerEvents="none"
        style={[
          styles.flyer,
          {
            width: size,
            height: size,
            opacity,
            transform: [
              { translateX: progress.interpolate({ inputRange: path.ks, outputRange: path.xs.map((x) => x - size / 2) }) },
              { translateY: progress.interpolate({ inputRange: path.ks, outputRange: path.ys.map((y) => y - size / 2) }) },
              { rotate: progress.interpolate({ inputRange: [0, 1], outputRange: ['-360deg', '0deg'] }) },
              { scale: progress.interpolate({ inputRange: [0, 1], outputRange: [from.size / size, to.size / size] }) },
            ],
          },
        ]}>
        <GoldStar size={size} />
      </Animated.View>
    </>
  );
}

/* ── the host ───────────────────────────────────────────────────────── */

export type FlightSpec = {
  from: StarPoint;
  to: StarPoint;
  duration?: number;
  /** Called when the star lands — or when a new flight cuts this one short. */
  onDone?: () => void;
};

type FlyFn = (spec: FlightSpec) => void;

const FlightCtx = createContext<FlyFn | null>(null);

/** Ask for a flight. Null when no host is above (the caller then draws its own). */
export function useStarFlight(): FlyFn | null {
  return useContext(FlightCtx);
}

let flightSeq = 0;

/**
 * Runs one flight at a time and hands back the node that draws it. The caller
 * decides where that node goes — an overlay at the root, or a modal of its own.
 */
export function useFlightRunner(): { fly: FlyFn; node: React.ReactNode } {
  const [spec, setSpec] = useState<(FlightSpec & { id: number }) | null>(null);
  const progress = useRef(new Animated.Value(0)).current;

  const fly = useCallback<FlyFn>(
    (s) => {
      // Rewind before the flyer mounts: a leftover 1 would paint one frame at
      // the far end of the trip.
      progress.setValue(0);
      setSpec({ ...s, id: ++flightSeq });
    },
    [progress],
  );

  useEffect(() => {
    if (!spec) return;
    let settled = false;
    const settle = () => {
      if (settled) return;
      settled = true;
      spec.onDone?.();
    };
    progress.setValue(0);
    const anim = Animated.timing(progress, {
      toValue: 1,
      duration: spec.duration ?? 800,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    });
    anim.start(({ finished }) => {
      if (!finished) return; // an interrupted flight settles in the cleanup below
      settle();
      setSpec((cur) => (cur && cur.id === spec.id ? null : cur));
    });
    return () => {
      anim.stop();
      settle();
    };
  }, [spec, progress]);

  return {
    fly,
    node: spec ? <StarFlyer key={spec.id} from={spec.from} to={spec.to} progress={progress} /> : null,
  };
}

/**
 * Draws flying stars above the whole app. The overlay is transparent and
 * `pointerEvents="none"`, so it never takes a tap.
 */
export function StarFlightHost({ children }: { children: React.ReactNode }) {
  const { fly, node } = useFlightRunner();
  return (
    <FlightCtx.Provider value={fly}>
      {children}
      <View pointerEvents="none" style={StyleSheet.absoluteFill}>
        {node}
      </View>
    </FlightCtx.Provider>
  );
}

/**
 * The same overlay for a caller that has no host above it (a screen rendered
 * outside the root layout, or a flight that must sit above a modal). A
 * transparent modal that lets every touch through.
 */
export function StarFlightOverlay({ children }: { children: React.ReactNode }) {
  return (
    <Modal visible transparent animationType="none" statusBarTranslucent>
      <View pointerEvents="none" style={StyleSheet.absoluteFill}>
        {children}
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  burst: { position: 'absolute', left: '50%', top: '50%', width: 0, height: 0 },
  spark: { position: 'absolute', left: -5, top: -5 },
  trail: { position: 'absolute', width: 12, height: 12 },
  flyer: { position: 'absolute', left: 0, top: 0 },
});
