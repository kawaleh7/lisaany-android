/**
 * The gold star companion.
 *
 * It rests small in a header slot, gently bobbing. When it has something to
 * say it opens a "talk row" in the page flow — so it pushes content down and
 * never covers words — shows one short line in a bubble, then tucks back into
 * its slot. Tapping the star repeats the page's tips; tapping the bubble
 * closes it.
 *
 *   const guide = useStarGuide(tips, { greet: 'Welcome back!', greetKey: 'today' });
 *   <StarSlot guide={guide} />   // in the header
 *   <StarTalk guide={guide} />   // just under the header
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Animated, Easing, Pressable, StyleSheet, Text, View } from 'react-native';
import Svg, { Circle, Defs, Ellipse, Path, RadialGradient, Stop } from 'react-native-svg';

import { Fonts } from '@/constants/lisaany';
import { useLang } from '@/lib/i18n';
import { useTheme } from '@/theme';

const PUFFY =
  'M50 9 C55 9 58 29 64 32 C70 35 90 32 92 38 C94 44 76 53 74 60 C72 67 83 85 78 89 C73 93 57 79 50 79 C43 79 27 93 22 89 C17 85 28 67 26 60 C24 53 6 44 8 38 C10 32 30 35 36 32 C42 29 45 9 50 9 Z';

let gradSeq = 0;

/** The glossy puffy gold star with its halo and highlight. */
export function GoldStar({ size = 44, halo = true }: { size?: number; halo?: boolean }) {
  const id = useMemo(() => `gs${++gradSeq}`, []);
  return (
    <Svg width={size} height={size} viewBox="-14 -14 128 128">
      <Defs>
        <RadialGradient id={`${id}p`} cx="0.38" cy="0.3" r="0.75">
          <Stop offset="0" stopColor="#FFF6C2" />
          <Stop offset="0.35" stopColor="#FFD84A" />
          <Stop offset="0.75" stopColor="#E6A800" />
          <Stop offset="1" stopColor="#B07A00" />
        </RadialGradient>
        <RadialGradient id={`${id}h`} cx="0.5" cy="0.5" r="0.5">
          <Stop offset="0" stopColor="#FFD84A" stopOpacity="0.55" />
          <Stop offset="0.6" stopColor="#FFD84A" stopOpacity="0.12" />
          <Stop offset="1" stopColor="#FFD84A" stopOpacity="0" />
        </RadialGradient>
        <RadialGradient id={`${id}s`} cx="0.5" cy="0.5" r="0.5">
          <Stop offset="0" stopColor="#ffffff" stopOpacity="0.95" />
          <Stop offset="1" stopColor="#ffffff" stopOpacity="0" />
        </RadialGradient>
      </Defs>
      {halo && <Circle cx="50" cy="50" r="62" fill={`url(#${id}h)`} />}
      <Path d={PUFFY} fill={`url(#${id}p)`} stroke="#C98C00" strokeWidth={1.2} />
      <Ellipse cx="40" cy="36" rx="9" ry="6" fill={`url(#${id}s)`} transform="rotate(-25 40 36)" />
    </Svg>
  );
}

/** A four-point twinkle used for sparkle bursts. */
function Twinkle({ size = 10 }: { size?: number }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 10 10">
      <Path d="M5 0 L6.2 3.8 L10 5 L6.2 6.2 L5 10 L3.8 6.2 L0 5 L3.8 3.8Z" fill="#FFE98A" />
    </Svg>
  );
}

/** A ring of sparkles that flies outward once each time `trigger` changes. */
export function SparkleBurst({ trigger, count = 8, radius = 40 }: { trigger: number; count?: number; radius?: number }) {
  const parts = useRef(
    Array.from({ length: 12 }, () => ({ v: new Animated.Value(0), a: 0, r: 0 })),
  ).current;
  useEffect(() => {
    if (!trigger) return;
    const anims = parts.slice(0, count).map((p, i) => {
      p.a = (i / count) * Math.PI * 2 + Math.random() * 0.5;
      p.r = radius * (0.6 + Math.random() * 0.6);
      p.v.setValue(0);
      return Animated.timing(p.v, {
        toValue: 1,
        duration: 650 + Math.random() * 300,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      });
    });
    Animated.parallel(anims).start();
  }, [trigger, count, radius, parts]);
  if (!trigger) return null;
  return (
    <View pointerEvents="none" style={styles.burst}>
      {parts.slice(0, count).map((p, i) => (
        <Animated.View
          key={i}
          style={[
            styles.spark,
            {
              opacity: p.v.interpolate({ inputRange: [0, 0.1, 1], outputRange: [0, 1, 0] }),
              transform: [
                { translateX: p.v.interpolate({ inputRange: [0, 1], outputRange: [0, Math.cos(p.a) * p.r] }) },
                { translateY: p.v.interpolate({ inputRange: [0, 1], outputRange: [0, Math.sin(p.a) * p.r] }) },
                { scale: p.v.interpolate({ inputRange: [0, 1], outputRange: [1.3, 0.3] }) },
              ],
            },
          ]}>
          <Twinkle />
        </Animated.View>
      ))}
    </View>
  );
}

/** Gentle float: bob up and down with a slow sway. */
function useFloat() {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(v, { toValue: 1, duration: 1800, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
        Animated.timing(v, { toValue: 0, duration: 1800, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [v]);
  return {
    transform: [
      { translateY: v.interpolate({ inputRange: [0, 1], outputRange: [-3, 3] }) },
      { rotate: v.interpolate({ inputRange: [0, 1], outputRange: ['-8deg', '8deg'] }) },
    ],
  };
}

/* ── state ──────────────────────────────────────────────────────────── */

/** Greetings already shown this app session, by key, so they don't repeat. */
const greeted = new Set<string>();

/** Count a greeting as shown (e.g. when another welcome already covered it). */
export function markGreeted(key: string) {
  greeted.add(key);
}

export type StarGuide = {
  text: string | null;
  say: (text: string, ms?: number) => void;
  tuck: () => void;
  tap: () => void;
  burst: number;
};

export function useStarGuide(
  tips: string[],
  opts: { greet?: string | null; greetKey?: string; delay?: number } = {},
): StarGuide {
  const [text, setText] = useState<string | null>(null);
  const [burst, setBurst] = useState(0);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const tip = useRef(0);
  const tipsRef = useRef(tips);
  tipsRef.current = tips;

  const tuck = useCallback(() => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = null;
    setText(null);
  }, []);

  const say = useCallback(
    (t: string, ms?: number) => {
      if (timer.current) clearTimeout(timer.current);
      setText(t);
      timer.current = setTimeout(tuck, ms ?? Math.max(3800, 1800 + t.length * 45));
    },
    [tuck],
  );

  // Read the current line from a ref so `tap` has no side effects inside a
  // state updater (those run twice in StrictMode and skipped tips).
  const textRef = useRef<string | null>(null);
  textRef.current = text;

  const tap = useCallback(() => {
    setBurst((b) => b + 1);
    if (textRef.current) {
      tuck();
      return;
    }
    const list = tipsRef.current;
    if (!list.length) return;
    const next = list[tip.current % list.length];
    tip.current++;
    say(next);
  }, [tuck, say]);

  const { greet, greetKey, delay = 700 } = opts;
  useEffect(() => {
    if (!greet) return;
    if (greetKey && greeted.has(greetKey)) return;
    const id = setTimeout(() => {
      if (greetKey) greeted.add(greetKey);
      say(greet);
    }, delay);
    return () => clearTimeout(id);
  }, [greet, greetKey, delay, say]);

  useEffect(() => () => {
    if (timer.current) clearTimeout(timer.current);
  }, []);

  return { text, say, tuck, tap, burst };
}

/* ── views ──────────────────────────────────────────────────────────── */

/** The star's resting place in a page header (44×44). */
export function StarSlot({ guide, size = 44 }: { guide: StarGuide; size?: number }) {
  const float = useFloat();
  const { t } = useLang();
  const shown = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    Animated.spring(shown, { toValue: guide.text ? 0 : 1, useNativeDriver: true, friction: 6 }).start();
  }, [guide.text, shown]);
  return (
    <Pressable
      onPress={guide.tap}
      hitSlop={8}
      accessibilityRole="button"
      accessibilityLabel={t('Tips')}
      style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Animated.View style={[{ opacity: shown, transform: [{ scale: shown }] }]}>
        <Animated.View style={float}>
          <GoldStar size={size} />
        </Animated.View>
      </Animated.View>
      <SparkleBurst trigger={guide.burst} />
    </Pressable>
  );
}

/** The in-flow talk row: a bigger star and its bubble. Takes no space when quiet. */
export function StarTalk({ guide }: { guide: StarGuide }) {
  const { c } = useTheme();
  const [shownText, setShownText] = useState<string | null>(guide.text);
  const v = useRef(new Animated.Value(0)).current;
  const spin = useRef(new Animated.Value(0)).current;
  const float = useFloat();

  useEffect(() => {
    if (guide.text) {
      setShownText(guide.text);
      spin.setValue(0);
      Animated.parallel([
        Animated.spring(v, { toValue: 1, useNativeDriver: true, friction: 7 }),
        Animated.timing(spin, { toValue: 1, duration: 700, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
      ]).start();
    } else {
      Animated.timing(v, { toValue: 0, duration: 180, useNativeDriver: true }).start(({ finished }) => {
        if (finished) setShownText(null);
      });
    }
  }, [guide.text, v, spin]);

  if (!shownText) return null;
  const light = c.scheme === 'light';
  return (
    <Pressable onPress={guide.tuck} style={styles.talkRow} accessibilityRole="button">
      <Animated.View
        style={{
          opacity: v,
          transform: [
            { scale: v.interpolate({ inputRange: [0, 1], outputRange: [0.4, 1] }) },
            { rotate: spin.interpolate({ inputRange: [0, 1], outputRange: ['-200deg', '0deg'] }) },
          ],
        }}>
        <Animated.View style={float}>
          <GoldStar size={62} />
        </Animated.View>
      </Animated.View>
      <Animated.View
        style={[
          styles.bubble,
          light && styles.bubbleLight,
          { opacity: v, transform: [{ translateX: v.interpolate({ inputRange: [0, 1], outputRange: [-10, 0] }) }] },
        ]}>
        <View style={[styles.bubbleTail, light && styles.bubbleTailLight]} />
        <Text style={styles.bubbleText}>{shownText}</Text>
      </Animated.View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  burst: { position: 'absolute', left: '50%', top: '50%', width: 0, height: 0 },
  spark: { position: 'absolute', left: -5, top: -5 },
  talkRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 8, marginBottom: 6 },
  bubble: {
    flex: 1,
    backgroundColor: '#ffffff',
    borderRadius: 16,
    paddingHorizontal: 14,
    paddingVertical: 12,
    shadowColor: '#000',
    shadowOpacity: 0.35,
    shadowRadius: 13,
    shadowOffset: { width: 0, height: 8 },
    elevation: 6,
  },
  bubbleLight: { borderWidth: 1, borderColor: '#e6ebf1', shadowOpacity: 0.1 },
  bubbleTail: {
    position: 'absolute',
    left: -6,
    top: '50%',
    marginTop: -6,
    width: 12,
    height: 12,
    backgroundColor: '#ffffff',
    transform: [{ rotate: '45deg' }],
  },
  bubbleTailLight: { borderLeftWidth: 1, borderBottomWidth: 1, borderColor: '#e6ebf1' },
  bubbleText: { color: '#16213a', fontFamily: Fonts.bodySemi, fontSize: 15, lineHeight: 20 },
});
