/**
 * The gold star companion.
 *
 * It rests small in a header slot, gently bobbing. When it has something to
 * say it opens a "talk row" in the page flow — so it pushes content down and
 * never covers words — and *flies* there: one star, on a curved arc, spinning
 * and growing, dropping sparkles on the way and bursting when it lands. It
 * shows one short line in a bubble, then flies home again. Tapping the star
 * repeats the page's tips; tapping the bubble closes it.
 *
 *   const guide = useStarGuide(tips, { greet: 'Welcome back!', greetKey: 'today' });
 *   <StarSlot guide={guide} />   // in the header
 *   <StarTalk guide={guide} />   // just under the header
 *
 * The flight itself lives in star-flight.tsx and is drawn by <StarFlightHost>
 * at the root of the app, so the star passes above every card and header.
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Animated, Easing, Pressable, StyleSheet, Text, View } from 'react-native';

import {
  GoldStar,
  SparkleBurst,
  StarFlightOverlay,
  useFlightRunner,
  useFloat,
  useStarFlight,
  type StarPoint,
} from '@/components/star-flight';
import { Fonts } from '@/constants/lisaany';
import { useLang } from '@/lib/i18n';
import { useTheme } from '@/theme';

export { GoldStar, SparkleBurst } from '@/components/star-flight';
export type { StarPoint } from '@/components/star-flight';

/** How big the star is while it is talking. */
const TALK_SIZE = 62;
const FLY_OUT_MS = 800;
const FLY_HOME_MS = 640;

/* ── state ──────────────────────────────────────────────────────────── */

/** Greetings already shown this app session, by key, so they don't repeat. */
const greeted = new Set<string>();

/** Count a greeting as shown (e.g. when another welcome already covered it). */
export function markGreeted(key: string) {
  greeted.add(key);
}

/** Which end of the trip is holding the star — or neither, while it flies. */
type Holder = 'slot' | 'air' | 'talk';

export type StarGuide = {
  text: string | null;
  say: (text: string, ms?: number) => void;
  tuck: () => void;
  tap: () => void;
  burst: number;
  /** Shared between <StarSlot> and <StarTalk> so only one star is ever shown. */
  flight: {
    holder: Holder;
    setHolder: (h: Holder) => void;
    /** Where each end rests, in window coordinates; null until measured. */
    slot: React.MutableRefObject<StarPoint | null>;
    talk: React.MutableRefObject<StarPoint | null>;
    /** Re-measures the header slot; registered by <StarSlot>. */
    measureSlot: React.MutableRefObject<(() => void) | null>;
  };
};

export function useStarGuide(
  tips: string[],
  opts: { greet?: string | null; greetKey?: string; delay?: number } = {},
): StarGuide {
  const [text, setText] = useState<string | null>(null);
  const [burst, setBurst] = useState(0);
  const [holder, setHolder] = useState<Holder>('slot');
  const slot = useRef<StarPoint | null>(null);
  const talk = useRef<StarPoint | null>(null);
  const measureSlot = useRef<(() => void) | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const tip = useRef(0);
  const tipsRef = useRef(tips);
  tipsRef.current = tips;

  const tuck = useCallback(() => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = null;
    setText(null);
  }, []);

  const say = useCallback(
    (t: string, ms?: number) => {
      if (timer.current) clearTimeout(timer.current);
      setText(t);
      timer.current = setTimeout(tuck, ms ?? Math.max(3800, 1800 + t.length * 45));
    },
    [tuck],
  );

  // Read the current line from a ref so `tap` has no side effects inside a
  // state updater (those run twice in StrictMode and skipped tips).
  const textRef = useRef<string | null>(null);
  textRef.current = text;

  const tap = useCallback(() => {
    setBurst((b) => b + 1);
    if (textRef.current) {
      tuck();
      return;
    }
    const list = tipsRef.current;
    if (!list.length) return;
    const next = list[tip.current % list.length];
    tip.current++;
    say(next);
  }, [tuck, say]);

  const { greet, greetKey, delay = 700 } = opts;
  useEffect(() => {
    if (!greet) return;
    if (greetKey && greeted.has(greetKey)) return;
    const id = setTimeout(() => {
      if (greetKey) greeted.add(greetKey);
      say(greet);
    }, delay);
    return () => clearTimeout(id);
  }, [greet, greetKey, delay, say]);

  useEffect(() => () => {
    if (timer.current) clearTimeout(timer.current);
  }, []);

  const flight = useMemo(
    () => ({ holder, setHolder, slot, talk, measureSlot }),
    [holder],
  );

  return { text, say, tuck, tap, burst, flight };
}

/* ── views ──────────────────────────────────────────────────────────── */

/** The star's resting place in a page header (44×44). */
export function StarSlot({ guide, size = 44 }: { guide: StarGuide; size?: number }) {
  const float = useFloat();
  const { t } = useLang();
  const ref = useRef<View>(null);
  const { flight } = guide;
  const home = flight.holder === 'slot';
  const [land, setLand] = useState(0);
  const was = useRef(flight.holder);

  const measure = useCallback(() => {
    ref.current?.measureInWindow((x, y, w, h) => {
      if (w > 0 && h > 0) flight.slot.current = { x: x + w / 2, y: y + h / 2, size };
    });
  }, [flight.slot, size]);

  // The talk row asks for a fresh measurement right before each flight, and a
  // layout change (rotation, a header that grows) re-measures on its own.
  useEffect(() => {
    flight.measureSlot.current = measure;
    measure();
    return () => {
      if (flight.measureSlot.current === measure) flight.measureSlot.current = null;
    };
  }, [flight.measureSlot, measure]);

  // A small sparkle when the star gets home.
  useEffect(() => {
    if (was.current === 'air' && flight.holder === 'slot') setLand((n) => n + 1);
    was.current = flight.holder;
  }, [flight.holder]);

  return (
    <Pressable
      ref={ref}
      collapsable={false}
      onLayout={measure}
      onPress={guide.tap}
      hitSlop={8}
      accessibilityRole="button"
      accessibilityLabel={t('Tips')}
      style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <View style={{ opacity: home ? 1 : 0 }}>
        <Animated.View style={float}>
          <GoldStar size={size} />
        </Animated.View>
      </View>
      <SparkleBurst trigger={guide.burst} />
      <SparkleBurst trigger={land} count={6} radius={30} />
    </Pressable>
  );
}

/** The in-flow talk row: a bigger star and its bubble. Takes no space when quiet. */
export function StarTalk({ guide }: { guide: StarGuide }) {
  const { c } = useTheme();
  const { flight } = guide;
  const [shownText, setShownText] = useState<string | null>(guide.text);
  const [land, setLand] = useState(0);
  const v = useRef(new Animated.Value(0)).current;
  const float = useFloat();
  const starRef = useRef<View>(null);
  const sent = useRef<string | null>(null);
  const pending = useRef(false);
  /** Each flight gets a number; a flight that is cut short by the next one
   *  must not put the star back down where it was going. */
  const gen = useRef(0);

  // The flight is normally drawn by the host at the root of the app; without
  // one (a screen mounted outside it) this row carries its own overlay.
  const host = useStarFlight();
  const local = useFlightRunner();
  const fly = host ?? local.fly;

  /** Fly out of the header and into this row. */
  const flyOut = useCallback(() => {
    const to = flight.talk.current;
    if (!to) {
      // Never measured (a row that never laid out): just be here, don't vanish.
      flight.setHolder('talk');
      v.setValue(1);
      return;
    }
    // No header measurement (a header that never laid out, a rotation mid-flight):
    // come in from just above the row rather than not flying at all.
    const from = flight.slot.current ?? { x: to.x, y: to.y - 150, size: 40 };
    const g = ++gen.current;
    flight.setHolder('air');
    fly({
      from,
      to,
      duration: FLY_OUT_MS,
      onDone: () => {
        if (g !== gen.current) return; // another flight took over
        flight.setHolder('talk');
        setLand((n) => n + 1);
      },
    });
    Animated.timing(v, {
      toValue: 1,
      delay: FLY_OUT_MS * 0.62,
      duration: 260,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start();
  }, [flight, fly, v]);

  // The row measures itself as soon as it is laid out; a line waiting to be
  // said leaves the moment that measurement lands (the row is not in the tree
  // yet when the line is set, so there is nothing to measure before then).
  const measure = useCallback(() => {
    starRef.current?.measureInWindow((x, y, w, h) => {
      if (w > 0 && h > 0) flight.talk.current = { x: x + w / 2, y: y + h / 2, size: TALK_SIZE };
      if (pending.current) {
        pending.current = false;
        flyOut();
      }
    });
  }, [flight.talk, flyOut]);

  useEffect(() => {
    if (guide.text) {
      if (sent.current === guide.text) return;
      const swap = sent.current !== null; // already talking: only the line changed
      sent.current = guide.text;
      setShownText(guide.text);
      if (swap) return;
      v.setValue(0);
      // The header keeps its star until the flight actually starts, so there is
      // never a frame with no star at all.
      flight.measureSlot.current?.();
      pending.current = true;
      // Normally the row's own layout starts the flight; this is the safety net
      // for a row that is already laid out and so never fires onLayout again.
      const id = setTimeout(() => {
        if (!pending.current) return;
        pending.current = false;
        flyOut();
      }, 160);
      return () => clearTimeout(id);
    }
    sent.current = null;
    if (!shownText) return;
    // Home again: the bubble fades, the star flies back to the header.
    const to = flight.slot.current;
    const from = flight.talk.current;
    flight.setHolder('air');
    Animated.timing(v, { toValue: 0, duration: 200, useNativeDriver: true }).start(({ finished }) => {
      if (finished) setShownText(null);
    });
    if (from && to) {
      const g = ++gen.current;
      fly({
        from,
        to,
        duration: FLY_HOME_MS,
        onDone: () => {
          if (g !== gen.current) return; // another flight took over
          flight.setHolder('slot');
        },
      });
    } else {
      gen.current++;
      flight.setHolder('slot');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [guide.text]);

  if (!shownText) return host ? null : <>{local.node ? <StarFlightOverlay>{local.node}</StarFlightOverlay> : null}</>;
  const light = c.scheme === 'light';
  return (
    <>
      <Pressable onPress={guide.tuck} style={styles.talkRow} accessibilityRole="button">
        <View ref={starRef} collapsable={false} onLayout={measure} style={styles.talkStar}>
          <View style={{ opacity: flight.holder === 'talk' ? 1 : 0 }}>
            <Animated.View style={float}>
              <GoldStar size={TALK_SIZE} />
            </Animated.View>
          </View>
          <SparkleBurst trigger={land} count={12} radius={46} />
        </View>
        <Animated.View
          style={[
            styles.bubble,
            light && styles.bubbleLight,
            { opacity: v, transform: [{ translateX: v.interpolate({ inputRange: [0, 1], outputRange: [-10, 0] }) }] },
          ]}>
          <View style={[styles.bubbleTail, light && styles.bubbleTailLight]} />
          <Text style={styles.bubbleText}>{shownText}</Text>
        </Animated.View>
      </Pressable>
      {!host && local.node ? <StarFlightOverlay>{local.node}</StarFlightOverlay> : null}
    </>
  );
}

const styles = StyleSheet.create({
  talkRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 8, marginBottom: 6 },
  talkStar: { width: TALK_SIZE, height: TALK_SIZE, alignItems: 'center', justifyContent: 'center' },
  bubble: {
    flex: 1,
    backgroundColor: '#ffffff',
    borderRadius: 16,
    paddingHorizontal: 14,
    paddingVertical: 12,
    shadowColor: '#000',
    shadowOpacity: 0.35,
    shadowRadius: 13,
    shadowOffset: { width: 0, height: 8 },
    elevation: 6,
  },
  bubbleLight: { borderWidth: 1, borderColor: '#e6ebf1', shadowOpacity: 0.1 },
  bubbleTail: {
    position: 'absolute',
    left: -6,
    top: '50%',
    marginTop: -6,
    width: 12,
    height: 12,
    backgroundColor: '#ffffff',
    transform: [{ rotate: '45deg' }],
  },
  bubbleTailLight: { borderLeftWidth: 1, borderBottomWidth: 1, borderColor: '#e6ebf1' },
  bubbleText: { color: '#16213a', fontFamily: Fonts.bodySemi, fontSize: 15, lineHeight: 20 },
});
