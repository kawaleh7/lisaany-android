import { StyleSheet, Text, View, type ColorValue } from 'react-native';

/**
 * Three stars, filled for each one earned.
 *
 * Uses the Unicode star characters rather than the Material Symbols font:
 * the icon font we ship is the Outlined variant, which has no filled star, and
 * a row of hollow stars reads as "none earned" to a child.
 */
export function Stars({
  n,
  size = 15,
  on,
  off,
  gap = 3,
}: {
  n: number;
  size?: number;
  on: ColorValue;
  off: ColorValue;
  gap?: number;
}) {
  return (
    <View style={[styles.row, { gap }]}>
      {[0, 1, 2].map((k) => (
        <Text key={k} style={{ fontSize: size, lineHeight: size * 1.25, color: k < n ? on : off }}>
          {k < n ? '★' : '☆'}
        </Text>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({ row: { flexDirection: 'row', alignItems: 'center' } });
