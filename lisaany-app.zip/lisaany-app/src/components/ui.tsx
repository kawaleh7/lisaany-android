import { LinearGradient } from 'expo-linear-gradient';
import type { ReactNode } from 'react';
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  Text,
  View,
  type StyleProp,
  type TextStyle,
  type ViewStyle,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { Colors, Fonts, Gradients, Radius, Shadows, Spacing, Tracking } from '@/constants/lisaany';
import { makeStyles, useTheme, type Palette } from '@/theme';

import { Icon } from './icon';

/* ── layout ─────────────────────────────────────────────────────────── */

export function Screen({
  children,
  scroll = true,
  style,
}: {
  children: ReactNode;
  scroll?: boolean;
  style?: StyleProp<ViewStyle>;
}) {
  const styles = useStyles();
  const inner = <View style={[styles.screenInner, style]}>{children}</View>;

  return (
    <SafeAreaView style={styles.screen} edges={['top', 'left', 'right']}>
      {scroll ? (
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}>
          {inner}
        </ScrollView>
      ) : (
        inner
      )}
    </SafeAreaView>
  );
}

/* ── type ───────────────────────────────────────────────────────────── */

/** Large Cinzel display heading, in the cream the web hub uses. */
export function Display({
  children,
  style,
}: {
  children: ReactNode;
  style?: StyleProp<TextStyle>;
}) {
  const styles = useStyles();
  return <Text style={[styles.display, style]}>{children}</Text>;
}

/**
 * Small gold Cinzel eyebrow above a heading.
 *
 * Cinzel carries no Arabic glyphs, so Arabic text passed here would render as
 * blank boxes. Pass `arabic` to set it in Amiri instead.
 */
export function Eyebrow({ children, arabic }: { children: ReactNode; arabic?: boolean }) {
  const styles = useStyles();
  return <Text style={[styles.eyebrow, arabic && styles.eyebrowArabic]}>{children}</Text>;
}

/** Arabic line in Amiri — gold by default, as on the hub. */
export function ArabicLine({
  children,
  size = 29,
  color,
  style,
}: {
  children: ReactNode;
  size?: number;
  color?: string;
  style?: StyleProp<TextStyle>;
}) {
  const styles = useStyles();
  const { c } = useTheme();
  return (
    <Text style={[styles.arabic, { fontSize: size, lineHeight: size * 1.6, color: color ?? c.gold }, style]}>
      {children}
    </Text>
  );
}

export function Body({ children, style }: { children: ReactNode; style?: StyleProp<TextStyle> }) {
  const styles = useStyles();
  return <Text style={[styles.body, style]}>{children}</Text>;
}

/**
 * Uppercase Cinzel section label with the gradient rule trailing off to the
 * right — one of the most recognisable details in the web design.
 */
export function SectionHeading({ children }: { children: ReactNode }) {
  const styles = useStyles();
  const { c } = useTheme();
  return (
    <View style={styles.sectionHeading}>
      <Text style={styles.sectionHeadingText}>{children}</Text>
      <LinearGradient
        colors={[dk(c, Colors.border, c.line), 'transparent']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        style={styles.sectionRule}
      />
    </View>
  );
}

/* ── surfaces ───────────────────────────────────────────────────────── */

/** The standard gradient card: 18px radius, hairline border, layered shadow. */
export function Card({
  children,
  onPress,
  style,
  variant = 'card',
}: {
  children: ReactNode;
  onPress?: () => void;
  style?: StyleProp<ViewStyle>;
  variant?: 'card' | 'gold' | 'hero' | 'header';
}) {
  const styles = useStyles();
  const { c } = useTheme();
  const dark = c.scheme === 'dark';
  const gradient =
    variant === 'gold'
      ? dark
        ? Gradients.gold
        : ([c.goldTint, 'rgba(201,146,30,0.04)'] as const)
      : variant === 'hero'
        ? dark
          ? Gradients.hero
          : c.navyGrad
        : variant === 'header'
          ? dark
            ? Gradients.header
            : c.navyGrad
          : dark
            ? Gradients.card
            : c.cardGrad;

  const isGold = variant === 'gold';
  const isTall = variant === 'hero' || variant === 'header';

  const body = (pressed: boolean) => (
    <LinearGradient
      colors={gradient as unknown as readonly [string, string]}
      start={variant === 'card' ? { x: 0.1, y: 0 } : { x: 0, y: 0 }}
      end={variant === 'card' ? { x: 0.9, y: 1 } : { x: 0, y: 1 }}
      style={[
        styles.card,
        variant === 'card' && styles.cardEdge,
        isTall && styles.cardTall,
        isGold && styles.cardGold,
        pressed && styles.cardPressed,
        style,
      ]}>
      {children}
    </LinearGradient>
  );

  if (!onPress) return <View style={styles.cardWrap}>{body(false)}</View>;

  return (
    <Pressable onPress={onPress} style={styles.cardWrap}>
      {({ pressed }) => body(pressed)}
    </Pressable>
  );
}

/* ── controls ───────────────────────────────────────────────────────── */

export function Button({
  label,
  onPress,
  variant = 'primary',
  icon,
  disabled,
  loading,
}: {
  label: string;
  onPress: () => void;
  variant?: 'primary' | 'ghost';
  /** Material Symbols name. */
  icon?: string;
  disabled?: boolean;
  loading?: boolean;
}) {
  const styles = useStyles();
  const { c } = useTheme();
  const isPrimary = variant === 'primary';

  return (
    <Pressable
      onPress={onPress}
      disabled={disabled || loading}
      style={({ pressed }) => [
        styles.button,
        isPrimary ? styles.buttonPrimary : styles.buttonGhost,
        (disabled || loading) && styles.buttonDisabled,
        pressed && styles.buttonPressed,
      ]}>
      {loading ? (
        <ActivityIndicator color={isPrimary ? c.onGold : c.gold} />
      ) : (
        <>
          {icon ? (
            <Icon
              name={icon}
              size={18}
              color={isPrimary ? c.onGold : dk(c, Colors.text, c.text)}
              style={styles.buttonIcon}
            />
          ) : null}
          <Text style={[styles.buttonLabel, isPrimary ? styles.labelPrimary : styles.labelGhost]}>
            {label}
          </Text>
        </>
      )}
    </Pressable>
  );
}

/** Corner tag used on module cards to mark free vs premium. */
export function Tag({ label, tone = 'premium' }: { label: string; tone?: 'free' | 'premium' }) {
  const styles = useStyles();
  const { c } = useTheme();
  const isFree = tone === 'free';
  return (
    <View style={[styles.tag, isFree ? styles.tagFree : styles.tagPremium]}>
      <Text style={[styles.tagText, { color: isFree ? dk(c, Colors.mint, c.green) : c.gold }]}>{label}</Text>
    </View>
  );
}

/** Round icon chip — the 46px circles beside unit rows. */
export function IconChip({
  name,
  size = 46,
  active = false,
}: {
  name: string;
  size?: number;
  active?: boolean;
}) {
  const styles = useStyles();
  const { c } = useTheme();
  return (
    <View
      style={[
        styles.iconChip,
        { width: size, height: size, borderRadius: size / 2 },
        active && styles.iconChipActive,
      ]}>
      <Icon name={name} size={size * 0.44} color={active ? c.gold : dk(c, Colors.text, c.text)} />
    </View>
  );
}

/** Squared icon tile used in lesson headers. */
export function IconTile({ name, size = 48 }: { name: string; size?: number }) {
  const styles = useStyles();
  const { c } = useTheme();
  return (
    <View style={[styles.iconTile, { width: size, height: size }]}>
      <Icon name={name} size={size * 0.5} color={c.gold} />
    </View>
  );
}

export function ProgressTrack({ value }: { value: number }) {
  const styles = useStyles();
  const pct = Math.max(0, Math.min(1, value));
  return (
    <View style={styles.track}>
      <View style={[styles.trackFill, { width: `${pct * 100}%` }]} />
    </View>
  );
}

/* ── states ─────────────────────────────────────────────────────────── */

export function Loading({ label }: { label?: string }) {
  const styles = useStyles();
  const { c } = useTheme();
  return (
    <View style={styles.loading}>
      <ActivityIndicator color={c.gold} />
      {label ? <Text style={styles.loadingLabel}>{label}</Text> : null}
    </View>
  );
}

export function ErrorNote({ message }: { message: string }) {
  const styles = useStyles();
  const { c } = useTheme();
  return (
    <View style={styles.error}>
      <Icon name="error" size={18} color={c.red} />
      <Text style={styles.errorText}>{message}</Text>
    </View>
  );
}

/* ── styles ─────────────────────────────────────────────────────────── */

/**
 * Dark keeps the original hand-tuned values exactly (some differ from the
 * shared palette, e.g. cream headings, full-brightness body copy); light uses
 * palette tokens.
 */
function dk<T>(c: Palette, dark: T, light: T): T {
  return c.scheme === 'dark' ? dark : light;
}

/** Soft gold border used on gold-accented surfaces. */
const goldLine = (c: Palette) => dk(c, Colors.goldGlow, 'rgba(201,146,30,0.3)');

const useStyles = makeStyles((c) => ({
  screen: { flex: 1, backgroundColor: c.bg },
  screenInner: { flex: 1, paddingHorizontal: Spacing.md },
  scrollContent: { paddingBottom: 40, flexGrow: 1 },

  display: {
    fontFamily: Fonts.display,
    fontSize: 34,
    lineHeight: 40,
    color: dk(c, Colors.cream, c.text),
    letterSpacing: Tracking.tight,
  },
  eyebrow: {
    fontFamily: Fonts.display,
    fontSize: 11,
    letterSpacing: Tracking.eyebrow,
    textTransform: 'uppercase',
    color: c.gold,
    marginBottom: 10,
  },
  eyebrowArabic: {
    fontFamily: Fonts.arabic,
    fontSize: 16,
    letterSpacing: 0,
    textTransform: 'none',
  },
  arabic: {
    fontFamily: Fonts.arabic,
    textAlign: 'right',
    writingDirection: 'rtl',
  },
  body: {
    fontFamily: Fonts.body,
    fontSize: 15,
    lineHeight: 24,
    color: dk(c, Colors.dim, c.muted),
  },

  sectionHeading: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginTop: Spacing.lg,
    marginBottom: Spacing.md,
  },
  sectionHeadingText: {
    fontFamily: Fonts.display,
    fontSize: 12,
    letterSpacing: Tracking.heading,
    textTransform: 'uppercase',
    color: dk(c, Colors.dim, c.muted),
  },
  sectionRule: { flex: 1, height: 1 },

  cardWrap: {
    marginBottom: 10,
    borderRadius: Radius.card,
    ...dk(c, Shadows.card, {
      shadowColor: c.shadow,
      shadowOffset: { width: 0, height: 8 },
      shadowOpacity: c.shadowOpacity,
      shadowRadius: 14,
      elevation: 3,
    }),
  },
  card: {
    borderRadius: Radius.card,
    borderWidth: 1,
    borderColor: dk(c, Colors.border, c.line),
    padding: 20,
    overflow: 'hidden',
  },
  /** Light theme: navy top edge on standard cards. */
  cardEdge: dk(c, {}, { borderTopWidth: 3, borderTopColor: c.edge }),
  cardTall: { borderRadius: Radius.lg, padding: 22 },
  cardGold: { borderColor: goldLine(c) },
  cardPressed: { borderColor: goldLine(c), opacity: 0.92 },

  button: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    borderRadius: Radius.pill,
    paddingVertical: 14,
    paddingHorizontal: 22,
    marginTop: 10,
    minHeight: 50,
  },
  buttonPrimary: {
    backgroundColor: c.goldFill,
    ...Shadows.goldGlow,
    ...dk(c, {}, { shadowOpacity: 0.25, elevation: 3 }),
  },
  buttonGhost: {
    backgroundColor: dk(c, Colors.faint, c.raised),
    borderWidth: 1,
    borderColor: dk(c, Colors.border, c.line),
  },
  buttonDisabled: { opacity: 0.5 },
  buttonPressed: { transform: [{ scale: 0.97 }] },
  buttonIcon: { marginRight: 2 },
  buttonLabel: { fontFamily: Fonts.bodyBold, fontSize: 15 },
  labelPrimary: { color: c.onGold },
  labelGhost: { color: dk(c, Colors.text, c.text) },

  tag: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderBottomLeftRadius: Radius.sm,
    borderLeftWidth: 1,
    borderBottomWidth: 1,
  },
  tagFree: {
    backgroundColor: dk(c, 'rgba(127,201,156,0.12)', 'rgba(47,157,92,0.10)'),
    borderColor: dk(c, 'rgba(127,201,156,0.25)', 'rgba(47,157,92,0.25)'),
  },
  tagPremium: { backgroundColor: dk(c, 'rgba(242,190,98,0.10)', c.goldTint), borderColor: goldLine(c) },
  tagText: {
    fontFamily: Fonts.bodyBold,
    fontSize: 9.5,
    letterSpacing: Tracking.meta,
    textTransform: 'uppercase',
  },

  iconChip: {
    backgroundColor: dk(c, 'rgba(13,27,50,0.85)', c.raised),
    borderWidth: 1.5,
    borderColor: dk(c, 'rgba(242,190,98,0.28)', 'rgba(201,146,30,0.3)'),
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconChipActive: { borderColor: c.gold },

  iconTile: {
    borderRadius: 14,
    backgroundColor: dk(c, 'rgba(242,190,98,0.10)', c.goldTint),
    borderWidth: 1,
    borderColor: goldLine(c),
    alignItems: 'center',
    justifyContent: 'center',
  },

  track: {
    height: 5,
    borderRadius: Radius.pill,
    backgroundColor: dk(c, Colors.faint, c.track),
    overflow: 'hidden',
  },
  trackFill: { height: '100%', borderRadius: Radius.pill, backgroundColor: c.goldFill },

  loading: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: Spacing.xl },
  loadingLabel: { fontFamily: Fonts.body, color: dk(c, Colors.dim, c.muted), marginTop: 10, fontSize: 14 },

  error: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
    backgroundColor: dk(c, 'rgba(224,112,112,0.10)', 'rgba(208,76,76,0.08)'),
    borderColor: dk(c, 'rgba(224,112,112,0.35)', 'rgba(208,76,76,0.3)'),
    borderWidth: 1,
    borderRadius: Radius.sm,
    padding: Spacing.md,
    marginVertical: Spacing.sm,
  },
  errorText: { flex: 1, fontFamily: Fonts.body, color: dk(c, '#f3b5ac', c.red), fontSize: 14, lineHeight: 20 },
}));
