import { useEffect, useRef, useState } from 'react';
import {
  Animated,
  Dimensions,
  Modal,
  PanResponder,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Icon } from '@/components/icon';
import { ArabicLine } from '@/components/ui';
import { Fonts, Tracking } from '@/constants/lisaany';
import { blockSizeLabel, getObjectives, type Unit } from '@/lib/curriculum';
import { isBlockUnlocked, nextBlockFor, type CompletedMap } from '@/lib/progress';
import { makeStyles, useTheme } from '@/theme';

export type SheetUnit =
  | { unit: Unit; state: 'open' }
  /** Blocked by order. `before` is the unit to work on now; `blocksLeft` is
   *  set only when that's the unit directly before this one. */
  | { unit: Unit; state: 'locked'; before: Unit; blocksLeft: number }
  /** Blocked by plan: needs a subscription. */
  | { unit: Unit; state: 'premium' };

/**
 * The card that slides up when a unit is tapped on the module page: where
 * you are, what's next, one Continue button. The full block list is folded
 * away behind "Review a block" — it's there for going back, not for choosing.
 */
export function UnitSheet({
  target,
  done,
  onClose,
  onOpenBlock,
  onGoToUnit,
  onUnlock,
}: {
  target: SheetUnit | null;
  done: CompletedMap;
  onClose: () => void;
  onOpenBlock: (unit: Unit, blockId: number) => void;
  onGoToUnit: (unit: Unit) => void;
  onUnlock: () => void;
}) {
  const insets = useSafeAreaInsets();
  const { c } = useTheme();
  const styles = useStyles();
  const [goalsOpen, setGoalsOpen] = useState(false);
  const [reviewOpen, setReviewOpen] = useState(false);
  const drag = useRef(new Animated.Value(0)).current;
  const slide = useRef(new Animated.Value(1)).current;

  const visible = !!target;

  useEffect(() => {
    if (!visible) return;
    setGoalsOpen(false);
    setReviewOpen(false);
    drag.setValue(0);
    slide.setValue(1);
    Animated.spring(slide, { toValue: 0, useNativeDriver: true, bounciness: 3, speed: 16 }).start();
  }, [visible, target?.unit.id, drag, slide]);

  const close = () => {
    Animated.timing(slide, { toValue: 1, duration: 180, useNativeDriver: true }).start(() => onClose());
  };

  // Swipe down on the top of the card to dismiss it.
  const pan = useRef(
    PanResponder.create({
      onMoveShouldSetPanResponder: (_, g) => g.dy > 6 && Math.abs(g.dy) > Math.abs(g.dx),
      onPanResponderMove: (_, g) => drag.setValue(Math.max(0, g.dy)),
      onPanResponderRelease: (_, g) => {
        if (g.dy > 110 || g.vy > 1.2) {
          Animated.timing(slide, { toValue: 1, duration: 160, useNativeDriver: true }).start(() => onClose());
        } else {
          Animated.spring(drag, { toValue: 0, useNativeDriver: true }).start();
        }
      },
    })
  ).current;

  if (!target) return null;
  const { unit } = target;

  const height = Dimensions.get('window').height;
  const translateY = Animated.add(
    slide.interpolate({ inputRange: [0, 1], outputRange: [0, height] }),
    drag
  );

  const doneCount = unit.blocks.filter((b) => done[`${unit.id}:${b.id}`]).length;
  const complete = doneCount === unit.blocks.length;
  const nextId = nextBlockFor(unit, done);
  const next = unit.blocks.find((b) => b.id === nextId);
  const nextIdx = unit.blocks.findIndex((b) => b.id === nextId);
  const objectives = getObjectives(unit.id);

  return (
    <Modal visible transparent animationType="fade" onRequestClose={close} statusBarTranslucent>
      <Pressable style={styles.backdrop} onPress={close} accessibilityLabel="Close" />

      <Animated.View
        style={[
          styles.sheet,
          { paddingBottom: insets.bottom + 22, maxHeight: height * 0.9, transform: [{ translateY }] },
        ]}>
        <View {...pan.panHandlers}>
          <View style={styles.grabber} />

          <View style={styles.headRow}>
            <View style={[styles.headIcon, target.state !== 'open' && styles.headIconLocked]}>
              <Icon
                name={target.state === 'open' ? unit.icon ?? 'menu_book' : 'lock'}
                size={24}
                color={target.state === 'open' ? c.gold : c.muted}
              />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.eyebrow, target.state !== 'open' && { color: c.muted }]}>
                UNIT {unit.id}
              </Text>
              <Text style={styles.title}>{unit.title}</Text>
              {unit.desc ? (
                <ArabicLine size={15} color={c.gold} style={styles.arabic}>
                  {unit.desc}
                </ArabicLine>
              ) : null}
            </View>
            <Pressable onPress={close} hitSlop={10} style={styles.closeBtn} accessibilityLabel="Close">
              <Icon name="close" size={18} color={c.muted} />
            </Pressable>
          </View>
        </View>

        {target.state === 'locked' ? (
          <View>
            <Text style={styles.lockText}>
              {target.blocksLeft > 0 ? (
                <>
                  Finish <Text style={styles.lockStrong}>{target.before.title}</Text> to open this unit.
                  {` You're ${target.blocksLeft} block${target.blocksLeft === 1 ? '' : 's'} away.`}
                </>
              ) : (
                <>
                  Units open one after another. Keep going with{' '}
                  <Text style={styles.lockStrong}>{target.before.title}</Text> first.
                </>
              )}
            </Text>
            <GoldButton label={`Go to ${target.before.title}`} onPress={() => onGoToUnit(target.before)} />
          </View>
        ) : target.state === 'premium' ? (
          <View>
            <Text style={styles.lockText}>
              This unit is part of the full course. Units 1.1, 1.2 and 1.3 are free.
            </Text>
            <GoldButton label="See plans" onPress={onUnlock} />
          </View>
        ) : (
          <ScrollView bounces={false} showsVerticalScrollIndicator={false}>
            <View style={styles.segments}>
              {unit.blocks.map((b, i) => (
                <View
                  key={b.id}
                  style={[
                    styles.segment,
                    done[`${unit.id}:${b.id}`]
                      ? styles.segmentDone
                      : i === nextIdx && !complete
                        ? styles.segmentNext
                        : null,
                  ]}
                />
              ))}
            </View>
            <View style={styles.countRow}>
              <Text style={styles.count}>
                {doneCount} of {unit.blocks.length} blocks
              </Text>
              <Text style={styles.count}>
                {complete ? 'Complete' : `${unit.blocks.length - doneCount} to go`}
              </Text>
            </View>

            {objectives.length ? (
              <Pressable onPress={() => setGoalsOpen(!goalsOpen)} style={styles.goals}>
                <View style={styles.goalsHead}>
                  <Icon name="lightbulb" size={19} color={c.gold} />
                  <View style={{ flex: 1 }}>
                    <Text style={styles.small}>You'll be able to</Text>
                    <Text style={styles.goalsLead} numberOfLines={goalsOpen ? undefined : 1}>
                      {goalsOpen ? 'By the end of this unit:' : capitalise(objectives[0])}
                    </Text>
                  </View>
                  <Icon name={goalsOpen ? 'expand_less' : 'expand_more'} size={20} color={c.muted} />
                </View>
                {goalsOpen
                  ? objectives.map((o) => (
                      <View key={o} style={styles.goalRow}>
                        <Icon name="check" size={16} color={c.gold} />
                        <Text style={styles.goalText}>{capitalise(o)}</Text>
                      </View>
                    ))
                  : null}
              </Pressable>
            ) : null}

            {next ? (
              <View style={styles.nextRow}>
                <Icon name={next.icon ?? 'play_arrow'} size={21} color={c.gold} />
                <View style={{ flex: 1 }}>
                  <Text style={styles.small}>{complete ? 'Start again with' : 'Next up'}</Text>
                  <Text style={styles.nextTitle}>
                    {next.title}
                    {blockSizeLabel(next) ? ` · ${blockSizeLabel(next)}` : ''}
                  </Text>
                </View>
              </View>
            ) : null}

            <GoldButton
              label={complete ? 'Review unit' : doneCount > 0 ? 'Continue' : 'Start'}
              onPress={() => onOpenBlock(unit, nextId)}
            />

            <Pressable onPress={() => setReviewOpen(!reviewOpen)} style={styles.reviewLink} hitSlop={6}>
              <Text style={styles.reviewText}>{reviewOpen ? 'Hide blocks' : 'Review a block'}</Text>
              <Icon name={reviewOpen ? 'expand_less' : 'expand_more'} size={18} color={c.muted} />
            </Pressable>

            {reviewOpen ? (
              <View>
                <Text style={styles.listLabel}>ALL BLOCKS</Text>
                {unit.blocks.map((b) => {
                  const isDone = !!done[`${unit.id}:${b.id}`];
                  const open = isDone || isBlockUnlocked(unit, b.id, done);
                  return (
                    <Pressable
                      key={b.id}
                      disabled={!open}
                      onPress={() => onOpenBlock(unit, b.id)}
                      style={({ pressed }) => [styles.blockRow, !open && { opacity: 0.45 }, pressed && { opacity: 0.7 }]}>
                      <View style={[styles.mark, isDone ? styles.markDone : open ? styles.markNext : styles.markTodo]}>
                        <Icon
                          name={isDone ? 'check' : open ? 'play_arrow' : 'lock'}
                          size={isDone ? 14 : 13}
                          color={isDone ? c.gold : open ? c.onGold : c.scheme === 'light' ? c.navy : c.locked}
                        />
                      </View>
                      <Text style={styles.blockTitle} numberOfLines={1}>
                        {b.title}
                      </Text>
                      {isDone ? <Text style={styles.redo}>Redo</Text> : null}
                    </Pressable>
                  );
                })}
              </View>
            ) : null}
          </ScrollView>
        )}
      </Animated.View>
    </Modal>
  );
}

function GoldButton({ label, onPress }: { label: string; onPress: () => void }) {
  const { c } = useTheme();
  const styles = useStyles();
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.btn, pressed && { opacity: 0.88 }]}>
      <Text style={styles.btnLabel}>{label}</Text>
      <Icon name="arrow_forward" size={19} color={c.onGold} />
    </Pressable>
  );
}

function capitalise(s: string) {
  return s ? s[0].toUpperCase() + s.slice(1) : s;
}

const useStyles = makeStyles((c) => ({
  backdrop: { ...StyleSheet.absoluteFill, backgroundColor: 'rgba(3,8,20,0.62)' },
  sheet: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: c.card,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderTopWidth: c.scheme === 'light' ? 3 : 1,
    borderColor: c.scheme === 'light' ? c.edge : 'rgba(255,255,255,0.12)',
    paddingHorizontal: 24,
    paddingTop: 12,
  },
  grabber: {
    width: 40,
    height: 5,
    borderRadius: 3,
    backgroundColor: c.faint,
    alignSelf: 'center',
    marginBottom: 18,
  },

  headRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 14, marginBottom: 16 },
  headIcon: {
    width: 52,
    height: 52,
    borderRadius: 16,
    backgroundColor: c.goldTint,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headIconLocked: { backgroundColor: c.raised },
  eyebrow: {
    fontFamily: Fonts.bodyBold,
    fontSize: 10.5,
    letterSpacing: Tracking.meta,
    color: c.gold,
    marginBottom: 3,
  },
  title: { fontFamily: Fonts.display, fontSize: 22, lineHeight: 27, color: c.text },
  arabic: { marginTop: 3 },
  closeBtn: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: c.raised,
    alignItems: 'center',
    justifyContent: 'center',
  },

  segments: { flexDirection: 'row', gap: 4, marginBottom: 8 },
  segment: { flex: 1, height: 6, borderRadius: 3, backgroundColor: c.track },
  segmentDone: { backgroundColor: c.gold },
  // Half-strength gold marks the next block.
  segmentNext: { backgroundColor: c.scheme === 'light' ? 'rgba(201,146,30,0.4)' : 'rgba(230,184,90,0.4)' },
  countRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 18 },
  count: { fontFamily: Fonts.body, fontSize: 12, color: c.muted },

  goals: {
    borderRadius: 16,
    backgroundColor: c.raised,
    borderWidth: 1,
    borderColor: c.line,
    padding: 14,
    marginBottom: 18,
  },
  goalsHead: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  small: { fontFamily: Fonts.body, fontSize: 11.5, color: c.muted },
  goalsLead: { fontFamily: Fonts.bodySemi, fontSize: 14, color: c.text, marginTop: 1 },
  goalRow: { flexDirection: 'row', gap: 10, marginTop: 10, paddingLeft: 2 },
  goalText: { flex: 1, fontFamily: Fonts.body, fontSize: 13.5, lineHeight: 19, color: c.text },

  nextRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 14 },
  nextTitle: { fontFamily: Fonts.bodySemi, fontSize: 15, color: c.text, marginTop: 1 },

  btn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: c.goldFill,
    borderRadius: 999,
    minHeight: 54,
    paddingHorizontal: 22,
  },
  btnLabel: { fontFamily: Fonts.bodyBold, fontSize: 15.5, color: c.onGold },

  reviewLink: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 14,
  },
  reviewText: { fontFamily: Fonts.bodySemi, fontSize: 13.5, color: c.muted },

  listLabel: {
    fontFamily: Fonts.bodyBold,
    fontSize: 10.5,
    letterSpacing: Tracking.meta,
    color: c.muted,
    marginBottom: 2,
  },
  blockRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 11,
    borderBottomWidth: 1,
    borderColor: c.line,
  },
  mark: { width: 24, height: 24, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  markDone: { backgroundColor: c.goldTint },
  markNext: { backgroundColor: c.goldFill },
  markTodo: { borderWidth: 1.5, borderColor: c.line },
  blockTitle: { flex: 1, fontFamily: Fonts.body, fontSize: 14, color: c.text },
  redo: { fontFamily: Fonts.bodySemi, fontSize: 12.5, color: c.gold },

  lockText: {
    fontFamily: Fonts.body,
    fontSize: 14,
    lineHeight: 21,
    color: c.muted,
    marginBottom: 20,
  },
  lockStrong: { fontFamily: Fonts.bodySemi, color: c.text },
}));
