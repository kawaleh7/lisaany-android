/**
 * The welcome-back sheet.
 *
 * It slides up over Today when the learner comes back (a new day, or a return
 * after a long break — both kinds show this same sheet). The gold star flies
 * out of its header slot on a curved arc, spinning, and lands beside the title
 * with a sparkle burst. It then says one Arabic greeting in a white bubble,
 * word by word, and the sheet writes two short lines underneath: how many
 * Arabic words the learner knows and how far the next milestone is. A quiet
 * panel counts the words up and shows the milestone ladder. One tap starts the
 * lesson; on close the star flies home.
 */
import { LinearGradient } from 'expo-linear-gradient';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Animated, Easing, Modal, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Icon } from '@/components/icon';
import { GoldStar, SparkleBurst } from '@/components/star-guide';
import { CardFill, currentCard, spaceCard } from '@/components/ui';
import { Fonts } from '@/constants/lisaany';
import { useLang } from '@/lib/i18n';
import { farMilestone, MILESTONES, nextMilestone, prevMilestone, projectMilestone, takeMilestone, wordPace } from '@/lib/word-pace';
import { makeStyles, useTheme } from '@/theme';

export type WelcomeNext = {
  /** e.g. "1.1 · Basic Greetings" (already translated). */
  kicker: string;
  title: string;
  icon: string;
  locked: boolean;
};

/** Where the star rests in the Today header (window coordinates, centre). */
export type StarPoint = { x: number; y: number; size: number };

/* ── timing ─────────────────────────────────────────────────────────── */

const SLIDE_MS = 420;
const FLY_MS = 900;
const FLY_AT = 380;
const AR_STEP = 270;
const LINE_STEP = 70;
const COUNT_MS = 1900;
const STAR_SIZE = 54;

type Part = { w: string; gold: boolean };

/**
 * Split "You have *{n} words* left." into words, marking the gold ones.
 * Punctuation that follows a gold run with no space (the full stop after
 * "*{when}*.") stays glued to the word before it.
 */
function parts(text: string): Part[] {
  const out: Part[] = [];
  let gold = false;
  let spaced = true;
  for (const chunk of text.split('*')) {
    for (const tk of chunk.split(/(\s+)/)) {
      if (!tk) continue;
      if (/^\s+$/.test(tk)) {
        spaced = true;
        continue;
      }
      if (!spaced && out.length) out[out.length - 1].w += tk;
      else out.push({ w: tk, gold });
      spaced = false;
    }
    gold = !gold;
  }
  return out;
}

/** Text revealed one word at a time; the starred words are gold and bold. */
function Words({
  text,
  step,
  delay,
  run,
  style,
  goldColor,
  color,
  rtl,
}: {
  text: string;
  step: number;
  delay: number;
  /** Changes to replay the reveal; 0 keeps everything hidden. */
  run: number;
  style?: any;
  color: string;
  goldColor?: string;
  rtl?: boolean;
}) {
  const list = useMemo(() => parts(text), [text]);
  const [shown, setShown] = useState(0);
  useEffect(() => {
    setShown(0);
    if (!run) return;
    const timers: ReturnType<typeof setTimeout>[] = [];
    list.forEach((_, i) => timers.push(setTimeout(() => setShown(i + 1), delay + i * step)));
    return () => timers.forEach(clearTimeout);
  }, [run, list, delay, step]);
  return (
    <Text style={[style, rtl && { writingDirection: 'rtl', textAlign: 'right' }]}>
      {list.map((p, i) => (
        <Text
          key={i}
          style={[
            p.gold && { fontFamily: Fonts.bodyBold },
            { color: i < shown ? (p.gold ? goldColor ?? color : color) : 'transparent' },
          ]}>
          {p.w}
          {i < list.length - 1 ? ' ' : ''}
        </Text>
      ))}
    </Text>
  );
}

/** A number that counts up from zero. */
function CountUp({ to, run, style, locale }: { to: number; run: number; style?: any; locale: string }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    if (!run) {
      setN(0);
      return;
    }
    const t0 = Date.now();
    setN(0);
    const id = setInterval(() => {
      const k = Math.min(1, (Date.now() - t0) / COUNT_MS);
      setN(Math.round(to * (1 - Math.pow(1 - k, 3))));
      if (k >= 1) clearInterval(id);
    }, 40);
    return () => clearInterval(id);
  }, [to, run]);
  return <Text style={style}>{n.toLocaleString(locale)}</Text>;
}

export function WelcomeBackSheet({
  visible,
  onClose,
  onContinue,
  words,
  next,
  starFrom,
}: {
  visible: boolean;
  onClose: () => void;
  onContinue: () => void;
  /** Arabic words learned across the whole course. */
  words: number;
  next?: WelcomeNext;
  /** The star's resting place in the Today header, when it could be measured. */
  starFrom?: StarPoint | null;
}) {
  const { c } = useTheme();
  const styles = useStyles();
  const { t, locale } = useLang();
  const insets = useSafeAreaInsets();

  const [mounted, setMounted] = useState(false);
  const [landed, setLanded] = useState(false);
  const [burst, setBurst] = useState(0);
  const [markBurst, setMarkBurst] = useState(0);
  /** Reveal steps: 0 none, then the greeting, the lines and the panel in turn. */
  const [stage, setStage] = useState(0);
  const [milestone, setMilestone] = useState<number | null>(null);
  const [pace, setPace] = useState<number | null>(null);
  const [to, setTo] = useState<StarPoint | null>(null);

  const slide = useRef(new Animated.Value(1)).current;
  const veil = useRef(new Animated.Value(0)).current;
  const fly = useRef(new Animated.Value(0)).current;
  const flying = useRef(new Animated.Value(0)).current;
  const panel = useRef(new Animated.Value(0)).current;
  const bar = useRef(new Animated.Value(0)).current;
  const trans = useRef(new Animated.Value(0)).current;
  const slotRef = useRef<View>(null);
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);
  const closing = useRef(false);

  const later = (fn: () => void, ms: number) => timers.current.push(setTimeout(fn, ms));
  const clear = () => {
    timers.current.forEach(clearTimeout);
    timers.current = [];
  };

  /* ── the words and the ladder ─────────────────────────────────────── */

  const hour = useMemo(() => new Date().getHours(), [visible]); // eslint-disable-line react-hooks/exhaustive-deps
  const slot: 'morning' | 'afternoon' | 'evening' = hour < 12 ? 'morning' : hour < 18 ? 'afternoon' : 'evening';
  const step = nextMilestone(words);
  const below = prevMilestone(words);
  const top = step ?? MILESTONES[MILESTONES.length - 1];
  const toGo = Math.max(0, (step ?? top) - words);
  const far = farMilestone(words);
  const num = (n: number) => n.toLocaleString(locale);

  const when = useMemo(
    () => (pace && far ? projectMilestone(words, far, pace, locale) : null),
    [pace, far, words, locale],
  );

  const title = milestone ? t('{n} words!', { n: num(milestone) }) : slot === 'morning' ? t('Good morning!') : slot === 'afternoon' ? t('Good afternoon!') : t('Good evening!');
  const sub = milestone
    ? t('A milestone in your sky')
    : slot === 'morning'
      ? t('A new day of Arabic')
      : slot === 'afternoon'
        ? t('Ready when you are')
        : t('A quiet time to learn');

  const arabic = hour < 12 ? 'السَّلامُ عَلَيْكُم! صَباحُ الخَيْر' : 'السَّلامُ عَلَيْكُم! مَساءُ الخَيْر';
  const reading = hour < 12 ? t('Assalamu alaikum! Sabah al-khayr') : t('Assalamu alaikum! Masaa al-khayr');
  const meaning =
    slot === 'morning' ? t('Peace be upon you! Good morning') : slot === 'afternoon' ? t('Peace be upon you! Good afternoon') : t('Peace be upon you! Good evening');

  const line1 = milestone
    ? t('Welcome back — and congratulations. You have just passed *{n} words*, half the way to *{next}*.', { n: num(milestone), next: num(step ?? top) })
    : slot === 'evening'
      ? t('Good to see you tonight. You have learned *{n} Arabic words* — ten quiet minutes still count.', { n: num(words) })
      : t('Welcome back! You have learned *{n} Arabic words* so far — more than most learners reach in a year.', { n: num(words) });

  const line2 = !step
    ? ''
    : pace && far && when
      ? t('That is *{n} words* from your next milestone, and at *+{p} words a week* you will pass *{far} words* by *{when}*.', {
          n: num(toGo),
          p: num(pace),
          far: num(far),
          when,
        })
      : t('That is *{n} words* from your next milestone.', { n: num(toGo) });

  const arWords = arabic.split(/\s+/).length;
  const l1 = parts(line1).length;
  const arEnd = AR_STEP * arWords + 150;
  const line1At = arEnd + 500;
  const line2At = line1At + l1 * LINE_STEP + 600;
  const panelAt = line1At + 400;

  /* ── opening ──────────────────────────────────────────────────────── */

  const measure = useCallback(() => {
    slotRef.current?.measureInWindow((x, y, w, h) => {
      if (w > 0) setTo({ x: x + w / 2, y: y + h / 2, size: w });
    });
  }, []);

  useEffect(() => {
    if (!visible) {
      if (!closing.current) setMounted(false);
      return;
    }
    closing.current = false;
    setMounted(true);
    setLanded(false);
    setStage(0);
    setMilestone(null);
    setPace(null);
    slide.setValue(1);
    veil.setValue(0);
    fly.setValue(0);
    flying.setValue(0);
    panel.setValue(0);
    bar.setValue(0);
    trans.setValue(0);
    takeMilestone(words).then(setMilestone);
    wordPace(words).then(setPace);
    Animated.parallel([
      Animated.timing(veil, { toValue: 1, duration: 300, useNativeDriver: true }),
      Animated.spring(slide, { toValue: 0, useNativeDriver: true, damping: 20, stiffness: 180, mass: 0.9 }),
    ]).start();
    later(measure, FLY_AT - 120);
    later(() => {
      flying.setValue(1);
      Animated.timing(fly, { toValue: 1, duration: FLY_MS, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
    }, FLY_AT);
    later(() => {
      flying.setValue(0);
      setLanded(true);
      setBurst((b) => b + 1);
      setStage(1);
    }, FLY_AT + FLY_MS);
    later(() => Animated.timing(trans, { toValue: 1, duration: 350, useNativeDriver: true }).start(), FLY_AT + FLY_MS + arEnd + 120);
    later(() => setStage(2), FLY_AT + FLY_MS + line1At);
    later(() => {
      setStage(3);
      Animated.timing(panel, { toValue: 1, duration: 420, useNativeDriver: true }).start();
      Animated.timing(bar, { toValue: 1, duration: 1100, delay: 150, easing: Easing.out(Easing.cubic), useNativeDriver: false }).start();
    }, FLY_AT + FLY_MS + panelAt);
    later(() => setStage(4), FLY_AT + FLY_MS + line2At);
    return clear;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visible]);

  // The milestone marker sparkles once the bar has run up to it.
  useEffect(() => {
    if (stage >= 3 && milestone) {
      const id = setTimeout(() => setMarkBurst((b) => b + 1), 1300);
      return () => clearTimeout(id);
    }
  }, [stage, milestone]);

  /* ── closing: the star flies home ─────────────────────────────────── */

  const leave = (after: () => void) => {
    if (closing.current) return;
    closing.current = true;
    clear();
    setLanded(false);
    flying.setValue(1);
    Animated.timing(fly, { toValue: 0, duration: 620, easing: Easing.inOut(Easing.cubic), useNativeDriver: true }).start();
    Animated.parallel([
      Animated.timing(veil, { toValue: 0, duration: 420, delay: 160, useNativeDriver: true }),
      Animated.timing(slide, { toValue: 1, duration: 420, delay: 160, easing: Easing.in(Easing.cubic), useNativeDriver: true }),
    ]).start();
    setTimeout(() => {
      flying.setValue(0);
      setMounted(false);
      closing.current = false;
      after();
    }, 640);
  };

  /* ── the flight path ──────────────────────────────────────────────── */

  const from: StarPoint = starFrom ?? { x: to?.x ?? 60, y: (to?.y ?? 300) - 260, size: 40 };
  const path = useMemo(() => {
    const a = from;
    const b = to ?? { x: from.x, y: from.y + 200, size: STAR_SIZE };
    const mx = (a.x + b.x) / 2 + (a.x > b.x ? 70 : -70);
    const my = Math.min(a.y, b.y) - 90;
    const xs: number[] = [];
    const ys: number[] = [];
    const ks: number[] = [];
    for (let i = 0; i <= 12; i++) {
      const k = i / 12;
      ks.push(k);
      xs.push((1 - k) * (1 - k) * a.x + 2 * (1 - k) * k * mx + k * k * b.x);
      ys.push((1 - k) * (1 - k) * a.y + 2 * (1 - k) * k * my + k * k * b.y);
    }
    return { ks, xs, ys, a, b };
  }, [from.x, from.y, to?.x, to?.y]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!mounted) return null;

  const barTo = Math.min(1, words / Math.max(1, top));
  const markLeft = (v: number) => `${Math.min(100, Math.max(0, (v / Math.max(1, top)) * 100))}%` as const;

  return (
    <Modal visible transparent animationType="none" onRequestClose={() => leave(onClose)} statusBarTranslucent>
      <Animated.View style={[styles.backdropWrap, { opacity: veil }]}>
        <Pressable style={StyleSheet.absoluteFill} onPress={() => leave(onClose)} accessibilityLabel={t('Not now')} />
      </Animated.View>

      <Animated.View
        style={[
          styles.sheet,
          {
            paddingBottom: insets.bottom + 14,
            maxHeight: '94%',
            transform: [{ translateY: slide.interpolate({ inputRange: [0, 1], outputRange: [0, 800] }) }],
          },
        ]}>
        {c.scheme === 'dark' ? (
          <LinearGradient pointerEvents="none" colors={c.navyGrad} start={{ x: 0.2, y: 0 }} end={{ x: 0.8, y: 1 }} style={styles.sheetFill} />
        ) : null}
        <View style={styles.grabber} />
        <ScrollView style={{ flexShrink: 1 }} showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 4 }} bounces={false}>
          {/* Title row: the star lands here */}
          <View style={styles.titleRow}>
            <View ref={slotRef} collapsable={false} onLayout={measure} style={styles.slot}>
              <View style={{ opacity: landed ? 1 : 0 }}>
                <GoldStar size={STAR_SIZE} />
              </View>
              <SparkleBurst trigger={burst} count={12} radius={48} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.title}>{title}</Text>
              <Text style={styles.sub}>{sub}</Text>
            </View>
          </View>

          {/* One bubble: the greeting only */}
          <View style={styles.bubble}>
            <View style={styles.bubbleTail} />
            <Words text={arabic} step={AR_STEP} delay={150} run={stage >= 1 ? 1 : 0} style={styles.arabic} color="#16213a" rtl />
            <Animated.View style={{ opacity: trans }}>
              <Text style={styles.reading}>{reading}</Text>
              <Text style={styles.meaning}>{meaning}</Text>
            </Animated.View>
          </View>

          {/* Two short lines, on the sheet itself */}
          <View style={styles.lines}>
            {stage >= 2 ? (
            <Words text={line1} step={LINE_STEP} delay={0} run={stage >= 2 ? 1 : 0} style={styles.line} goldColor={c.gold} color={c.scheme === 'dark' ? '#dbe2f0' : c.text} />
            ) : null}
            {line2 && stage >= 4 ? (
              <Words
                text={line2}
                step={LINE_STEP}
                delay={0}
                run={stage >= 4 ? 1 : 0}
                style={[styles.line, { marginTop: 6 }]}
                goldColor={c.gold}
                color={c.scheme === 'dark' ? '#dbe2f0' : c.text}
              />
            ) : null}
          </View>

          {/* The quiet panel: the count and the ladder */}
          {stage >= 3 ? (
          <Animated.View style={[styles.panel, { opacity: panel, transform: [{ translateY: panel.interpolate({ inputRange: [0, 1], outputRange: [10, 0] }) }] }]}>
            <CountUp to={words} run={stage >= 3 ? 1 : 0} style={styles.big} locale={locale} />
            <Text style={styles.wordsLabel}>{t('WORDS YOU KNOW')}</Text>
            <View style={styles.track}>
              <Animated.View
                style={[styles.fill, { width: bar.interpolate({ inputRange: [0, 1], outputRange: ['0%', `${Math.round(barTo * 100)}%`] }) }]}
              />
              <Mark left="0%" done />
              {below > 0 ? (
                <Mark left={markLeft(below)} done burst={milestone === below ? markBurst : 0} />
              ) : null}
              <Mark left="100%" done={words >= top} />
            </View>
            <View style={styles.marks}>
              <Text style={styles.markText}>0</Text>
              {below > 0 ? <Text style={styles.markText}>{num(below)}</Text> : null}
              <Text style={styles.markText}>{num(top)}</Text>
            </View>
            {step ? (
              <Words
                text={t('*{n} words* to your next milestone: *{next}*', { n: num(toGo), next: num(step) })}
                step={LINE_STEP}
                delay={200}
                run={stage >= 3 ? 1 : 0}
                style={styles.goLine}
                goldColor={c.gold}
                color={c.muted}
              />
            ) : null}
          </Animated.View>
          ) : null}

          {/* Up next */}
          {next ? (
            <View style={styles.next}>
              <CardFill radius={16} />
              <View style={styles.nextIcon}>
                <Icon name={next.icon} size={22} color={c.gold} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.nextKick} numberOfLines={1}>
                  {t('Up next · {unit}', { unit: next.kicker })}
                </Text>
                <Text style={styles.nextTitle} numberOfLines={1}>
                  {next.title}
                </Text>
              </View>
              {next.locked ? <Icon name="lock" size={18} color={c.faint} /> : null}
            </View>
          ) : null}

        </ScrollView>

        {/* The buttons stay in reach, even on a short screen */}
        <Pressable onPress={() => leave(onContinue)} style={({ pressed }) => [styles.btn, pressed && { opacity: 0.9, transform: [{ scale: 0.98 }] }]}>
          <Text style={styles.btnText}>{t('Start the lesson')}</Text>
          <Icon name="arrow_forward" size={20} color={c.btnText} />
        </Pressable>
        <Pressable onPress={() => leave(onClose)} hitSlop={8} style={styles.later}>
          <Text style={styles.laterText}>{t('Not now')}</Text>
        </Pressable>
      </Animated.View>

      {/* The star in flight, above everything */}
      <Animated.View
        pointerEvents="none"
        style={[
          styles.flyer,
          {
            opacity: flying,
            transform: [
              { translateX: fly.interpolate({ inputRange: path.ks, outputRange: path.xs.map((x) => x - STAR_SIZE / 2) }) },
              { translateY: fly.interpolate({ inputRange: path.ks, outputRange: path.ys.map((y) => y - STAR_SIZE / 2) }) },
              { rotate: fly.interpolate({ inputRange: [0, 1], outputRange: ['-360deg', '0deg'] }) },
              { scale: fly.interpolate({ inputRange: [0, 1], outputRange: [(path.a.size || 40) / STAR_SIZE, 1] }) },
            ],
          },
        ]}>
        <GoldStar size={STAR_SIZE} />
      </Animated.View>
    </Modal>
  );
}

function Mark({ left, done, burst = 0 }: { left: string; done: boolean; burst?: number }) {
  const styles = useStyles();
  return (
    <View style={[styles.mark, done && styles.markDone, { left: left as any }]}>
      {burst ? <SparkleBurst trigger={burst} count={10} radius={34} /> : null}
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  backdropWrap: { ...StyleSheet.absoluteFill, backgroundColor: 'rgba(4,8,18,0.58)' },
  sheet: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: c.card,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderTopWidth: 1,
    borderColor: c.scheme === 'dark' ? 'rgba(214,178,90,0.30)' : c.line,
    paddingHorizontal: 20,
    paddingTop: 10,
    boxShadow: c.scheme === 'dark' ? '0 -12px 40px rgba(0,0,0,0.45)' : '0 -10px 30px rgba(22,33,58,0.12)',
  },
  sheetFill: { position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, borderTopLeftRadius: 27, borderTopRightRadius: 27 },
  grabber: { width: 40, height: 5, borderRadius: 3, backgroundColor: c.scheme === 'dark' ? 'rgba(255,255,255,0.18)' : c.line, alignSelf: 'center', marginBottom: 8 },

  titleRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingTop: 2, paddingBottom: 8 },
  slot: { width: STAR_SIZE, height: STAR_SIZE, alignItems: 'center', justifyContent: 'center' },
  title: { fontFamily: Fonts.displayBold, fontSize: 23, color: c.text },
  sub: { fontFamily: Fonts.bodySemi, fontSize: 12.5, letterSpacing: 0.4, color: c.gold, marginTop: 2 },

  bubble: { marginTop: 10, backgroundColor: '#ffffff', borderRadius: 16, paddingHorizontal: 14, paddingVertical: 11 },
  bubbleTail: { position: 'absolute', left: 24, top: -6, width: 12, height: 12, backgroundColor: '#ffffff', transform: [{ rotate: '45deg' }] },
  arabic: { fontFamily: Fonts.arabicBold, fontSize: 25, lineHeight: 42, color: '#16213a' },
  reading: { fontFamily: Fonts.bodySemi, fontSize: 12.5, color: '#5a6680', marginTop: 3 },
  meaning: { fontFamily: Fonts.bodySemi, fontSize: 12.5, color: '#8a6d1f', marginTop: 2 },

  lines: { marginTop: 14 },
  line: { fontFamily: Fonts.body, fontSize: 14.5, lineHeight: 22, color: c.scheme === 'dark' ? '#dbe2f0' : c.text },

  panel: {
    marginTop: 14,
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingTop: 14,
    paddingBottom: 12,
    backgroundColor: c.scheme === 'dark' ? 'rgba(14,23,48,0.75)' : c.raised,
    borderWidth: 1,
    borderColor: c.scheme === 'dark' ? 'rgba(214,178,90,0.22)' : c.line,
  },
  big: { fontFamily: Fonts.bodyBold, fontSize: 42, lineHeight: 48, color: c.text, textAlign: 'center' },
  wordsLabel: { fontFamily: Fonts.bodyBold, fontSize: 11, letterSpacing: 2, color: c.gold, textAlign: 'center', marginTop: 4 },
  track: { height: 8, borderRadius: 4, backgroundColor: c.track, marginTop: 16, marginHorizontal: 8 },
  fill: { height: 8, borderRadius: 4, backgroundColor: c.goldFill },
  mark: {
    position: 'absolute',
    top: -4,
    width: 16,
    height: 16,
    marginLeft: -8,
    borderRadius: 8,
    backgroundColor: c.scheme === 'dark' ? '#16223c' : c.card,
    borderWidth: 1.5,
    borderColor: 'rgba(214,178,90,0.5)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  markDone: { backgroundColor: c.goldFill, borderColor: c.goldFill },
  marks: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 12, marginHorizontal: 2 },
  markText: { fontFamily: Fonts.body, fontSize: 11, color: c.muted },
  goLine: { fontFamily: Fonts.body, fontSize: 13, lineHeight: 19, color: c.muted, textAlign: 'center', marginTop: 10 },

  next: { ...spaceCard(c), ...currentCard(c), flexDirection: 'row', alignItems: 'center', gap: 12, padding: 12, borderRadius: 16, marginTop: 14 },
  nextIcon: { width: 44, height: 44, borderRadius: 13, backgroundColor: c.goldTint, alignItems: 'center', justifyContent: 'center' },
  nextKick: { fontFamily: Fonts.body, fontSize: 12, color: c.muted },
  nextTitle: { fontFamily: Fonts.bodyBold, fontSize: 15.5, color: c.text, marginTop: 1 },

  btn: {
    height: 52,
    borderRadius: 26,
    backgroundColor: c.btnBg,
    borderWidth: 1.2,
    borderColor: c.btnBorder,
    marginTop: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  btnText: { fontFamily: Fonts.bodyBold, fontSize: 16, color: c.btnText },
  later: { alignSelf: 'center', paddingVertical: 10, paddingHorizontal: 20 },
  laterText: { fontFamily: Fonts.bodySemi, fontSize: 14, color: c.muted },

  flyer: { position: 'absolute', left: 0, top: 0, width: STAR_SIZE, height: STAR_SIZE },
}));
