/**
 * Lisaany design tokens.
 *
 * Lifted from the CSS in arabic_platform.html so the native app and the web
 * platform read as one product. The web file has five stacked `:root` blocks
 * that override each other with `!important`; these are the values that
 * actually win.
 */

/** Public Supabase project (same one the web app uses). */
export const SUPABASE_URL =
  process.env.EXPO_PUBLIC_SUPABASE_URL ?? 'https://cfaxrzfqvoalwznkhwnx.supabase.co';

/** Publishable (anon) key — safe to ship in a client. */
export const SUPABASE_ANON_KEY =
  process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ??
  'sb_publishable_JzVuIvyj2OEP4o0zbURcQA_NhfBFPaa';

/** Cloudflare Worker that serves the site + /api/* routes. */
export const WEB_BASE = process.env.EXPO_PUBLIC_WEB_BASE ?? 'https://lisaany.com';

export const Colors = {
  /** Page ground. */
  bg: '#0b1223',
  /** Raised surfaces, lightest to deepest. */
  s1: '#1a2539',
  s2: '#111d36',
  s3: '#1e2a42',

  card: '#1e2a42',
  cardElev: 'rgba(37,49,73,0.96)',
  cardHover: '#27344e',

  border: 'rgba(255,255,255,0.16)',
  borderStrong: 'rgba(255,255,255,0.22)',
  faint: 'rgba(255,255,255,0.07)',

  /** Primary text. The web design deliberately keeps secondary text at full
   *  brightness too, so hierarchy comes from size, weight and letter-spacing. */
  text: '#f3f6fc',
  dim: '#f3f6fc',
  /** Cream used for the largest display headings. */
  cream: '#f5e8c5',

  gold: '#d6b25a',
  goldLight: '#e8c86a',
  goldDeep: '#8a6420',
  goldMuted: '#d4a34a',
  goldGlow: 'rgba(214,178,90,0.18)',
  /** Text colour on a filled gold surface. */
  onGold: '#3a2400',

  green: '#d6b25a',
  mint: '#d6b25a',
  red: '#e07070',
  blue: '#7a9cc8',
  purple: '#9c7ab8',
} as const;

/** Gradient stop pairs for expo-linear-gradient. */
export const Gradients = {
  /** Module and list cards — 158° in CSS. */
  card: ['rgba(36,48,73,0.92)', 'rgba(20,29,51,0.92)'] as const,
  /** Hero panels — vertical. */
  hero: ['rgba(42,56,86,0.95)', 'rgba(24,34,58,0.95)'] as const,
  /** Lesson header — vertical, slightly lifted. */
  header: [Colors.cardElev, Colors.card] as const,
  /** The gold "continue" treatment. */
  gold: ['rgba(214,178,90,0.12)', 'rgba(214,178,90,0.04)'] as const,
  /** Progress / journey bar — fainter gold. */
  goldFaint: ['rgba(214,178,90,0.08)', 'rgba(214,178,90,0.02)'] as const,
} as const;

export const Fonts = {
  /** Cinzel — display face for titles, unit names, section headings. */
  display: 'Cinzel_600SemiBold',
  displayBold: 'Cinzel_700Bold',
  displayRegular: 'Cinzel_400Regular',
  /** Amiri — every word of Arabic in the app. */
  arabic: 'Amiri_400Regular',
  arabicBold: 'Amiri_700Bold',
  /**
   * Noto Naskh — Arabic carrying vowel marks (Norania). Amiri lifts stacked
   * marks (a shaddah with its vowel) off the letter on phones; Naskh keeps them
   * attached.
   */
  naskh: 'NotoNaskhArabic_400Regular',
  /** Inter — UI, body copy, meta labels. */
  body: 'Inter_400Regular',
  bodyMedium: 'Inter_500Medium',
  bodySemi: 'Inter_600SemiBold',
  bodyBold: 'Inter_700Bold',
  /** Material Symbols Outlined — renders the icon names in the curriculum. */
  icons: 'MaterialSymbolsOutlined_400Regular',
} as const;

export const Radius = {
  sm: 12,
  md: 16,
  card: 18,
  lg: 22,
  pill: 999,
} as const;

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
} as const;

/** Layered shadows from the web cards. */
export const Shadows = {
  card: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.34,
    shadowRadius: 30,
    elevation: 8,
  },
  soft: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.26,
    shadowRadius: 24,
    elevation: 5,
  },
  goldGlow: {
    shadowColor: Colors.goldMuted,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.35,
    shadowRadius: 18,
    elevation: 6,
  },
} as const;

/** Letter-spacing values the web design leans on heavily for small caps. */
export const Tracking = {
  eyebrow: 2.4,
  heading: 3.1,
  meta: 1.8,
  tight: 0.2,
} as const;
