/**
 * Keeps reminders and the email backend in step with the app:
 *  - start-up and every return to the foreground: reschedule the next 7 days
 *    of reminders (a new day, a goal met elsewhere, a changed setting);
 *  - going to the background: report today's minutes right away;
 *  - language change or sign-in: re-send the email preferences and reword the
 *    scheduled reminders.
 */
import { useEffect, useRef } from 'react';
import { AppState, type AppStateStatus } from 'react-native';

import { useAuth } from '@/lib/auth-context';
import { reportMinutes, syncEmailPrefs } from '@/lib/email-reminders';
import { useLang } from '@/lib/i18n';
import { initReminders, rescheduleReminders } from '@/lib/reminders';

export function useGoalReminders() {
  const { lang } = useLang();
  const { session } = useAuth();
  const first = useRef(true);

  useEffect(() => {
    initReminders();
    rescheduleReminders();
    const onChange = (state: AppStateStatus) => {
      if (state === 'active') rescheduleReminders();
      else if (state === 'background') {
        reportMinutes(true);
        // the "days away" countdown starts from the moment they leave
        rescheduleReminders();
      }
    };
    const sub = AppState.addEventListener('change', onChange);
    return () => sub.remove();
  }, []);

  // Language: the reminder text follows it. (Skipped on mount — the effect above covers it.)
  useEffect(() => {
    if (first.current) {
      first.current = false;
      return;
    }
    rescheduleReminders();
    syncEmailPrefs();
  }, [lang]);

  const userId = session?.user?.id;
  useEffect(() => {
    if (userId) syncEmailPrefs();
  }, [userId]);
}
