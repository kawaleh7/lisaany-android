/**
 * Keeps reminders and the email backend in step with the app:
 *  - start-up and every return to the foreground: reschedule the "days away"
 *    reminders (a new day, a goal met elsewhere, a changed setting);
 *  - going to the background: report today's minutes right away;
 *  - language change or sign-in: re-send the email preferences and reword the
 *    scheduled reminders;
 *  - a tap on one of our reminders (while running, or the tap that started
 *    the app) opens Today.
 */
import { router } from 'expo-router';
import { useEffect, useRef } from 'react';
import { AppState, type AppStateStatus } from 'react-native';

import { useAuth } from '@/lib/auth-context';
import { reportMinutes, syncEmailPrefs } from '@/lib/email-reminders';
import { useLang } from '@/lib/i18n';
import { initReminders, rescheduleReminders, watchReminderTaps } from '@/lib/reminders';

/** The reminders carry `data.url: '/'` — Today is where they lead. */
function openToday() {
  try {
    if (router.canDismiss()) router.dismissAll();
    router.replace('/');
  } catch {
    /* navigation not ready yet (cold start lands on Today anyway) */
  }
}

export function useGoalReminders() {
  const { lang } = useLang();
  const { session } = useAuth();
  const first = useRef(true);

  useEffect(() => {
    initReminders();
    rescheduleReminders();
    const stopTaps = watchReminderTaps(openToday);
    const onChange = (state: AppStateStatus) => {
      if (state === 'active') rescheduleReminders();
      else if (state === 'background') {
        reportMinutes(true);
        // the "days away" countdown starts from the moment they leave
        rescheduleReminders();
      }
    };
    const sub = AppState.addEventListener('change', onChange);
    return () => {
      sub.remove();
      stopTaps();
    };
  }, []);

  // Language: the reminder text follows it. (Skipped on mount — the effect above covers it.)
  useEffect(() => {
    if (first.current) {
      first.current = false;
      return;
    }
    rescheduleReminders();
    syncEmailPrefs();
  }, [lang]);

  const userId = session?.user?.id;
  useEffect(() => {
    if (userId) syncEmailPrefs();
  }, [userId]);
}
