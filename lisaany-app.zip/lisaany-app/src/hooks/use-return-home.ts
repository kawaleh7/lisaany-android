/**
 * After a long break, reopen the app on Today and welcome the learner back.
 *
 * A short switch away (answering a message mid-lesson) keeps the learner in
 * place. After RETURN_HOME_AFTER_MS away, any open lesson, sheet or modal is
 * closed, Today is shown and the welcome-back sheet slides up. The same
 * happens when the phone had closed the app and it starts again after a long
 * break. Lesson progress is saved as it happens, so nothing is lost.
 */
import { router } from 'expo-router';
import { useEffect, useRef } from 'react';
import { AppState, type AppStateStatus } from 'react-native';

import { dayOf, getLastActive, markWelcomeBack, saveLastActive } from '@/lib/welcome-back';

export const RETURN_HOME_AFTER_MS = 30 * 60 * 1000;

export function useReturnHome() {
  const leftAt = useRef<number | null>(null);

  useEffect(() => {
    // Cold start: the phone closed the app while it was away.
    getLastActive().then((last) => {
      if (last === null) return;
      if (dayOf(last) !== dayOf(Date.now())) markWelcomeBack('newday');
      else if (Date.now() - last >= RETURN_HOME_AFTER_MS) markWelcomeBack('return');
    });

    const onChange = (state: AppStateStatus) => {
      if (state === 'background') {
        leftAt.current = Date.now();
        saveLastActive(leftAt.current);
        return;
      }
      if (state !== 'active' || leftAt.current === null) return;
      const away = Date.now() - leftAt.current;
      const newDay = dayOf(leftAt.current) !== dayOf(Date.now());
      leftAt.current = null;
      if (!newDay && away < RETURN_HOME_AFTER_MS) return;
      markWelcomeBack(newDay ? 'newday' : 'return');
      try {
        if (router.canDismiss()) router.dismissAll();
        router.replace('/');
      } catch {
        /* navigation not ready — stay where we are */
      }
    };
    const sub = AppState.addEventListener('change', onChange);
    return () => sub.remove();
  }, []);
}
