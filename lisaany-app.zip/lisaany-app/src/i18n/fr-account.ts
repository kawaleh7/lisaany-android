/** French strings — account screens. English text is the key. */
export const FR_ACCOUNT: Record<string, string> = {
  // sign-in.tsx — forgot password
  'Forgot your password?': 'Mot de passe oublié ?',
  'Enter your email first, then tap Forgot your password.': 'Saisissez d’abord votre courriel, puis touchez « Mot de passe oublié ».',
  'Check your email for a link to choose a new password.': 'Consultez vos courriels : un lien vous permet de choisir un nouveau mot de passe.',

  // profile.tsx — the star
  'Your daily goal, reminders, sounds, language and account are all in Settings.':
    'Objectif du jour, rappels, sons, langue et compte : tout est dans les réglages.',

  // profile.tsx — Learning settings (reminders only go out after days away)
  'Minutes of Arabic a day. Today’s ring fills as you learn.': 'Minutes d’arabe par jour. L’anneau du jour se remplit à mesure que vous apprenez.',
  'A nudge if you have been away for a few days. Nothing while you keep learning.':
    'Un petit rappel si vous vous absentez quelques jours. Rien tant que vous continuez d’apprendre.',

  // profile.tsx — plan, billing, restore
  'Manage subscription': 'Gérer l’abonnement',
  'Your subscription was set up on lisaany.com. Manage or cancel it from your account there.':
    'Votre abonnement a été souscrit sur lisaany.com. Gérez-le ou résiliez-le depuis votre compte là-bas.',
  'Lisaany Premium is active on this device.': 'Lisaany Premium est actif sur cet appareil.',

  // profile.tsx — delete account
  'An App Store subscription is not cancelled automatically — cancel it in Settings → Apple ID → Subscriptions.':
    'Un abonnement App Store n’est pas résilié automatiquement : résiliez-le dans Réglages → Identifiant Apple → Abonnements.',
  'A Google Play subscription is not cancelled automatically — cancel it in Google Play → Subscriptions.':
    'Un abonnement Google Play n’est pas résilié automatiquement : résiliez-le dans Google Play → Abonnements.',
  'If you subscribed on lisaany.com, cancel the subscription there first.':
    'Si vous vous êtes abonné sur lisaany.com, résiliez d’abord l’abonnement là-bas.',

  // lessons.tsx — the pill on a locked module
  'Premium': 'Premium',
  'Staff access': 'Accès équipe',
  'Every lesson is open on this account through staff access. There is no subscription to manage.': 'Toutes les leçons sont ouvertes sur ce compte grâce à l’accès équipe. Il n’y a pas d’abonnement à gérer.',
  'There is already an account with this email. Sign in, or tap Forgot your password.': 'Un compte existe déjà avec cette adresse. Connectez-vous, ou touchez Mot de passe oublié ?',
  'Email me once a month if I’m away?': 'M’envoyer un e-mail par mois si je m’absente ?',
  'If you stop learning, Lisaany sends one friendly email a month to help you come back. Never while you keep learning. Unsubscribe anytime.': 'Si vous arrêtez d’apprendre, Lisaany vous envoie un petit e-mail par mois pour vous aider à revenir. Jamais tant que vous continuez. Désabonnement à tout moment.',
  'Yes, email me': 'Oui, envoyez-moi un e-mail',
  'One email a month if you have been away. You can unsubscribe at any time.': 'Un e-mail par mois si vous vous êtes absenté. Vous pouvez vous désabonner à tout moment.',
  'ON': 'OUI',
  'OFF': 'NON',
};
