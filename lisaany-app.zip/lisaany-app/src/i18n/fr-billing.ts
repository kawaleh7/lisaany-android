/** French strings — billing screens. English text is the key. */
export const FR_BILLING: Record<string, string> = {
  // plans.tsx — store prices only, both platforms
  '{price} a month · save {pct}%': '{price} par mois · économisez {pct} %',
  'Sign in to keep progress on phone and web': 'Connectez-vous pour garder votre progression sur mobile et sur le Web',
  'Premium is not available in this version yet': "Premium n'est pas encore disponible dans cette version",
  'If you already have Lisaany Premium, sign in and your lessons open here.':
    'Si vous avez déjà Lisaany Premium, connectez-vous et vos leçons s’ouvrent ici.',
  'Check again': 'Vérifier à nouveau',
  'There is no Lisaany Premium subscription on this Google account.': "Aucun abonnement Lisaany Premium n'est associé à ce compte Google.",
  'Payment is charged to your Google Play account when you confirm. The subscription renews automatically unless it is cancelled at least 24 hours before the end of the current period. Manage or cancel it anytime in Google Play → Subscriptions.':
    'Le paiement est débité de votre compte Google Play à la confirmation. L’abonnement se renouvelle automatiquement, sauf s’il est annulé au moins 24 heures avant la fin de la période en cours. Gérez-le ou annulez-le à tout moment dans Google Play → Abonnements.',

  // Plan labels (PLAN_LABELS in lib/plan.ts — translated at render with t())
  'Premium — monthly': 'Premium — mensuel',
  'Premium — yearly': 'Premium — annuel',
  'Prices could not be loaded': 'Les prix n’ont pas pu être chargés',
  'Check your connection and tap Check again. If you already have Lisaany Premium, sign in and your lessons open here.': 'Vérifiez votre connexion et touchez Vérifier à nouveau. Si vous avez déjà Lisaany Premium, connectez-vous et vos leçons s’ouvrent ici.',
  'Purchases are not available on this device.': 'Les achats ne sont pas disponibles sur cet appareil.',
  'Premium is available on lisaany.com': 'Premium est disponible sur lisaany.com',
  'It is not sold in this app. Once you have it, sign in here with the same account and every lesson opens.': 'Il n’est pas vendu dans cette application. Une fois abonné, connectez-vous ici avec le même compte et toutes les leçons s’ouvrent.',
};
