/** French strings — lesson screens. English text is the key. */
export const FR_LESSON: Record<string, string> = {
  // Opening overlay / failure state (lesson and Norania web views)
  'This is taking longer than usual.': 'Cela prend plus de temps que d’habitude.',
  'The lesson could not be opened.': 'La leçon n’a pas pu s’ouvrir.',
  'Try again': 'Réessayer',
};
