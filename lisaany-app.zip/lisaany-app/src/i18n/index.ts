/** French UI strings, merged from one file per group of screens. */
import { FR_CIRCLE } from './fr-circle';
import { FR_COURSE } from './fr-course';
import { FR_GOAL } from './fr-goal';
import { FR_HOME } from './fr-home';
import { FR_NORANIA } from './fr-norania';
import { FR_START } from './fr-start';
import { FR_BILLING } from './fr-billing';
import { FR_ACCOUNT } from './fr-account';
import { FR_LESSON } from './fr-lesson';

export const FR: Record<string, string> = { ...FR_START, ...FR_HOME, ...FR_COURSE, ...FR_NORANIA, ...FR_CIRCLE, ...FR_GOAL, ...FR_BILLING, ...FR_ACCOUNT, ...FR_LESSON };
