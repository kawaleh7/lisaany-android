/** French UI strings, merged from one file per group of screens. */
import { FR_COURSE } from './fr-course';
import { FR_HOME } from './fr-home';
import { FR_NORANIA } from './fr-norania';
import { FR_START } from './fr-start';

export const FR: Record<string, string> = { ...FR_START, ...FR_HOME, ...FR_COURSE, ...FR_NORANIA };
