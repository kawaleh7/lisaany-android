/**
 * Thin client for the Lisaany Cloudflare Worker (src/index.js in the web repo).
 *
 * Every /api/* route the worker exposes is reachable from here; the handful
 * below are the ones the mobile app needs first. Add more as you port screens.
 */
import { WEB_BASE } from '@/constants/lisaany';

import { supabase } from './supabase';

async function authHeaders(): Promise<Record<string, string>> {
  const {
    data: { session },
  } = await supabase.auth.getSession();

  return session?.access_token
    ? { Authorization: `Bearer ${session.access_token}` }
    : {};
}

export async function apiPost<T = unknown>(path: string, body?: unknown): Promise<T> {
  const res = await fetch(`${WEB_BASE}${path}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(await authHeaders()),
    },
    body: JSON.stringify(body ?? {}),
  });

  const text = await res.text();
  let parsed: unknown;
  try {
    parsed = text ? JSON.parse(text) : null;
  } catch {
    throw new Error(`${path} returned non-JSON (${res.status}): ${text.slice(0, 200)}`);
  }

  if (!res.ok) {
    const message =
      (parsed as { error?: string } | null)?.error ?? `${path} failed (${res.status})`;
    throw new Error(message);
  }

  return parsed as T;
}

/** The class this student belongs to, if any. */
export function myClass() {
  return apiPost<{ class?: { id: string; name: string } }>('/api/my-class');
}

/** Join a class with the teacher's PIN. */
export function lookupByPin(pin: string) {
  return apiPost('/api/lookup-by-pin', { pin });
}
