import type { Session } from '@supabase/supabase-js';
import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';

import { getPlan, invalidatePlanCache, type Plan } from './plan';
import { STORE_ENABLED, syncStoreUser } from './store';
import { supabase } from './supabase';

type AuthState = {
  session: Session | null;
  plan: Plan;
  /** True until the stored session has been read back from disk. */
  loading: boolean;
  signOut: () => Promise<void>;
  refreshPlan: () => Promise<void>;
};

const AuthContext = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [plan, setPlan] = useState<Plan>('free');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;

    supabase.auth.getSession().then(({ data }) => {
      if (!active) return;
      setSession(data.session);
      setLoading(false);
    });

    const { data: sub } = supabase.auth.onAuthStateChange((_event, next) => {
      setSession(next);
      invalidatePlanCache();
    });

    return () => {
      active = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  useEffect(() => {
    let active = true;
    const userId = session?.user?.id ?? null;
    // Without a session only an App Store purchase (iPhone) can make the plan paid.
    if (!userId && !STORE_ENABLED) {
      setPlan('free');
      return;
    }
    syncStoreUser(userId)
      .then(() => {
        invalidatePlanCache();
        return getPlan();
      })
      .then((p) => {
        if (active) setPlan(p);
      });
    return () => {
      active = false;
    };
  }, [session]);

  const value = useMemo<AuthState>(
    () => ({
      session,
      plan,
      loading,
      signOut: async () => {
        await supabase.auth.signOut();
        invalidatePlanCache();
      },
      refreshPlan: async () => {
        invalidatePlanCache();
        setPlan(await getPlan());
      },
    }),
    [session, plan, loading]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>');
  return ctx;
}
