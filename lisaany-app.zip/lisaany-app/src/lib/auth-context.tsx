/**
 * Session, plan and the learner's cloud progress.
 *
 * Besides holding the Supabase session and the resolved plan, this provider
 * is where the app talks to the cloud on the learner's behalf when no lesson
 * is open:
 *  - at start-up with a stored session, on every sign-in, and when the app
 *    comes back to the foreground after a long break, it PULLS the course
 *    row (`learner_progress`) and the Norania row (`norania_progress`) into
 *    the local mirror, so a returning web learner — or the same learner on a
 *    second phone — sees their real XP, streak and "Continue" unit at once;
 *  - `progressVersion` goes up after each pull and after sign-out, so the
 *    Today / Lessons / Profile screens re-read the mirror;
 *  - sign-out and account deletion flush what is still queued for the cloud
 *    and then wipe everything on the device that belongs to the learner
 *    (progress.ts clearLearnerData, plan.ts clearPersistedPlan), so the next
 *    person on the phone starts clean;
 *  - AppState drives `startAutoRefresh` / `stopAutoRefresh`, as the Supabase
 *    React Native setup requires, so tokens are refreshed while the app is in
 *    the foreground and never rotated behind the lesson page's back.
 */
import type { Session } from '@supabase/supabase-js';
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { AppState, type AppStateStatus } from 'react-native';

import { flushCloudProgress, pullCloudProgress } from './cloud-progress';
import { flushNoraniaProgress, pullNoraniaProgress } from './norania';
import { clearPersistedPlan, getPlan, invalidatePlanCache, type Plan } from './plan';
import { adoptLastUnitFromCloud, clearLearnerData, getEngineProgress, startDayFrom } from './progress';
import { reportError } from './report';
import { STORE_ENABLED, syncStoreUser } from './store';
import { readStoredSession, supabase } from './supabase';

type AuthState = {
  session: Session | null;
  plan: Plan;
  /** True until the stored session has been read back from disk. */
  loading: boolean;
  /**
   * Goes up whenever the local progress mirror changed outside a lesson: a
   * cloud pull merged something, or the learner signed out / deleted the
   * account. Screens that read the mirror re-load when it changes.
   */
  progressVersion: number;
  signOut: () => Promise<void>;
  /**
   * After `delete_user()` succeeded on the server: drop the session on this
   * device only (the account is gone) and clear every trace of the learner.
   */
  afterAccountDeleted: () => Promise<void>;
  refreshPlan: () => Promise<void>;
};

const AuthContext = createContext<AuthState | null>(null);

/** Back from the background after this long: pull the cloud rows again. */
const FOREGROUND_PULL_MS = 10 * 60 * 1000;
/** The same learner is not pulled twice within this window (start-up emits several auth events). */
const PULL_DEDUPE_MS = 60 * 1000;

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [plan, setPlan] = useState<Plan>('free');
  const [loading, setLoading] = useState(true);
  const [progressVersion, setProgressVersion] = useState(0);

  // The current session, readable from listeners without a stale closure.
  const sessionRef = useRef<Session | null>(null);
  useEffect(() => {
    sessionRef.current = session;
  }, [session]);

  const lastPull = useRef<{ uid: string; at: number } | null>(null);

  /**
   * Pull the course and Norania rows for `userId` into the local mirror,
   * then point "Continue" at the right unit for a learner this device did
   * not know. Bumps `progressVersion` when anything arrived.
   */
  const pullProgress = useCallback(async (userId: string, force = false) => {
    const prev = lastPull.current;
    if (!force && prev && prev.uid === userId && Date.now() - prev.at < PULL_DEDUPE_MS) return;
    lastPull.current = { uid: userId, at: Date.now() };
    try {
      // Whose mirror this was before the pull: another learner's (or none) means
      // nothing in the cloud row was earned on this device today.
      const before = await getEngineProgress();
      const [snapshot, norania] = await Promise.all([pullCloudProgress(userId), pullNoraniaProgress(userId)]);
      let changed = norania;
      if (snapshot) {
        changed = true;
        if (before.uid !== userId) await startDayFrom(snapshot);
        await adoptLastUnitFromCloud(userId, snapshot, before.uid);
      }
      if (changed) setProgressVersion((v) => v + 1);
    } catch (e) {
      reportError(e, { where: 'auth pull progress' });
    }
  }, []);

  useEffect(() => {
    let active = true;

    (async () => {
      const { data, error } = await supabase.auth.getSession();
      let s = data.session;
      // Offline with an expired token: auth-js answers "no session" but keeps
      // it stored. Show the app signed in (with the old token) rather than as
      // a guest; the auto-refresh tick swaps in a fresh token when it can.
      const restored = !s && !!error ? await readStoredSession() : null;
      if (restored) s = restored;
      if (!active) return;
      setSession(s);
      setLoading(false);
      const uid = data.session?.user?.id;
      if (uid) void pullProgress(uid);
    })();

    const { data: sub } = supabase.auth.onAuthStateChange((event, next) => {
      // The start-up read above handles INITIAL_SESSION (which is null in the
      // offline case just described and must not undo the restored session).
      if (event === 'INITIAL_SESSION') return;
      setSession(next);
      invalidatePlanCache();
      const uid = next?.user?.id;
      // Deferred: other Supabase calls must not run inside the auth callback itself.
      if (event === 'SIGNED_IN' && uid) setTimeout(() => void pullProgress(uid), 0);
    });

    return () => {
      active = false;
      sub.subscription.unsubscribe();
    };
  }, [pullProgress]);

  // Token refresh only runs while the app is in the foreground (Supabase's
  // React Native setup), and a long time away earns a fresh pull so two
  // devices stay in step.
  useEffect(() => {
    void supabase.auth.startAutoRefresh();
    let leftAt: number | null = null;
    const onChange = (state: AppStateStatus) => {
      if (state === 'active') {
        void supabase.auth.startAutoRefresh();
        const uid = sessionRef.current?.user?.id;
        if (uid && leftAt !== null && Date.now() - leftAt >= FOREGROUND_PULL_MS) void pullProgress(uid, true);
        leftAt = null;
      } else {
        void supabase.auth.stopAutoRefresh();
        if (leftAt === null) leftAt = Date.now();
      }
    };
    const sub = AppState.addEventListener('change', onChange);
    return () => {
      sub.remove();
      void supabase.auth.stopAutoRefresh();
    };
  }, [pullProgress]);

  useEffect(() => {
    let active = true;
    const userId = session?.user?.id ?? null;
    // Without a session only a store purchase can make the plan paid.
    if (!userId && !STORE_ENABLED) {
      setPlan('free');
      return;
    }
    syncStoreUser(userId)
      .then(() => {
        invalidatePlanCache();
        return getPlan();
      })
      .then((p) => {
        if (active) setPlan(p);
      });
    return () => {
      active = false;
    };
  }, [session]);

  /** Everything of the learner's that lives on this device, gone. */
  const forgetLearner = useCallback(async (uid: string | null) => {
    invalidatePlanCache();
    await clearPersistedPlan(uid);
    await clearLearnerData();
    lastPull.current = null;
    setProgressVersion((v) => v + 1);
  }, []);

  const value = useMemo<AuthState>(
    () => ({
      session,
      plan,
      loading,
      progressVersion,
      signOut: async () => {
        const uid = sessionRef.current?.user?.id ?? null;
        // Whatever the last lesson left queued goes up first.
        await Promise.all([flushCloudProgress(), flushNoraniaProgress()]).catch(() => {});
        const { error } = await supabase.auth.signOut();
        if (error) {
          // The server could not be reached: still sign this device out.
          reportError(error, { where: 'auth signOut' });
          await supabase.auth.signOut({ scope: 'local' }).catch(() => {});
        }
        await forgetLearner(uid);
      },
      afterAccountDeleted: async () => {
        const uid = sessionRef.current?.user?.id ?? null;
        await supabase.auth.signOut({ scope: 'local' }).catch(() => {});
        await forgetLearner(uid);
      },
      refreshPlan: async () => {
        invalidatePlanCache();
        setPlan(await getPlan());
      },
    }),
    [session, plan, loading, progressVersion, forgetLearner]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>');
  return ctx;
}
