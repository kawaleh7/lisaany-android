/**
 * Family & friends circles — the Circle tab's leaderboard.
 *
 * All reads and writes go through Supabase functions (supabase/circles.sql),
 * which check that the caller is signed in and a member of the circle. The
 * app reports the learner's own XP (total, this week, streak) whenever the
 * Circle or Today tab opens, so boards stay fresh without a server job.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';

import { getDailyGoal, getEngineProgress, getWeekXp } from './progress';
import { supabase } from './supabase';

export type Circle = { id: string; name: string; code: string; members: number; myName: string };
export type BoardRow = {
  userId: string;
  name: string;
  weekXp: number;
  totalXp: number;
  streak: number;
  isMe: boolean;
  /** A Star League practice rival, not a real learner. */
  rival?: boolean;
  /** Fixed position (Star League keeps the learner in the middle). */
  order?: number;
};

/** Error codes raised by the SQL functions, plus 'offline' / 'not_set_up' / 'unknown'. */
export type CircleError =
  | 'not_signed_in'
  | 'circle_not_found'
  | 'circle_full'
  | 'too_many_circles'
  | 'name_required'
  | 'display_name_required'
  | 'not_a_member'
  | 'not_set_up'
  | 'offline'
  | 'unknown';

export class CircleFailure extends Error {
  code: CircleError;
  constructor(code: CircleError) {
    super(code);
    this.code = code;
  }
}

const KNOWN: CircleError[] = ['not_signed_in', 'circle_not_found', 'circle_full', 'too_many_circles', 'name_required', 'display_name_required', 'not_a_member'];

function fail(err: { message?: string; code?: string } | null): never {
  const msg = err?.message ?? '';
  const hit = KNOWN.find((k) => msg.includes(k));
  if (hit) throw new CircleFailure(hit);
  // PGRST202: function not found → the SQL hasn't been run in Supabase yet.
  if (err?.code === 'PGRST202' || /could not find the function/i.test(msg)) throw new CircleFailure('not_set_up');
  if (/network|fetch|timeout/i.test(msg)) throw new CircleFailure('offline');
  throw new CircleFailure('unknown');
}

async function rpc<T>(fn: string, args?: Record<string, unknown>): Promise<T> {
  let res;
  try {
    res = await supabase.rpc(fn, args ?? {});
  } catch {
    throw new CircleFailure('offline');
  }
  if (res.error) fail(res.error);
  return res.data as T;
}

type CircleRow = { id: string; name: string; code: string; members?: number; my_name?: string };

export async function myCircles(): Promise<Circle[]> {
  const rows = await rpc<CircleRow[]>('my_circles');
  return (rows ?? []).map((r) => ({ id: r.id, name: r.name, code: r.code, members: r.members ?? 1, myName: r.my_name ?? '' }));
}

export async function createCircle(name: string, displayName: string): Promise<Circle> {
  const rows = await rpc<CircleRow[]>('create_circle', { p_name: name, p_display: displayName });
  const r = rows[0];
  await reportXp(true);
  return { id: r.id, name: r.name, code: r.code, members: 1, myName: displayName.trim() };
}

export async function joinCircle(code: string, displayName: string): Promise<Circle> {
  const rows = await rpc<CircleRow[]>('join_circle', { p_code: code, p_display: displayName });
  const r = rows[0];
  await reportXp(true);
  return { id: r.id, name: r.name, code: r.code, members: 0, myName: displayName.trim() };
}

export async function leaveCircle(id: string): Promise<void> {
  await rpc('leave_circle', { p_circle: id });
}

type RawRow = { user_id: string; display_name: string; week_xp: number; total_xp: number; streak: number; is_me: boolean };

export async function circleBoard(id: string): Promise<BoardRow[]> {
  const rows = await rpc<RawRow[]>('circle_board', { p_circle: id });
  return (rows ?? []).map((r) => ({
    userId: r.user_id,
    name: r.display_name,
    weekXp: r.week_xp ?? 0,
    totalXp: r.total_xp ?? 0,
    streak: r.streak ?? 0,
    isMe: !!r.is_me,
  }));
}

/** Sort for a period; ties keep a stable order by name. */
export function rank(rows: BoardRow[], period: 'week' | 'all'): BoardRow[] {
  if (rows.some((r) => r.order != null)) return [...rows].sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
  const key = (r: BoardRow) => (period === 'week' ? r.weekXp : r.totalXp);
  return [...rows].sort((a, b) => key(b) - key(a) || a.name.localeCompare(b.name));
}

export function mondayOf(d = new Date()) {
  const m = new Date(d);
  m.setDate(d.getDate() - ((d.getDay() + 6) % 7));
  return `${m.getFullYear()}-${String(m.getMonth() + 1).padStart(2, '0')}-${String(m.getDate()).padStart(2, '0')}`;
}

const LAST_REPORT_KEY = 'lisaany:circle-report';

/**
 * Send this learner's XP to Supabase (signed-in users only). Skipped when
 * nothing changed since the last report, unless `force`.
 */
export async function reportXp(force = false): Promise<void> {
  try {
    const { data } = await supabase.auth.getSession();
    if (!data.session) return;
    const snap = await getEngineProgress();
    const week = (await getWeekXp()).reduce((s, d) => s + d.xp, 0);
    const payload = { p_total: snap.xp, p_week: week, p_week_start: mondayOf(), p_streak: snap.streak };
    const sig = `${data.session.user.id}|${payload.p_total}|${payload.p_week}|${payload.p_week_start}|${payload.p_streak}`;
    if (!force && (await AsyncStorage.getItem(LAST_REPORT_KEY)) === sig) return;
    const res = await supabase.rpc('report_xp', payload);
    if (!res.error) await AsyncStorage.setItem(LAST_REPORT_KEY, sig);
  } catch {
    /* best-effort: the board just shows the last reported numbers */
  }
}

/** Initials for the round badge (no people icons): "Maryam A." → "MA". */
export function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  const s = parts.length > 1 ? parts[0][0] + parts[1][0] : (parts[0] ?? '?').slice(0, 2);
  return s.toUpperCase();
}

/** A steady colour per person, from the space palette. */
const BADGE = ['#3a4a73', '#34506a', '#4a3f6b', '#3d5a5a', '#5a4a3a', '#3a5070', '#4b4466', '#35546b'];
export function badgeColor(id: string): string {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  return BADGE[h % BADGE.length];
}

/** The circle the tab showed last, so it reopens on the same one. */
const LAST_CIRCLE_KEY = 'lisaany:last-circle';
export async function getLastCircle(): Promise<string | null> {
  try {
    return await AsyncStorage.getItem(LAST_CIRCLE_KEY);
  } catch {
    return null;
  }
}
export async function setLastCircle(id: string): Promise<void> {
  try {
    await AsyncStorage.setItem(LAST_CIRCLE_KEY, id);
  } catch {
    /* best-effort */
  }
}

/* ── Star League: practice rivals (clearly labelled, not real learners) ──── */

/** Pace-setters named after stars. Shown in the "Star League" practice board. */
const RIVALS = ['Vega', 'Altair', 'Rigel', 'Sirius', 'Deneb', 'Capella', 'Polaris', 'Antares'];
/** Each rival's pace as a multiple of the learner's daily goal. */
const PACE = [1.9, 1.55, 1.3, 1.1, 0.9, 0.7, 0.5, 0.3];

function seeded(seed: string) {
  let h = 2166136261;
  for (let i = 0; i < seed.length; i++) h = Math.imul(h ^ seed.charCodeAt(i), 16777619) >>> 0;
  return () => {
    h = Math.imul(h ^ (h >>> 15), 2246822507) >>> 0;
    h = Math.imul(h ^ (h >>> 13), 3266489909) >>> 0;
    return ((h ^= h >>> 16) >>> 0) / 4294967296;
  };
}

/**
 * The week's rivals and their XP right now. Each rival keeps a steady daily
 * pace set around the learner's daily goal, so hitting the goal every day
 * keeps you mid-pack, doing more lets you pass rivals, and a quiet day lets
 * them pass you. The lesson page uses the exact same formula
 * (tools/app-check.js → lsRivals), so both show the same board.
 */
export function starRivals(goal: number, now = new Date()): { name: string; xp: number }[] {
  const monday = new Date(now);
  monday.setHours(0, 0, 0, 0);
  monday.setDate(monday.getDate() - ((monday.getDay() + 6) % 7));
  const days = Math.min(7, Math.max(0, (now.getTime() - monday.getTime()) / 86400000));
  const rand = seeded(mondayOf(now));
  const names = [...RIVALS];
  for (let i = names.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [names[i], names[j]] = [names[j], names[i]];
  }
  return names.map((name, i) => ({ name, xp: Math.round(Math.max(10, goal) * PACE[i] * days + rand() * 6) }));
}

/** The Star League board for this week, with the learner placed by their XP. */
export async function starLeague(): Promise<BoardRow[]> {
  const [snap, weekDays, goal] = await Promise.all([getEngineProgress(), getWeekXp(), getDailyGoal()]);
  const week = weekDays.reduce((s, d) => s + d.xp, 0);
  const rand = seeded('streak' + mondayOf());
  const rows: BoardRow[] = starRivals(goal).map((r) => ({
    userId: `rival:${r.name}`,
    name: r.name,
    weekXp: r.xp,
    totalXp: r.xp,
    streak: 1 + Math.floor(rand() * 9),
    isMe: false,
    rival: true,
  }));
  rows.push({ userId: 'me', name: '', weekXp: week, totalXp: snap.xp, streak: snap.streak, isMe: true });
  return rows;
}
