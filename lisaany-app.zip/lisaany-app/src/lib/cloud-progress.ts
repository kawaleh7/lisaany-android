/**
 * Course progress in Supabase (`learner_progress`), read and written by the
 * native app itself.
 *
 * The lesson page already syncs this row while it is open. The app does it
 * too, for the moments the page is not there: at sign-in and start-up it
 * PULLS the row so Today / Lessons show a returning learner where they left
 * off on the website, and after every snapshot the page posts it PUSHES the
 * row, so a lesson finished just before the web view closes still reaches the
 * cloud (the page's own push is cancelled when the view is torn down).
 *
 * Same row shape and merge rules as the engine (assets/lesson/lesson.html,
 * loadCloudProgress / pushCloudProgress): union of what is done, the higher
 * XP, and the streak of whichever side had the more recent `last_day`.
 */
import { applyEngineProgress, getEngineProgress, mergePos, mergeProg, type EngineSnapshot, type PosMap, type ProgMap } from './progress';
import { reportError } from './report';
import { supabase } from './supabase';

type Row = {
  prog: ProgMap | null;
  pos: PosMap | null;
  xp: number | null;
  streak: number | null;
  last_day: string | null;
  updated_at?: string | null;
};

const dayMs = (d: string | null | undefined) => {
  if (!d) return 0;
  const t = new Date(d).getTime();
  return Number.isFinite(t) ? t : 0;
};

/** The engine's rule: the side with the more recent activity day decides the streak. */
function reconcileStreak(local: { streak: number; lastDay?: string }, remote: { streak: number; lastDay?: string | null }) {
  const lt = dayMs(local.lastDay);
  const rt = dayMs(remote.lastDay);
  if (rt > lt) return { streak: remote.streak, lastDay: remote.lastDay ?? local.lastDay };
  if (rt === lt) return { streak: Math.max(local.streak, remote.streak), lastDay: local.lastDay ?? remote.lastDay ?? undefined };
  return { streak: local.streak, lastDay: local.lastDay };
}

async function readRow(userId: string): Promise<Row | null> {
  const { data, error } = await supabase
    .from('learner_progress')
    .select('prog,pos,xp,streak,last_day,updated_at')
    .eq('user_id', userId)
    .maybeSingle();
  if (error) throw error;
  return (data as Row | null) ?? null;
}

/**
 * Merge the learner's cloud row into the local mirror. Returns the merged
 * snapshot, or null when there is no row / no network (the mirror is left
 * as it was). Safe to call often; one network read.
 */
export async function pullCloudProgress(userId: string): Promise<EngineSnapshot | null> {
  try {
    const row = await readRow(userId);
    if (!row) return null;
    const local = await getEngineProgress();
    const sameUser = local.uid === userId;
    const streak = reconcileStreak(
      { streak: sameUser ? local.streak : 0, lastDay: sameUser ? local.lastDay : undefined },
      { streak: row.streak ?? 0, lastDay: row.last_day }
    );
    return await applyEngineProgress({
      prog: row.prog ?? {},
      pos: row.pos ?? {},
      xp: row.xp ?? 0,
      streak: streak.streak,
      lastDay: streak.lastDay ?? undefined,
      uid: userId,
    });
  } catch (e) {
    reportError(e, { where: 'cloud-progress pull' });
    return null;
  }
}

/* ── push (debounced) ─────────────────────────────────────────────────── */

let pending: EngineSnapshot | null = null;
let timer: ReturnType<typeof setTimeout> | null = null;
let inflight: Promise<void> | null = null;

/**
 * Queue a snapshot for upload. Guests are ignored. Repeated calls within
 * `delayMs` collapse into one write; call `flushCloudProgress()` to send now.
 */
export function scheduleCloudPush(snapshot: EngineSnapshot, delayMs = 1500): void {
  if (!snapshot.uid || snapshot.uid === 'guest') return;
  pending = snapshot;
  if (timer) clearTimeout(timer);
  timer = setTimeout(() => {
    timer = null;
    void flushCloudProgress();
  }, delayMs);
}

/** Send whatever is queued, now. Resolves when the write has finished (or failed). */
export async function flushCloudProgress(): Promise<void> {
  if (timer) {
    clearTimeout(timer);
    timer = null;
  }
  if (inflight) {
    await inflight;
  }
  const snap = pending;
  pending = null;
  if (!snap || snap.uid === 'guest') return;
  inflight = (async () => {
    try {
      const {
        data: { session },
      } = await supabase.auth.getSession();
      // Never write another account's row (the snapshot may be from a session that has since ended).
      if (!session || session.user.id !== snap.uid) return;

      // Merge with what is already in the cloud so a snapshot taken before the
      // page had loaded the row (slow network) can never shrink it.
      let remote: Row | null = null;
      try {
        remote = await readRow(snap.uid);
      } catch {
        remote = null;
      }
      const prog: ProgMap = {};
      const pos: PosMap = {};
      mergeProg(prog, remote?.prog ?? undefined);
      mergePos(pos, remote?.pos ?? undefined);
      mergeProg(prog, snap.prog);
      mergePos(pos, snap.pos);
      const streak = reconcileStreak(
        { streak: snap.streak, lastDay: snap.lastDay },
        { streak: remote?.streak ?? 0, lastDay: remote?.last_day ?? null }
      );
      const row: Record<string, unknown> = {
        user_id: snap.uid,
        prog,
        pos,
        xp: Math.max(snap.xp, remote?.xp ?? 0),
        streak: streak.streak,
        updated_at: new Date().toISOString(),
      };
      if (streak.lastDay) row.last_day = streak.lastDay;
      const { error } = await supabase.from('learner_progress').upsert(row, { onConflict: 'user_id' });
      if (error) throw error;
    } catch (e) {
      // Keep it for the next flush (the newest snapshot wins if one arrived meanwhile).
      pending = pending ?? snap;
      reportError(e, { where: 'cloud-progress push' });
    }
  })();
  try {
    await inflight;
  } finally {
    inflight = null;
  }
}

/** True while a snapshot is waiting to be sent. */
export function hasPendingCloudPush(): boolean {
  return pending !== null || inflight !== null;
}
