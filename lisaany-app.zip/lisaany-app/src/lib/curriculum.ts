/**
 * The Lisaany course structure, read out of the running lesson engine by
 * tools/extract-curriculum.mjs.
 *
 * Only ids, titles and types live here — the lesson content itself is rendered
 * by the lesson page (the website's engine in a web view), so the app never
 * carries a second copy of it. The structure includes the blocks the engine
 * generates at runtime (Listening Dictation, Practice Drill, Sentence Fill),
 * which is why there are more blocks here than in the static curriculum.
 *
 * Rebuild after the website's arabic_platform.html changes:
 *   python3 tools/build-lesson-page.py && node tools/extract-curriculum.mjs
 */
import curriculumData from '@/data/curriculum.json';
import objectivesData from '@/data/objectives.json';
import { translate, type Lang } from '@/lib/i18n';

export type BlockType =
  | 'dialogue'
  | 'vocab'
  | 'grammar'
  | 'cloze'
  | 'clutter'
  | 'quiz'
  | 'fill'
  | 'seqquiz'
  | 'possessive'
  | 'swipe'
  | 'conjugation'
  | 'video'
  | 'choose';

export type Block = {
  id: number;
  type: BlockType | string;
  title: string;
  desc?: string;
  icon?: string;
  color?: string;
  /** How much content the block holds, e.g. { count: 10, unit: 'lines' }. */
  size?: { count: number; unit: string };
};

export type Unit = {
  /** Dotted id, e.g. "3.2" — the same id the paywall rules use. */
  id: string;
  title: string;
  icon?: string;
  /** Short Arabic description shown under the title. */
  desc?: string;
  blocks: Block[];
};

export type Module = {
  id: number;
  title: string;
  color: string;
  icon?: string;
  units: Unit[];
};

export const MODULES = curriculumData as Module[];

const OBJECTIVES = objectivesData as Record<string, string[]>;

const unitIndex = new Map<string, { unit: Unit; module: Module }>();
for (const mod of MODULES) {
  for (const unit of mod.units) {
    unitIndex.set(unit.id, { unit, module: mod });
  }
}

export function getUnit(id: string): Unit | undefined {
  return unitIndex.get(id)?.unit;
}

export function getModuleForUnit(id: string): Module | undefined {
  return unitIndex.get(id)?.module;
}

/** "By the end of this lesson, you can…" — empty for units that have none yet. */
export function getObjectives(unitId: string): string[] {
  return OBJECTIVES[unitId] ?? [];
}

export function getModule(id: number | string): Module | undefined {
  return MODULES.find((m) => String(m.id) === String(id));
}

export type Level = { label: string; ar: string; desc: string; moduleIds: number[] };

/** The website's level grouping (arabic_platform.html, the "Your Journey" hub). */
export const LEVELS: Level[] = [
  { label: 'Beginner', ar: 'مُبْتَدِئ', desc: 'Greetings, family, school & home', moduleIds: [1, 2, 3, 4] },
  { label: 'Intermediate', ar: 'مُتَوَسِّط', desc: 'Food, daily life, health & groceries', moduleIds: [5, 6, 7, 8, 14] },
  { label: 'Advanced', ar: 'مُتَقَدِّم', desc: 'Malls, travel, nature & hobbies', moduleIds: [9, 10, 11, 12] },
  { label: 'Expert', ar: 'مُتَمَكِّن', desc: 'Media Arabic — news & politics', moduleIds: [13] },
];

export function levelForModule(id: number): Level | undefined {
  return LEVELS.find((l) => l.moduleIds.includes(id));
}

export const TOTAL_UNITS = unitIndex.size;

export const TOTAL_BLOCKS = MODULES.reduce(
  (sum, mod) => sum + mod.units.reduce((n, unit) => n + unit.blocks.length, 0),
  0
);

/** Human-readable name for a block type, matching the website's labels. */
export const BLOCK_TYPE_LABELS: Record<string, string> = {
  dialogue: 'Conversation',
  vocab: 'Vocabulary',
  grammar: 'Grammar',
  cloze: 'Listening dictation',
  clutter: 'Sentence builder',
  quiz: 'Practice drill',
  fill: 'Sentence fill',
  seqquiz: 'Quiz',
  possessive: 'Suffix tap',
  swipe: 'Swipe drill',
  conjugation: 'Conjugation',
  video: 'Video',
  choose: 'Choose',
};

/** Blocks that teach (the rest practise) — the engine adds a quick check after these. */
export const TEACHING_TYPES = new Set<string>(['dialogue', 'vocab', 'grammar', 'conjugation']);

/** "10 lines", "13 words" — for list rows. Pass the app language to get French. */
export function blockSizeLabel(block: Block, lang: Lang = 'en'): string | null {
  if (!block.size) return null;
  const { count, unit } = block.size;
  const one = unit.replace(/s$/, '');
  // Keys: '1 line' / '{n} lines', '1 word' / '{n} words', … (see src/i18n/fr-course.ts).
  if (SIZE_UNITS.has(unit)) return translate(lang, count === 1 ? `1 ${one}` : `{n} ${unit}`, { n: count });
  return `${count} ${count === 1 ? one : unit}`;
}

const SIZE_UNITS = new Set(['lines', 'words', 'sentences', 'questions', 'examples', 'items']);

/** Arabic title and a one-line summary for each module (Lessons tab). */
export const MODULE_META: Record<number, { ar: string; blurb: string }> = {
  1: { ar: 'التَّحِيَّاتُ وَالتَّعَارُف', blurb: 'Say hello, introduce yourself and have simple conversations.' },
  2: { ar: 'العَائِلَةُ وَالمِهَن', blurb: 'Talk about your family, describe people and learn common jobs.' },
  3: { ar: 'الصَّفُّ وَالمَدْرَسَة', blurb: 'Learn school vocabulary and talk about your studies.' },
  4: { ar: 'البَيْتُ وَالحَيَاةُ اليَوْمِيَّة', blurb: 'Describe your home, rooms and everyday activities.' },
  5: { ar: 'الطَّعَامُ وَالتَّسَوُّق', blurb: 'Order food, shop and ask about prices.' },
  6: { ar: 'الحَيَاةُ اليَوْمِيَّةُ وَالعِبَادَة', blurb: 'Describe your routine and talk about prayer times.' },
  7: { ar: 'الصِّحَّةُ وَالطِّبّ', blurb: 'Describe symptoms and speak with a doctor.' },
  8: { ar: 'البِقَالَةُ وَالسُّوبَرْمَارْكِت', blurb: 'Buy groceries, weigh, count and pay.' },
  9: { ar: 'التَّسَوُّقُ فِي المَرْكَز', blurb: 'Shop for clothes, compare prices and bargain.' },
  10: { ar: 'المُوَاصَلَات', blurb: 'Take a taxi, a bus or a train and ask for directions.' },
  11: { ar: 'الطَّبِيعَةُ وَالهَوَاءُ الطَّلْق', blurb: 'Talk about the weather, seasons and the outdoors.' },
  12: { ar: 'الرِّيَاضَةُ وَالهِوَايَات', blurb: 'Talk about sports, free time and what you enjoy.' },
  13: { ar: 'الأَخْبَارُ وَالسِّيَاسَة', blurb: 'Read headlines and follow the news in formal Arabic.' },
  14: { ar: 'السَّفَرُ وَالتَّأْشِيرَات', blurb: 'Plan a trip and talk about travel documents.' },
};
