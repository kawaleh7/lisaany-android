/**
 * Opt-in email reminders (sent by the backend on days the goal isn't met).
 *
 * The app only tells Supabase what it needs through two RPCs (security
 * definer, signed-in session required):
 *   set_reminder_prefs(p_opt_in, p_hour, p_minute, p_tz, p_goal, p_lang)
 *   report_minutes(p_day, p_secs)   — today's total active seconds, local date
 * If the SQL isn't installed yet (PGRST202, function not found) the calls
 * are ignored quietly.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';

import { getMinGoal, getTodaySecs, localDay } from './goal';
import { getReminderPrefs } from './reminders';
import { getLessonLang } from './settings';
import { supabase } from './supabase';

const OPT_KEY = 'lisaany:email-reminders';
const REPORT_EVERY_MS = 60_000;

/** null = never touched (then nothing is sent to the server). */
async function readOptIn(): Promise<boolean | null> {
  try {
    const v = await AsyncStorage.getItem(OPT_KEY);
    return v === null ? null : v === '1';
  } catch {
    return null;
  }
}

export async function getEmailOptIn(): Promise<boolean> {
  return (await readOptIn()) === true;
}

export async function setEmailOptIn(on: boolean): Promise<void> {
  try {
    await AsyncStorage.setItem(OPT_KEY, on ? '1' : '0');
  } catch {
    /* best-effort */
  }
  await syncEmailPrefs();
  if (on) await reportMinutes(true);
}

function timeZone(): string {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
  } catch {
    return 'UTC';
  }
}

async function signedIn(): Promise<boolean> {
  try {
    const { data } = await supabase.auth.getSession();
    return !!data.session;
  } catch {
    return false;
  }
}

function quiet(error: { code?: string; message?: string } | null, what: string) {
  if (!error || error.code === 'PGRST202') return; // RPC not installed yet
  console.warn(`[email reminders] ${what}:`, error.message ?? error.code);
}

/**
 * Send the current email preferences (opt-in, reminder time, time zone, goal,
 * language). Called when the toggle, time, goal or language changes and on
 * sign-in. Does nothing for guests or if the toggle was never touched.
 */
export async function syncEmailPrefs(): Promise<void> {
  const opt = await readOptIn();
  if (opt === null || !(await signedIn())) return;
  const [prefs, goal, lang] = await Promise.all([getReminderPrefs(), getMinGoal(), getLessonLang()]);
  try {
    const { error } = await supabase.rpc('set_reminder_prefs', {
      p_opt_in: opt,
      p_hour: prefs.hour,
      p_minute: prefs.minute,
      p_tz: timeZone(),
      p_goal: goal,
      p_lang: lang,
    });
    quiet(error, 'set_reminder_prefs');
  } catch {
    /* offline — the next change or app start tries again */
  }
}

let lastReport = 0;
let trailing: ReturnType<typeof setTimeout> | null = null;

/**
 * Report today's active seconds, at most once a minute (a trailing call
 * catches the last update). `now` skips the wait — used when the app goes to
 * the background and when the goal is met.
 */
export async function reportMinutes(now = false): Promise<void> {
  const wait = REPORT_EVERY_MS - (Date.now() - lastReport);
  if (!now && wait > 0) {
    if (!trailing) {
      trailing = setTimeout(() => {
        trailing = null;
        reportMinutes(true);
      }, wait);
    }
    return;
  }
  if (trailing) {
    clearTimeout(trailing);
    trailing = null;
  }
  if (!(await getEmailOptIn()) || !(await signedIn())) return;
  lastReport = Date.now();
  try {
    const { error } = await supabase.rpc('report_minutes', {
      p_day: localDay(),
      p_secs: Math.round(await getTodaySecs()),
    });
    quiet(error, 'report_minutes');
  } catch {
    /* offline — the next report carries the full total anyway */
  }
}
