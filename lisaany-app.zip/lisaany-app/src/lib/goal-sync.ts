/**
 * The places where the goal, reminders and email preferences meet. Screens
 * and the lesson bridge call these instead of the lower-level setters.
 */
import { syncEmailPrefs, reportMinutes } from './email-reminders';
import { addActiveSecs, setMinGoal, type AddResult } from './goal';
import { getReminderPrefs, rescheduleReminders, setReminderPrefs, type ReminderPrefs } from './reminders';

/** New daily goal (minutes): save, reschedule reminders, tell the email backend. */
export async function changeMinGoal(minutes: number): Promise<number> {
  const g = await setMinGoal(minutes);
  await rescheduleReminders();
  syncEmailPrefs();
  return g;
}

/** Active seconds from the lesson page. Once the goal is met, today's reminder is dropped. */
export async function recordActiveSecs(delta: number): Promise<AddResult> {
  const r = await addActiveSecs(delta);
  if (r.justMet) {
    rescheduleReminders();
    reportMinutes(true);
  } else {
    reportMinutes();
  }
  return r;
}

/** New reminder time / on-off: reschedule and keep the email time in step. */
export async function changeReminderPrefs(next: Partial<ReminderPrefs>): Promise<ReminderPrefs> {
  const prefs = { ...(await getReminderPrefs()), ...next };
  await setReminderPrefs(prefs);
  syncEmailPrefs();
  return prefs;
}
