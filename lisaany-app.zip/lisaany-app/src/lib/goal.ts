/**
 * The daily minutes goal and today's active learning time.
 *
 * Everyone starts at 30 minutes a day; onboarding and Settings can lower it
 * to 5, 10 or 15 (or bring it back to 30). The lesson page counts active
 * seconds while the learner works and sends them over the bridge as deltas
 * (`{ type: 'minutes', secs }`), which are added up here per local day.
 *
 * The XP goal used by the Star League pace and the lesson celebration is
 * derived from this (see getDailyGoal in progress.ts), so both stay in step.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';

const GOAL_KEY = 'lisaany:goal-min';
const DAY_KEY = 'lisaany:min-day';
const HISTORY_KEY = 'lisaany:min-history';

/** The goals a learner can pick, in minutes. */
export const GOAL_CHOICES = [5, 10, 15, 30] as const;
export const DEFAULT_MIN_GOAL = 30;

/** Local calendar day, e.g. "2026-09-22" (same rule as progress.ts). */
export function localDay(d = new Date()): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

/** Snap any number to the nearest allowed goal. */
export function normalizeGoal(n: number): number {
  if (!Number.isFinite(n) || n <= 0) return DEFAULT_MIN_GOAL;
  return GOAL_CHOICES.reduce((best, g) => (Math.abs(g - n) < Math.abs(best - n) ? g : best), GOAL_CHOICES[0] as number);
}

export async function getMinGoal(): Promise<number> {
  try {
    const raw = await AsyncStorage.getItem(GOAL_KEY);
    const n = raw ? parseInt(raw, 10) : NaN;
    return Number.isFinite(n) && n > 0 ? normalizeGoal(n) : DEFAULT_MIN_GOAL;
  } catch {
    return DEFAULT_MIN_GOAL;
  }
}

/** Saves the goal. Use changeMinGoal (goal-sync.ts) from screens so reminders and email follow. */
export async function setMinGoal(minutes: number): Promise<number> {
  const g = normalizeGoal(minutes);
  try {
    await AsyncStorage.setItem(GOAL_KEY, String(g));
  } catch {
    /* best-effort */
  }
  return g;
}

/* ── Active seconds per day ─────────────────────────────────────────── */

type DayRec = { day: string; secs: number };

async function readDay(): Promise<DayRec> {
  const today = localDay();
  try {
    const raw = await AsyncStorage.getItem(DAY_KEY);
    const rec = raw ? (JSON.parse(raw) as DayRec) : null;
    if (rec && rec.day === today && Number.isFinite(rec.secs)) return rec;
  } catch {
    /* fall through */
  }
  return { day: today, secs: 0 };
}

/** Seconds of active learning today (0 on a new day). */
export async function getTodaySecs(): Promise<number> {
  return (await readDay()).secs;
}

export async function isGoalMetToday(): Promise<boolean> {
  const [secs, goal] = await Promise.all([getTodaySecs(), getMinGoal()]);
  return secs >= goal * 60;
}

// Bridge messages can arrive back to back; chain the read-modify-writes so
// no delta is lost.
let queue: Promise<unknown> = Promise.resolve();

export type AddResult = { secs: number; goalSecs: number; justMet: boolean };

/**
 * Add a delta of active seconds to today. `justMet` is true when this delta
 * took today's total across the goal.
 */
export function addActiveSecs(delta: number): Promise<AddResult> {
  const run = queue.then(async (): Promise<AddResult> => {
    const goalSecs = (await getMinGoal()) * 60;
    const rec = await readDay();
    // A delta is a few seconds to a few minutes; ignore anything odd.
    const d = Number.isFinite(delta) ? Math.max(0, Math.min(600, Math.round(delta))) : 0;
    if (!d) return { secs: rec.secs, goalSecs, justMet: false };
    const before = rec.secs;
    const next: DayRec = { day: rec.day, secs: before + d };
    try {
      await AsyncStorage.setItem(DAY_KEY, JSON.stringify(next));
      await recordHistory(next.day, next.secs);
    } catch {
      /* best-effort */
    }
    return { secs: next.secs, goalSecs, justMet: before < goalSecs && next.secs >= goalSecs };
  });
  queue = run.catch(() => undefined);
  return run;
}

/* ── History (day → seconds), last ~60 days ─────────────────────────── */

export async function getMinutesHistory(): Promise<Record<string, number>> {
  try {
    const raw = await AsyncStorage.getItem(HISTORY_KEY);
    return raw ? (JSON.parse(raw) as Record<string, number>) : {};
  } catch {
    return {};
  }
}

async function recordHistory(day: string, secs: number): Promise<void> {
  const hist = await getMinutesHistory();
  hist[day] = secs;
  const keys = Object.keys(hist).sort();
  for (const k of keys.slice(0, Math.max(0, keys.length - 60))) delete hist[k];
  await AsyncStorage.setItem(HISTORY_KEY, JSON.stringify(hist));
}
