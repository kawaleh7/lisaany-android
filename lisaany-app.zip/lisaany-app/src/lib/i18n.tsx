/**
 * App language (English / French).
 *
 * English text is the key: screens call t('Get started') and French comes from
 * the dictionaries in src/i18n. Anything not translated yet falls back to the
 * English, so a missing string never shows as a blank or a key.
 *
 * The same setting drives the lesson pages (they read it when they open).
 *
 *   const { t, lang, setLang } = useLang();
 *   t('{n} of {total} done', { n: 3, total: 5 })
 */
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';

import { FR } from '@/i18n';
import { COURSE_FR, OBJECTIVES_FR } from '@/i18n/course';
import { getLessonLang, setLessonLang, type LessonLang } from '@/lib/settings';

export type Lang = LessonLang;
export type Vars = Record<string, string | number>;

function fill(s: string, vars?: Vars): string {
  if (!vars) return s;
  return s.replace(/\{(\w+)\}/g, (m, k: string) => (k in vars ? String(vars[k]) : m));
}

/** French typography: a non-breaking space before ? ! : ; » (and after «),
 *  so a lone "?" never wraps onto its own line. */
function nbsp(s: string): string {
  return s.replace(/ ([?!:;»])/g, '\u00A0$1').replace(/« /g, '«\u00A0');
}

/** Translate without the hook (for helpers that get `lang` passed in). */
export function translate(lang: Lang, s: string, vars?: Vars): string {
  return lang === 'fr' ? nbsp(fill(FR[s] ?? s, vars)) : fill(s, vars);
}

/** Module / unit / block / Norania titles. */
export function courseText(lang: Lang, s: string): string {
  return lang === 'fr' ? nbsp(COURSE_FR[s] ?? s) : s;
}

type Ctx = {
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (s: string, vars?: Vars) => string;
  /** Course titles (modules, units, blocks, Norania). */
  ct: (s: string) => string;
  /** A unit's learning goals, in the current language. */
  objectives: (unitId: string, en: string[]) => string[];
  /** BCP-47 locale for dates. */
  locale: string;
};

const LangContext = createContext<Ctx | null>(null);

export function LangProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>('en');

  useEffect(() => {
    getLessonLang().then(setLangState);
  }, []);

  const setLang = useCallback((l: Lang) => {
    setLangState(l);
    setLessonLang(l);
  }, []);

  const value = useMemo<Ctx>(
    () => ({
      lang,
      setLang,
      t: (s, vars) => translate(lang, s, vars),
      ct: (s) => courseText(lang, s),
      objectives: (id, en) => (lang === 'fr' ? (OBJECTIVES_FR[id] ?? en) : en),
      locale: lang === 'fr' ? 'fr-CA' : 'en-GB',
    }),
    [lang, setLang]
  );

  return <LangContext.Provider value={value}>{children}</LangContext.Provider>;
}

const FALLBACK: Ctx = {
  lang: 'en',
  setLang: () => {},
  t: (s, vars) => fill(s, vars),
  ct: (s) => s,
  objectives: (_id, en) => en,
  locale: 'en-GB',
};

export function useLang(): Ctx {
  return useContext(LangContext) ?? FALLBACK;
}
