/**
 * The contract between the app and the lesson page.
 *
 * The page is the website's lesson engine (see tools/build-lesson-page.py).
 * The app opens it with a LessonConfig and listens for BridgeMessages; the
 * page never navigates on its own — anything outside a lesson (unit list,
 * sign-up, upgrade) is handed back to the app as a `navigate` message.
 */
import type { PosMap, ProgMap } from './progress';
import type { LessonLang } from './settings';

/** Origin the page runs under. Nothing is fetched from it; it gives the page
 *  a stable origin for its local storage. */
export const LESSON_ORIGIN = 'https://app.lisaany.com/';

export type LessonView = 'lesson' | 'review' | 'srsreview' | 'reviewBuilder';

export type LessonConfig = {
  view: LessonView;
  /** Module id (number), unit id ("1.1") and block id — required for `lesson`. */
  mId?: number;
  uId?: string;
  bId?: number;
  /** Whether the app has granted access beyond the free units. */
  premium: boolean;
  /** Supabase session to sign the page in with; omitted for guests. */
  session?: { access_token: string; refresh_token: string } | null;
  /**
   * The signed-in learner's user id. The page keeps this learner's progress
   * slot even when the session cannot be applied (offline with an expired
   * token), so nothing is saved as a guest's.
   */
  uid?: string;
  /** Progress the app already knows, merged into the page on open. */
  prog?: ProgMap;
  pos?: PosMap;
  lang: LessonLang;
  /**
   * Sound effects in the lesson (coins, right/wrong). The engine gates every
   * sound on `window.__LISAANY_APP.sfx`, so `false` means a silent page.
   * Off unless the learner turns Sounds on in Settings.
   */
  sfx: boolean;
  /** Colour theme of the app; the lesson page follows it. */
  theme?: 'dark' | 'light';
  /**
   * Today's numbers when the page opened, for the part-complete screen (goal
   * ring, Star League). `xp` is the total XP at that moment; the page adds
   * whatever it earns on top. `goal` is the XP goal (minGoal × 1.5);
   * `minGoal` is the daily goal in minutes and `daySecs` the active seconds
   * already counted today.
   */
  day?: { goal: number; dayXp: number; weekXp: number; xp: number; minGoal: number; daySecs: number };
};

/**
 * The engine's progress as the page posts it. `last_day` is the calendar day
 * of the last completed lesson (`Date.toDateString()`), which decides whose
 * streak wins when the cloud row and the device disagree.
 */
export type BridgeProgress = {
  prog: ProgMap;
  pos: PosMap;
  xp: number;
  streak: number;
  uid: string;
  last_day?: string | null;
};

export type BridgeMessage =
  | { type: 'opened'; view: LessonView; mId: number; uId: string; bId: number }
  | ({ type: 'progress' } & BridgeProgress)
  | {
      type: 'navigate';
      view: 'hub' | 'units' | 'blocks' | 'signup' | 'upgrade';
      mId: number;
      uId: string;
      bId: number;
      progress?: BridgeProgress;
    }
  | { type: 'view'; view: string; mId: number; uId: string; bId: number; top: string; bottom: string; stage: boolean }
  /** Active seconds since the last `minutes` message (a delta, not a total). */
  | { type: 'minutes'; secs: number }
  /** The learner changed their daily goal from inside the lesson (minutes). */
  | { type: 'setGoal'; minutes: number }
  /**
   * The access token the page was handed is already past its expiry. The page
   * will not use it (auth-js would refresh it and rotate the refresh token the
   * app holds); the app answers with a fresh one through `setSessionScript`.
   */
  | { type: 'needSession' }
  /**
   * The page's own client refreshed the token (auth-js does this inside
   * getSession() near expiry). The app must adopt the rotated pair, or its
   * refresh token is dead and it is signed out at its next refresh.
   */
  | { type: 'session'; access_token: string; refresh_token: string }
  | { type: 'error'; message: string }
  | { type: 'jserror'; message: string; source?: string; line?: number };

/** Why a lesson web view gave up: the page failed to load, answered with an
 *  HTTP error, or its renderer process was killed (low memory) or crashed. */
export type HostFailure = 'load' | 'http' | 'crashed';

export function parseBridgeMessage(raw: unknown): BridgeMessage | null {
  try {
    const data = typeof raw === 'string' ? JSON.parse(raw) : raw;
    if (data && typeof data === 'object' && typeof (data as { type?: unknown }).type === 'string') {
      return data as BridgeMessage;
    }
  } catch {
    /* not ours */
  }
  return null;
}

/** Everything except the session and progress — safe to log. */
export function describeConfig(cfg: LessonConfig): string {
  return `${cfg.view} ${cfg.uId ?? ''}${cfg.bId != null ? `/${cfg.bId}` : ''}`;
}

/**
 * Runs before the page's own scripts: language (read by the engine at load) and the config.
 *
 * The `ls-light` flag is pinned off: light mode is off app-wide (see
 * LIGHT_MODE_ENABLED in src/theme). The page keeps its light CSS, unused.
 * To follow the app theme again, set `var L=` back to `cfg.theme === 'light'`.
 */
export function preloadScript(cfg: LessonConfig): string {
  return (
    `try{localStorage.setItem('lisaany_lang',${JSON.stringify(cfg.lang)});}catch(e){}` +
    `(function(){var L=false;function a(){var d=document.documentElement;if(!d)return false;d.classList.toggle('ls-light',L);return true;}if(!a()){document.addEventListener('readystatechange',a);document.addEventListener('DOMContentLoaded',a);}})();` +
    `window.__LISAANY_APP=${JSON.stringify(cfg)};true;`
  );
}

/** Opens (or re-opens) the configured view once the page is up. */
export function openScript(cfg: LessonConfig): string {
  // Keep the sound flag right even if this runs after the page's own scripts
  // (the engine reads window.__LISAANY_APP.sfx at every sound).
  return (
    `try{window.__LISAANY_APP=window.__LISAANY_APP||{};window.__LISAANY_APP.sfx=${JSON.stringify(!!cfg.sfx)};}catch(e){}` +
    `try{window.LisaanyApp&&window.LisaanyApp.open(${JSON.stringify(cfg)});}catch(e){}true;`
  );
}

export function setSessionScript(session: LessonConfig['session']): string {
  return `try{window.LisaanyApp&&window.LisaanyApp.setSession(${JSON.stringify(session ?? null)});}catch(e){}true;`;
}

export const FLUSH_SCRIPT = `try{window.LisaanyApp&&window.LisaanyApp.flush();}catch(e){}true;`;
