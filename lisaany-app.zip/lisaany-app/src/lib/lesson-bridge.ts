/**
 * The contract between the app and the lesson page.
 *
 * The page is the website's lesson engine (see tools/build-lesson-page.py).
 * The app opens it with a LessonConfig and listens for BridgeMessages; the
 * page never navigates on its own — anything outside a lesson (unit list,
 * sign-up, upgrade) is handed back to the app as a `navigate` message.
 */
import type { PosMap, ProgMap } from './progress';
import type { LessonLang } from './settings';

/** Origin the page runs under. Nothing is fetched from it; it gives the page
 *  a stable origin for its local storage. */
export const LESSON_ORIGIN = 'https://app.lisaany.com/';

export type LessonView = 'lesson' | 'review' | 'srsreview' | 'reviewBuilder';

export type LessonConfig = {
  view: LessonView;
  /** Module id (number), unit id ("1.1") and block id — required for `lesson`. */
  mId?: number;
  uId?: string;
  bId?: number;
  /** Whether the app has granted access beyond the free units. */
  premium: boolean;
  /** Supabase session to sign the page in with; omitted for guests. */
  session?: { access_token: string; refresh_token: string } | null;
  /** Progress the app already knows, merged into the page on open. */
  prog?: ProgMap;
  pos?: PosMap;
  lang: LessonLang;
  /** Colour theme of the app; the lesson page follows it. */
  theme?: 'dark' | 'light';
};

export type BridgeMessage =
  | { type: 'opened'; view: LessonView; mId: number; uId: string; bId: number }
  | { type: 'progress'; prog: ProgMap; pos: PosMap; xp: number; streak: number; uid: string }
  | {
      type: 'navigate';
      view: 'hub' | 'units' | 'blocks' | 'signup' | 'upgrade';
      mId: number;
      uId: string;
      bId: number;
      progress?: { prog: ProgMap; pos: PosMap; xp: number; streak: number; uid: string };
    }
  | { type: 'view'; view: string; mId: number; uId: string; bId: number; top: string; bottom: string; stage: boolean }
  | { type: 'error'; message: string }
  | { type: 'jserror'; message: string; source?: string; line?: number };

export function parseBridgeMessage(raw: unknown): BridgeMessage | null {
  try {
    const data = typeof raw === 'string' ? JSON.parse(raw) : raw;
    if (data && typeof data === 'object' && typeof (data as { type?: unknown }).type === 'string') {
      return data as BridgeMessage;
    }
  } catch {
    /* not ours */
  }
  return null;
}

/** Everything except the session and progress — safe to log. */
export function describeConfig(cfg: LessonConfig): string {
  return `${cfg.view} ${cfg.uId ?? ''}${cfg.bId != null ? `/${cfg.bId}` : ''}`;
}

/** Runs before the page's own scripts: language (read by the engine at load) and the config. */
export function preloadScript(cfg: LessonConfig): string {
  return (
    `try{localStorage.setItem('lisaany_lang',${JSON.stringify(cfg.lang)});}catch(e){}` +
    `(function(){var L=${cfg.theme === 'light'};function a(){var d=document.documentElement;if(!d)return false;d.classList.toggle('ls-light',L);return true;}if(!a()){document.addEventListener('readystatechange',a);document.addEventListener('DOMContentLoaded',a);}})();` +
    `window.__LISAANY_APP=${JSON.stringify(cfg)};true;`
  );
}

/** Opens (or re-opens) the configured view once the page is up. */
export function openScript(cfg: LessonConfig): string {
  return `try{window.LisaanyApp&&window.LisaanyApp.open(${JSON.stringify(cfg)});}catch(e){}true;`;
}

export function setSessionScript(session: LessonConfig['session']): string {
  return `try{window.LisaanyApp&&window.LisaanyApp.setSession(${JSON.stringify(session ?? null)});}catch(e){}true;`;
}

export const FLUSH_SCRIPT = `try{window.LisaanyApp&&window.LisaanyApp.flush();}catch(e){}true;`;
