/**
 * What a finished lesson (unit) taught, and which lesson comes next — for the
 * celebration screen and the "lesson complete" card on the unit page.
 */
import { MODULES, type Unit } from './curriculum';
import type { CompletedMap } from './progress';

export type UnitStats = { words: number; conversations: number };

/** Words from the vocabulary parts, and the number of conversations. */
export function unitStats(unit: Unit): UnitStats {
  let words = 0;
  let conversations = 0;
  for (const b of unit.blocks) {
    if (b.type === 'vocab' && b.size?.unit === 'words') words += b.size.count;
    if (b.type === 'dialogue') conversations += 1;
  }
  return { words, conversations };
}

/** The lesson after this one, across modules (1.5 → 2.1); null after the last. */
export function nextUnitAfter(unitId: string): Unit | null {
  const all = MODULES.flatMap((m) => m.units);
  const i = all.findIndex((u) => u.id === unitId);
  return i >= 0 && i + 1 < all.length ? all[i + 1] : null;
}

export function isUnitComplete(unit: Unit, done: CompletedMap): boolean {
  return unit.blocks.length > 0 && unit.blocks.every((b) => done[`${unit.id}:${b.id}`]);
}
