import { NORANIA_HTML } from '@/data/norania-page';

export type NoraniaMessage =
  | { type: 'norania-opened' }
  | { type: 'norania-progress'; done: Record<string, boolean> }
  | { type: 'norania-close'; done: Record<string, boolean> }
  | { type: 'norania-finished'; lesson: number; wrong: number; done: Record<string, boolean> }
  | { type: 'jserror'; message: string };

export type NoraniaHostProps = {
  lesson: number;
  done: Record<string, boolean>;
  onMessage: (m: NoraniaMessage) => void;
};

export function noraniaHtml(lesson: number, done: Record<string, boolean>) {
  const cfg = JSON.stringify({ lesson, done });
  return NORANIA_HTML.replace('/*__NORANIA_CFG__*/', () => `window.__NORANIA_APP=${cfg};`);
}

export function parseNorania(raw: unknown): NoraniaMessage | null {
  try {
    const d = typeof raw === 'string' ? JSON.parse(raw) : raw;
    if (d && typeof d === 'object' && typeof (d as { type?: unknown }).type === 'string') return d as NoraniaMessage;
  } catch {
    /* not ours */
  }
  return null;
}

