/**
 * Norania (learn to read) — lesson data and progress.
 * Lesson content lives in the bundled page (src/data/norania-page.ts); the
 * native screens only need titles, steps and which lessons are done.
 *
 * Progress is kept on the device and, for a signed-in learner, mirrored to
 * Supabase (`norania_progress`, one row per user — supabase/norania_progress.sql):
 * every local write queues a push, and auth-context pulls the row at sign-in,
 * start-up and after a long time in the background, so a reinstall or a new
 * phone brings the lessons, stars and certificates back. Guests stay on the
 * device only; their progress joins the account they later sign in to.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';

import data from '@/data/norania.json';

import { reportError } from './report';
import { supabase } from './supabase';

export type NoraniaLesson = { i: number; part: string; type: string; title: string; icon: string; step: number; letters: string[] };
export type NoraniaStep = { name: string; icon: string; desc: string; lessons: number[] };

export const NORANIA_LESSONS = data.lessons as NoraniaLesson[];
export const NORANIA_STEPS = data.steps as NoraniaStep[];

/** Keys are lesson titles — the same keys the page itself uses. */
export type NoraniaDone = Record<string, true>;

const KEY = 'lisaany:norania-done';

export async function getNoraniaDone(): Promise<NoraniaDone> {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as NoraniaDone) : {};
  } catch {
    return {};
  }
}

export async function mergeNoraniaDone(incoming: Record<string, unknown> | undefined): Promise<NoraniaDone> {
  const cur = await getNoraniaDone();
  if (incoming) for (const k of Object.keys(incoming)) if (incoming[k]) cur[k] = true;
  try {
    await AsyncStorage.setItem(KEY, JSON.stringify(cur));
  } catch {
    /* best-effort */
  }
  pushNoraniaProgress();
  return cur;
}

export function isLessonDone(done: NoraniaDone, i: number): boolean {
  const l = NORANIA_LESSONS[i];
  return !!(l && done[l.title]);
}

export function stepDoneCount(done: NoraniaDone, step: NoraniaStep): number {
  return step.lessons.filter((i) => isLessonDone(done, i)).length;
}

/** First lesson not yet finished (or the first one). */
export function nextNoraniaLesson(done: NoraniaDone): number {
  const l = NORANIA_LESSONS.find((x) => !done[x.title]);
  return l ? l.i : 0;
}

/** Friendly lesson name: "Lesson 1" stays; letters lessons get a hint. */
export function lessonLabel(l: NoraniaLesson): string {
  return l.title;
}

export const NORANIA_TYPE_LABELS: Record<string, string> = {
  letters: 'Letters',
  letterdrill: 'Exercises',
  movement: 'Vowels',
  joining: 'Joining',
  madd: 'Long vowels',
  madddrill: 'Practice',
  daggeralif: 'Small alif',
  tanwin: 'Tanwīn',
  shaddah: 'Shaddah',
  reading: 'Reading',
  rule: 'Reading rule',
  stopping: 'Stopping',
  shapes: 'Letter shapes',
  sentences: 'Sentences',
  words: 'Quran words',
  surah: 'Quran reading',
};

/* ── stars, sticker album, weekly chart ─────────────────────────────── */

const STARS_KEY = 'lisaany:norania-stars';
const DAYS_KEY = 'lisaany:norania-days';
const NAME_KEY = 'lisaany:learner-name';

/** Lesson title → 1, 2 or 3 stars. */
export type NoraniaStars = Record<string, number>;

export async function getNoraniaStars(): Promise<NoraniaStars> {
  try {
    const raw = await AsyncStorage.getItem(STARS_KEY);
    return raw ? (JSON.parse(raw) as NoraniaStars) : {};
  } catch {
    return {};
  }
}

/** Three stars with no mistakes, two with one or two, otherwise one. */
export function starsForWrong(wrong: number): number {
  return wrong <= 0 ? 3 : wrong <= 2 ? 2 : 1;
}

export async function setNoraniaStars(lesson: number, stars: number): Promise<NoraniaStars> {
  const l = NORANIA_LESSONS[lesson];
  const cur = await getNoraniaStars();
  if (l && (cur[l.title] ?? 0) < stars) cur[l.title] = stars;
  try {
    await AsyncStorage.setItem(STARS_KEY, JSON.stringify(cur));
  } catch {
    /* best-effort */
  }
  pushNoraniaProgress();
  return cur;
}

export function starsFor(stars: NoraniaStars, i: number): number {
  const l = NORANIA_LESSONS[i];
  return l ? (stars[l.title] ?? 0) : 0;
}

/**
 * The glyph shown for a lesson (tiles, cards, the reward medal).
 *
 * The curriculum stores some icons as a bare combining mark (a lone sukūn),
 * which draws nothing on its own, and leaves the practice lessons with no icon
 * at all — so a bare mark is carried on a bāʾ and an empty one falls back to
 * the icon of the step the lesson belongs to.
 */
export function lessonGlyph(l: NoraniaLesson | undefined): string {
  if (!l) return '\u0628';
  const icon = (l.icon ?? '').trim();
  if (!icon) return NORANIA_STEPS[l.step]?.icon || '\u0628';
  const code = icon.codePointAt(0) ?? 0;
  // A combining mark (fatḥa … sukūn, shaddah, dagger alif) with no letter under it.
  if (icon.length === 1 && ((code >= 0x064b && code <= 0x0652) || code === 0x0670)) return `\u0628${icon}`;
  // A lone tatweel is just a stroke; a joined bāʾ makes "joining" legible.
  if (icon === '\u0640') return '\u0640\u0628\u0640';
  return icon;
}

/** Same, for a step's own icon (steps always carry one, but guard anyway). */
export function stepGlyph(s: NoraniaStep | undefined): string {
  const icon = (s?.icon ?? '').trim();
  const code = icon.codePointAt(0) ?? 0;
  if (!icon) return '\u0628';
  if (icon.length === 1 && ((code >= 0x064b && code <= 0x0652) || code === 0x0670)) return `\u0628${icon}`;
  return icon;
}

function localDay(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

/** Days on which a lesson was finished ("2026-09-22" → true). */
type NoraniaDays = Record<string, true>;

async function readDays(): Promise<NoraniaDays> {
  try {
    const raw = await AsyncStorage.getItem(DAYS_KEY);
    return raw ? (JSON.parse(raw) as NoraniaDays) : {};
  } catch {
    return {};
  }
}

/** Keeps roughly the last two months. */
function trimDays(days: NoraniaDays): NoraniaDays {
  const keys = Object.keys(days).sort();
  for (const k of keys.slice(0, Math.max(0, keys.length - 60))) delete days[k];
  return days;
}

async function writeDays(days: NoraniaDays): Promise<void> {
  await AsyncStorage.setItem(DAYS_KEY, JSON.stringify(trimDays(days)));
}

/** Days a lesson was finished, for the weekly star chart. */
export async function markNoraniaDay(): Promise<void> {
  try {
    const days = await readDays();
    days[localDay()] = true;
    await writeDays(days);
  } catch {
    /* best-effort */
  }
  pushNoraniaProgress();
}

export type NoraniaWeekDay = { label: string; star: boolean; isToday: boolean };

export async function getNoraniaWeek(): Promise<NoraniaWeekDay[]> {
  const days = await readDays();
  const now = new Date();
  const monday = new Date(now);
  monday.setDate(now.getDate() - ((now.getDay() + 6) % 7));
  const today = localDay(now);
  return ['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((label, i) => {
    const d = new Date(monday);
    d.setDate(monday.getDate() + i);
    const key = localDay(d);
    return { label, star: !!days[key], isToday: key === today };
  });
}

export async function getLearnerName(): Promise<string> {
  try {
    return (await AsyncStorage.getItem(NAME_KEY)) ?? '';
  } catch {
    return '';
  }
}

/** The child's first name for the certificate. Stays on this device only — it is never uploaded. */
export async function setLearnerName(name: string): Promise<void> {
  try {
    await AsyncStorage.setItem(NAME_KEY, name);
  } catch {
    /* best-effort */
  }
}

/* ── Cloud copy (`norania_progress`) ─────────────────────────────────── */

type NoraniaRow = {
  done: Record<string, unknown> | null;
  stars: Record<string, unknown> | null;
  days: Record<string, unknown> | null;
};

const TABLE = 'norania_progress';

/** True until supabase/norania_progress.sql has been run: then the table is simply not there yet. */
function tableMissing(e: unknown): boolean {
  const code = (e as { code?: string } | null)?.code;
  return code === '42P01' || code === 'PGRST205';
}

async function readRow(userId: string): Promise<NoraniaRow | null> {
  const { data, error } = await supabase.from(TABLE).select('done,stars,days').eq('user_id', userId).maybeSingle();
  if (error) throw error;
  return (data as NoraniaRow | null) ?? null;
}

type Merged = { done: NoraniaDone; stars: NoraniaStars; days: NoraniaDays; localAhead: boolean };

/**
 * The union of what is on the device and what is in the row: done lessons
 * never un-do, each lesson keeps its best stars, every day with a finished
 * lesson counts. (The child's name is not part of the row: it stays on the
 * device.) `localAhead` says whether the device knew something the row did not.
 */
function mergeRow(local: { done: NoraniaDone; stars: NoraniaStars; days: NoraniaDays }, row: NoraniaRow | null): Merged {
  const done: NoraniaDone = { ...local.done };
  const stars: NoraniaStars = { ...local.stars };
  const days: NoraniaDays = { ...local.days };
  let localAhead = false;
  const remoteDone = row?.done ?? {};
  for (const k of Object.keys(remoteDone)) if (remoteDone[k]) done[k] = true;
  for (const k of Object.keys(local.done)) if (!remoteDone[k]) localAhead = true;
  const remoteStars = row?.stars ?? {};
  for (const k of Object.keys(remoteStars)) {
    const n = Number(remoteStars[k]);
    if (Number.isFinite(n) && n > (stars[k] ?? 0)) stars[k] = n;
  }
  for (const k of Object.keys(local.stars)) if ((local.stars[k] ?? 0) > Number(remoteStars[k] ?? 0)) localAhead = true;
  const remoteDays = row?.days ?? {};
  for (const k of Object.keys(remoteDays)) if (remoteDays[k]) days[k] = true;
  for (const k of Object.keys(local.days)) if (!remoteDays[k]) localAhead = true;
  return { done, stars, days: trimDays(days), localAhead };
}

async function readLocal() {
  const [done, stars, days] = await Promise.all([getNoraniaDone(), getNoraniaStars(), readDays()]);
  return { done, stars, days };
}

/** Saves a merge result on the device without queueing another push. */
async function writeLocal(m: Merged): Promise<void> {
  try {
    await AsyncStorage.setItem(KEY, JSON.stringify(m.done));
    await AsyncStorage.setItem(STARS_KEY, JSON.stringify(m.stars));
    await writeDays(m.days);
  } catch {
    /* best-effort */
  }
}

/**
 * Bring the learner's cloud row onto this device (merged, never replacing
 * what is already here). Returns true when a row was found. When the device
 * knew something the row did not, a push follows so both sides agree.
 */
export async function pullNoraniaProgress(userId: string): Promise<boolean> {
  try {
    const row = await readRow(userId);
    if (!row) {
      // Nothing in the cloud yet: a guest's lessons become the account's.
      const local = await readLocal();
      if (Object.keys(local.done).length || Object.keys(local.stars).length) pushNoraniaProgress();
      return false;
    }
    const merged = mergeRow(await readLocal(), row);
    await writeLocal(merged);
    if (merged.localAhead) pushNoraniaProgress();
    return true;
  } catch (e) {
    if (!tableMissing(e)) reportError(e, { where: 'norania pull' });
    return false;
  }
}

let pushTimer: ReturnType<typeof setTimeout> | null = null;
let pushing: Promise<void> | null = null;
let pushAgain = false;

/**
 * Queue an upload of the device's Norania progress. Guests are skipped
 * (checked at send time). Calls within `delayMs` collapse into one write;
 * `flushNoraniaProgress()` sends now. Errors are reported, never thrown.
 */
export function pushNoraniaProgress(delayMs = 2500): void {
  if (pushTimer) clearTimeout(pushTimer);
  pushTimer = setTimeout(() => {
    pushTimer = null;
    void pushNow();
  }, delayMs);
}

async function pushNow(): Promise<void> {
  if (pushing) {
    pushAgain = true;
    return pushing;
  }
  pushing = (async () => {
    do {
      pushAgain = false;
      try {
        const { data } = await supabase.auth.getSession();
        const userId = data.session?.user?.id;
        if (!userId) return; // a guest's progress stays on the device until they sign in
        // Merge with the row first so a device that missed a pull can never shrink it.
        let row: NoraniaRow | null = null;
        try {
          row = await readRow(userId);
        } catch {
          row = null;
        }
        const merged = mergeRow(await readLocal(), row);
        const { error } = await supabase.from(TABLE).upsert(
          {
            user_id: userId,
            done: merged.done,
            stars: merged.stars,
            days: merged.days,
            updated_at: new Date().toISOString(),
          },
          { onConflict: 'user_id' }
        );
        if (error) throw error;
      } catch (e) {
        if (!tableMissing(e)) reportError(e, { where: 'norania push' });
      }
    } while (pushAgain);
  })();
  try {
    await pushing;
  } finally {
    pushing = null;
  }
}

/** Send whatever is queued, now (before signing out). Resolves when the write has finished or failed. */
export async function flushNoraniaProgress(): Promise<void> {
  if (pushTimer) {
    clearTimeout(pushTimer);
    pushTimer = null;
    await pushNow();
    return;
  }
  if (pushing) await pushing;
}
