/**
 * Norania (learn to read) — lesson data and on-device progress.
 * Lesson content lives in the bundled page (src/data/norania-page.ts); the
 * native screens only need titles, steps and which lessons are done.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';

import data from '@/data/norania.json';

export type NoraniaLesson = { i: number; part: string; type: string; title: string; icon: string; step: number; letters: string[] };
export type NoraniaStep = { name: string; icon: string; desc: string; lessons: number[] };

export const NORANIA_LESSONS = data.lessons as NoraniaLesson[];
export const NORANIA_STEPS = data.steps as NoraniaStep[];

/** Keys are lesson titles — the same keys the page itself uses. */
export type NoraniaDone = Record<string, true>;

const KEY = 'lisaany:norania-done';

export async function getNoraniaDone(): Promise<NoraniaDone> {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as NoraniaDone) : {};
  } catch {
    return {};
  }
}

export async function mergeNoraniaDone(incoming: Record<string, unknown> | undefined): Promise<NoraniaDone> {
  const cur = await getNoraniaDone();
  if (incoming) for (const k of Object.keys(incoming)) if (incoming[k]) cur[k] = true;
  try {
    await AsyncStorage.setItem(KEY, JSON.stringify(cur));
  } catch {
    /* best-effort */
  }
  return cur;
}

export function isLessonDone(done: NoraniaDone, i: number): boolean {
  const l = NORANIA_LESSONS[i];
  return !!(l && done[l.title]);
}

export function stepDoneCount(done: NoraniaDone, step: NoraniaStep): number {
  return step.lessons.filter((i) => isLessonDone(done, i)).length;
}

/** First lesson not yet finished (or the first one). */
export function nextNoraniaLesson(done: NoraniaDone): number {
  const l = NORANIA_LESSONS.find((x) => !done[x.title]);
  return l ? l.i : 0;
}

/** Friendly lesson name: "Lesson 1" stays; letters lessons get a hint. */
export function lessonLabel(l: NoraniaLesson): string {
  return l.title;
}

export const NORANIA_TYPE_LABELS: Record<string, string> = {
  letters: 'Letters',
  letterdrill: 'Exercises',
  movement: 'Vowels',
  joining: 'Joining',
  madd: 'Long vowels',
  madddrill: 'Practice',
  daggeralif: 'Small alif',
  tanwin: 'Tanwīn',
  shaddah: 'Shaddah',
  reading: 'Reading',
  rule: 'Reading rule',
  stopping: 'Stopping',
  shapes: 'Letter shapes',
  sentences: 'Sentences',
  words: 'Quran words',
  surah: 'Quran reading',
};

/* ── stars, sticker album, weekly chart ─────────────────────────────── */

const STARS_KEY = 'lisaany:norania-stars';
const DAYS_KEY = 'lisaany:norania-days';
const NAME_KEY = 'lisaany:learner-name';

/** Lesson title → 1, 2 or 3 stars. */
export type NoraniaStars = Record<string, number>;

export async function getNoraniaStars(): Promise<NoraniaStars> {
  try {
    const raw = await AsyncStorage.getItem(STARS_KEY);
    return raw ? (JSON.parse(raw) as NoraniaStars) : {};
  } catch {
    return {};
  }
}

/** Three stars with no mistakes, two with one or two, otherwise one. */
export function starsForWrong(wrong: number): number {
  return wrong <= 0 ? 3 : wrong <= 2 ? 2 : 1;
}

export async function setNoraniaStars(lesson: number, stars: number): Promise<NoraniaStars> {
  const l = NORANIA_LESSONS[lesson];
  const cur = await getNoraniaStars();
  if (l && (cur[l.title] ?? 0) < stars) cur[l.title] = stars;
  try {
    await AsyncStorage.setItem(STARS_KEY, JSON.stringify(cur));
  } catch {
    /* best-effort */
  }
  return cur;
}

export function starsFor(stars: NoraniaStars, i: number): number {
  const l = NORANIA_LESSONS[i];
  return l ? (stars[l.title] ?? 0) : 0;
}

/**
 * The glyph shown for a lesson (tiles, cards, the reward medal).
 *
 * The curriculum stores some icons as a bare combining mark (a lone sukūn),
 * which draws nothing on its own, and leaves the practice lessons with no icon
 * at all — so a bare mark is carried on a bāʾ and an empty one falls back to
 * the icon of the step the lesson belongs to.
 */
export function lessonGlyph(l: NoraniaLesson | undefined): string {
  if (!l) return '\u0628';
  const icon = (l.icon ?? '').trim();
  if (!icon) return NORANIA_STEPS[l.step]?.icon || '\u0628';
  const code = icon.codePointAt(0) ?? 0;
  // A combining mark (fatḥa … sukūn, shaddah, dagger alif) with no letter under it.
  if (icon.length === 1 && ((code >= 0x064b && code <= 0x0652) || code === 0x0670)) return `\u0628${icon}`;
  // A lone tatweel is just a stroke; a joined bāʾ makes "joining" legible.
  if (icon === '\u0640') return '\u0640\u0628\u0640';
  return icon;
}

/** Same, for a step's own icon (steps always carry one, but guard anyway). */
export function stepGlyph(s: NoraniaStep | undefined): string {
  const icon = (s?.icon ?? '').trim();
  const code = icon.codePointAt(0) ?? 0;
  if (!icon) return '\u0628';
  if (icon.length === 1 && ((code >= 0x064b && code <= 0x0652) || code === 0x0670)) return `\u0628${icon}`;
  return icon;
}

function localDay(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

/** Days a lesson was finished, for the weekly star chart. */
export async function markNoraniaDay(): Promise<void> {
  try {
    const raw = await AsyncStorage.getItem(DAYS_KEY);
    const days: Record<string, true> = raw ? JSON.parse(raw) : {};
    days[localDay()] = true;
    const keys = Object.keys(days).sort();
    for (const k of keys.slice(0, Math.max(0, keys.length - 60))) delete days[k];
    await AsyncStorage.setItem(DAYS_KEY, JSON.stringify(days));
  } catch {
    /* best-effort */
  }
}

export type NoraniaWeekDay = { label: string; star: boolean; isToday: boolean };

export async function getNoraniaWeek(): Promise<NoraniaWeekDay[]> {
  let days: Record<string, true> = {};
  try {
    const raw = await AsyncStorage.getItem(DAYS_KEY);
    days = raw ? JSON.parse(raw) : {};
  } catch {
    /* best-effort */
  }
  const now = new Date();
  const monday = new Date(now);
  monday.setDate(now.getDate() - ((now.getDay() + 6) % 7));
  const today = localDay(now);
  return ['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((label, i) => {
    const d = new Date(monday);
    d.setDate(monday.getDate() + i);
    const key = localDay(d);
    return { label, star: !!days[key], isToday: key === today };
  });
}

export async function getLearnerName(): Promise<string> {
  try {
    return (await AsyncStorage.getItem(NAME_KEY)) ?? '';
  } catch {
    return '';
  }
}

export async function setLearnerName(name: string): Promise<void> {
  try {
    await AsyncStorage.setItem(NAME_KEY, name);
  } catch {
    /* best-effort */
  }
}
