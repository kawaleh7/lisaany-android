import AsyncStorage from '@react-native-async-storage/async-storage';

/**
 * First-run gate: has this device already been through the landing +
 * onboarding flow? Checked once at cold start (see `(tabs)/index.tsx`), and
 * set the moment the learner finishes onboarding so it never shows again on
 * this device.
 */
const SEEN_KEY = 'lisaany_seen_landing';

export async function getHasSeenLanding(): Promise<boolean> {
  try {
    return (await AsyncStorage.getItem(SEEN_KEY)) === '1';
  } catch {
    return true; // fail open — never trap someone on the landing screen
  }
}

export async function setHasSeenLanding(): Promise<void> {
  try {
    await AsyncStorage.setItem(SEEN_KEY, '1');
  } catch {
    /* best effort */
  }
}

/** Why someone said they're learning Arabic — collected once, onboarding step 1. */
export type LearningGoal = 'quran' | 'people' | 'curious';

const GOAL_KEY = 'lisaany_goal';

export async function getGoal(): Promise<LearningGoal | null> {
  try {
    return (await AsyncStorage.getItem(GOAL_KEY)) as LearningGoal | null;
  } catch {
    return null;
  }
}

export async function setGoal(goal: LearningGoal): Promise<void> {
  try {
    await AsyncStorage.setItem(GOAL_KEY, goal);
  } catch {
    /* best effort */
  }
}

/** Whether they said they can already read Arabic script — onboarding step 2. */
const CAN_READ_KEY = 'lisaany_can_read';

export async function getCanReadArabic(): Promise<boolean | null> {
  try {
    const v = await AsyncStorage.getItem(CAN_READ_KEY);
    return v === null ? null : v === '1';
  } catch {
    return null;
  }
}

export async function setCanReadArabic(canRead: boolean): Promise<void> {
  try {
    await AsyncStorage.setItem(CAN_READ_KEY, canRead ? '1' : '0');
  } catch {
    /* best effort */
  }
}
