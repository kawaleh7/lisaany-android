/**
 * Port of the web app's plan.js — single source of truth for subscription state.
 *
 * Maps the Supabase `subscriptions.plan` text column onto the four-state model
 * the rest of the app reasons about, plus a `staff` bypass.
 */
import { storePremium } from './store';
import { supabase } from './supabase';

export type Plan = 'free' | 'basic' | 'premium_monthly' | 'premium_yearly' | 'staff';

const CACHE_MS = 60_000;

let cached: Plan | null = null;
let cachedAt = 0;

function mapPlanString(rawPlan: string | null | undefined): Plan {
  const p = String(rawPlan ?? '').toLowerCase().trim();
  if (!p) return 'free';
  if (p === 'self_paced' || p === 'basic') return 'basic';
  if (p.includes('year') || p.includes('annual')) return 'premium_yearly';
  // Any other active plan (with_tutor, premium, tutor, …) → monthly premium.
  return 'premium_monthly';
}

export async function getPlan(): Promise<Plan> {
  if (cached && Date.now() - cachedAt < CACHE_MS) return cached;

  const remember = (p: Plan): Plan => {
    cached = p;
    cachedAt = Date.now();
    return p;
  };

  try {
    // iPhone: an active App Store subscription counts, signed in or not.
    const store = await storePremium();
    if (store) return remember(store === 'yearly' ? 'premium_yearly' : 'premium_monthly');

    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) return remember('free');

    // Tutors and owners bypass every paywall (set via the staff code on auth).
    if ((user.app_metadata as { role?: string } | undefined)?.role === 'staff') {
      return remember('staff');
    }

    const { data, error } = await supabase
      .from('subscriptions')
      .select('status, plan, stripe_subscription_id')
      .eq('user_id', user.id)
      .in('status', ['active', 'trialing'])
      .limit(1)
      .maybeSingle();

    if (error || !data) return remember('free');

    return remember(mapPlanString(data.plan));
  } catch {
    return remember('free');
  }
}

export function invalidatePlanCache() {
  cached = null;
  cachedAt = 0;
}

export async function isPaid() {
  return (await getPlan()) !== 'free';
}

export async function isStaff() {
  return (await getPlan()) === 'staff';
}

/** Units that stay open on the free tier — the same ones the Arabic platform
 *  page opens to signed-up free users (arabic_platform.html FREE_UNITS). */
export const FREE_UNITS = ['1.1', '1.2', '1.3'];

export function isUnitFree(unitId: string | number) {
  return FREE_UNITS.includes(String(unitId));
}

export async function canAccessUnit(unitId: string | number) {
  return isUnitFree(unitId) || (await isPaid());
}

export const PLAN_LABELS: Record<Plan, string> = {
  free: 'Free',
  basic: 'Self-paced',
  premium_monthly: 'With tutor — monthly',
  premium_yearly: 'With tutor — yearly',
  staff: 'Staff',
};
