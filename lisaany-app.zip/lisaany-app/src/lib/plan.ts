/**
 * Port of the web app's plan.js — single source of truth for subscription state.
 *
 * Maps the Supabase `subscriptions.plan` text column onto the four-state model
 * the rest of the app reasons about, plus a `staff` bypass.
 *
 * Resolution order, first hit wins:
 *   1. store entitlement (App Store / Google Play through RevenueCat — cached on
 *      the device, so it answers offline too)
 *   2. staff role on the session
 *   3. the `subscriptions` row on Supabase (website / Stripe subscribers)
 *   4. the last plan this device saw for this user (AsyncStorage)
 *   5. free
 *
 * Only steps 1–3 need the network, and only step 3 always does. Whenever any
 * of them fails we answer with step 4 so a paying learner opening the app on
 * the metro is not paywalled, and we keep that answer for a few seconds only,
 * so a recovering connection is picked up quickly. Nothing here reads the
 * session from the server: `getSession()` is a local read — except that an
 * EXPIRED access token makes it try a refresh, and offline that refresh fails
 * and it answers "no session" although one is stored. That is the most common
 * offline case (first open of the day), so the last signed-in user id is kept
 * here too and used to look up the remembered plan when that happens.
 *
 * Every network step is bounded (LOOKUP_TIMEOUT_MS): a connection that
 * neither answers nor fails (captive portal, one bar) must not hold a lesson.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';

import { reportError } from './report';
import { storePremiumStrict } from './store';
import { supabase } from './supabase';

export type Plan = 'free' | 'basic' | 'premium_monthly' | 'premium_yearly' | 'staff';

/** How long a successful lookup stands. */
const CACHE_MS = 60_000;
/** How long a failed lookup (persisted fallback) stands before we try again. */
const ERROR_CACHE_MS = 5_000;

const PERSIST_PREFIX = 'lisaany:plan:';
/** The last signed-in user this device resolved a plan for. */
const LAST_UID_KEY = 'lisaany:plan-last-uid';
/** A lookup that has not answered by then counts as failed. */
const LOOKUP_TIMEOUT_MS = 4_000;
/** Key suffix for a device with no signed-in learner (a store-only purchase). */
const GUEST = 'guest';

const PLANS: readonly Plan[] = ['free', 'basic', 'premium_monthly', 'premium_yearly', 'staff'];

let cached: Plan | null = null;
let cachedAt = 0;
let cachedTtl = CACHE_MS;
/** One lookup at a time — the module screen asks for every unit at once. */
let inflight: Promise<Plan> | null = null;
/** Bumped by invalidatePlanCache so a lookup started for the previous learner is not cached. */
let generation = 0;

function mapPlanString(rawPlan: string | null | undefined): Plan {
  const p = String(rawPlan ?? '').toLowerCase().trim();
  if (!p) return 'free';
  if (p === 'self_paced' || p === 'basic') return 'basic';
  if (p.includes('year') || p.includes('annual')) return 'premium_yearly';
  // Any other active plan (premium, with_tutor, tutor, …) → monthly premium.
  return 'premium_monthly';
}

function persistKey(userId: string | null): string {
  return PERSIST_PREFIX + (userId ?? GUEST);
}

async function readPersisted(userId: string | null): Promise<Plan | null> {
  try {
    const raw = await AsyncStorage.getItem(persistKey(userId));
    return raw && (PLANS as readonly string[]).includes(raw) ? (raw as Plan) : null;
  } catch {
    return null;
  }
}

async function writePersisted(userId: string | null, plan: Plan): Promise<void> {
  try {
    await AsyncStorage.setItem(persistKey(userId), plan);
    if (userId) await AsyncStorage.setItem(LAST_UID_KEY, userId);
  } catch (e) {
    reportError(e, { where: 'plan.persist' });
  }
}

/** The signed-in user this device last resolved a plan for (null after sign-out). */
export async function getLastKnownUserId(): Promise<string | null> {
  try {
    return (await AsyncStorage.getItem(LAST_UID_KEY)) || null;
  } catch {
    return null;
  }
}

function withTimeout<T>(work: PromiseLike<T>, ms: number, what: string): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`${what} timed out`)), ms);
    work.then(
      (v) => {
        clearTimeout(timer);
        resolve(v);
      },
      (e) => {
        clearTimeout(timer);
        reject(e);
      }
    );
  });
}

/**
 * Forget the plan this device remembered for a learner. Call it on sign-out and
 * after account deletion with that user's id; with no id it clears every
 * remembered plan (including the guest one), e.g. when wiping local data.
 * Also drops the in-memory cache.
 */
export async function clearPersistedPlan(userId?: string | null): Promise<void> {
  invalidatePlanCache();
  try {
    if (userId) {
      await AsyncStorage.removeItem(persistKey(userId));
      if ((await AsyncStorage.getItem(LAST_UID_KEY)) === userId) await AsyncStorage.removeItem(LAST_UID_KEY);
      return;
    }
    const keys = (await AsyncStorage.getAllKeys()).filter((k) => k.startsWith(PERSIST_PREFIX));
    if (keys.length) await AsyncStorage.multiRemove(keys);
    await AsyncStorage.removeItem(LAST_UID_KEY);
  } catch (e) {
    reportError(e, { where: 'plan.clearPersisted' });
  }
}

async function resolvePlan(gen: number): Promise<Plan> {
  const remember = (p: Plan, ttl: number): Plan => {
    if (gen !== generation) return p; // the learner changed while we were looking
    cached = p;
    cachedAt = Date.now();
    cachedTtl = ttl;
    return p;
  };
  /** A definite answer: cache it for a minute and remember it for next time. */
  const settle = (userId: string | null, p: Plan): Plan => {
    void writePersisted(userId, p);
    return remember(p, CACHE_MS);
  };
  /** The lookup failed: answer with what this device last saw, and retry soon. */
  const fallback = async (userId: string | null): Promise<Plan> => remember((await readPersisted(userId)) ?? 'free', ERROR_CACHE_MS);

  // 1. Store entitlement (either platform), signed in or not. RevenueCat keeps
  //    CustomerInfo on the device, so this normally answers offline as well.
  let store: 'yearly' | 'monthly' | null = null;
  let storeFailed = false;
  try {
    store = await withTimeout(storePremiumStrict(), LOOKUP_TIMEOUT_MS, 'store');
  } catch {
    storeFailed = true;
  }

  // Who is signed in — a local read of the stored session, no round-trip
  // unless the token has expired (then auth-js tries to refresh it, and
  // offline that fails: `session` is null although one is stored).
  let userId: string | null = null;
  let role: string | undefined;
  let sessionUnreadable = false;
  try {
    const { data, error } = await supabase.auth.getSession();
    userId = data.session?.user?.id ?? null;
    role = (data.session?.user?.app_metadata as { role?: string } | undefined)?.role;
    sessionUnreadable = !data.session && !!error;
  } catch (e) {
    reportError(e, { where: 'plan.getSession' });
    sessionUnreadable = true;
  }
  if (!userId && sessionUnreadable) {
    // Offline with an expired token: the learner is still signed in on this
    // device — answer for the user we last knew, never as a guest.
    const last = await getLastKnownUserId();
    if (store) return settle(last, store === 'yearly' ? 'premium_yearly' : 'premium_monthly');
    return fallback(last);
  }

  if (store) return settle(userId, store === 'yearly' ? 'premium_yearly' : 'premium_monthly');

  if (!userId) {
    // A guest can only be paid through the store.
    return storeFailed ? fallback(null) : settle(null, 'free');
  }

  // 2. Tutors and owners bypass every paywall (set via the staff code on auth).
  if (role === 'staff') return settle(userId, 'staff');

  // 3. Website / Stripe subscribers: the `subscriptions` row.
  try {
    const query = supabase
      .from('subscriptions')
      .select('status, plan, current_period_end')
      .eq('user_id', userId)
      .in('status', ['active', 'trialing'])
      .limit(1)
      .maybeSingle();
    const { data, error } = await withTimeout(query, LOOKUP_TIMEOUT_MS, 'subscriptions');
    if (error) throw error;
    let plan: Plan = data ? mapPlanString(data.plan) : 'free';
    // Store purchases reach this table as plan 'premium' (the only value the
    // website recognises); a period running for more than two months is the
    // yearly one. Label only — access is the same.
    if (plan === 'premium_monthly' && data?.current_period_end) {
      const end = new Date(data.current_period_end as string).getTime();
      if (Number.isFinite(end) && end - Date.now() > 60 * 86_400_000) plan = 'premium_yearly';
    }
    // The table says free but the store could not answer: do not overwrite a
    // remembered store purchase with 'free' — wait for the store to come back.
    if (plan === 'free' && storeFailed) return fallback(userId);
    return settle(userId, plan);
  } catch (e) {
    reportError(e, { where: 'plan.subscriptions' });
    return fallback(userId);
  }
}

export async function getPlan(): Promise<Plan> {
  if (cached && Date.now() - cachedAt < cachedTtl) return cached;
  if (!inflight) {
    const gen = generation;
    inflight = resolvePlan(gen)
      .catch((e) => {
        // resolvePlan handles its own failures; this is a last line of defence.
        reportError(e, { where: 'plan.getPlan' });
        return (cached ?? 'free') as Plan;
      })
      .finally(() => {
        if (gen === generation) inflight = null;
      });
  }
  return inflight;
}

export function invalidatePlanCache() {
  cached = null;
  cachedAt = 0;
  cachedTtl = CACHE_MS;
  generation++;
  inflight = null;
}

export async function isPaid() {
  return (await getPlan()) !== 'free';
}

export async function isStaff() {
  return (await getPlan()) === 'staff';
}

/** Units that stay open on the free tier — the same ones the Arabic platform
 *  page opens to signed-up free users (arabic_platform.html FREE_UNITS). */
export const FREE_UNITS = ['1.1', '1.2', '1.3'];

export function isUnitFree(unitId: string | number) {
  return FREE_UNITS.includes(String(unitId));
}

export async function canAccessUnit(unitId: string | number) {
  return isUnitFree(unitId) || (await isPaid());
}

export const PLAN_LABELS: Record<Plan, string> = {
  free: 'Free',
  basic: 'Self-paced',
  premium_monthly: 'Premium — monthly',
  premium_yearly: 'Premium — yearly',
  staff: 'Staff',
};
