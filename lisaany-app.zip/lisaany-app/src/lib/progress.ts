/**
 * Course progress, mirrored from the lesson engine.
 *
 * The lesson page (the website's own engine, running in a web view) owns
 * progress: it saves locally as the learner works and syncs signed-in users
 * to Supabase (`learner_progress`), exactly as lisaany.com does. Every save
 * also reaches the app over the bridge as a snapshot, which is kept here so
 * the native screens (Today, Lessons, Unit) can show it without opening the
 * page. When a lesson opens, the mirror is handed back to the page and
 * merged, so nothing is lost if a bridge message was missed.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';

import { MODULES, type Unit } from './curriculum';
import { getMinGoal } from './goal';

const SNAPSHOT_KEY = 'lisaany:engine-progress:v1';
const LAST_UNIT_KEY = 'lisaany:last-unit';

/** mId → uId → bId → 'done' (the engine's `PROG`). */
export type ProgMap = Record<string, Record<string, Record<string, string>>>;
/** mId → uId → bId → furthest step reached (the engine's `POS`). */
export type PosMap = Record<string, Record<string, Record<string, { n: number; total: number }>>>;

export type EngineSnapshot = {
  prog: ProgMap;
  pos: PosMap;
  xp: number;
  streak: number;
  /** Supabase user id, or 'guest'. */
  uid: string;
  /** ISO time the snapshot was taken. */
  at: string;
};

export type LastUnit = {
  /** Dotted unit id, e.g. "2.3". */
  unitId: string;
  at: string;
};

const EMPTY: EngineSnapshot = { prog: {}, pos: {}, xp: 0, streak: 0, uid: 'guest', at: '' };

export async function getEngineProgress(): Promise<EngineSnapshot> {
  try {
    const raw = await AsyncStorage.getItem(SNAPSHOT_KEY);
    return raw ? { ...EMPTY, ...(JSON.parse(raw) as Partial<EngineSnapshot>) } : EMPTY;
  } catch {
    return EMPTY;
  }
}

function mergeProg(into: ProgMap, from: ProgMap | undefined) {
  if (!from) return;
  for (const m of Object.keys(from)) {
    into[m] ??= {};
    for (const u of Object.keys(from[m])) {
      into[m][u] ??= {};
      for (const b of Object.keys(from[m][u])) {
        if (from[m][u][b] === 'done' || !into[m][u][b]) into[m][u][b] = from[m][u][b];
      }
    }
  }
}

function mergePos(into: PosMap, from: PosMap | undefined) {
  if (!from) return;
  for (const m of Object.keys(from)) {
    into[m] ??= {};
    for (const u of Object.keys(from[m])) {
      into[m][u] ??= {};
      for (const b of Object.keys(from[m][u])) {
        const r = from[m][u][b];
        const l = into[m][u][b];
        if (!l || (r && r.n > l.n)) into[m][u][b] = r;
      }
    }
  }
}

/**
 * Record a snapshot posted by the page. Same user: union of what is done
 * (done never un-does). Different user: the snapshot replaces the mirror.
 */
export async function applyEngineProgress(
  incoming: Partial<EngineSnapshot> & { prog?: ProgMap }
): Promise<EngineSnapshot> {
  const current = await getEngineProgress();
  await noteXpBaseline(current.xp);
  await noteLearnedBaseline(current.prog);
  const uid = incoming.uid ?? current.uid;
  const sameUser = uid === current.uid;

  const next: EngineSnapshot = {
    prog: sameUser ? current.prog : {},
    pos: sameUser ? current.pos : {},
    xp: Math.max(sameUser ? current.xp : 0, incoming.xp ?? 0),
    streak: incoming.streak ?? (sameUser ? current.streak : 0),
    uid,
    at: new Date().toISOString(),
  };
  mergeProg(next.prog, incoming.prog);
  mergePos(next.pos, incoming.pos);

  try {
    await AsyncStorage.setItem(SNAPSHOT_KEY, JSON.stringify(next));
  } catch {
    /* best-effort */
  }
  await getTodayXp(next.xp); // records today's XP in the weekly history
  return next;
}

/** Keys are `${unitId}:${blockId}` — the shape the list screens consume. */
export type CompletedMap = Record<string, true>;

export function completedFromProg(prog: ProgMap): CompletedMap {
  const map: CompletedMap = {};
  for (const m of Object.keys(prog)) {
    for (const u of Object.keys(prog[m])) {
      for (const b of Object.keys(prog[m][u])) {
        if (prog[m][u][b] === 'done') map[`${u}:${b}`] = true;
      }
    }
  }
  return map;
}

export async function getCompletedBlocks(): Promise<CompletedMap> {
  return completedFromProg((await getEngineProgress()).prog);
}

export function unitDoneCount(unit: Unit, completed: CompletedMap): number {
  return unit.blocks.filter((b) => completed[`${unit.id}:${b.id}`]).length;
}

/** The website's rule: a block opens once the one before it is done. */
export function isBlockUnlocked(unit: Unit, blockId: number, completed: CompletedMap): boolean {
  const idx = unit.blocks.findIndex((b) => b.id === blockId);
  if (idx <= 0) return true;
  const prev = unit.blocks[idx - 1];
  return !!completed[`${unit.id}:${prev.id}`];
}

/** Where "Continue" goes: the first block not yet done, or the first block. */
export function nextBlockFor(unit: Unit, completed: CompletedMap): number {
  const pending = unit.blocks.find((b) => !completed[`${unit.id}:${b.id}`]);
  return (pending ?? unit.blocks[0]).id;
}

export type Streak = { count: number };

export async function getStreak(): Promise<Streak> {
  return { count: (await getEngineProgress()).streak };
}

export async function getXp(): Promise<number> {
  return (await getEngineProgress()).xp;
}

export async function getLastUnit(): Promise<LastUnit | null> {
  try {
    const raw = await AsyncStorage.getItem(LAST_UNIT_KEY);
    return raw ? (JSON.parse(raw) as LastUnit) : null;
  } catch {
    return null;
  }
}

export async function setLastUnit(unitId: string): Promise<void> {
  try {
    const value: LastUnit = { unitId, at: new Date().toISOString() };
    await AsyncStorage.setItem(LAST_UNIT_KEY, JSON.stringify(value));
  } catch {
    /* best-effort */
  }
}

/* ── Daily XP (for the Today goal ring) ─────────────────────────────── */

const XP_DAY_KEY = 'lisaany:xp-day';

function localDay(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

/**
 * XP earned today = total XP now − total XP at the start of today.
 * The baseline is taken the first time we see the app on a new day.
 */
export async function getTodayXp(totalXp: number): Promise<number> {
  const today = localDay();
  try {
    const raw = await AsyncStorage.getItem(XP_DAY_KEY);
    const rec = raw ? (JSON.parse(raw) as { day: string; base: number }) : null;
    if (rec && rec.day === today) {
      const earned = Math.max(0, totalXp - rec.base);
      await recordDayXp(today, earned);
      return earned;
    }
    await AsyncStorage.setItem(XP_DAY_KEY, JSON.stringify({ day: today, base: totalXp }));
  } catch {
    /* best-effort */
  }
  return 0;
}

/** Called before a new snapshot is stored, so XP earned in the first lesson of the day still counts. */
export async function noteXpBaseline(previousXp: number): Promise<void> {
  const today = localDay();
  try {
    const raw = await AsyncStorage.getItem(XP_DAY_KEY);
    const rec = raw ? (JSON.parse(raw) as { day: string; base: number }) : null;
    if (!rec || rec.day !== today) await AsyncStorage.setItem(XP_DAY_KEY, JSON.stringify({ day: today, base: previousXp }));
  } catch {
    /* best-effort */
  }
}

/**
 * Daily XP goal, derived from the minutes goal (goal.ts) so the Star League
 * pace and the lesson celebration follow it: 30 min → 45 XP, 10 min → 15 XP.
 * The goal itself is changed in minutes (changeMinGoal in goal-sync.ts).
 */
export async function getDailyGoal(): Promise<number> {
  return Math.round((await getMinGoal()) * 1.5);
}

/* ── XP history (for the weekly chart on the profile) ─────────────────── */

const XP_HISTORY_KEY = 'lisaany:xp-history';
const FIRST_SEEN_KEY = 'lisaany:first-seen';

async function readHistory(): Promise<Record<string, number>> {
  try {
    const raw = await AsyncStorage.getItem(XP_HISTORY_KEY);
    return raw ? (JSON.parse(raw) as Record<string, number>) : {};
  } catch {
    return {};
  }
}

async function recordDayXp(day: string, xp: number): Promise<void> {
  try {
    const hist = await readHistory();
    if ((hist[day] ?? -1) === xp) return;
    hist[day] = xp;
    // Keep roughly the last two months.
    const keys = Object.keys(hist).sort();
    for (const k of keys.slice(0, Math.max(0, keys.length - 60))) delete hist[k];
    await AsyncStorage.setItem(XP_HISTORY_KEY, JSON.stringify(hist));
  } catch {
    /* best-effort */
  }
}

export type WeekDay = { day: string; label: string; xp: number; isToday: boolean };

/** Monday → Sunday of the current week, with the XP earned each day. */
export async function getWeekXp(): Promise<WeekDay[]> {
  const hist = await readHistory();
  const now = new Date();
  const monday = new Date(now);
  monday.setDate(now.getDate() - ((now.getDay() + 6) % 7));
  const labels = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
  const today = localDay(now);
  return labels.map((label, i) => {
    const d = new Date(monday);
    d.setDate(monday.getDate() + i);
    const day = localDay(d);
    return { day, label, xp: hist[day] ?? 0, isToday: day === today };
  });
}

/** The first day this device opened the app (for "learning since"). */
export async function getFirstSeen(): Promise<Date> {
  try {
    const raw = await AsyncStorage.getItem(FIRST_SEEN_KEY);
    if (raw) return new Date(raw);
    const now = new Date();
    await AsyncStorage.setItem(FIRST_SEEN_KEY, now.toISOString());
    return now;
  } catch {
    return new Date();
  }
}

/* ── Learned today (parts finished, new words) ───────────────────────── */

const LEARNED_DAY_KEY = 'lisaany:learned-day';

export type Learned = { parts: number; words: number };

/** Parts finished and vocabulary words covered, across the whole course. */
export function countLearned(completed: CompletedMap): Learned {
  let parts = 0;
  let words = 0;
  for (const m of MODULES)
    for (const u of m.units)
      for (const b of u.blocks)
        if (completed[`${u.id}:${b.id}`]) {
          parts += 1;
          if (b.size?.unit === 'words') words += b.size.count;
        }
  return { parts, words };
}

/** Before a new snapshot is stored: the first save of the day sets today's starting point. */
async function noteLearnedBaseline(previous: ProgMap): Promise<void> {
  const today = localDay();
  try {
    const raw = await AsyncStorage.getItem(LEARNED_DAY_KEY);
    const rec = raw ? (JSON.parse(raw) as { day: string } & Learned) : null;
    if (!rec || rec.day !== today) {
      await AsyncStorage.setItem(LEARNED_DAY_KEY, JSON.stringify({ day: today, ...countLearned(completedFromProg(previous)) }));
    }
  } catch {
    /* best-effort */
  }
}

/** Parts finished and new words learned today (same day-start logic as today's XP). */
export async function getLearnedToday(completed: CompletedMap): Promise<Learned> {
  const today = localDay();
  const now = countLearned(completed);
  try {
    const raw = await AsyncStorage.getItem(LEARNED_DAY_KEY);
    const rec = raw ? (JSON.parse(raw) as { day: string } & Learned) : null;
    if (rec && rec.day === today) {
      return { parts: Math.max(0, now.parts - rec.parts), words: Math.max(0, now.words - rec.words) };
    }
    await AsyncStorage.setItem(LEARNED_DAY_KEY, JSON.stringify({ day: today, ...now }));
  } catch {
    /* best-effort */
  }
  return { parts: 0, words: 0 };
}
