/**
 * Course progress, mirrored from the lesson engine.
 *
 * The lesson page (the website's own engine, running in a web view) owns
 * progress: it saves locally as the learner works and syncs signed-in users
 * to Supabase (`learner_progress`), exactly as lisaany.com does. Every save
 * also reaches the app over the bridge as a snapshot, which is kept here so
 * the native screens (Today, Lessons, Unit) can show it without opening the
 * page. When a lesson opens, the mirror is handed back to the page and
 * merged, so nothing is lost if a bridge message was missed. The app also
 * pulls the cloud row itself at sign-in and start-up (cloud-progress.ts,
 * driven from auth-context.tsx), so a returning web learner sees their real
 * position before opening any lesson.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';

import { MODULES, type Unit } from './curriculum';
import { getMinGoal } from './goal';

const SNAPSHOT_KEY = 'lisaany:engine-progress:v1';
const LAST_UNIT_KEY = 'lisaany:last-unit';

/** mId → uId → bId → 'done' (the engine's `PROG`). */
export type ProgMap = Record<string, Record<string, Record<string, string>>>;
/** mId → uId → bId → furthest step reached (the engine's `POS`). */
export type PosMap = Record<string, Record<string, Record<string, { n: number; total: number }>>>;

export type EngineSnapshot = {
  prog: ProgMap;
  pos: PosMap;
  xp: number;
  streak: number;
  /** Supabase user id, or 'guest'. */
  uid: string;
  /** ISO time the snapshot was taken. */
  at: string;
  /**
   * The engine's `last_day` (the calendar day of the last completed lesson,
   * as `Date.toDateString()`), used to reconcile the streak between devices.
   */
  lastDay?: string;
};

export type LastUnit = {
  /** Dotted unit id, e.g. "2.3". */
  unitId: string;
  at: string;
  /**
   * Whose position this is: the Supabase user id or 'guest'. Records saved
   * before this field existed have none; readers treat those as belonging to
   * whoever the mirror belonged to at the time.
   */
  uid?: string;
};

const EMPTY: EngineSnapshot = { prog: {}, pos: {}, xp: 0, streak: 0, uid: 'guest', at: '' };

export async function getEngineProgress(): Promise<EngineSnapshot> {
  try {
    const raw = await AsyncStorage.getItem(SNAPSHOT_KEY);
    return raw ? { ...EMPTY, ...(JSON.parse(raw) as Partial<EngineSnapshot>) } : EMPTY;
  } catch {
    return EMPTY;
  }
}

export function mergeProg(into: ProgMap, from: ProgMap | undefined) {
  if (!from) return;
  for (const m of Object.keys(from)) {
    into[m] ??= {};
    for (const u of Object.keys(from[m])) {
      into[m][u] ??= {};
      for (const b of Object.keys(from[m][u])) {
        if (from[m][u][b] === 'done' || !into[m][u][b]) into[m][u][b] = from[m][u][b];
      }
    }
  }
}

export function mergePos(into: PosMap, from: PosMap | undefined) {
  if (!from) return;
  for (const m of Object.keys(from)) {
    into[m] ??= {};
    for (const u of Object.keys(from[m])) {
      into[m][u] ??= {};
      for (const b of Object.keys(from[m][u])) {
        const r = from[m][u][b];
        const l = into[m][u][b];
        if (!l || (r && r.n > l.n)) into[m][u][b] = r;
      }
    }
  }
}

/**
 * Record a snapshot posted by the page. Same user: union of what is done
 * (done never un-does). Different user: the snapshot replaces the mirror.
 */
export async function applyEngineProgress(
  incoming: Partial<EngineSnapshot> & { prog?: ProgMap }
): Promise<EngineSnapshot> {
  const current = await getEngineProgress();
  await noteXpBaseline(current.xp);
  await noteLearnedBaseline(current.prog);
  // A guest snapshot merges into whoever owns the mirror (and a signed-in
  // snapshot absorbs guest progress): only two different accounts replace.
  // Sign-out clears the mirror, so a second account starts from nothing anyway.
  const uid = incoming.uid && incoming.uid !== 'guest' ? incoming.uid : current.uid;
  const sameUser = uid === current.uid || current.uid === 'guest' || !incoming.uid || incoming.uid === 'guest';

  const next: EngineSnapshot = {
    prog: sameUser ? current.prog : {},
    pos: sameUser ? current.pos : {},
    xp: Math.max(sameUser ? current.xp : 0, incoming.xp ?? 0),
    streak: incoming.streak ?? (sameUser ? current.streak : 0),
    uid,
    at: new Date().toISOString(),
    lastDay: incoming.lastDay ?? (sameUser ? current.lastDay : undefined),
  };
  mergeProg(next.prog, incoming.prog);
  mergePos(next.pos, incoming.pos);

  try {
    await AsyncStorage.setItem(SNAPSHOT_KEY, JSON.stringify(next));
  } catch {
    /* best-effort */
  }
  await getTodayXp(next.xp); // records today's XP in the weekly history
  return next;
}

/** Keys are `${unitId}:${blockId}` — the shape the list screens consume. */
export type CompletedMap = Record<string, true>;

export function completedFromProg(prog: ProgMap): CompletedMap {
  const map: CompletedMap = {};
  for (const m of Object.keys(prog)) {
    for (const u of Object.keys(prog[m])) {
      for (const b of Object.keys(prog[m][u])) {
        if (prog[m][u][b] === 'done') map[`${u}:${b}`] = true;
      }
    }
  }
  return map;
}

export async function getCompletedBlocks(): Promise<CompletedMap> {
  return completedFromProg((await getEngineProgress()).prog);
}

export function unitDoneCount(unit: Unit, completed: CompletedMap): number {
  return unit.blocks.filter((b) => completed[`${unit.id}:${b.id}`]).length;
}

/** The website's rule: a block opens once the one before it is done. */
export function isBlockUnlocked(unit: Unit, blockId: number, completed: CompletedMap): boolean {
  const idx = unit.blocks.findIndex((b) => b.id === blockId);
  if (idx <= 0) return true;
  const prev = unit.blocks[idx - 1];
  return !!completed[`${unit.id}:${prev.id}`];
}

/** Where "Continue" goes: the first block not yet done, or the first block. */
export function nextBlockFor(unit: Unit, completed: CompletedMap): number {
  const pending = unit.blocks.find((b) => !completed[`${unit.id}:${b.id}`]);
  return (pending ?? unit.blocks[0]).id;
}

export type Streak = { count: number };

export async function getStreak(): Promise<Streak> {
  return { count: (await getEngineProgress()).streak };
}

export async function getXp(): Promise<number> {
  return (await getEngineProgress()).xp;
}

export async function getLastUnit(): Promise<LastUnit | null> {
  try {
    const raw = await AsyncStorage.getItem(LAST_UNIT_KEY);
    return raw ? (JSON.parse(raw) as LastUnit) : null;
  } catch {
    return null;
  }
}

/**
 * Remember the unit "Continue" should open. `uid` defaults to the mirror's
 * owner (the learner the page last reported, or 'guest'), so a later cloud
 * pull can tell whether the position belongs to the learner signing in.
 */
export async function setLastUnit(unitId: string, uid?: string): Promise<void> {
  try {
    const owner = uid ?? (await getEngineProgress()).uid;
    const value: LastUnit = { unitId, at: new Date().toISOString(), uid: owner };
    await AsyncStorage.setItem(LAST_UNIT_KEY, JSON.stringify(value));
  } catch {
    /* best-effort */
  }
}

/* ── Cloud pulls (sign-in, start-up, back from the background) ─────────── */

/**
 * Where a learner is, judging from a progress snapshot alone: the furthest
 * unit in course order with any finished block or any position in a block.
 * When that unit is fully done, the one after it (or itself if it is the
 * last). Null when the snapshot holds nothing.
 */
export function deriveLastUnit(snapshot: Pick<EngineSnapshot, 'prog' | 'pos'>): string | null {
  const touched = new Set<string>();
  for (const m of Object.keys(snapshot.prog ?? {}))
    for (const u of Object.keys(snapshot.prog[m] ?? {}))
      if (Object.values(snapshot.prog[m][u] ?? {}).some((v) => v === 'done')) touched.add(u);
  for (const m of Object.keys(snapshot.pos ?? {}))
    for (const u of Object.keys(snapshot.pos[m] ?? {}))
      if (Object.keys(snapshot.pos[m][u] ?? {}).length > 0) touched.add(u);
  if (!touched.size) return null;

  const order: Unit[] = MODULES.flatMap((m) => m.units);
  let furthest = -1;
  order.forEach((u, i) => {
    if (touched.has(u.id)) furthest = i;
  });
  if (furthest < 0) return null;
  const unit = order[furthest];
  const completed = completedFromProg(snapshot.prog);
  const finished = unit.blocks.length > 0 && unitDoneCount(unit, completed) >= unit.blocks.length;
  return finished && furthest + 1 < order.length ? order[furthest + 1].id : unit.id;
}

/**
 * After a cloud pull for `userId`: unless this device already knows where
 * this learner is, point "Continue" at the furthest unit the cloud row
 * reaches (a returning web learner on a fresh install, or a phone someone
 * else used before). `previousUid` is who the mirror belonged to before the
 * pull; records saved before `uid` was stored are attributed to that learner.
 * Returns true when the last unit was changed.
 */
export async function adoptLastUnitFromCloud(userId: string, snapshot: EngineSnapshot, previousUid: string): Promise<boolean> {
  const last = await getLastUnit();
  const owner = last ? (last.uid ?? previousUid) : null;
  if (last && owner === userId) return false;
  const unitId = deriveLastUnit(snapshot);
  if (!unitId) return false;
  await setLastUnit(unitId, userId);
  return true;
}

/**
 * After a pull replaced another learner's (or an empty) mirror: everything in
 * the cloud row is history, none of it was earned on this device today. Sets
 * today's XP and "learned today" starting points to the snapshot's totals so
 * the ring, the weekly chart and the circle boards do not show years of XP
 * as today's.
 */
export async function startDayFrom(snapshot: EngineSnapshot): Promise<void> {
  const today = localDay();
  try {
    await AsyncStorage.setItem(XP_DAY_KEY, JSON.stringify({ day: today, base: snapshot.xp }));
    await recordDayXp(today, 0);
    await AsyncStorage.setItem(LEARNED_DAY_KEY, JSON.stringify({ day: today, ...countLearned(completedFromProg(snapshot.prog)) }));
  } catch {
    /* best-effort */
  }
}

/* ── Sign-out / account deletion ───────────────────────────────────────── */

/**
 * Everything on this device that belongs to a learner rather than to the
 * phone: the progress mirror and "Continue" position, the XP / minutes /
 * words day counters and histories, the Norania lessons, stars, days and the
 * child's name, circle bookkeeping and the email opt-in. Device preferences
 * (language, sounds, the daily goal, reminder settings, "seen landing",
 * first-seen / last-active) stay.
 *
 * Norania progress is cleared too: a signed-in learner's copy lives in
 * `norania_progress` (pullNoraniaProgress brings it back on the next
 * sign-in), and a guest's was never anyone else's to keep.
 */
export async function clearLearnerData(): Promise<void> {
  const keys = [
    SNAPSHOT_KEY,
    LAST_UNIT_KEY,
    XP_DAY_KEY,
    XP_HISTORY_KEY,
    LEARNED_DAY_KEY,
    'lisaany:word-history', // word-pace.ts
    'lisaany:milestone-seen', // word-pace.ts
    'lisaany:min-day', // goal.ts
    'lisaany:min-history', // goal.ts
    'lisaany:norania-done', // norania.ts
    'lisaany:norania-stars', // norania.ts
    'lisaany:norania-days', // norania.ts
    'lisaany:learner-name', // norania.ts
    'lisaany:circle-report', // circles.ts
    'lisaany:last-circle', // circles.ts
    'lisaany:email-reminders', // email-reminders.ts
  ];
  try {
    await AsyncStorage.multiRemove(keys);
  } catch {
    /* best-effort: a key that would not go is overwritten by the next learner's data */
  }
}

/* ── Daily XP (for the Today goal ring) ─────────────────────────────── */

const XP_DAY_KEY = 'lisaany:xp-day';

function localDay(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

/**
 * XP earned today = total XP now − total XP at the start of today.
 * The baseline is taken the first time we see the app on a new day.
 */
export async function getTodayXp(totalXp: number): Promise<number> {
  const today = localDay();
  try {
    const raw = await AsyncStorage.getItem(XP_DAY_KEY);
    const rec = raw ? (JSON.parse(raw) as { day: string; base: number }) : null;
    if (rec && rec.day === today) {
      const earned = Math.max(0, totalXp - rec.base);
      await recordDayXp(today, earned);
      return earned;
    }
    await AsyncStorage.setItem(XP_DAY_KEY, JSON.stringify({ day: today, base: totalXp }));
  } catch {
    /* best-effort */
  }
  return 0;
}

/** Called before a new snapshot is stored, so XP earned in the first lesson of the day still counts. */
export async function noteXpBaseline(previousXp: number): Promise<void> {
  const today = localDay();
  try {
    const raw = await AsyncStorage.getItem(XP_DAY_KEY);
    const rec = raw ? (JSON.parse(raw) as { day: string; base: number }) : null;
    if (!rec || rec.day !== today) await AsyncStorage.setItem(XP_DAY_KEY, JSON.stringify({ day: today, base: previousXp }));
  } catch {
    /* best-effort */
  }
}

/**
 * Daily XP goal, derived from the minutes goal (goal.ts) so the Star League
 * pace and the lesson celebration follow it: 30 min → 45 XP, 10 min → 15 XP.
 * The goal itself is changed in minutes (changeMinGoal in goal-sync.ts).
 */
export async function getDailyGoal(): Promise<number> {
  return Math.round((await getMinGoal()) * 1.5);
}

/* ── XP history (for the weekly chart on the profile) ─────────────────── */

const XP_HISTORY_KEY = 'lisaany:xp-history';
const FIRST_SEEN_KEY = 'lisaany:first-seen';

async function readHistory(): Promise<Record<string, number>> {
  try {
    const raw = await AsyncStorage.getItem(XP_HISTORY_KEY);
    return raw ? (JSON.parse(raw) as Record<string, number>) : {};
  } catch {
    return {};
  }
}

async function recordDayXp(day: string, xp: number): Promise<void> {
  try {
    const hist = await readHistory();
    if ((hist[day] ?? -1) === xp) return;
    hist[day] = xp;
    // Keep roughly the last two months.
    const keys = Object.keys(hist).sort();
    for (const k of keys.slice(0, Math.max(0, keys.length - 60))) delete hist[k];
    await AsyncStorage.setItem(XP_HISTORY_KEY, JSON.stringify(hist));
  } catch {
    /* best-effort */
  }
}

export type WeekDay = { day: string; label: string; xp: number; isToday: boolean };

/** Monday → Sunday of the current week, with the XP earned each day. */
export async function getWeekXp(): Promise<WeekDay[]> {
  const hist = await readHistory();
  const now = new Date();
  const monday = new Date(now);
  monday.setDate(now.getDate() - ((now.getDay() + 6) % 7));
  const labels = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
  const today = localDay(now);
  return labels.map((label, i) => {
    const d = new Date(monday);
    d.setDate(monday.getDate() + i);
    const day = localDay(d);
    return { day, label, xp: hist[day] ?? 0, isToday: day === today };
  });
}

/** The first day this device opened the app (for "learning since"). */
export async function getFirstSeen(): Promise<Date> {
  try {
    const raw = await AsyncStorage.getItem(FIRST_SEEN_KEY);
    if (raw) return new Date(raw);
    const now = new Date();
    await AsyncStorage.setItem(FIRST_SEEN_KEY, now.toISOString());
    return now;
  } catch {
    return new Date();
  }
}

/* ── Learned today (parts finished, new words) ───────────────────────── */

const LEARNED_DAY_KEY = 'lisaany:learned-day';

export type Learned = { parts: number; words: number };

/** Parts finished and vocabulary words covered, across the whole course. */
export function countLearned(completed: CompletedMap): Learned {
  let parts = 0;
  let words = 0;
  for (const m of MODULES)
    for (const u of m.units)
      for (const b of u.blocks)
        if (completed[`${u.id}:${b.id}`]) {
          parts += 1;
          if (b.size?.unit === 'words') words += b.size.count;
        }
  return { parts, words };
}

/** Before a new snapshot is stored: the first save of the day sets today's starting point. */
async function noteLearnedBaseline(previous: ProgMap): Promise<void> {
  const today = localDay();
  try {
    const raw = await AsyncStorage.getItem(LEARNED_DAY_KEY);
    const rec = raw ? (JSON.parse(raw) as { day: string } & Learned) : null;
    if (!rec || rec.day !== today) {
      await AsyncStorage.setItem(LEARNED_DAY_KEY, JSON.stringify({ day: today, ...countLearned(completedFromProg(previous)) }));
    }
  } catch {
    /* best-effort */
  }
}

/** Parts finished and new words learned today (same day-start logic as today's XP). */
export async function getLearnedToday(completed: CompletedMap): Promise<Learned> {
  const today = localDay();
  const now = countLearned(completed);
  try {
    const raw = await AsyncStorage.getItem(LEARNED_DAY_KEY);
    const rec = raw ? (JSON.parse(raw) as { day: string } & Learned) : null;
    if (rec && rec.day === today) {
      return { parts: Math.max(0, now.parts - rec.parts), words: Math.max(0, now.words - rec.words) };
    }
    await AsyncStorage.setItem(LEARNED_DAY_KEY, JSON.stringify({ day: today, ...now }));
  } catch {
    /* best-effort */
  }
  return { parts: 0, words: 0 };
}
