/**
 * "Come back" notifications for learners who have been away.
 *
 * Nothing is sent while someone is using the app. rescheduleReminders()
 * cancels every reminder this app scheduled before, then schedules one-off
 * notifications for 2, 4 and 7 days from now, then weekly up to 4 weeks, at
 * the learner's chosen time. It runs on app start and every time the app is
 * opened or put away, so each visit pushes them all forward: they only ever
 * fire after days without opening the app. (There is no daily "you have not
 * reached your goal" notification — the Settings copy says so.)
 *
 * Tapping one opens the app on Today (watchReminderTaps, wired in
 * hooks/use-goal-reminders.ts).
 *
 * On the web build everything here is a no-op apart from reading and saving
 * the preferences.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Platform } from 'react-native';
import type * as NotificationsModule from 'expo-notifications';

import { getMinGoal } from './goal';
import { translate, type Vars } from './i18n';
import { getLessonLang } from './settings';

// Loaded lazily so the web bundle never runs the native module.
const Notifications: typeof NotificationsModule | null =
  // eslint-disable-next-line @typescript-eslint/no-require-imports -- deliberate lazy load (see above)
  Platform.OS === 'web' ? null : (require('expo-notifications') as typeof NotificationsModule);

const PREFS_KEY = 'lisaany:reminders';
const IDS_KEY = 'lisaany:reminder-ids';
const CHANNEL_ID = 'reminders';
const KIND = 'goal-reminder';

export type ReminderPrefs = { enabled: boolean; hour: number; minute: number };

export const DEFAULT_REMINDER: ReminderPrefs = { enabled: false, hour: 18, minute: 0 };

/** The times offered in onboarding and Settings (local time). */
export const REMINDER_TIMES: { hour: number; minute: number; label: string }[] = [
  { hour: 7, minute: 0, label: 'Morning' },
  { hour: 12, minute: 0, label: 'Midday' },
  { hour: 18, minute: 0, label: 'Evening' },
  { hour: 20, minute: 0, label: 'Night' },
];

export const NOTIFICATIONS_SUPPORTED = Notifications !== null;

/** "7:00" / "18:00" in English, "7 h" / "18 h 30" in French (24-hour, as on the website). */
export function formatTime(hour: number, minute: number, locale: string): string {
  const mm = String(minute).padStart(2, '0');
  if (locale.startsWith('fr')) return minute ? `${hour}\u00a0h\u00a0${mm}` : `${hour}\u00a0h`;
  return `${hour}:${mm}`;
}

export async function getReminderPrefs(): Promise<ReminderPrefs> {
  try {
    const raw = await AsyncStorage.getItem(PREFS_KEY);
    if (!raw) return DEFAULT_REMINDER;
    const p = JSON.parse(raw) as Partial<ReminderPrefs>;
    return {
      enabled: !!p.enabled,
      hour: Number.isInteger(p.hour) && p.hour! >= 0 && p.hour! < 24 ? p.hour! : DEFAULT_REMINDER.hour,
      minute: Number.isInteger(p.minute) && p.minute! >= 0 && p.minute! < 60 ? p.minute! : DEFAULT_REMINDER.minute,
    };
  } catch {
    return DEFAULT_REMINDER;
  }
}

/** Saves the preferences and reschedules. */
export async function setReminderPrefs(prefs: ReminderPrefs): Promise<void> {
  try {
    await AsyncStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
  } catch {
    /* best-effort */
  }
  await rescheduleReminders();
}

/* ── setup ──────────────────────────────────────────────────────────── */

let channelReady = false;

async function ensureChannel(): Promise<void> {
  if (!Notifications || Platform.OS !== 'android' || channelReady) return;
  try {
    const lang = await getLessonLang();
    await Notifications.setNotificationChannelAsync(CHANNEL_ID, {
      // Shown in Android's notification settings; they are not daily.
      name: translate(lang, 'Reminders'),
      importance: Notifications.AndroidImportance.DEFAULT,
    });
    channelReady = true;
  } catch {
    /* best-effort */
  }
}

let handlerSet = false;

/**
 * Once at start-up: reminders are for when the app is closed, so one that
 * fires while the learner is already in the app is not shown.
 */
export function initReminders(): void {
  if (!Notifications || handlerSet) return;
  handlerSet = true;
  try {
    Notifications.setNotificationHandler({
      handleNotification: async (n) => {
        const ours = (n.request.content.data as { kind?: string } | undefined)?.kind === KIND;
        return {
          shouldShowBanner: !ours,
          shouldShowList: !ours,
          shouldPlaySound: !ours,
          shouldSetBadge: false,
        };
      },
    });
  } catch {
    /* best-effort */
  }
}

/** Asks for permission to notify (once; after that returns the saved answer). */
export async function requestPermission(): Promise<boolean> {
  if (!Notifications) return false;
  try {
    await ensureChannel(); // Android 13+ shows the prompt only once a channel exists
    const cur = await Notifications.getPermissionsAsync();
    if (cur.granted || cur.ios?.status === Notifications.IosAuthorizationStatus.PROVISIONAL) return true;
    if (!cur.canAskAgain) return false;
    const res = await Notifications.requestPermissionsAsync({
      ios: { allowAlert: true, allowBadge: false, allowSound: true },
    });
    return res.granted;
  } catch {
    return false;
  }
}

async function hasPermission(): Promise<boolean> {
  if (!Notifications) return false;
  try {
    const cur = await Notifications.getPermissionsAsync();
    return cur.granted || cur.ios?.status === Notifications.IosAuthorizationStatus.PROVISIONAL;
  } catch {
    return false;
  }
}

/* ── taps ───────────────────────────────────────────────────────────── */

function isOurs(response: NotificationsModule.NotificationResponse | null | undefined): boolean {
  return (response?.notification.request.content.data as { kind?: string } | undefined)?.kind === KIND;
}

/**
 * Runs `onTap` when the learner opens the app from one of our reminders:
 * while the app is running or in the background (the listener) and on a cold
 * start from the tap (the last response, read once). Returns the function
 * that stops listening. Other apps' notifications are ignored.
 */
export function watchReminderTaps(onTap: () => void): () => void {
  if (!Notifications) return () => {};
  let sub: { remove: () => void } | null = null;
  try {
    sub = Notifications.addNotificationResponseReceivedListener((response) => {
      if (isOurs(response)) onTap();
    });
    Notifications.getLastNotificationResponseAsync()
      .then((response) => {
        if (isOurs(response)) onTap();
      })
      .catch(() => {});
  } catch {
    /* notifications unavailable on this device */
  }
  return () => {
    try {
      sub?.remove();
    } catch {
      /* already gone */
    }
  };
}

/* ── text ───────────────────────────────────────────────────────────── */

/** Days away at which a reminder goes out (then it stops). */
const AWAY_DAYS = [2, 4, 7, 14, 21, 28];

/** Star-voiced "come back" lines, by how long the learner has been away. */
function awayLine(lang: 'en' | 'fr', days: number, goal: number): { title: string; body: string } {
  const t = (s: string, v?: Vars) => translate(lang, s, v);
  if (days <= 2) return { title: t('Your Arabic is waiting'), body: t('It’s been 2 days. A short lesson today keeps your words fresh.') };
  if (days <= 4) return { title: t('Your place is saved'), body: t('I kept your spot. Come back for {g} minutes of Arabic?', { g: goal }) };
  if (days <= 7) return { title: t('One week away'), body: t('Let’s pick up where you left off — your next lesson is one tap away.') };
  if (days <= 14) return { title: t('Your words miss you'), body: t('Two weeks is a great moment to restart. I’ll be right there with you.') };
  return { title: t('Whenever you’re ready'), body: t('Your Arabic journey is waiting for you. Let’s continue together.') };
}

/* ── scheduling ─────────────────────────────────────────────────────── */

let running: Promise<void> | null = null;
let again = false;

async function cancelOurs(): Promise<void> {
  if (!Notifications) return;
  const ids = new Set<string>();
  try {
    const raw = await AsyncStorage.getItem(IDS_KEY);
    for (const id of raw ? (JSON.parse(raw) as string[]) : []) ids.add(id);
  } catch {
    /* ignore */
  }
  try {
    for (const n of await Notifications.getAllScheduledNotificationsAsync()) {
      if ((n.content.data as { kind?: string } | undefined)?.kind === KIND) ids.add(n.identifier);
    }
  } catch {
    /* ignore */
  }
  await Promise.all([...ids].map((id) => Notifications.cancelScheduledNotificationAsync(id).catch(() => {})));
  try {
    await AsyncStorage.setItem(IDS_KEY, '[]');
  } catch {
    /* ignore */
  }
}

async function scheduleNow(): Promise<void> {
  if (!Notifications) return;
  await cancelOurs();
  const prefs = await getReminderPrefs();
  if (!prefs.enabled || !(await hasPermission())) return;
  await ensureChannel();

  const [goal, lang] = await Promise.all([getMinGoal(), getLessonLang()]);
  const now = new Date();
  const ids: string[] = [];

  // Only after days away: each visit to the app moves these forward again.
  for (const days of AWAY_DAYS) {
    const at = new Date(now.getFullYear(), now.getMonth(), now.getDate() + days, prefs.hour, prefs.minute, 0, 0);
    const pick = awayLine(lang, days, goal);
    try {
      const id = await Notifications.scheduleNotificationAsync({
        content: { title: pick.title, body: pick.body, data: { kind: KIND, url: '/' }, sound: 'default' },
        trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: at, channelId: CHANNEL_ID },
      });
      ids.push(id);
    } catch {
      /* skip this day */
    }
  }
  try {
    await AsyncStorage.setItem(IDS_KEY, JSON.stringify(ids));
  } catch {
    /* ignore */
  }
}

/**
 * Cancel and re-create the "days away" reminders (2, 4, 7, 14, 21 and 28
 * days from now). Safe to call often; overlapping calls are folded into one
 * extra run.
 */
export async function rescheduleReminders(): Promise<void> {
  if (!Notifications) return;
  if (running) {
    again = true;
    return running;
  }
  running = (async () => {
    do {
      again = false;
      try {
        await scheduleNow();
      } catch {
        /* never break the app over a reminder */
      }
    } while (again);
  })();
  try {
    await running;
  } finally {
    running = null;
  }
}
