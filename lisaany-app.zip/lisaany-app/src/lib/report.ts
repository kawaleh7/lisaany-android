/**
 * Error reporting for the app.
 *
 * Every "this should not happen" path calls `reportError` so it reaches the
 * crash reporter in a store build and the console in development. The reporter
 * itself (Sentry) is attached in `src/app/_layout.tsx` when a DSN is set; until
 * then this only logs, so nothing here ever throws or blocks the caller.
 */
type Reporter = (error: unknown, context?: Record<string, unknown>) => void;

let reporter: Reporter | null = null;

/** Called once at start-up by whoever owns the crash reporter. */
export function setErrorReporter(fn: Reporter | null): void {
  reporter = fn;
}

/**
 * Record an error with a little context (where it happened, which unit…).
 * `context` must not contain tokens, emails or other personal data.
 */
export function reportError(error: unknown, context?: Record<string, unknown>): void {
  try {
    if (__DEV__) console.warn('[lisaany]', context?.where ?? '', error, context ?? '');
    reporter?.(error, context);
  } catch {
    /* never let reporting break the app */
  }
}

/** Same, for a message with no Error object (e.g. a page-side JS error). */
export function reportMessage(message: string, context?: Record<string, unknown>): void {
  reportError(new Error(message), context);
}
