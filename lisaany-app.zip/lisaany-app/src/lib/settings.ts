/**
 * Small on-device settings.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';

const LESSON_LANG_KEY = 'lisaany:lesson-lang';

/** Language of the lesson page's interface (the course itself is Arabic). */
export type LessonLang = 'en' | 'fr';

export const LESSON_LANG_LABELS: Record<LessonLang, string> = {
  en: 'English',
  fr: 'Français',
};

export async function getLessonLang(): Promise<LessonLang> {
  try {
    const v = await AsyncStorage.getItem(LESSON_LANG_KEY);
    return v === 'fr' ? 'fr' : 'en';
  } catch {
    return 'en';
  }
}

export async function setLessonLang(lang: LessonLang): Promise<void> {
  try {
    await AsyncStorage.setItem(LESSON_LANG_KEY, lang);
  } catch {
    /* best-effort */
  }
}
