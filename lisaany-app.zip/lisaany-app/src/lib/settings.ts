/**
 * Small on-device settings.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';

const LESSON_LANG_KEY = 'lisaany:lesson-lang';
const SOUNDS_KEY = 'lisaany:sounds';

/** Language of the lesson page's interface (the course itself is Arabic). */
export type LessonLang = 'en' | 'fr';

export const LESSON_LANG_LABELS: Record<LessonLang, string> = {
  en: 'English',
  fr: 'Français',
};

export async function getLessonLang(): Promise<LessonLang> {
  try {
    const v = await AsyncStorage.getItem(LESSON_LANG_KEY);
    return v === 'fr' ? 'fr' : 'en';
  } catch {
    return 'en';
  }
}

export async function setLessonLang(lang: LessonLang): Promise<void> {
  try {
    await AsyncStorage.setItem(LESSON_LANG_KEY, lang);
  } catch {
    /* best-effort */
  }
}

/* ── Sound effects ──────────────────────────────────────────────────── */

/** Sounds are off unless the learner turns them on. */
export const DEFAULT_SOUNDS = false;

/**
 * Whether the lesson page plays its sound effects (coins, right/wrong).
 * The engine reads this as `window.__LISAANY_APP.sfx`; the star is silent
 * either way.
 */
export async function getSoundsOn(): Promise<boolean> {
  try {
    return (await AsyncStorage.getItem(SOUNDS_KEY)) === '1';
  } catch {
    return DEFAULT_SOUNDS;
  }
}

export async function setSoundsOn(on: boolean): Promise<void> {
  try {
    await AsyncStorage.setItem(SOUNDS_KEY, on ? '1' : '0');
  } catch {
    /* best-effort */
  }
}
