/**
 * One-tap sign-in with Google (both platforms) and Apple (iPhone).
 *
 * Google goes through Supabase's own Google login in the system browser
 * sheet (the same Google login the website uses), and comes back to the app
 * on lisaany://auth-callback with the session in the link. Apple uses the
 * native "Sign in with Apple" sheet and hands Apple's token to Supabase.
 *
 * Each is off until its setup is done (see docs/sign-in-google-apple.md):
 * set EXPO_PUBLIC_SSO_GOOGLE=on / EXPO_PUBLIC_SSO_APPLE=on in .env and build.
 */
import * as Linking from 'expo-linking';
import * as WebBrowser from 'expo-web-browser';
import { Platform } from 'react-native';

import { reportError } from './report';
import { supabase } from './supabase';

export const GOOGLE_ON = (process.env.EXPO_PUBLIC_SSO_GOOGLE ?? '').toLowerCase() === 'on' && Platform.OS !== 'web';
export const APPLE_ON = (process.env.EXPO_PUBLIC_SSO_APPLE ?? '').toLowerCase() === 'on' && Platform.OS === 'ios';

export type SsoResult = 'signed-in' | 'cancelled';

/** Pull access/refresh tokens (or an error) out of the callback link. */
function readCallback(url: string): { access_token?: string; refresh_token?: string; error?: string } {
  const out: Record<string, string> = {};
  const parts = [url.split('#')[1] ?? '', (url.split('?')[1] ?? '').split('#')[0]];
  for (const part of parts)
    for (const pair of part.split('&')) {
      const [k, v] = pair.split('=');
      if (k) out[decodeURIComponent(k)] = decodeURIComponent((v ?? '').replace(/\+/g, ' '));
    }
  return { access_token: out.access_token, refresh_token: out.refresh_token, error: out.error_description || out.error };
}

export async function signInWithGoogle(): Promise<SsoResult> {
  const redirectTo = Linking.createURL('auth-callback');
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: 'google',
    options: { redirectTo, skipBrowserRedirect: true, queryParams: { prompt: 'select_account' } },
  });
  if (error || !data?.url) throw error ?? new Error('Google sign-in is not available right now.');
  const res = await WebBrowser.openAuthSessionAsync(data.url, redirectTo);
  if (res.type !== 'success') return 'cancelled';
  const got = readCallback(res.url);
  if (got.error) throw new Error(got.error);
  if (!got.access_token || !got.refresh_token) throw new Error('Google sign-in did not finish. Please try again.');
  const { error: setErr } = await supabase.auth.setSession({ access_token: got.access_token, refresh_token: got.refresh_token });
  if (setErr) throw setErr;
  return 'signed-in';
}

export async function signInWithApple(): Promise<SsoResult> {
  // Loaded only on iPhone, so Android and web never touch the native module.
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const Apple = require('expo-apple-authentication') as typeof import('expo-apple-authentication');
  try {
    const cred = await Apple.signInAsync({
      requestedScopes: [Apple.AppleAuthenticationScope.FULL_NAME, Apple.AppleAuthenticationScope.EMAIL],
    });
    if (!cred.identityToken) throw new Error('Apple did not return a sign-in token. Please try again.');
    const { error } = await supabase.auth.signInWithIdToken({ provider: 'apple', token: cred.identityToken });
    if (error) throw error;
    // Apple gives the name only on the very first sign-in: keep it on the account.
    const given = cred.fullName?.givenName;
    if (given) await supabase.auth.updateUser({ data: { name: given, full_name: [given, cred.fullName?.familyName].filter(Boolean).join(' ') } }).catch(() => {});
    return 'signed-in';
  } catch (e) {
    if ((e as { code?: string })?.code === 'ERR_REQUEST_CANCELED') return 'cancelled';
    reportError(e, { where: 'sso.apple' });
    throw e;
  }
}
