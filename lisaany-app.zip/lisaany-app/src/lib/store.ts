/**
 * App Store purchases (iPhone only), through RevenueCat.
 *
 * Apple requires in-app purchase for unlocking lessons inside the app, so on
 * iPhone Premium is bought here. Android and the website keep their existing
 * flow (Stripe on lisaany.com) for now — nothing in this file runs there.
 *
 * Premium is the RevenueCat entitlement `premium`, attached to two App Store
 * subscriptions (monthly, yearly) in the RevenueCat "default" offering.
 * A signed-in learner's purchases are tied to their Supabase user id, so the
 * same Premium follows them to a new phone.
 *
 * Disabled (STORE_ENABLED = false) in Expo Go, on Android/web, and until the
 * RevenueCat iOS key is set — callers then fall back to "store unavailable".
 */
import Constants, { ExecutionEnvironment } from 'expo-constants';
import { Platform } from 'react-native';
import type { CustomerInfo, PurchasesPackage } from 'react-native-purchases';

/** RevenueCat public iOS SDK key (starts with `appl_`). Safe to ship in the app. */
export const REVENUECAT_IOS_KEY = process.env.EXPO_PUBLIC_REVENUECAT_IOS_KEY ?? '';

/** The entitlement that unlocks every unit. */
export const ENTITLEMENT_ID = 'premium';

const inExpoGo = Constants.executionEnvironment === ExecutionEnvironment.StoreClient;

export const IS_IOS = Platform.OS === 'ios';
/** A real key starts with `appl_`; the placeholder in eas.json doesn't count. */
const HAS_KEY = REVENUECAT_IOS_KEY.startsWith('appl_') && !REVENUECAT_IOS_KEY.includes('PASTE');

export const STORE_ENABLED = IS_IOS && !inExpoGo && HAS_KEY;

type PurchasesModule = typeof import('react-native-purchases').default;

let mod: PurchasesModule | null = null;
let configured = false;

/** Loaded lazily so Expo Go and Android never touch the native module. */
function purchases(): PurchasesModule | null {
  if (!STORE_ENABLED) return null;
  if (!mod) {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    mod = require('react-native-purchases').default as PurchasesModule;
  }
  if (!configured) {
    mod.configure({ apiKey: REVENUECAT_IOS_KEY });
    configured = true;
  }
  return mod;
}

export type StorePlan = 'yearly' | 'monthly';
export type StorePackages = Partial<Record<StorePlan, PurchasesPackage>>;

/** Called when the Supabase session changes, so purchases follow the account. */
export async function syncStoreUser(userId: string | null): Promise<void> {
  const p = purchases();
  if (!p) return;
  try {
    if (userId) await p.logIn(userId);
    else if (!(await p.isAnonymous())) await p.logOut();
  } catch {
    /* best-effort — a failed sync only delays attribution */
  }
}

function premiumProduct(info: CustomerInfo): string | null {
  const ent = info.entitlements.active[ENTITLEMENT_ID];
  return ent ? ent.productIdentifier : null;
}

/** 'yearly' / 'monthly' when the App Store entitlement is active, else null. */
export async function storePremium(): Promise<StorePlan | null> {
  const p = purchases();
  if (!p) return null;
  try {
    const product = premiumProduct(await p.getCustomerInfo());
    if (!product) return null;
    return /year|annual/i.test(product) ? 'yearly' : 'monthly';
  } catch {
    return null;
  }
}

/** The two subscriptions with their App Store prices (local currency). */
export async function getStorePackages(): Promise<StorePackages> {
  const p = purchases();
  if (!p) return {};
  const offerings = await p.getOfferings();
  const cur = offerings.current;
  if (!cur) return {};
  return {
    yearly: cur.annual ?? cur.availablePackages.find((x) => /year|annual/i.test(x.product.identifier)),
    monthly: cur.monthly ?? cur.availablePackages.find((x) => /month/i.test(x.product.identifier)),
  };
}

export type BuyResult = 'purchased' | 'cancelled';

/** Runs Apple's purchase sheet. Throws on real errors; 'cancelled' if the learner backs out. */
export async function buy(pkg: PurchasesPackage): Promise<BuyResult> {
  const p = purchases();
  if (!p) throw new Error('Purchases are not available on this device.');
  try {
    const { customerInfo } = await p.purchasePackage(pkg);
    return premiumProduct(customerInfo) ? 'purchased' : 'cancelled';
  } catch (e) {
    if ((e as { userCancelled?: boolean })?.userCancelled) return 'cancelled';
    throw e;
  }
}

/** Apple requires a Restore button: re-links past purchases to this device. */
export async function restore(): Promise<boolean> {
  const p = purchases();
  if (!p) return false;
  return premiumProduct(await p.restorePurchases()) !== null;
}

/** Apple's own subscription page — where App Store subscriptions are managed. */
export const APPLE_SUBSCRIPTIONS_URL = 'https://apps.apple.com/account/subscriptions';
