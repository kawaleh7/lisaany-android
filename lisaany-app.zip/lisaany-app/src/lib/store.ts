/**
 * In-app purchases on iPhone (App Store) and Android (Google Play), through
 * RevenueCat.
 *
 * Both stores require their own billing for unlocking lessons inside the app,
 * so Premium is bought here on both platforms — never through a link to the
 * website. The website keeps its own Stripe checkout for web learners; store
 * purchases reach the website through the RevenueCat webhook described in
 * docs/revenuecat-webhook.md.
 *
 * Premium is the RevenueCat entitlement `premium`, attached to two
 * subscriptions (`lisaany_premium_monthly`, `lisaany_premium_yearly`, same ids
 * on both stores) in the RevenueCat "default" offering. A signed-in learner's
 * purchases are tied to their Supabase user id (Purchases.logIn), so the same
 * Premium follows them to a new phone and to the other platform.
 *
 * Disabled (STORE_ENABLED = false) in Expo Go, on web, and until the RevenueCat
 * key for this platform is set — callers then fall back to "store unavailable".
 * If the native module fails to configure, the same fallback applies; nothing
 * here throws at import time.
 */
import Constants, { ExecutionEnvironment } from 'expo-constants';
import { Platform } from 'react-native';
import type { CustomerInfo, PurchasesPackage } from 'react-native-purchases';

import { reportError } from './report';

/** RevenueCat public iOS SDK key (starts with `appl_`). Safe to ship in the app. */
export const REVENUECAT_IOS_KEY = process.env.EXPO_PUBLIC_REVENUECAT_IOS_KEY ?? '';
/** RevenueCat public Android SDK key (starts with `goog_`). Safe to ship in the app. */
export const REVENUECAT_ANDROID_KEY = process.env.EXPO_PUBLIC_REVENUECAT_ANDROID_KEY ?? '';

/** The entitlement that unlocks every unit. */
export const ENTITLEMENT_ID = 'premium';

const inExpoGo = Constants.executionEnvironment === ExecutionEnvironment.StoreClient;

export const IS_IOS = Platform.OS === 'ios';
export const IS_ANDROID = Platform.OS === 'android';

export type StorePlatform = 'apple' | 'google';

/** Which store this build sells through, or null on web / unsupported platforms. */
export const STORE_PLATFORM: StorePlatform | null = IS_IOS ? 'apple' : IS_ANDROID ? 'google' : null;

/** A real key has the store's prefix; the `PASTE` placeholders in .env do not count. */
function validKey(key: string, prefix: string): boolean {
  return key.startsWith(prefix) && !key.includes('PASTE');
}

const STORE_KEY = STORE_PLATFORM === 'apple' ? REVENUECAT_IOS_KEY : STORE_PLATFORM === 'google' ? REVENUECAT_ANDROID_KEY : '';
const HAS_KEY = STORE_PLATFORM === 'apple' ? validKey(STORE_KEY, 'appl_') : STORE_PLATFORM === 'google' ? validKey(STORE_KEY, 'goog_') : false;

export const STORE_ENABLED = STORE_PLATFORM !== null && !inExpoGo && HAS_KEY;

type PurchasesModule = typeof import('react-native-purchases').default;

let mod: PurchasesModule | null = null;
let configured = false;
/** Set once loading or configuring the native module has failed — the store then stays "unavailable". */
let broken = false;

/**
 * Loaded lazily so Expo Go and web never touch the native module. Returns null
 * when the store is disabled or the module could not be configured; every
 * caller treats null as "store unavailable" rather than crashing.
 */
function purchases(): PurchasesModule | null {
  if (!STORE_ENABLED || broken) return null;
  try {
    if (!mod) {
      // eslint-disable-next-line @typescript-eslint/no-require-imports
      mod = require('react-native-purchases').default as PurchasesModule;
    }
    if (!configured) {
      mod.configure({ apiKey: STORE_KEY });
      configured = true;
    }
    return mod;
  } catch (e) {
    broken = true;
    reportError(e, { where: 'store.configure', platform: STORE_PLATFORM });
    return null;
  }
}

export type StorePlan = 'yearly' | 'monthly';
export type StorePackages = Partial<Record<StorePlan, PurchasesPackage>>;

/** Called when the Supabase session changes, so purchases follow the account. */
export async function syncStoreUser(userId: string | null): Promise<void> {
  const p = purchases();
  if (!p) return;
  try {
    if (userId) await p.logIn(userId);
    else if (!(await p.isAnonymous())) await p.logOut();
  } catch (e) {
    // Best-effort — a failed sync only delays attribution.
    reportError(e, { where: 'store.syncStoreUser' });
  }
}

function premiumEntitlement(info: CustomerInfo) {
  return info.entitlements.active[ENTITLEMENT_ID] ?? null;
}

function premiumProduct(info: CustomerInfo): string | null {
  const ent = premiumEntitlement(info);
  return ent ? ent.productIdentifier : null;
}

function planOf(productId: string): StorePlan {
  return /year|annual/i.test(productId) ? 'yearly' : 'monthly';
}

/**
 * 'yearly' / 'monthly' when the store entitlement is active, null when the
 * store answered "no entitlement" (or the store is disabled in this build).
 * Throws only when the store could not answer at all — no cached CustomerInfo
 * and no network — so callers can tell "not a subscriber" from "unknown".
 * RevenueCat caches CustomerInfo on the device, so this usually answers offline.
 */
export async function storePremiumStrict(): Promise<StorePlan | null> {
  const p = purchases();
  if (!p) return null;
  const product = premiumProduct(await p.getCustomerInfo());
  return product ? planOf(product) : null;
}

/** Same as storePremiumStrict, but "unknown" counts as null. */
export async function storePremium(): Promise<StorePlan | null> {
  try {
    return await storePremiumStrict();
  } catch {
    return null;
  }
}

export type StoreSubscriptionInfo = {
  plan: StorePlan;
  /** Where it was bought — 'other' covers promotional grants and web purchases. */
  store: StorePlatform | 'other';
  /** ISO date the current period ends, or null for a lifetime/promotional grant. */
  expiresAt: string | null;
  /** False once the learner has cancelled — access continues until `expiresAt`. */
  willRenew: boolean;
};

/** Details of the active store subscription for Settings, or null when there is none. */
export async function storeSubscriptionInfo(): Promise<StoreSubscriptionInfo | null> {
  const p = purchases();
  if (!p) return null;
  try {
    const ent = premiumEntitlement(await p.getCustomerInfo());
    if (!ent) return null;
    const store = ent.store === 'APP_STORE' || ent.store === 'MAC_APP_STORE' ? 'apple' : ent.store === 'PLAY_STORE' ? 'google' : 'other';
    return {
      plan: planOf(ent.productIdentifier),
      store,
      expiresAt: ent.expirationDate ?? null,
      willRenew: !!ent.willRenew,
    };
  } catch {
    return null;
  }
}

/** The two subscriptions with their store prices (local currency). Throws when the store cannot be reached. */
export async function getStorePackages(): Promise<StorePackages> {
  const p = purchases();
  if (!p) return {};
  const offerings = await p.getOfferings();
  const cur = offerings.current;
  if (!cur) return {};
  return {
    yearly: cur.annual ?? cur.availablePackages.find((x) => /year|annual/i.test(x.product.identifier)),
    monthly: cur.monthly ?? cur.availablePackages.find((x) => /month/i.test(x.product.identifier)),
  };
}

export type BuyResult = 'purchased' | 'cancelled';

/** Runs the store's purchase sheet. Throws on real errors; 'cancelled' if the learner backs out. */
export async function buy(pkg: PurchasesPackage): Promise<BuyResult> {
  const p = purchases();
  if (!p) throw new Error('Purchases are not available on this device.');
  try {
    const { customerInfo } = await p.purchasePackage(pkg);
    return premiumProduct(customerInfo) ? 'purchased' : 'cancelled';
  } catch (e) {
    if ((e as { userCancelled?: boolean })?.userCancelled) return 'cancelled';
    throw e;
  }
}

/** Both stores expect a Restore button: re-links past purchases to this device. */
export async function restore(): Promise<boolean> {
  const p = purchases();
  if (!p) return false;
  return premiumProduct(await p.restorePurchases()) !== null;
}

/** Apple's own subscription page — where App Store subscriptions are managed. */
export const APPLE_SUBSCRIPTIONS_URL = 'https://apps.apple.com/account/subscriptions';
/** Google's own subscription page — where Google Play subscriptions are managed. */
export const GOOGLE_SUBSCRIPTIONS_URL = 'https://play.google.com/store/account/subscriptions';

/** Where this platform's store lets the learner manage or cancel the subscription. */
export function manageSubscriptionUrl(): string {
  return STORE_PLATFORM === 'google' ? GOOGLE_SUBSCRIPTIONS_URL : APPLE_SUBSCRIPTIONS_URL;
}
