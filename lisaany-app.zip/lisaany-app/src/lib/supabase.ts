import 'react-native-url-polyfill/auto';

import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';

import { SUPABASE_ANON_KEY, SUPABASE_URL } from '@/constants/lisaany';

/**
 * Supabase client for the native app.
 *
 * Differences from the web build:
 *  - sessions persist in AsyncStorage rather than localStorage
 *  - detectSessionInUrl is off (no browser URL to parse); deep links are
 *    handled explicitly in the sign-in screen
 */
export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});
