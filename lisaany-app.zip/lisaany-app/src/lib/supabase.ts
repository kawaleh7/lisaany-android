import 'react-native-url-polyfill/auto';

import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient, type Session } from '@supabase/supabase-js';

import { SUPABASE_ANON_KEY, SUPABASE_URL } from '@/constants/lisaany';

/**
 * Supabase client for the native app.
 *
 * Differences from the web build:
 *  - sessions persist in AsyncStorage rather than localStorage
 *  - detectSessionInUrl is off (no browser URL to parse); deep links are
 *    handled explicitly in the sign-in screen
 */
export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

/** Where auth-js keeps the session on this device (its default key). */
const SESSION_STORAGE_KEY = `sb-${new URL(SUPABASE_URL).hostname.split('.')[0]}-auth-token`;

/**
 * The session as stored on the device, even when `getSession()` cannot return
 * it: with an EXPIRED access token auth-js tries to refresh first, and offline
 * that fails and it answers "no session" although the learner is signed in.
 * The returned session may carry an expired access token — good enough to
 * know who is signed in and to show the app in its signed-in state; the
 * auto-refresh tick picks up a real token as soon as the network is back.
 */
export async function readStoredSession(): Promise<Session | null> {
  try {
    const raw = await AsyncStorage.getItem(SESSION_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Session | { currentSession?: Session };
    const s = 'currentSession' in parsed && parsed.currentSession ? parsed.currentSession : (parsed as Session);
    return s && typeof s.access_token === 'string' && s.user?.id ? s : null;
  } catch {
    return null;
  }
}
