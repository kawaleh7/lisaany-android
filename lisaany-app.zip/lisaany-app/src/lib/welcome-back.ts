/**
 * "Welcome back" signal: set when the learner returns after a long break
 * (app resumed, or reopened after the phone closed it), read once by Today,
 * which then shows the welcome-back sheet.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';

const LAST_ACTIVE_KEY = 'lisaany:last-active';

/** 'newday' = first open on a new calendar day; 'return' = back after a long break the same day. */
export type WelcomeKind = 'newday' | 'return';

let pending: WelcomeKind | null = null;
const listeners = new Set<() => void>();

export function markWelcomeBack(kind: WelcomeKind = 'return'): void {
  // A new day wins over a plain return.
  if (pending !== 'newday') pending = kind;
  listeners.forEach((fn) => fn());
}

/** The pending welcome (once per return), or null; clears the signal. */
export function takeWelcomeBack(): WelcomeKind | null {
  const was = pending;
  pending = null;
  return was;
}

/** Local calendar day of a timestamp, e.g. "2026-09-22". */
export function dayOf(at: number): string {
  const d = new Date(at);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export function onWelcomeBack(fn: () => void): () => void {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}

export async function saveLastActive(at = Date.now()): Promise<void> {
  try {
    await AsyncStorage.setItem(LAST_ACTIVE_KEY, String(at));
  } catch {
    /* best-effort */
  }
}

/** When the app was last put away, or null on a first launch. */
export async function getLastActive(): Promise<number | null> {
  try {
    const raw = await AsyncStorage.getItem(LAST_ACTIVE_KEY);
    const n = raw ? Number(raw) : NaN;
    return Number.isFinite(n) ? n : null;
  } catch {
    return null;
  }
}
