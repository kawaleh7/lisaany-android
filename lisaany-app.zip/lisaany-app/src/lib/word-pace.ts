/**
 * The word ladder: how many Arabic words the learner knows, the milestone
 * they are walking towards, and how fast they are moving.
 *
 * A small snapshot of the total word count is kept once a day (about five
 * weeks of them). From the oldest sample at least a week old we derive a
 * "words a week" pace, which the welcome-back sheet uses to say when the
 * learner will pass the milestone after next. With too little history there
 * is no pace and the sheet simply says nothing about it.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';

const HISTORY_KEY = 'lisaany:word-history';
const MILESTONE_KEY = 'lisaany:milestone-seen';
const KEEP_DAYS = 35;

/** The milestones the sheet walks the learner through. */
export const MILESTONES = [100, 250, 500, 1000, 2000, 3000, 5000] as const;

/** Local calendar day, e.g. "2026-09-22" (same rule as goal.ts). */
function localDay(d = new Date()): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function dayToTime(day: string): number {
  const [y, m, d] = day.split('-').map(Number);
  return new Date(y, (m ?? 1) - 1, d ?? 1).getTime();
}

/** The next milestone above `words`, or null once the ladder is finished. */
export function nextMilestone(words: number): number | null {
  return MILESTONES.find((m) => m > words) ?? null;
}

/** The milestone already passed (0 before the first one). */
export function prevMilestone(words: number): number {
  let best = 0;
  for (const m of MILESTONES) if (m <= words) best = m;
  return best;
}

/** The milestone after the next one — the one a pace can promise. */
export function farMilestone(words: number): number | null {
  const next = nextMilestone(words);
  if (next === null) return null;
  return MILESTONES.find((m) => m > next) ?? null;
}

async function readHistory(): Promise<Record<string, number>> {
  try {
    const raw = await AsyncStorage.getItem(HISTORY_KEY);
    return raw ? (JSON.parse(raw) as Record<string, number>) : {};
  } catch {
    return {};
  }
}

/** Record today's word total (best-effort, once a day is enough). */
export async function noteWordTotal(words: number): Promise<void> {
  if (!Number.isFinite(words) || words < 0) return;
  try {
    const hist = await readHistory();
    const today = localDay();
    if (hist[today] === words) return;
    hist[today] = Math.max(hist[today] ?? 0, words);
    const cutoff = Date.now() - KEEP_DAYS * 86400_000;
    for (const day of Object.keys(hist)) if (dayToTime(day) < cutoff) delete hist[day];
    await AsyncStorage.setItem(HISTORY_KEY, JSON.stringify(hist));
  } catch {
    /* best-effort */
  }
}

/**
 * Words learned per week, from the oldest sample at least seven days old,
 * or null when there is not enough history yet (or no movement at all).
 */
export async function wordPace(words: number): Promise<number | null> {
  const hist = await readHistory();
  const now = Date.now();
  let oldest: { at: number; words: number } | null = null;
  for (const [day, n] of Object.entries(hist)) {
    const at = dayToTime(day);
    if (!Number.isFinite(at)) continue;
    const days = (now - at) / 86400_000;
    if (days < 7) continue;
    if (!oldest || at < oldest.at) oldest = { at, words: n };
  }
  if (!oldest) return null;
  const days = (now - oldest.at) / 86400_000;
  const perWeek = ((words - oldest.words) / days) * 7;
  if (!Number.isFinite(perWeek) || perWeek < 1) return null;
  return Math.round(perWeek);
}

/**
 * When the learner reaches `target` at `perWeek` words a week, as a month and
 * year ("March 2027"). Null when that is further away than five years.
 */
export function projectMilestone(words: number, target: number, perWeek: number, locale: string): string | null {
  if (perWeek < 1 || target <= words) return null;
  const weeks = (target - words) / perWeek;
  if (weeks > 5 * 52) return null;
  const when = new Date(Date.now() + weeks * 7 * 86400_000);
  try {
    return when.toLocaleDateString(locale, { month: 'long', year: 'numeric' });
  } catch {
    return null;
  }
}

/**
 * The milestone the learner has crossed since the sheet last spoke about one,
 * or null. Announced once: the crossing is remembered straight away. The very
 * first run only remembers, so an existing learner is not congratulated for a
 * milestone they passed long ago.
 */
export async function takeMilestone(words: number): Promise<number | null> {
  const reached = prevMilestone(words);
  try {
    const raw = await AsyncStorage.getItem(MILESTONE_KEY);
    if (raw === null) {
      await AsyncStorage.setItem(MILESTONE_KEY, String(reached));
      return null;
    }
    const seen = Number(raw);
    if (!Number.isFinite(seen) || reached <= seen) return null;
    await AsyncStorage.setItem(MILESTONE_KEY, String(reached));
    return reached > 0 ? reached : null;
  } catch {
    return null;
  }
}
