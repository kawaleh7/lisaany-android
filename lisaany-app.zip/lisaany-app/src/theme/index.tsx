/**
 * App colour themes. Dark is the original navy + gold; Light is white cards
 * with a navy top edge, navy "question" cards and gold accents.
 *
 * Screens read colours with `useTheme().c` or build styles with
 * `makeStyles((c) => ({ ... }))`, which caches one StyleSheet per theme.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { StyleSheet, useColorScheme } from 'react-native';

export type Scheme = 'dark' | 'light';
export type ThemeMode = 'system' | Scheme;

export type Palette = {
  scheme: Scheme;
  /** Page background. */
  bg: string;
  /** Standard card fill (use `cardGrad` for gradient cards). */
  card: string;
  cardGrad: readonly [string, string];
  /** Slightly raised fill: chips, icon tiles, segmented controls. */
  raised: string;
  /** Thin card border and dividers. */
  line: string;
  /** Card top edge accent (light theme only; transparent in dark). */
  edge: string;
  /** Main text, secondary text, faint text. */
  text: string;
  muted: string;
  faint: string;
  /** Gold used for text/icons (darker in light mode for contrast). */
  gold: string;
  /** Gold used for filled buttons. */
  goldFill: string;
  onGold: string;
  /** Outline gold button: faint fill, gold edge, gold label. */
  btnBg: string;
  btnBorder: string;
  btnText: string;
  /** Border of the current ("you are here") card. */
  curBorder: string;
  /** Soft gold tint behind icons. */
  goldTint: string;
  /** Navy "feature" cards (journey hero, lesson questions) — navy in both themes. */
  navy: string;
  navyGrad: readonly [string, string];
  onNavy: string;
  onNavyMuted: string;
  /** Progress tracks. */
  track: string;
  /** Locked / disabled. */
  locked: string;
  green: string;
  red: string;
  orange: string;
  /** Bottom tab bar. */
  tabBar: string;
  shadow: string;
  shadowOpacity: number;
};

export const DARK: Palette = {
  scheme: 'dark',
  bg: '#0b1223',
  card: '#1a2440',
  cardGrad: ['#243049', '#141d33'],
  raised: 'rgba(255,255,255,0.06)',
  line: 'rgba(214,178,90,0.16)',
  edge: 'transparent',
  text: '#ffffff',
  muted: '#aab3c5',
  faint: '#5b667d',
  gold: '#e8c86a',
  goldFill: '#d6b25a',
  onGold: '#2a1a00',
  btnBg: 'rgba(214,178,90,0.10)',
  btnBorder: 'rgba(214,178,90,0.70)',
  btnText: '#e8c86a',
  curBorder: 'rgba(214,178,90,0.45)',
  goldTint: 'rgba(214,178,90,0.14)',
  navy: '#1d2945',
  navyGrad: ['#2a3856', '#18223a'],
  onNavy: '#ffffff',
  onNavyMuted: '#aab3c5',
  track: 'rgba(255,255,255,0.08)',
  locked: '#5d6880',
  green: '#5fd08a',
  red: '#e07070',
  orange: '#f08a4b',
  tabBar: '#0d1529',
  shadow: '#000000',
  shadowOpacity: 0.45,
};

export const LIGHT: Palette = {
  scheme: 'light',
  bg: '#f5f7fa',
  card: '#ffffff',
  cardGrad: ['#ffffff', '#ffffff'],
  raised: '#eef1f5',
  line: '#e6ebf1',
  edge: '#16213a',
  text: '#0f172a',
  muted: '#64748b',
  faint: '#9aa3b4',
  gold: '#b8861f',
  goldFill: '#d6b25a',
  onGold: '#2a1a00',
  btnBg: 'rgba(214,178,90,0.12)',
  btnBorder: 'rgba(184,134,31,0.65)',
  btnText: '#8a6417',
  curBorder: 'rgba(184,134,31,0.45)',
  goldTint: 'rgba(201,146,30,0.12)',
  navy: '#16213a',
  navyGrad: ['#243049', '#141d33'],
  onNavy: '#ffffff',
  onNavyMuted: '#aab3c5',
  track: '#e3e8ef',
  locked: '#aab1bf',
  green: '#2f9d5c',
  red: '#d04c4c',
  orange: '#e8742c',
  tabBar: '#ffffff',
  shadow: '#0f172a',
  shadowOpacity: 0.06,
};

/**
 * Light mode is OFF: the app is dark everywhere, whatever the phone's colour
 * scheme or any preference stored on the device. The LIGHT palette, the
 * `Scheme`/`ThemeMode` types and the light-only style helpers below are kept
 * intact but unreachable.
 *
 * To switch light mode back on: set this to `true`, and restore the Appearance
 * picker in src/app/(tabs)/profile.tsx plus the pinned `theme: 'dark'` in
 * src/app/lesson/[unit].tsx and the pinned `ls-light` toggle in
 * src/lib/lesson-bridge.ts.
 */
const LIGHT_MODE_ENABLED = false;

const MODE_KEY = 'lisaany:theme-mode';

type ThemeState = { c: Palette; scheme: Scheme; mode: ThemeMode; setMode: (m: ThemeMode) => void };

const ThemeCtx = createContext<ThemeState>({ c: DARK, scheme: 'dark', mode: 'dark', setMode: () => {} });

export function AppThemeProvider({ children }: { children: ReactNode }) {
  const system = useColorScheme();
  const [mode, setModeState] = useState<ThemeMode>('dark');

  useEffect(() => {
    if (!LIGHT_MODE_ENABLED) return;
    AsyncStorage.getItem(MODE_KEY)
      .then((v) => {
        if (v === 'light' || v === 'dark' || v === 'system') setModeState(v);
      })
      .catch(() => {});
  }, []);

  const setMode = useCallback((m: ThemeMode) => {
    if (!LIGHT_MODE_ENABLED) return;
    setModeState(m);
    AsyncStorage.setItem(MODE_KEY, m).catch(() => {});
  }, []);

  // With light mode off the scheme is always 'dark'; `system` and the stored
  // preference are ignored.
  const picked: Scheme = mode === 'system' ? (system === 'light' ? 'light' : 'dark') : mode;
  const scheme: Scheme = LIGHT_MODE_ENABLED ? picked : 'dark';
  const value = useMemo(
    () => ({ c: scheme === 'light' ? LIGHT : DARK, scheme, mode: LIGHT_MODE_ENABLED ? mode : ('dark' as ThemeMode), setMode }),
    [scheme, mode, setMode]
  );
  return <ThemeCtx.Provider value={value}>{children}</ThemeCtx.Provider>;
}

export function useTheme() {
  return useContext(ThemeCtx);
}

/** Build a style hook whose StyleSheet is created once per theme. */
export function makeStyles<T extends StyleSheet.NamedStyles<T>>(fn: (c: Palette) => T) {
  const cache: Partial<Record<Scheme, T>> = {};
  return function useStyles(): T {
    const { c } = useTheme();
    return (cache[c.scheme] ??= StyleSheet.create(fn(c)));
  };
}

/** Border of every standard card in the light theme (one place to change it). */
export function lightCardBorder(c: Palette) {
  if (c.scheme !== 'light') return {};
  // Hairline only: a soft navy glow (see cardGlow) does the lifting. The
  // hairline keeps white cards from melting into the page where shadows are faint.
  return { borderWidth: 1, borderColor: c.line, borderTopWidth: 1, borderTopColor: c.line };
}

/** Light theme: soft navy glow all round each white card. */
export function cardGlow(c: Palette) {
  if (c.scheme !== 'light') return {};
  return { shadowColor: c.navy, shadowOpacity: 0.2, shadowRadius: 24, shadowOffset: { width: 0, height: 0 }, elevation: 4 };
}

/** Card look shared by the light theme: white, hairline edge, soft navy glow. */
export function cardSurface(c: Palette) {
  return {
    backgroundColor: c.card,
    borderWidth: 1,
    borderColor: c.line,
    borderTopWidth: 1,
    borderTopColor: c.line,
    ...lightCardBorder(c),
    shadowColor: c.shadow,
    shadowOpacity: c.shadowOpacity,
    shadowRadius: c.scheme === 'light' ? 30 : 14,
    shadowOffset: { width: 0, height: c.scheme === 'light' ? 10 : 8 },
    elevation: c.scheme === 'light' ? 2 : 6,
    ...cardGlow(c),
  } as const;
}
