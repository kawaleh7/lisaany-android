/**
 * App colour themes. Dark is the original navy + gold; Light is white cards
 * with a navy top edge, navy "question" cards and gold accents.
 *
 * Screens read colours with `useTheme().c` or build styles with
 * `makeStyles((c) => ({ ... }))`, which caches one StyleSheet per theme.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { StyleSheet, useColorScheme } from 'react-native';

export type Scheme = 'dark' | 'light';
export type ThemeMode = 'system' | Scheme;

export type Palette = {
  scheme: Scheme;
  /** Page background. */
  bg: string;
  /** Standard card fill (use `cardGrad` for gradient cards). */
  card: string;
  cardGrad: readonly [string, string];
  /** Slightly raised fill: chips, icon tiles, segmented controls. */
  raised: string;
  /** Thin card border and dividers. */
  line: string;
  /** Card top edge accent (light theme only; transparent in dark). */
  edge: string;
  /** Main text, secondary text, faint text. */
  text: string;
  muted: string;
  faint: string;
  /** Gold used for text/icons (darker in light mode for contrast). */
  gold: string;
  /** Gold used for filled buttons. */
  goldFill: string;
  onGold: string;
  /** Soft gold tint behind icons. */
  goldTint: string;
  /** Navy "feature" cards (journey hero, lesson questions) — navy in both themes. */
  navy: string;
  navyGrad: readonly [string, string];
  onNavy: string;
  onNavyMuted: string;
  /** Progress tracks. */
  track: string;
  /** Locked / disabled. */
  locked: string;
  green: string;
  red: string;
  orange: string;
  /** Bottom tab bar. */
  tabBar: string;
  shadow: string;
  shadowOpacity: number;
};

export const DARK: Palette = {
  scheme: 'dark',
  bg: '#0a1528',
  card: '#1e2a42',
  cardGrad: ['#253149', '#1e2a42'],
  raised: 'rgba(255,255,255,0.06)',
  line: 'rgba(255,255,255,0.1)',
  edge: 'transparent',
  text: '#ffffff',
  muted: '#8792a6',
  faint: '#5b667d',
  gold: '#e6b85a',
  goldFill: '#e6b85a',
  onGold: '#3a2400',
  goldTint: 'rgba(230,184,90,0.14)',
  navy: '#1e2a42',
  navyGrad: ['#253149', '#1a2438'],
  onNavy: '#ffffff',
  onNavyMuted: '#aab3c5',
  track: 'rgba(255,255,255,0.08)',
  locked: '#5d6880',
  green: '#7fd99a',
  red: '#e07070',
  orange: '#f08a4b',
  tabBar: '#101b31',
  shadow: '#000000',
  shadowOpacity: 0.45,
};

export const LIGHT: Palette = {
  scheme: 'light',
  bg: '#f6f7fa',
  card: '#ffffff',
  cardGrad: ['#ffffff', '#ffffff'],
  raised: '#eef1f6',
  line: '#e3e7ef',
  edge: '#16213a',
  text: '#111c34',
  muted: '#6b7486',
  faint: '#9aa3b4',
  gold: '#b8861f',
  goldFill: '#e0a93e',
  onGold: '#2a1a00',
  goldTint: 'rgba(201,146,30,0.12)',
  navy: '#16213a',
  navyGrad: ['#243049', '#141d33'],
  onNavy: '#ffffff',
  onNavyMuted: '#aab3c5',
  track: '#e6eaf1',
  locked: '#aab1bf',
  green: '#2f9d5c',
  red: '#d04c4c',
  orange: '#e8742c',
  tabBar: '#ffffff',
  shadow: '#111c34',
  shadowOpacity: 0.08,
};

const MODE_KEY = 'lisaany:theme-mode';

type ThemeState = { c: Palette; scheme: Scheme; mode: ThemeMode; setMode: (m: ThemeMode) => void };

const ThemeCtx = createContext<ThemeState>({ c: DARK, scheme: 'dark', mode: 'dark', setMode: () => {} });

export function AppThemeProvider({ children }: { children: ReactNode }) {
  const system = useColorScheme();
  const [mode, setModeState] = useState<ThemeMode>('dark');

  useEffect(() => {
    AsyncStorage.getItem(MODE_KEY)
      .then((v) => {
        if (v === 'light' || v === 'dark' || v === 'system') setModeState(v);
      })
      .catch(() => {});
  }, []);

  const setMode = useCallback((m: ThemeMode) => {
    setModeState(m);
    AsyncStorage.setItem(MODE_KEY, m).catch(() => {});
  }, []);

  const scheme: Scheme = mode === 'system' ? (system === 'light' ? 'light' : 'dark') : mode;
  const value = useMemo(() => ({ c: scheme === 'light' ? LIGHT : DARK, scheme, mode, setMode }), [scheme, mode, setMode]);
  return <ThemeCtx.Provider value={value}>{children}</ThemeCtx.Provider>;
}

export function useTheme() {
  return useContext(ThemeCtx);
}

/** Build a style hook whose StyleSheet is created once per theme. */
export function makeStyles<T extends StyleSheet.NamedStyles<T>>(fn: (c: Palette) => T) {
  const cache: Partial<Record<Scheme, T>> = {};
  return function useStyles(): T {
    const { c } = useTheme();
    return (cache[c.scheme] ??= StyleSheet.create(fn(c)));
  };
}

/** Card look shared by the light theme: white, navy top edge, soft shadow. */
export function cardSurface(c: Palette) {
  return {
    backgroundColor: c.card,
    borderWidth: 1,
    borderColor: c.line,
    borderTopWidth: c.scheme === 'light' ? 3 : 1,
    borderTopColor: c.scheme === 'light' ? c.edge : c.line,
    shadowColor: c.shadow,
    shadowOpacity: c.shadowOpacity,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 8 },
    elevation: c.scheme === 'light' ? 3 : 6,
  } as const;
}
