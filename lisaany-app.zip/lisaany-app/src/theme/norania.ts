/**
 * Norania (learn to read) has its own look: the Norania website's original
 * colours on a light page — navy text, gold buttons and bars, gold-brown
 * letters — and stays light whatever the app theme is. No navy cards.
 */
import { StyleSheet } from 'react-native';

import { LIGHT, type Palette } from './index';

export const NR = {
  bg: '#f5f6fb',
  card: '#ffffff',
  border: '#e7e9f5',
  navy: '#1b2154',
  dim: '#5b6092',
  faint: '#9aa0c4',
  gold: '#e8b62b',
  goldBr: '#ffd83a',
  goldDeep: '#b3842b',
  lock: '#b9bccf',
  track: '#e3e6f2',
} as const;

/** The gold button fill, as on the website: bright to deep. */
export const NR_GOLD = [NR.goldBr, NR.gold] as const;

/** Soft card shadow in the website's navy tint. */
export const NR_SHADOW = {
  shadowColor: NR.navy,
  shadowOpacity: 0.08,
  shadowRadius: 14,
  shadowOffset: { width: 0, height: 6 },
  elevation: 2,
} as const;

/**
 * The app Palette filled with Norania colours, for screens written against
 * `c` (the reward and certificate screens).
 */
export const NR_PALETTE: Palette = {
  ...LIGHT,
  scheme: 'light',
  bg: NR.bg,
  card: NR.card,
  cardGrad: [NR.card, NR.card],
  raised: NR.bg,
  line: NR.border,
  edge: 'transparent',
  text: NR.navy,
  muted: NR.dim,
  faint: NR.faint,
  gold: NR.goldDeep,
  goldFill: NR.gold,
  onGold: NR.navy,
  goldTint: NR.bg,
  navy: NR.navy,
  navyGrad: NR_GOLD,
  onNavy: NR.navy,
  onNavyMuted: NR.dim,
  track: NR.track,
  locked: NR.lock,
};

/** Like makeStyles, but always built from the Norania palette. */
export function makeNrStyles<T extends StyleSheet.NamedStyles<T>>(fn: (c: Palette) => T) {
  let sheet: T | undefined;
  return function useNrStyles(): T {
    return (sheet ??= StyleSheet.create(fn(NR_PALETTE)));
  };
}
