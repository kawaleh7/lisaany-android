# Lisaany email reminders: setup guide

This turns on the "come back" reminder emails ("Your Arabic is waiting").
Learners who switch on email reminders in the app only get an email **after they
have been away from the app for a few days**: after 2, 4 and 7 days, then weekly up
to 4 weeks, then no more. It arrives at the hour they chose, in their own time zone.
Opening the app resets the count.

How it works, in one paragraph: the app saves each learner's settings and today's
practice time in Supabase. Once an hour, Supabase runs a small job that calls the
`daily-reminders` function. That function asks the database who is due right now,
sends each person one email through Resend, and notes it so nobody gets two in a
day. Every email has an unsubscribe link handled by the `unsubscribe` function.

Files involved (all in the `supabase` folder):

| File | What it is |
|---|---|
| `reminders.sql` | the database part (run once in the SQL Editor) |
| `functions/daily-reminders/index.ts` | sends the emails |
| `functions/unsubscribe/index.ts` | handles the unsubscribe link |
| `functions/_shared/reminder-email.ts` | the email text and design (English and French) |
| `unsubscribed.html` | optional nicer "you're unsubscribed" page for your website |

You will need about 30 minutes. Commands are for **PowerShell** on Windows.
Type or paste **one line at a time** and press Enter after each.

---

## Step 1. Create a Resend account

1. Go to https://resend.com and sign up (the free plan is fine to start; check
   their pricing page for the current daily and monthly limits).
2. Use `admin@lisaany.com` as the account email if you can.

## Step 2. Add and verify the domain lisaany.com

Resend has to prove that it may send email "from" lisaany.com.

1. In Resend, open **Domains** and click **Add Domain**.
2. Type `lisaany.com` and pick the region closest to most learners
   (for Canada/US: North Virginia `us-east-1`). Click **Add**.
3. Resend now shows a few DNS records (usually an **MX** and a **TXT** record for
   `send`, and a **TXT** record for `resend._domainkey`).
4. Your domain's DNS is at **Cloudflare**. Resend offers a **Sign in to Cloudflare**
   button that adds the records for you. Use it if you see it. Otherwise:
   1. Open https://dash.cloudflare.com, click **lisaany.com**, then **DNS** > **Records**.
   2. For each record Resend shows, click **Add record**, choose the same **Type**,
      and copy the **Name**, **Content/Value** and (for MX) **Priority** exactly.
      Leave "Proxy status" as **DNS only** if Cloudflare asks.
   3. Don't change your existing records (for example the ones for your normal mailbox).
5. Back in Resend, click **Verify DNS Records**. It can take from a few minutes to a
   few hours. Wait until the domain shows **Verified**.
6. Recommended: if Cloudflare doesn't already have a DMARC record (a TXT record
   named `_dmarc`), add one with Name `_dmarc` and Content `v=DMARC1; p=none;`.
   This helps your emails avoid the spam folder.

## Step 3. Create a Resend API key

1. In Resend, open **API Keys** > **Create API Key**.
2. Name: `lisaany-reminders`. Permission: **Sending access**. Domain: `lisaany.com`.
3. Click **Add** and **copy the key** (it starts with `re_`). Resend shows it only
   once. Keep it somewhere safe for Step 6. Never put it in the app code.

## Step 4. Create the database part

1. Open https://supabase.com/dashboard/project/cfaxrzfqvoalwznkhwnx
2. Go to **SQL Editor** > **New query**.
3. Open `supabase/reminders.sql` in a text editor, copy **everything**, paste it,
   and click **Run**. You should see "Success. No rows returned".

It is safe to run again later. The part at the very bottom (the hourly schedule)
is switched off with `--` marks; you'll turn it on in Step 8.

## Step 5. Open PowerShell in the project folder and sign in to Supabase

1. Open PowerShell and go to the project folder (the one that contains the
   `supabase` folder). For example:

```powershell
cd C:\path\to\lisaany-app
```

2. Sign in to Supabase (a browser window opens; approve it):

```powershell
npx supabase login
```

3. Connect this folder to your project (it asks for your **database password**;
   if you don't know it, you can reset it in the dashboard under
   **Project Settings** > **Database**):

```powershell
npx supabase link --project-ref cfaxrzfqvoalwznkhwnx
```

Tips:
- The first `npx supabase` command asks to install the `supabase` package. Type `y`.
- If PowerShell says **"running scripts is disabled on this system"**, type
  `npx.cmd` instead of `npx` in every command (for example `npx.cmd supabase login`).
- If a command says it can't find `config.toml`, run this once and then repeat the
  command (it only adds a settings file next to your SQL files):

```powershell
npx supabase init
```

## Step 6. Give the functions their secrets

These are stored safely inside Supabase, not in your code.

1. The Resend key from Step 3 (replace `re_your_key_here`):

```powershell
npx supabase secrets set RESEND_API_KEY=re_your_key_here
```

2. Your postal mailing address. Canada's anti-spam law (CASL) requires a real
   mailing address in every email, so **the function will not send any email
   until this is set**. A PO box is fine. Keep the quotes:

```powershell
npx supabase secrets set "LISAANY_MAILING_ADDRESS=Your street or PO Box, City, Province, Postal code, Canada"
```

3. A private password that only the hourly job knows (the "cron secret"). This
   line makes a random one and shows it:

```powershell
$cron = [guid]::NewGuid().ToString("N") + [guid]::NewGuid().ToString("N")
```

```powershell
$cron
```

   **Copy what it prints** and keep it for Step 8 and Step 9. Then save it as a secret:

```powershell
npx supabase secrets set CRON_SECRET=$cron
```

4. Optional: where the email button goes. It is `https://lisaany.com` unless you set this:

```powershell
npx supabase secrets set APP_URL=https://lisaany.com
```

## Step 7. Upload (deploy) the two functions

Still in the project folder:

```powershell
npx supabase functions deploy daily-reminders --no-verify-jwt
```

```powershell
npx supabase functions deploy unsubscribe --no-verify-jwt
```

Why `--no-verify-jwt`:
- `unsubscribe` must open for anyone who clicks the link in an email, without signing in.
- `daily-reminders` checks the cron secret from Step 6 itself, so strangers who
  find its address get "Unauthorized" and nothing is sent.

**Prefer the dashboard?** You can also create functions in the Supabase dashboard
(**Edge Functions** > **Deploy a new function** > **Via Editor**), name them exactly
`daily-reminders` and `unsubscribe`, paste the code, and turn **Verify JWT** off in
each function's settings. `daily-reminders` also needs the shared email file
(`functions/_shared/reminder-email.ts`) added next to it in the editor, so the
command line above is simpler. Secrets can be added under **Edge Functions** > **Secrets**.

## Step 8. Turn on the hourly schedule

1. In Supabase, go to **Database** > **Extensions** and make sure **pg_cron** and
   **pg_net** are enabled (the SQL below also tries to enable them).
2. Open **SQL Editor** > **New query**.
3. Copy **PART A** from the bottom of `reminders.sql` (the lines under
   `-- PART A`), paste them, and remove the `-- ` at the start of each line.
4. Replace `PASTE_YOUR_CRON_SECRET_HERE` with the cron secret from Step 6.
5. Click **Run**. This stores the project address and the cron secret in
   **Supabase Vault** (encrypted). Run PART A only once.
6. New query again: copy **PART B**, remove the `-- ` at the start of each line,
   and click **Run**. You'll see a number (the job id).

The job now runs at 2 minutes past every hour. To check that it runs, a few hours
later run this in the SQL Editor:

```sql
select jobid, status, return_message, start_time from cron.job_run_details order by start_time desc limit 10;
```

And to see what the function answered:

```sql
select id, status_code, content, created from net._http_response order by created desc limit 10;
```

To pause the reminders at any time:

```sql
select cron.unschedule('lisaany-daily-reminders');
```

(Running PART B again turns them back on.)

## Step 9. Test it

In PowerShell, put your cron secret in a variable (replace the text in quotes):

```powershell
$cron = "PASTE_YOUR_CRON_SECRET_HERE"
```

**A. Send yourself a sample email** (nothing in the database changes).
English:

```powershell
Invoke-RestMethod -Method Post -Uri "https://cfaxrzfqvoalwznkhwnx.supabase.co/functions/v1/daily-reminders" -Headers @{ Authorization = "Bearer $cron" } -ContentType "application/json" -Body '{"preview_to":"admin@lisaany.com","lang":"en","goal":10,"days":4}'
```

French:

```powershell
Invoke-RestMethod -Method Post -Uri "https://cfaxrzfqvoalwznkhwnx.supabase.co/functions/v1/daily-reminders" -Headers @{ Authorization = "Bearer $cron" } -ContentType "application/json" -Body '{"preview_to":"admin@lisaany.com","lang":"fr","goal":15,"days":7}'
```

You should see `preview : sent` and the email should arrive within a minute.
(Its unsubscribe link is a dummy one and will say the link didn't work; that's expected.)

**B. See how many learners are due right now, without sending:**

```powershell
Invoke-RestMethod -Method Post -Uri "https://cfaxrzfqvoalwznkhwnx.supabase.co/functions/v1/daily-reminders" -Headers @{ Authorization = "Bearer $cron" } -ContentType "application/json" -Body '{"dry_run":true}'
```

**C. A real end-to-end test with your own account:** in the app, turn on email
reminders and set the time to the **current hour** (for example 14:00 if it is now
14:20). Then run the command below. You should get the real email, and running it a
second time sends nothing (one email per day).

```powershell
Invoke-RestMethod -Method Post -Uri "https://cfaxrzfqvoalwznkhwnx.supabase.co/functions/v1/daily-reminders" -Headers @{ Authorization = "Bearer $cron" } -ContentType "application/json" -Body '{}'
```

The answer lists `due`, `sent` and `failed`. If something failed, the `errors`
part says why, and Resend's **Emails** / **Logs** pages show every attempt.
Supabase shows the function's own logs under **Edge Functions** > **daily-reminders** > **Logs**.

## Step 10. The mailing address

You set it in Step 6 (`LISAANY_MAILING_ADDRESS`); it appears in the footer of every
email where the template says `{{MAILING_ADDRESS}}`. To change it later, run the same
`secrets set` line with the new address. No redeploy is needed.

## Optional: a nicer "you're unsubscribed" page

Supabase shows pages from its own web address as plain text, so the unsubscribe
link shows a short plain message in English and French. If you'd like a page in the
Lisaany colours, upload `supabase/unsubscribed.html` to your website (for example as
`https://lisaany.com/unsubscribed`) and then run:

```powershell
npx supabase secrets set UNSUBSCRIBE_PAGE_URL=https://lisaany.com/unsubscribed
```

---

## Good to know

- **Timing.** The job runs a couple of minutes after each hour, so a learner who
  picked 19:30 gets the email around 19:02 their time (the start of their chosen hour).
- **Who gets an email.** Only learners who switched reminders on, have an email
  address on their account, and haven't used the app for exactly 2, 4, 7, 14, 21 or
  28 days (their own dates), with at most one email that day.
- **Limits.** One run sends up to 200 emails, about 2 per second (Resend's default
  speed limit). That's plenty for now; if you ever need more in one hour, ask for
  the limits to be raised.
- **Consent records (CASL).** The database keeps `consent_at`, the time each learner
  last switched reminders on. Unsubscribing takes effect immediately.
- **Deleted accounts** lose their reminder settings automatically.
- **Changing the email wording or design:** edit `functions/_shared/reminder-email.ts`,
  then run the `functions deploy daily-reminders --no-verify-jwt` line again.
