-- Lisaany: family & friends circles (the Circle tab's leaderboard).
--
-- Run this ONCE in Supabase: Dashboard -> SQL Editor -> New query -> paste -> Run.
-- Safe to run again: it only creates what is missing and replaces the functions.
--
-- What it adds:
--   circles         a named group with a join code (e.g. LSN-7K2P)
--   circle_members  who is in which circle, and the name they show there
--   member_xp       each learner's XP (total, this week, streak) as reported by the app
--
-- The tables are locked (row level security, no policies): the app only reaches
-- them through the functions below, which check who is asking. A member can see
-- names and XP of people in their own circles, nothing else. Rows are removed
-- automatically when an account is deleted (ON DELETE CASCADE).

create table if not exists public.circles (
  id          uuid primary key default gen_random_uuid(),
  name        text not null check (char_length(name) between 1 and 40),
  code        text not null unique,
  owner       uuid references auth.users(id) on delete set null,
  created_at  timestamptz not null default now()
);

create table if not exists public.circle_members (
  circle_id     uuid not null references public.circles(id) on delete cascade,
  user_id       uuid not null references auth.users(id) on delete cascade,
  display_name  text not null check (char_length(display_name) between 1 and 24),
  joined_at     timestamptz not null default now(),
  primary key (circle_id, user_id)
);
create index if not exists circle_members_user_idx on public.circle_members(user_id);

create table if not exists public.member_xp (
  user_id     uuid primary key references auth.users(id) on delete cascade,
  total_xp    integer not null default 0,
  week_xp     integer not null default 0,
  week_start  date,
  streak      integer not null default 0,
  updated_at  timestamptz not null default now()
);

alter table public.circles        enable row level security;
alter table public.circle_members enable row level security;
alter table public.member_xp      enable row level security;

-- An empty circle is removed as soon as its last member is gone (they left,
-- or deleted their account).
create or replace function public._circle_cleanup()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  delete from public.circles c
   where c.id = old.circle_id
     and not exists (select 1 from public.circle_members m where m.circle_id = old.circle_id);
  return null;
end $$;
drop trigger if exists circle_members_cleanup on public.circle_members;
create trigger circle_members_cleanup after delete on public.circle_members
  for each row execute function public._circle_cleanup();

-- ── helpers ──────────────────────────────────────────────────────────────────

create or replace function public._circle_uid()
returns uuid language plpgsql stable as $$
declare uid uuid := auth.uid();
begin
  if uid is null then raise exception 'not_signed_in'; end if;
  return uid;
end $$;

create or replace function public._circle_name(p text)
returns text language sql immutable as $$
  select left(regexp_replace(btrim(coalesce(p, '')), '\s+', ' ', 'g'), 24)
$$;

-- ── start a circle ───────────────────────────────────────────────────────────

create or replace function public.create_circle(p_name text, p_display text)
returns table (id uuid, name text, code text)
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := public._circle_uid();
  cname text := left(regexp_replace(btrim(coalesce(p_name, '')), '\s+', ' ', 'g'), 40);
  dname text := public._circle_name(p_display);
  alphabet text := 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  new_code text;
  new_id uuid;
  i int;
begin
  if cname = '' then raise exception 'name_required'; end if;
  if dname = '' then raise exception 'display_name_required'; end if;
  if (select count(*) from public.circle_members m where m.user_id = uid) >= 5 then
    raise exception 'too_many_circles';
  end if;
  loop
    new_code := 'LSN-';
    for i in 1..4 loop
      new_code := new_code || substr(alphabet, 1 + floor(random() * length(alphabet))::int, 1);
    end loop;
    exit when not exists (select 1 from public.circles c where c.code = new_code);
  end loop;
  insert into public.circles (name, code, owner) values (cname, new_code, uid) returning circles.id into new_id;
  insert into public.circle_members (circle_id, user_id, display_name) values (new_id, uid, dname);
  return query select new_id, cname, new_code;
end $$;

-- ── join with a code ─────────────────────────────────────────────────────────

create or replace function public.join_circle(p_code text, p_display text)
returns table (id uuid, name text, code text)
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := public._circle_uid();
  raw text := upper(regexp_replace(coalesce(p_code, ''), '[^A-Za-z0-9]', '', 'g'));
  want text;
  dname text := public._circle_name(p_display);
  c public.circles%rowtype;
begin
  if raw like 'LSN%' then raw := substr(raw, 4); end if;
  want := 'LSN-' || raw;
  if dname = '' then raise exception 'display_name_required'; end if;
  select * into c from public.circles where circles.code = want;
  if not found then raise exception 'circle_not_found'; end if;
  if exists (select 1 from public.circle_members m where m.circle_id = c.id and m.user_id = uid) then
    update public.circle_members set display_name = dname where circle_id = c.id and user_id = uid;
  else
    if (select count(*) from public.circle_members m where m.circle_id = c.id) >= 30 then
      raise exception 'circle_full';
    end if;
    if (select count(*) from public.circle_members m where m.user_id = uid) >= 5 then
      raise exception 'too_many_circles';
    end if;
    insert into public.circle_members (circle_id, user_id, display_name) values (c.id, uid, dname);
  end if;
  return query select c.id, c.name, c.code;
end $$;

-- ── leave (the circle disappears when its last member leaves) ────────────────

create or replace function public.leave_circle(p_circle uuid)
returns void
language plpgsql security definer set search_path = public as $$
declare uid uuid := public._circle_uid();
begin
  delete from public.circle_members where circle_id = p_circle and user_id = uid;
  delete from public.circles c
   where c.id = p_circle
     and not exists (select 1 from public.circle_members m where m.circle_id = p_circle);
end $$;

-- ── my circles ───────────────────────────────────────────────────────────────

create or replace function public.my_circles()
returns table (id uuid, name text, code text, members integer, my_name text)
language sql security definer set search_path = public stable as $$
  select c.id, c.name, c.code,
         (select count(*)::int from public.circle_members x where x.circle_id = c.id),
         m.display_name
    from public.circle_members m
    join public.circles c on c.id = m.circle_id
   where m.user_id = public._circle_uid()
   order by m.joined_at
$$;

-- ── the board for one circle ─────────────────────────────────────────────────
-- week_xp only counts when it was reported for the current week (a day of slack
-- for time zones); otherwise it shows 0 until that learner opens the app again.

create or replace function public.circle_board(p_circle uuid)
returns table (user_id uuid, display_name text, week_xp integer, total_xp integer, streak integer, is_me boolean)
language plpgsql security definer set search_path = public stable as $$
declare uid uuid := public._circle_uid();
begin
  if not exists (select 1 from public.circle_members m where m.circle_id = p_circle and m.user_id = uid) then
    raise exception 'not_a_member';
  end if;
  return query
    select m.user_id, m.display_name,
           case when x.week_start >= (date_trunc('week', now())::date - 1) then coalesce(x.week_xp, 0) else 0 end,
           coalesce(x.total_xp, 0),
           coalesce(x.streak, 0),
           m.user_id = uid
      from public.circle_members m
      left join public.member_xp x on x.user_id = m.user_id
     where m.circle_id = p_circle;
end $$;

-- ── the app reports the learner's own XP ─────────────────────────────────────

create or replace function public.report_xp(p_total integer, p_week integer, p_week_start date, p_streak integer)
returns void
language plpgsql security definer set search_path = public as $$
declare uid uuid := public._circle_uid();
begin
  insert into public.member_xp (user_id, total_xp, week_xp, week_start, streak, updated_at)
  values (uid,
          least(greatest(coalesce(p_total, 0), 0), 10000000),
          least(greatest(coalesce(p_week, 0), 0), 100000),
          p_week_start,
          least(greatest(coalesce(p_streak, 0), 0), 10000),
          now())
  on conflict (user_id) do update
     set total_xp = excluded.total_xp,
         week_xp = excluded.week_xp,
         week_start = excluded.week_start,
         streak = excluded.streak,
         updated_at = now();
end $$;

-- ── who may call what ────────────────────────────────────────────────────────

revoke all on function public.create_circle(text, text)                    from public, anon;
revoke all on function public.join_circle(text, text)                      from public, anon;
revoke all on function public.leave_circle(uuid)                           from public, anon;
revoke all on function public.my_circles()                                 from public, anon;
revoke all on function public.circle_board(uuid)                           from public, anon;
revoke all on function public.report_xp(integer, integer, date, integer)   from public, anon;
grant execute on function public.create_circle(text, text)                  to authenticated;
grant execute on function public.join_circle(text, text)                    to authenticated;
grant execute on function public.leave_circle(uuid)                         to authenticated;
grant execute on function public.my_circles()                               to authenticated;
grant execute on function public.circle_board(uuid)                         to authenticated;
grant execute on function public.report_xp(integer, integer, date, integer) to authenticated;
