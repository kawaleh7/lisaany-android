-- Lisaany: let a signed-in user delete their own account from the app.
-- Apple (and Google) require account deletion inside the app.
--
-- Run this ONCE in Supabase: Dashboard -> SQL Editor -> New query -> paste -> Run.
-- The app calls it with supabase.rpc('delete_user').
--
-- It deletes the caller's row in auth.users. Tables that reference auth.users
-- with ON DELETE CASCADE are cleaned up automatically. If a table references
-- users WITHOUT cascade, add a matching DELETE for it below (the commented
-- lines are examples) — otherwise the delete fails and the app shows an error
-- asking the user to email admin@lisaany.com.

create or replace function public.delete_user()
returns void
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  uid uuid := auth.uid();
begin
  if uid is null then
    raise exception 'Not signed in';
  end if;

  -- Rows in your own tables that point at the user without ON DELETE CASCADE:
  -- delete from public.progress      where user_id = uid;
  -- delete from public.subscriptions where user_id = uid;

  delete from auth.users where id = uid;
end;
$$;

-- Only signed-in users may call it, and only for themselves (auth.uid()).
revoke all on function public.delete_user() from public, anon;
grant execute on function public.delete_user() to authenticated;


-- ============================================================================
-- Make every table that points at auth.users clean itself up on delete
-- ============================================================================
--
-- Why: delete_user() only deletes the row in auth.users and relies on the
-- foreign keys to remove the learner's other rows. A foreign key created as a
-- plain `references auth.users(id)` (no ON DELETE clause — the default is
-- NO ACTION) blocks the delete instead: the function fails with
-- "update or delete on table users violates foreign key constraint …", and
-- the app shows "Could not delete the account … email admin@lisaany.com".
-- `subscriptions` and `learner_progress` were created on the website side and
-- may well be in that state; `circles.sql`, `reminders.sql` and
-- `norania_progress.sql` already cascade.
--
-- This block finds every foreign key in schema `public` that references
-- auth.users(id) and whose delete rule would BLOCK the delete (NO ACTION or
-- RESTRICT), and recreates it with ON DELETE CASCADE, keeping everything else
-- about the constraint (columns, MATCH, ON UPDATE, DEFERRABLE, NOT VALID).
-- Foreign keys that already say SET NULL or SET DEFAULT are left alone: they
-- never block a delete, and they are deliberate — `circles.owner` is SET NULL
-- so a family circle survives when the parent who created it deletes their
-- account (circles.sql). Run it once — running it again finds nothing to
-- change. Run it BEFORE testing the Delete account button.

do $$
declare
  fk record;
  def text;
begin
  for fk in
    select con.oid, con.conname, con.conrelid::regclass as tbl, con.confdeltype
    from pg_constraint con
    join pg_namespace nsp on nsp.oid = con.connamespace
    where con.contype = 'f'
      and nsp.nspname = 'public'
      and con.confrelid = 'auth.users'::regclass
      and con.confdeltype in ('a', 'r')   -- NO ACTION / RESTRICT only
  loop
    def := pg_get_constraintdef(fk.oid);
    -- Drop the ON DELETE clause it has (NO ACTION / RESTRICT).
    def := regexp_replace(def, '\s+ON DELETE\s+(NO ACTION|RESTRICT|CASCADE|SET NULL|SET DEFAULT)(\s*\([^)]*\))?', '', 'i');
    -- Put ON DELETE CASCADE where the grammar allows it: before ON UPDATE /
    -- DEFERRABLE / INITIALLY / NOT VALID when present, otherwise at the end.
    if def ~* '\s(ON UPDATE|NOT DEFERRABLE|DEFERRABLE|INITIALLY|NOT VALID)\M' then
      def := regexp_replace(def, '(\s(ON UPDATE|NOT DEFERRABLE|DEFERRABLE|INITIALLY|NOT VALID)\M)', ' ON DELETE CASCADE\1', 'i');
    else
      def := def || ' ON DELETE CASCADE';
    end if;
    execute format('alter table %s drop constraint %I', fk.tbl, fk.conname);
    execute format('alter table %s add constraint %I %s', fk.tbl, fk.conname, def);
    raise notice 'Foreign key % on % now cascades on user delete (was %)', fk.conname, fk.tbl, fk.confdeltype;
  end loop;
end
$$;

-- Verification: every row should show delete_rule 'c' (cascade), 'n' (set
-- null) or 'd' (set default). An 'a' (no action) or 'r' (restrict) would still
-- make delete_user() fail for a learner with a row in that table.
select con.conrelid::regclass as table_name,
       con.conname             as constraint_name,
       con.confdeltype         as delete_rule,
       pg_get_constraintdef(con.oid) as definition
from pg_constraint con
join pg_namespace nsp on nsp.oid = con.connamespace
where con.contype = 'f'
  and nsp.nspname = 'public'
  and con.confrelid = 'auth.users'::regclass
order by 1, 2;
