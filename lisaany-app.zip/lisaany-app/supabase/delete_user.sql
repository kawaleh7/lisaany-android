-- Lisaany: let a signed-in user delete their own account from the app.
-- Apple (and Google) require account deletion inside the app.
--
-- Run this ONCE in Supabase: Dashboard -> SQL Editor -> New query -> paste -> Run.
-- The app calls it with supabase.rpc('delete_user').
--
-- It deletes the caller's row in auth.users. Tables that reference auth.users
-- with ON DELETE CASCADE are cleaned up automatically. If a table references
-- users WITHOUT cascade, add a matching DELETE for it below (the commented
-- lines are examples) — otherwise the delete fails and the app shows an error
-- asking the user to email admin@lisaany.com.

create or replace function public.delete_user()
returns void
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  uid uuid := auth.uid();
begin
  if uid is null then
    raise exception 'Not signed in';
  end if;

  -- Rows in your own tables that point at the user without ON DELETE CASCADE:
  -- delete from public.progress      where user_id = uid;
  -- delete from public.subscriptions where user_id = uid;

  delete from auth.users where id = uid;
end;
$$;

-- Only signed-in users may call it, and only for themselves (auth.uid()).
revoke all on function public.delete_user() from public, anon;
grant execute on function public.delete_user() to authenticated;
