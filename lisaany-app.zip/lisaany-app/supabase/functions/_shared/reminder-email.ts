// Lisaany reminder email: subject, HTML and plain-text versions (English / French).
// Pure TypeScript with no Deno or Node APIs, so it can be previewed anywhere.
//
// {{MAILING_ADDRESS}} is replaced with the LISAANY_MAILING_ADDRESS secret by the
// daily-reminders function. Canada's anti-spam law (CASL) requires a postal
// mailing address in every commercial email, so the function refuses to send
// until that secret is set.

export type Lang = 'en' | 'fr';

export interface ReminderEmailInput {
  lang: Lang;
  goalMin: number;        // daily goal in minutes (5, 10, 15 or 30)
  minutesDone?: number;   // unused (kept for older callers)
  daysAway: number;       // days since the learner last used the app
  appUrl: string;         // button target, e.g. https://lisaany.com
  unsubscribeUrl: string; // one-click unsubscribe link for this learner
  mailingAddress: string; // postal address shown in the footer
  variant?: number;       // picks one of the subject/intro alternatives
}

export interface ReminderEmail {
  subject: string;
  html: string;
  text: string;
}

export const MAILING_ADDRESS_PLACEHOLDER = '{{MAILING_ADDRESS}}';
export const CONTACT_EMAIL = 'admin@lisaany.com';

const NAVY = '#0b1223';
const CARD = '#131d36';
const GOLD = '#D6B25A';
const INK = '#F4EFE2';
const MUTED = '#A9B0C2';
const TRACK = '#26314f';

const NBSP = ' '; // French puts a no-break space before ? ! :

interface Copy {
  subject: (days: number, g: number) => string;
  greeting: string;
  intro: (days: number, g: number) => string;
  away: (days: number) => string;
  button: string;
  signoff: string;
  why: string;
  settings: string;
  contact: string;
  unsubscribe: string;
  preheader: (days: number) => string;
}

// "Come back" emails: sent only after 2, 4 and 7 days away, then weekly up to 4 weeks.
const COPY: Record<Lang, Copy> = {
  en: {
    subject: (d, g) =>
      d <= 2 ? 'Your Arabic is waiting'
      : d <= 4 ? `Come back for ${g} minutes of Arabic?`
      : d <= 7 ? 'It’s been a week — let’s pick up where you left off'
      : d <= 14 ? 'Your words miss you'
      : 'Whenever you’re ready, your Arabic is here',
    greeting: 'Hi, it’s your Lisaany star.',
    intro: (d, g) =>
      d <= 2 ? 'A short lesson today keeps your new words fresh. I saved your place.'
      : d <= 4 ? `I kept your spot. ${g} minutes today and you’re right back on track.`
      : d <= 7 ? 'A week goes by fast. Your next lesson is ready — let’s continue together.'
      : d <= 14 ? 'Two weeks is a great moment to restart. I’ll be right there with you.'
      : 'Your Arabic journey is waiting for you. Pick up exactly where you left off.',
    away: (d) => `Last lesson: ${d} days ago`,
    button: 'Continue learning',
    signoff: 'See you in the app!',
    why: 'You’re getting this email because you turned on email reminders in the Lisaany app.',
    settings: 'We only write when you haven’t learned for a few days. You can turn this off in the app’s settings.',
    contact: 'Questions?',
    unsubscribe: 'Unsubscribe from reminder emails',
    preheader: (d) => `It’s been ${d} days. Your next lesson is one tap away.`,
  },
  fr: {
    subject: (d, g) =>
      d <= 2 ? 'Votre arabe vous attend'
      : d <= 4 ? `On reprend pour ${g} minutes d’arabe${NBSP}?`
      : d <= 7 ? 'Une semaine déjà — reprenons là où vous en étiez'
      : d <= 14 ? 'Vos mots vous attendent'
      : 'Quand vous serez prêt, votre arabe est là',
    greeting: `Bonjour, c’est votre étoile Lisaany${NBSP}!`,
    intro: (d, g) =>
      d <= 2 ? 'Une petite leçon aujourd’hui garde vos nouveaux mots frais. Je vous ai gardé votre place.'
      : d <= 4 ? `J’ai gardé votre place. ${g} minutes aujourd’hui et vous êtes de retour sur la bonne voie.`
      : d <= 7 ? 'Une semaine passe vite. Votre prochaine leçon est prête — continuons ensemble.'
      : d <= 14 ? 'Deux semaines, c’est le bon moment pour reprendre. Je serai là avec vous.'
      : 'Votre parcours en arabe vous attend. Reprenez exactement là où vous en étiez.',
    away: (d) => `Dernière leçon${NBSP}: il y a ${d}${NBSP}jours`,
    button: 'Continuer à apprendre',
    signoff: `À tout de suite dans l’appli${NBSP}!`,
    why: 'Vous recevez ce courriel parce que vous avez activé les rappels par courriel dans l’application Lisaany.',
    settings: 'Nous n’écrivons que si vous n’avez pas appris depuis quelques jours. Vous pouvez désactiver cela dans les réglages de l’application.',
    contact: `Des questions${NBSP}?`,
    unsubscribe: 'Se désabonner des rappels par courriel',
    preheader: (d) => `Cela fait ${d}${NBSP}jours. Votre prochaine leçon est à portée de main.`,
  },
};

function esc(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}


export function buildReminderEmail(input: ReminderEmailInput): ReminderEmail {
  const lang: Lang = input.lang === 'fr' ? 'fr' : 'en';
  const c = COPY[lang];
  const g = [5, 10, 15, 30].includes(input.goalMin) ? input.goalMin : 30;
  const days = Math.max(1, Math.floor(input.daysAway || 2));
  const subject = c.subject(days, g);
  const intro = c.intro(days, g);
  const away = c.away(days);
  const address = input.mailingAddress;

  const font = `font-family:'Segoe UI',Helvetica,Arial,sans-serif;`;

  const html = `<!DOCTYPE html>
<html lang="${lang}" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="dark light">
<meta name="supported-color-schemes" content="dark light">
<title>${esc(subject)}</title>
</head>
<body style="margin:0;padding:0;background:${NAVY};" bgcolor="${NAVY}">
<div style="display:none;max-height:0;overflow:hidden;opacity:0;color:${NAVY};">${esc(c.preheader(days))}</div>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="${NAVY}" style="background:${NAVY};">
<tr><td align="center" style="padding:32px 12px;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width:520px;">
    <tr><td align="center" style="padding:0 0 18px 0;${font}font-size:22px;font-weight:700;letter-spacing:1px;color:${GOLD};">Lisaany</td></tr>
    <tr><td bgcolor="${CARD}" style="background:${CARD};border:1px solid ${TRACK};border-radius:16px;padding:32px 28px;">
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr><td align="center" style="${font}font-size:44px;line-height:48px;color:${GOLD};padding:0 0 8px 0;">&#10022;</td></tr>
        <tr><td align="center" style="${font}font-size:15px;line-height:22px;color:${GOLD};font-weight:600;padding:0 0 6px 0;">${esc(c.greeting)}</td></tr>
        <tr><td align="center" style="${font}font-size:24px;line-height:31px;color:${INK};font-weight:700;padding:0 0 14px 0;">${esc(subject)}</td></tr>
        <tr><td align="center" style="${font}font-size:16px;line-height:24px;color:${MUTED};padding:0 0 24px 0;">${esc(intro)}</td></tr>
        <tr><td align="center" style="${font}font-size:13px;line-height:18px;color:${GOLD};letter-spacing:.5px;padding:0 0 24px 0;">${esc(away)}</td></tr>
        <tr><td align="center" style="padding:0 0 22px 0;">
          <table role="presentation" cellpadding="0" cellspacing="0" border="0"><tr>
            <td bgcolor="${GOLD}" style="background:${GOLD};border-radius:999px;">
              <a href="${esc(input.appUrl)}" target="_blank" style="display:inline-block;padding:14px 34px;${font}font-size:16px;font-weight:700;color:${NAVY};text-decoration:none;border-radius:999px;">${esc(c.button)}</a>
            </td>
          </tr></table>
        </td></tr>
        <tr><td align="center" style="${font}font-size:15px;line-height:22px;color:${INK};">${esc(c.signoff)}</td></tr>
      </table>
    </td></tr>
    <tr><td style="padding:24px 8px 0 8px;${font}font-size:12px;line-height:18px;color:${MUTED};" align="center">
      ${esc(c.why)} ${esc(c.settings)}<br><br>
      Lisaany &middot; ${esc(address)}<br>
      ${esc(c.contact)} <a href="mailto:${CONTACT_EMAIL}" style="color:${GOLD};text-decoration:underline;">${CONTACT_EMAIL}</a><br><br>
      <a href="${esc(input.unsubscribeUrl)}" style="color:${GOLD};text-decoration:underline;">${esc(c.unsubscribe)}</a>
    </td></tr>
  </table>
</td></tr>
</table>
</body>
</html>`;

  const text = [
    c.greeting,
    '',
    subject,
    '',
    intro,
    '',
    away,
    '',
    `${c.button}: ${input.appUrl}`,
    '',
    c.signoff,
    '',
    '--',
    `${c.why} ${c.settings}`,
    `Lisaany · ${address}`,
    `${c.contact} ${CONTACT_EMAIL}`,
    `${c.unsubscribe}: ${input.unsubscribeUrl}`,
  ].join('\n');

  return { subject, html, text };
}
