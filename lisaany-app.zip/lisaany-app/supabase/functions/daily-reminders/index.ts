// Lisaany: daily-reminders Edge Function.
//
// Called once an hour by pg_cron (see the bottom of supabase/reminders.sql).
// It asks the database who is due a reminder right now (due_reminders), sends
// each of them one email through Resend, and records the send (mark_reminded)
// so nobody gets two reminders on the same day.
//
// Secrets (npx supabase secrets set NAME=value):
//   RESEND_API_KEY           Resend API key (re_...)
//   CRON_SECRET              any long random string; callers must send
//                            "Authorization: Bearer <CRON_SECRET>"
//   LISAANY_MAILING_ADDRESS  postal address for the email footer (required by CASL)
//   APP_URL                  optional, button link (default https://lisaany.com)
// SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are provided by Supabase.
//
// Deploy with:  npx supabase functions deploy daily-reminders --no-verify-jwt
// (the function checks CRON_SECRET itself, so the public cannot trigger it).
//
// Request body (all optional, JSON):
//   {}                                        normal run: email everyone due now
//   {"dry_run": true}                         list how many are due, send nothing
//   {"preview_to": "you@example.com", "lang": "fr", "goal": 10, "days": 4}
//                                             send ONE sample email to that address
//                                             (no database changes)

import { createClient } from 'npm:@supabase/supabase-js@2';
import { buildReminderEmail, MAILING_ADDRESS_PLACEHOLDER, type Lang } from '../_shared/reminder-email.ts';

const FROM = 'Lisaany <reminders@lisaany.com>';
const REPLY_TO = 'admin@lisaany.com';
const CONCURRENCY = 2;       // Resend's default limit is a few requests per second
const MIN_GAP_MS = 1100;     // per worker: at most ~2 emails per second in total
const MAX_PER_RUN = 200;     // keeps one run well inside the function time limit

interface DueRow {
  user_id: string;
  email: string;
  lang: string;
  goal_min: number;
  minutes_done: number;
  days_away: number;
  unsub_token: string;
  local_day: string;
}

const env = (k: string) => (Deno.env.get(k) ?? '').trim();

function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

async function sha256(s: string): Promise<Uint8Array> {
  return new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)));
}

// Constant-time comparison of two strings (compares their hashes).
async function sameSecret(a: string, b: string): Promise<boolean> {
  if (!a || !b) return false;
  const [x, y] = await Promise.all([sha256(a), sha256(b)]);
  let diff = 0;
  for (let i = 0; i < x.length; i++) diff |= x[i] ^ y[i];
  return diff === 0;
}

async function authorized(req: Request): Promise<boolean> {
  const auth = req.headers.get('authorization') ?? '';
  const token = auth.replace(/^Bearer\s+/i, '').trim();
  const cronSecret = env('CRON_SECRET');
  const serviceKey = env('SUPABASE_SERVICE_ROLE_KEY');
  return (await sameSecret(token, cronSecret)) || (await sameSecret(token, serviceKey));
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

// A number that changes each day, so the subject line varies from day to day.
function dayVariant(day: string, userId: string): number {
  let h = 0;
  for (const ch of day + userId.slice(0, 4)) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return h;
}

async function sendEmail(
  apiKey: string,
  to: string,
  mail: { subject: string; html: string; text: string },
  unsubscribeUrl: string,
  idempotencyKey?: string,
): Promise<{ ok: true; id: string } | { ok: false; status: number; error: string }> {
  const body = JSON.stringify({
    from: FROM,
    to: [to],
    reply_to: REPLY_TO,
    subject: mail.subject,
    html: mail.html,
    text: mail.text,
    headers: {
      'List-Unsubscribe': `<${unsubscribeUrl}>, <mailto:${REPLY_TO}?subject=unsubscribe>`,
      'List-Unsubscribe-Post': 'List-Unsubscribe=One-Click',
    },
  });
  const headers: Record<string, string> = {
    Authorization: `Bearer ${apiKey}`,
    'Content-Type': 'application/json',
  };
  // Resend ignores a repeat with the same key for 24 hours: no double emails
  // if two runs ever overlap.
  if (idempotencyKey) headers['Idempotency-Key'] = idempotencyKey;

  for (let attempt = 0; attempt < 3; attempt++) {
    let res: Response;
    try {
      res = await fetch('https://api.resend.com/emails', { method: 'POST', headers, body });
    } catch (e) {
      if (attempt === 2) return { ok: false, status: 0, error: String(e) };
      await sleep(1000 * (attempt + 1));
      continue;
    }
    if (res.ok) {
      const data = await res.json().catch(() => ({}));
      return { ok: true, id: String((data as { id?: string }).id ?? '') };
    }
    const errText = await res.text().catch(() => '');
    if ((res.status === 429 || res.status >= 500) && attempt < 2) {
      const wait = Number(res.headers.get('retry-after'));
      await sleep(Number.isFinite(wait) && wait > 0 ? Math.min(wait, 10) * 1000 : 1000 * (attempt + 1));
      continue;
    }
    return { ok: false, status: res.status, error: errText.slice(0, 300) };
  }
  return { ok: false, status: 0, error: 'unreachable' };
}

Deno.serve(async (req) => {
  if (req.method !== 'POST') return json({ error: 'Use POST' }, 405);
  if (!(await authorized(req))) return json({ error: 'Unauthorized' }, 401);

  const supabaseUrl = env('SUPABASE_URL');
  const serviceKey = env('SUPABASE_SERVICE_ROLE_KEY');
  const resendKey = env('RESEND_API_KEY');
  const address = env('LISAANY_MAILING_ADDRESS');
  const appUrl = env('APP_URL') || 'https://lisaany.com';

  if (!resendKey) return json({ error: 'RESEND_API_KEY secret is not set' }, 500);
  if (!address || address === MAILING_ADDRESS_PLACEHOLDER) {
    return json({ error: 'LISAANY_MAILING_ADDRESS secret is not set (a postal address is required in every email)' }, 500);
  }

  const opts = (await req.json().catch(() => ({}))) as {
    dry_run?: boolean;
    preview_to?: string;
    lang?: string;
    goal?: number;
    days?: number;
  };
  const unsubBase = `${supabaseUrl}/functions/v1/unsubscribe`;

  // One sample email to the owner, no database involved.
  if (opts.preview_to) {
    const to = String(opts.preview_to).trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(to)) return json({ error: 'preview_to is not an email address' }, 400);
    const unsubscribeUrl = `${unsubBase}?t=00000000-0000-0000-0000-000000000000`;
    const mail = buildReminderEmail({
      lang: (opts.lang === 'fr' ? 'fr' : 'en') as Lang,
      goalMin: Number(opts.goal) || 10,
      daysAway: Number(opts.days) || 2,
      appUrl,
      unsubscribeUrl,
      mailingAddress: address,
      variant: Math.floor(Math.random() * 3),
    });
    const r = await sendEmail(resendKey, to, mail, unsubscribeUrl);
    return json(r.ok ? { preview: 'sent', id: r.id } : { preview: 'failed', ...r }, r.ok ? 200 : 502);
  }

  const db = createClient(supabaseUrl, serviceKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  const { data, error } = await db.rpc('due_reminders');
  if (error) return json({ error: `due_reminders failed: ${error.message}` }, 500);
  const due = ((data ?? []) as DueRow[]).slice(0, MAX_PER_RUN);
  const skipped = Math.max(0, (data?.length ?? 0) - due.length);

  if (opts.dry_run) {
    return json({ dry_run: true, due: data?.length ?? 0, would_send: due.length });
  }

  let sent = 0;
  let failed = 0;
  let markFailed = 0;
  const errors: { user_id: string; status: number; error: string }[] = [];

  let next = 0;
  async function worker() {
    while (next < due.length) {
      const row = due[next++];
      const started = Date.now();
      try {
        const unsubscribeUrl = `${unsubBase}?t=${encodeURIComponent(row.unsub_token)}`;
        const mail = buildReminderEmail({
          lang: row.lang === 'fr' ? 'fr' : 'en',
          goalMin: row.goal_min,
          daysAway: row.days_away,
          appUrl,
          unsubscribeUrl,
          mailingAddress: address,
          variant: dayVariant(row.local_day, row.user_id),
        });
        const r = await sendEmail(resendKey, row.email, mail, unsubscribeUrl, `reminder-${row.user_id}-${row.local_day}`);
        if (r.ok) {
          sent++;
          const m = await db.rpc('mark_reminded', { p_user: row.user_id, p_day: row.local_day });
          if (m.error) {
            markFailed++;
            console.error('mark_reminded failed', row.user_id, m.error.message);
          }
        } else {
          failed++;
          if (errors.length < 20) errors.push({ user_id: row.user_id, status: r.status, error: r.error });
          console.error('send failed', row.user_id, r.status, r.error);
        }
      } catch (e) {
        failed++;
        if (errors.length < 20) errors.push({ user_id: row.user_id, status: 0, error: String(e) });
        console.error('reminder error', row.user_id, e);
      }
      const spent = Date.now() - started;
      if (spent < MIN_GAP_MS && next < due.length) await sleep(MIN_GAP_MS - spent);
    }
  }
  await Promise.all(Array.from({ length: Math.min(CONCURRENCY, due.length) }, worker));

  const result = { due: data?.length ?? 0, sent, failed, mark_failed: markFailed, skipped_over_limit: skipped, errors };
  console.log('daily-reminders', JSON.stringify({ ...result, errors: errors.length }));
  return json(result);
});
