// Lisaany: unsubscribe Edge Function (the link at the bottom of every reminder).
//
//   GET  /functions/v1/unsubscribe?t=<token>   the footer link: turns reminders off
//                                              and shows a short EN + FR message
//   POST /functions/v1/unsubscribe?t=<token>   one-click unsubscribe sent by Gmail,
//                                              Apple Mail, etc. (RFC 8058); answers 200
//
// Anyone must be able to open it without signing in, so deploy it with:
//   npx supabase functions deploy unsubscribe --no-verify-jwt
//
// Supabase shows web pages from *.supabase.co as plain text (it rewrites
// text/html on GET to text/plain), so the message is plain text. If you host a
// nicer page (supabase/unsubscribed.html, e.g. at https://lisaany.com/unsubscribed),
// set the secret UNSUBSCRIBE_PAGE_URL to it and the link redirects there with
// ?status=ok, ?status=invalid or ?status=error.

import { createClient } from 'npm:@supabase/supabase-js@2';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

type Status = 'ok' | 'invalid' | 'error';

const MESSAGES: Record<Status, string> = {
  ok: [
    'Lisaany',
    '',
    'You’re unsubscribed from Lisaany reminder emails.',
    'You won’t get any more reminder emails. You can turn them back on any time in the app’s settings.',
    '',
    'Vous êtes désabonné(e) des rappels par courriel de Lisaany.',
    'Vous ne recevrez plus de rappels par courriel. Vous pouvez les réactiver à tout moment dans les réglages de l’application.',
    '',
    'Questions? / Des questions ? admin@lisaany.com',
  ].join('\n'),
  invalid: [
    'Lisaany',
    '',
    'Hmm, this unsubscribe link didn’t work. It may be incomplete or out of date.',
    'You can turn reminder emails off in the app’s settings, or write to admin@lisaany.com and we’ll do it for you.',
    '',
    'Oups, ce lien de désabonnement n’a pas fonctionné. Il est peut-être incomplet ou périmé.',
    'Vous pouvez désactiver les rappels dans les réglages de l’application, ou écrire à admin@lisaany.com et nous le ferons pour vous.',
  ].join('\n'),
  error: [
    'Lisaany',
    '',
    'Something went wrong on our side. Please try the link again in a few minutes, or write to admin@lisaany.com.',
    '',
    'Un problème est survenu de notre côté. Réessayez le lien dans quelques minutes, ou écrivez à admin@lisaany.com.',
  ].join('\n'),
};

async function unsubscribe(token: string | null): Promise<Status> {
  if (!token || !UUID.test(token)) return 'invalid';
  const db = createClient(Deno.env.get('SUPABASE_URL') ?? '', Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '', {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const { data, error } = await db.rpc('unsubscribe_by_token', { p_token: token });
  if (error) {
    console.error('unsubscribe_by_token failed', error.message);
    return 'error';
  }
  return data === true ? 'ok' : 'invalid';
}

Deno.serve(async (req) => {
  const url = new URL(req.url);
  let token = url.searchParams.get('t');

  if (req.method === 'POST') {
    // One-click: the token is in the URL; accept it in a form body as well.
    if (!token) {
      const form = await req.formData().catch(() => null);
      const t = form?.get('t');
      token = typeof t === 'string' ? t : null;
    }
    const status = await unsubscribe(token);
    return new Response(status === 'error' ? 'Error' : 'Unsubscribed', {
      status: status === 'error' ? 500 : 200,
      headers: { 'Content-Type': 'text/plain; charset=utf-8' },
    });
  }

  if (req.method === 'GET') {
    const status = await unsubscribe(token);
    const page = (Deno.env.get('UNSUBSCRIBE_PAGE_URL') ?? '').trim();
    if (page) {
      return new Response(null, {
        status: 303,
        headers: { Location: `${page}${page.includes('?') ? '&' : '?'}status=${status}` },
      });
    }
    return new Response(MESSAGES[status], {
      status: status === 'error' ? 500 : 200,
      headers: { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' },
    });
  }

  return new Response('Method not allowed', { status: 405, headers: { Allow: 'GET, POST' } });
});
