-- ============================================================================
-- Lisaany — Norania (learn to read) progress in the cloud
-- ============================================================================
--
-- Run once in the Supabase SQL editor (Dashboard → SQL Editor → New query →
-- paste → Run). Every statement is idempotent: running it twice is harmless.
--
-- Why: the Norania lessons, stars, "days with a lesson" and the learner's
-- first name used to live only on the phone (AsyncStorage). A reinstall or a
-- new phone lost all 33 lessons and the certificates. The app now keeps one
-- row per signed-in learner here (src/lib/norania.ts: pullNoraniaProgress on
-- sign-in / start-up / return from the background, pushNoraniaProgress after
-- every local change) and merges it with the device: done lessons never
-- un-do, each lesson keeps its best stars, every day counts.
--
-- Shape (all keyed by the lesson title, exactly as the Norania page keys them):
--   done         {"Lesson 1": true, ...}
--   stars        {"Lesson 1": 3, ...}          1, 2 or 3
--   days         {"2026-09-22": true, ...}     local calendar days, ~60 kept
-- The child's first name (certificate screen) is NOT stored here — it stays
-- on the device, so no personal data about a child leaves the phone.
--
-- The row goes with the account: ON DELETE CASCADE from auth.users, so
-- delete_user() removes it.
-- ============================================================================

create table if not exists public.norania_progress (
  user_id      uuid primary key references auth.users(id) on delete cascade,
  done         jsonb not null default '{}'::jsonb,
  stars        jsonb not null default '{}'::jsonb,
  days         jsonb not null default '{}'::jsonb,
  updated_at   timestamptz not null default now()
);

comment on table public.norania_progress is
  'Norania (learn to read) progress of the Lisaany app, one row per learner, merged with the device by the app.';

-- Row Level Security: a learner reads and writes their own row only. The app
-- uses the publishable key with the learner's session, so these policies are
-- the whole access control.
alter table public.norania_progress enable row level security;

drop policy if exists "norania_progress_select_own" on public.norania_progress;
create policy "norania_progress_select_own"
  on public.norania_progress
  for select
  to authenticated
  using (auth.uid() = user_id);

drop policy if exists "norania_progress_insert_own" on public.norania_progress;
create policy "norania_progress_insert_own"
  on public.norania_progress
  for insert
  to authenticated
  with check (auth.uid() = user_id);

drop policy if exists "norania_progress_update_own" on public.norania_progress;
create policy "norania_progress_update_own"
  on public.norania_progress
  for update
  to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- No delete policy on purpose: the row disappears with the account.

revoke all on public.norania_progress from anon;
grant select, insert, update on public.norania_progress to authenticated;

-- Check: expect rowsecurity = true and the three policies above.
select tablename, rowsecurity from pg_tables where schemaname = 'public' and tablename = 'norania_progress';
select policyname, cmd, qual, with_check from pg_policies where schemaname = 'public' and tablename = 'norania_progress' order by policyname;
