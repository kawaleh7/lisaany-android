-- Lisaany: daily email reminders ("your minutes of Arabic are waiting").
--
-- Run this ONCE in Supabase: Dashboard -> SQL Editor -> New query -> paste -> Run.
-- Safe to run again: it only creates what is missing and replaces the functions.
--
-- What it adds:
--   reminder_prefs  one row per learner: email opt-in (with consent time, for
--                   CASL), reminder time + time zone, daily goal in minutes,
--                   language, and today's practice seconds as reported by the app.
--
-- The table is locked (row level security, no policies). The app reaches it only
-- through set_reminder_prefs() and report_minutes(), which work on the caller's
-- own row (auth.uid()). The email job (the daily-reminders Edge Function) uses
-- due_reminders(), mark_reminded() and unsubscribe_by_token(), which only the
-- service role can run. Rows are removed automatically when an account is
-- deleted (ON DELETE CASCADE).
--
-- The hourly schedule (pg_cron + pg_net) is at the bottom, commented out.
-- Follow supabase/REMINDERS_SETUP.md before running that part.

create table if not exists public.reminder_prefs (
  user_id         uuid primary key references auth.users(id) on delete cascade,
  email_opt_in    boolean not null default false,
  remind_hour     integer not null default 19 check (remind_hour between 0 and 23),
  remind_minute   integer not null default 0  check (remind_minute between 0 and 59),
  tz              text    not null default 'UTC',
  goal_min        integer not null default 30 check (goal_min in (5, 10, 15, 30)),
  lang            text    not null default 'en' check (lang in ('en', 'fr')),
  day             date,                        -- learner's local date of day_secs
  day_secs        integer not null default 0,  -- active seconds on that date
  last_email_day  date,                        -- learner's local date of the last reminder
  unsub_token     uuid    not null default gen_random_uuid() unique,
  consent_at      timestamptz,                 -- when email_opt_in last turned on (CASL)
  updated_at      timestamptz not null default now()
);
create index if not exists reminder_prefs_opt_in_idx on public.reminder_prefs(user_id) where email_opt_in;

alter table public.reminder_prefs enable row level security;

-- ── helpers ──────────────────────────────────────────────────────────────────

create or replace function public._rem_uid()
returns uuid language plpgsql stable as $$
declare uid uuid := auth.uid();
begin
  if uid is null then raise exception 'not_signed_in'; end if;
  return uid;
end $$;

-- A real IANA zone name (e.g. 'America/Edmonton'), otherwise 'UTC'.
create or replace function public._rem_tz(p text)
returns text language sql stable as $$
  select coalesce((select n.name from pg_timezone_names n where n.name = btrim(p) limit 1), 'UTC')
$$;

-- The learner's local date right now.
create or replace function public._rem_local_day(p_tz text)
returns date language sql stable as $$
  select (now() at time zone public._rem_tz(p_tz))::date
$$;

-- ── the app saves the learner's reminder settings ────────────────────────────
-- Out-of-range values are clamped (hour 0-23, minute 0-59), an unknown goal
-- becomes 30, an unknown time zone 'UTC', any language other than French 'en'.
-- consent_at is stamped each time email reminders are switched on.

create or replace function public.set_reminder_prefs(
  p_opt_in boolean, p_hour integer, p_minute integer, p_tz text, p_goal integer, p_lang text)
returns void
language plpgsql security definer set search_path = public as $$
declare
  uid   uuid    := public._rem_uid();
  optin boolean := coalesce(p_opt_in, false);
  hh    integer := least(greatest(coalesce(p_hour, 19), 0), 23);
  mm    integer := least(greatest(coalesce(p_minute, 0), 0), 59);
  zone  text    := public._rem_tz(p_tz);
  goal  integer := case when p_goal in (5, 10, 15, 30) then p_goal else 30 end;
  lng   text    := case when lower(btrim(coalesce(p_lang, ''))) like 'fr%' then 'fr' else 'en' end;
begin
  insert into public.reminder_prefs as r
         (user_id, email_opt_in, remind_hour, remind_minute, tz, goal_min, lang, consent_at, updated_at)
  values (uid, optin, hh, mm, zone, goal, lng, case when optin then now() end, now())
  on conflict (user_id) do update
     set email_opt_in  = excluded.email_opt_in,
         remind_hour   = excluded.remind_hour,
         remind_minute = excluded.remind_minute,
         tz            = excluded.tz,
         goal_min      = excluded.goal_min,
         lang          = excluded.lang,
         -- new consent only when it goes from off to on; the old record is kept otherwise
         consent_at    = case when excluded.email_opt_in and not r.email_opt_in then now() else r.consent_at end,
         updated_at    = now();
end $$;

-- ── the app reports today's practice time ────────────────────────────────────
-- p_day is the learner's local date, p_secs the total active seconds for it
-- (clamped to 0..86400). A report for an older day than the one stored is
-- ignored; for the same day the larger total wins (two devices, late sync).

create or replace function public.report_minutes(p_day date, p_secs integer)
returns void
language plpgsql security definer set search_path = public as $$
declare
  uid  uuid    := public._rem_uid();
  secs integer := least(greatest(coalesce(p_secs, 0), 0), 86400);
  d    date    := coalesce(p_day, (now() at time zone 'UTC')::date);
begin
  -- a local date is never more than about a day away from the UTC date
  if d > (now() at time zone 'UTC')::date + 2 or d < (now() at time zone 'UTC')::date - 2 then
    return;
  end if;
  insert into public.reminder_prefs as r (user_id, day, day_secs, updated_at)
  values (uid, d, secs, now())
  on conflict (user_id) do update
     set day_secs   = case when r.day = excluded.day then greatest(r.day_secs, excluded.day_secs)
                           when r.day is null or r.day < excluded.day then excluded.day_secs
                           else r.day_secs end,
         day        = case when r.day is null or r.day < excluded.day then excluded.day else r.day end,
         updated_at = now();
end $$;

-- ── for the email job only (service role) ────────────────────────────────────
-- Who should get a reminder right now: opted in, has an email address, it is
-- currently their reminder hour in their own time zone (the job runs once an
-- hour, a few minutes past the hour), today's goal is not reached yet, and no
-- reminder was sent yet today (their local date).

drop function if exists public.due_reminders();
create function public.due_reminders()
returns table (user_id uuid, email text, lang text, goal_min integer, minutes_done integer,
               unsub_token uuid, local_day date, days_away integer)
language sql security definer set search_path = public, auth stable as $$
  select r.user_id, u.email::text, r.lang, r.goal_min,
         case when r.day = l.local_day then r.day_secs / 60 else 0 end,
         r.unsub_token, l.local_day, (l.local_day - r.day)::int
    from public.reminder_prefs r
    join auth.users u on u.id = r.user_id
    cross join lateral (select now() at time zone r.tz as ts) t  -- tz was checked when saved
    cross join lateral (select t.ts::date as local_day) l
   where r.email_opt_in
     and u.email is not null and btrim(u.email) <> ''
     and extract(hour from t.ts)::int = r.remind_hour
     -- only learners who have been away: 2, 4 and 7 days, then weekly up to 4 weeks
     -- (r.day = the last local day the app reported activity)
     and r.day is not null
     and (l.local_day - r.day) in (2, 4, 7, 14, 21, 28)
     and (r.last_email_day is null or r.last_email_day < l.local_day)
$$;

-- The job calls this after an email was accepted by Resend. p_day is the
-- learner's local date (local_day from due_reminders); null means "today, where they are".
create or replace function public.mark_reminded(p_user uuid, p_day date)
returns void
language sql security definer set search_path = public as $$
  update public.reminder_prefs
     set last_email_day = coalesce(p_day, public._rem_local_day(tz))
   where user_id = p_user
$$;

-- The unsubscribe link in every email. Returns true when the token is known.
create or replace function public.unsubscribe_by_token(p_token uuid)
returns boolean
language plpgsql security definer set search_path = public as $$
begin
  update public.reminder_prefs set email_opt_in = false, updated_at = now()
   where unsub_token = p_token;
  return found;
end $$;

-- ── who may call what ────────────────────────────────────────────────────────
-- Supabase grants EXECUTE on new functions to anon, authenticated and
-- service_role by default, so each role is revoked explicitly.

revoke all on function public._rem_uid()                                                    from public, anon, authenticated;
revoke all on function public._rem_tz(text)                                                 from public, anon, authenticated;
revoke all on function public._rem_local_day(text)                                          from public, anon, authenticated;
revoke all on function public.set_reminder_prefs(boolean, integer, integer, text, integer, text) from public, anon;
revoke all on function public.report_minutes(date, integer)                                 from public, anon;
revoke all on function public.due_reminders()                                               from public, anon, authenticated;
revoke all on function public.mark_reminded(uuid, date)                                     from public, anon, authenticated;
revoke all on function public.unsubscribe_by_token(uuid)                                    from public, anon, authenticated;

grant execute on function public.set_reminder_prefs(boolean, integer, integer, text, integer, text) to authenticated;
grant execute on function public.report_minutes(date, integer)                                 to authenticated;
grant execute on function public.due_reminders()                                               to service_role;
grant execute on function public.mark_reminded(uuid, date)                                     to service_role;
grant execute on function public.unsubscribe_by_token(uuid)                                    to service_role;


-- ═════════════════════════════════════════════════════════════════════════════
-- OPTIONAL: run the email job every hour (pg_cron + pg_net).
--
-- Do this only AFTER the daily-reminders function is deployed and its
-- CRON_SECRET is set (see supabase/REMINDERS_SETUP.md, steps 6 to 8).
--
-- 1. Remove the "-- " at the start of the lines in PART A and PART B below.
-- 2. In PART A, replace PASTE_YOUR_CRON_SECRET_HERE with the same secret you
--    gave the function (npx supabase secrets set CRON_SECRET=...).
-- 3. Select PART A and PART B only and Run them. Run PART A a single time: the
--    secrets are saved in Supabase Vault (encrypted), not in this file.
--    Running PART B again just updates the job (same name).
--
-- The job runs at 2 minutes past every hour. Each run, the function emails the
-- learners whose reminder hour it is right now in their own time zone.
-- To see recent runs:  select * from cron.job_run_details order by start_time desc limit 20;
-- To pause the job:    select cron.unschedule('lisaany-daily-reminders');
-- ═════════════════════════════════════════════════════════════════════════════

-- PART A: extensions + secrets (run once)
-- create extension if not exists pg_cron;
-- create extension if not exists pg_net;
-- select vault.create_secret('https://cfaxrzfqvoalwznkhwnx.supabase.co', 'lisaany_project_url');
-- select vault.create_secret('PASTE_YOUR_CRON_SECRET_HERE', 'lisaany_cron_secret');

-- PART B: the hourly job
-- select cron.schedule(
--   'lisaany-daily-reminders',
--   '2 * * * *',
--   $$
--   select net.http_post(
--     url := (select decrypted_secret from vault.decrypted_secrets where name = 'lisaany_project_url') || '/functions/v1/daily-reminders',
--     headers := jsonb_build_object(
--       'Content-Type', 'application/json',
--       'Authorization', 'Bearer ' || (select decrypted_secret from vault.decrypted_secrets where name = 'lisaany_cron_secret')
--     ),
--     body := jsonb_build_object('time', now()),
--     timeout_milliseconds := 150000
--   ) as request_id;
--   $$
-- );
