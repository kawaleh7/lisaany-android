-- Lisaany: email reminders once a month (instead of after 2, 4, 7, 14, 21, 28 days).
-- Run once in Supabase → SQL Editor. Safe to run again.
-- Only the query that picks who gets an email changes; nothing else.

drop function if exists public.due_reminders();
create function public.due_reminders()
returns table (user_id uuid, email text, lang text, goal_min integer, minutes_done integer,
               unsub_token uuid, local_day date, days_away integer)
language sql security definer set search_path = public, auth stable as $$
  select r.user_id, u.email::text, r.lang, r.goal_min,
         case when r.day = l.local_day then r.day_secs / 60 else 0 end,
         r.unsub_token, l.local_day, (l.local_day - r.day)::int
    from public.reminder_prefs r
    join auth.users u on u.id = r.user_id
    cross join lateral (select now() at time zone r.tz as ts) t  -- tz was checked when saved
    cross join lateral (select t.ts::date as local_day) l
   where r.email_opt_in
     and u.email is not null and btrim(u.email) <> ''
     and extract(hour from t.ts)::int = r.remind_hour
     -- only learners who have been away: one email a month — after 30, 60, 90,
     -- 120, 150 and 180 days, then nothing more
     -- (r.day = the last local day the app reported activity)
     and r.day is not null
     and (l.local_day - r.day) in (30, 60, 90, 120, 150, 180)
     and (r.last_email_day is null or r.last_email_day < l.local_day)
$$;

revoke all on function public.due_reminders() from public, anon, authenticated;
grant execute on function public.due_reminders() to service_role;
