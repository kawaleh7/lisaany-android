-- ============================================================================
-- Lisaany — App Store / Google Play purchases in the `subscriptions` table
-- ============================================================================
--
-- Run once in the Supabase SQL editor (Dashboard → SQL Editor → New query →
-- paste → Run). Every statement is idempotent: running it twice is harmless.
--
-- Why: lisaany.com and the lesson engine decide "is this learner Premium?"
-- from ONE table, `public.subscriptions`, which the Stripe webhook fills for
-- web subscribers. Purchases made in the app go through the App Store or
-- Google Play instead and never touch Stripe. The RevenueCat webhook
-- (docs/revenuecat-webhook.md) writes those purchases into the same table so
-- a learner who pays on the phone is Premium on the website too.
--
-- What the webhook writes (one row per user, upserted on user_id):
--   user_id            = the Supabase auth user id (RevenueCat app_user_id)
--   plan               = 'premium'
--   status             = 'active'   while the subscription runs (also after the
--                                   learner turns auto-renew off — they have
--                                   paid up to current_period_end)
--                        'expired'  once the store reports EXPIRATION
--                        'canceled' only when a cancellation arrives with an
--                                   expiration already in the past
--   current_period_end = the store's expiration date
--   source             = 'apple' | 'google'      (NEW column, below)
--   store_app_user_id  = RevenueCat app_user_id  (NEW column, below)
--   store_product_id   = 'lisaany_premium_monthly' | 'lisaany_premium_yearly'
--                                                 (NEW column, below)
--   updated_at         = now()                    (NEW column, below)
--
-- The website treats status in ('active','trialing') with plan in
-- ('premium','with_tutor','self_paced') as Premium, so nothing on the website
-- has to change.
-- ============================================================================


-- ----------------------------------------------------------------------------
-- 1. New columns (each guarded with IF NOT EXISTS)
-- ----------------------------------------------------------------------------
-- Where the subscription was bought. Existing rows were all created by the
-- Stripe webhook, hence the default.
alter table public.subscriptions add column if not exists source text default 'stripe';

-- RevenueCat's app_user_id for the purchase. Normally identical to user_id;
-- kept separately so a support question can be traced in the RevenueCat
-- dashboard without guessing.
alter table public.subscriptions add column if not exists store_app_user_id text;

-- The store product that is active (lisaany_premium_monthly / _yearly).
alter table public.subscriptions add column if not exists store_product_id text;

-- When the row was last written by any webhook.
alter table public.subscriptions add column if not exists updated_at timestamptz default now();

comment on column public.subscriptions.source is
  'Who created this subscription: stripe (website), apple (App Store via RevenueCat) or google (Google Play via RevenueCat).';
comment on column public.subscriptions.store_app_user_id is
  'RevenueCat app_user_id that made the store purchase (normally equal to user_id).';
comment on column public.subscriptions.store_product_id is
  'Store product id of the active subscription, e.g. lisaany_premium_yearly.';
comment on column public.subscriptions.updated_at is
  'Last time a webhook (Stripe or RevenueCat) wrote this row.';


-- ----------------------------------------------------------------------------
-- 2. Check: is Row Level Security on, and can users read only their own row?
-- ----------------------------------------------------------------------------
-- The app reads `subscriptions` by user_id with the publishable key, and the
-- lesson page UPSERTS `learner_progress` from the client. Both tables must have
-- RLS enabled, and every policy must be scoped to auth.uid().
--
-- Run these two SELECTs and read the results before going further.

-- Expected: two rows, both with rowsecurity = true.
select tablename, rowsecurity
from pg_tables
where schemaname = 'public' and tablename in ('subscriptions', 'learner_progress');

-- Expected shape (names will differ):
--   subscriptions     | <policy name> | SELECT              | (auth.uid() = user_id)
--   learner_progress  | <policy name> | SELECT/INSERT/UPDATE| (auth.uid() = user_id)   [+ with_check for INSERT/UPDATE]
-- There must be NO policy on `subscriptions` that lets `authenticated` INSERT
-- or UPDATE — only the webhooks (service role, which bypasses RLS) write it.
select tablename, policyname, cmd, roles, qual, with_check
from pg_policies
where schemaname = 'public' and tablename in ('subscriptions', 'learner_progress')
order by tablename, policyname;

-- If rowsecurity is false for either table, turn it on (safe to re-run):
-- alter table public.subscriptions   enable row level security;
-- alter table public.learner_progress enable row level security;

-- If `subscriptions` has NO read policy at all, add this one. Do NOT run it if
-- a read-own-row policy already exists (a second policy with the same name
-- errors, and a second policy with a different name is just clutter):
-- create policy "subscriptions: read own row"
--   on public.subscriptions
--   for select
--   to authenticated
--   using (auth.uid() = user_id);

-- Same for `learner_progress` (the lesson page needs select + insert + update
-- on the learner's own row only). Only if missing:
-- create policy "learner_progress: read own row"
--   on public.learner_progress for select to authenticated
--   using (auth.uid() = user_id);
-- create policy "learner_progress: insert own row"
--   on public.learner_progress for insert to authenticated
--   with check (auth.uid() = user_id);
-- create policy "learner_progress: update own row"
--   on public.learner_progress for update to authenticated
--   using (auth.uid() = user_id) with check (auth.uid() = user_id);


-- ----------------------------------------------------------------------------
-- 3. Check: is there at most one row per user?
-- ----------------------------------------------------------------------------
-- The website reads the row with .maybeSingle() (which fails on duplicates)
-- and the webhook upserts on user_id, so each user must have ONE row. Run
-- this first. It must return zero rows.
select user_id, count(*)
from public.subscriptions
group by 1
having count(*) > 1;

-- If it returns anything, the table already holds several rows for one user
-- (for example an old cancelled Stripe subscription next to a new one). Step 4
-- will then FAIL with "could not create unique index". Before step 4, keep the
-- newest row per user and delete the rest — for instance (review the SELECT
-- version before running the DELETE):
--
--   select id, user_id, status, plan, current_period_end
--   from public.subscriptions s
--   where id not in (
--     select distinct on (user_id) id
--     from public.subscriptions
--     order by user_id, current_period_end desc nulls last
--   );
--
--   delete from public.subscriptions
--   where id not in (
--     select distinct on (user_id) id
--     from public.subscriptions
--     order by user_id, current_period_end desc nulls last
--   );
--
-- (If your table has no `id` column, use `ctid` in place of `id`.)


-- ----------------------------------------------------------------------------
-- 4. OPTIONAL — only after step 3 returned zero rows:
--    one row per user, so the webhook's upsert has a conflict target
-- ----------------------------------------------------------------------------
-- The RevenueCat webhook calls the REST API with `on_conflict=user_id`, which
-- needs a unique index or constraint on user_id. If the Stripe webhook already
-- created one under another name, this statement is still harmless (a second
-- unique index on the same column is redundant but not wrong; drop this one
-- later if you like).
create unique index if not exists subscriptions_user_id_key
  on public.subscriptions (user_id);


-- ----------------------------------------------------------------------------
-- 5. Verify
-- ----------------------------------------------------------------------------
-- Columns present?
select column_name, data_type, column_default
from information_schema.columns
where table_schema = 'public' and table_name = 'subscriptions'
order by ordinal_position;

-- Unique index present?
select indexname, indexdef
from pg_indexes
where schemaname = 'public' and tablename = 'subscriptions';

-- After the first sandbox purchase (see docs/revenuecat-webhook.md, test
-- checklist), the row should look like:
--   select user_id, plan, status, source, store_product_id, current_period_end, updated_at
--   from public.subscriptions
--   where source in ('apple', 'google')
--   order by updated_at desc;
