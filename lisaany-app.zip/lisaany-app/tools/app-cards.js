/* ═══ Lisaany app — Vocabulary, swipe cards and sequential quiz ═══
   App-only replacements for three website views (same data, same finish rules):
   • mkVocab — first a grid of every word (tap to hear, colour-coded by gender
     when the data has it), then a swipe deck: right / ✓ = know it (card leaves),
     left / ✕ = still learning (card goes to the back). Empty deck = block done.
   • mkSwipe — the same deck for sentences; the pronoun is highlighted and the
     meaning shows on tap.
   • mkSeqQuiz — pick an answer (it drops into the blank), press Check, and a
     feedback panel slides up with the explanation.
   Built into the page by tools/build-lesson-page.py; reuses .qx styles from
   app-check.css for the top bar and the feedback panel. */
(function(){
  // lets :active (the tap pop) fire on iOS web views
  try { document.addEventListener('touchstart', function(){}, { passive: true }); } catch (e) {}
  if (typeof mkVocab !== 'function' || typeof mkSwipe !== 'function' || typeof mkSeqQuiz !== 'function') return;

  const ICON = {
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    vol: '<path d="M4 9.5h3.5L12 6v12l-4.5-3.5H4z"/><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7"/>',
    x: '<path d="M7 7l10 10M17 7L7 17"/>',
    fwd: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    tap: '<path d="M9 11V5.5a1.5 1.5 0 0 1 3 0V11m0-1.5a1.5 1.5 0 0 1 3 0V11m0-.5a1.5 1.5 0 0 1 3 0v4.5a6 6 0 0 1-6 6h-.5a6 6 0 0 1-5-2.7L4 15.5a1.5 1.5 0 0 1 2.4-1.8L9 16"/>',
  };
  const svg = (n, s, w) => '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="' + (w || 2) +
    '" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ICON[n] + '</svg>';
  function node(tag, cls, html){ const n = document.createElement(tag); if (cls) n.className = cls; if (html != null) n.innerHTML = html; return n; }
  function txt(tag, cls, text){ const n = node(tag, cls); n.textContent = text; return n; }
  function btn(cls, html, label, fn){
    const b = node('button', cls, html); b.type = 'button';
    if (label) b.setAttribute('aria-label', label);
    b.addEventListener('click', (e) => { e.stopPropagation(); fn(e); });
    return b;
  }
  const say = (t) => { try { stopAudio(); } catch (e) {} try { speak(t); } catch (e) {} };
  const quiet = () => { try { stopAudio(); } catch (e) {} };
  const AR = /[\u0600-\u06FF]/;
  // "as-salaamu alaykum (peace be upon you)" → "peace be upon you" (no transliteration)
  function meaning(en){
    const m = String(en || '').match(/^([a-z][a-z\-' ]*)\s*\((.+)\)$/);
    return m ? m[2] : String(en || '');
  }
  // "هِيَ (hiya) = She" → "هِيَ = She"
  const noRoman = (s) => String(s || '').replace(/\s*\([a-zāīūḥṣḍṭẓʿʾ\-' ]+\)/g, '');
  // mixed Arabic/English line: isolate each Arabic run so the order reads left→right
  function bidi(tag, cls, text){
    const n = node(tag, cls);
    String(text).split(/([\u0600-\u06FF][\u0600-\u06FF\u064B-\u0652\s]*[\u0600-\u06FF\u064B-\u0652])/).forEach((part) => {
      if (!part) return;
      if (AR.test(part)) { const b = document.createElement('bdi'); b.className = 'cd-bidi'; b.dir = 'rtl'; b.textContent = part; n.appendChild(b); }
      else n.appendChild(document.createTextNode(part));
    });
    n.dir = 'ltr';
    return n;
  }
  const CAT = { masculine: 'm', feminine: 'f' };
  const catCls = (c) => 'cd-c-' + (CAT[c] || 'n');

  function layer(extra){
    document.body.classList.add('dl-active');
    const root = node('div', 'qx cd' + (extra ? ' ' + extra : ''));
    const shell = node('div', 'qx-shell'); root.appendChild(shell);
    return { root, shell };
  }
  function topBar(shell, done, total, onClose){
    const top = node('div', 'qx-top');
    top.appendChild(btn('qx-close', svg('close', 16, 2.2), 'Close', onClose));
    if (total <= 12) {
      const s = node('div', 'qx-segs');
      for (let i = 0; i < total; i++) s.appendChild(node('div', 'qx-seg' + (i < done ? ' cur' : '')));
      top.appendChild(s);
    } else {
      const t = node('div', 'cd-track'); const f = node('div', 'cd-fill');
      f.style.width = Math.round(100 * done / Math.max(1, total)) + '%'; t.appendChild(f); top.appendChild(t);
    }
    top.appendChild(txt('div', 'qx-count', done + '/' + total));
    shell.appendChild(top);
  }
  function arabicSentence(ar, hi){
    const d = node('div', 'cd-ar'); d.dir = 'rtl';
    String(ar).split(' ').forEach((w, i) => {
      if (i) d.appendChild(document.createTextNode(' '));
      const s = txt('span', w === hi ? 'cd-hi' : '', w); d.appendChild(s);
    });
    return d;
  }

  // ── Swipe deck shared by vocab + sentences ────────────────────────────
  // opts: { key, items, eyebrow, front(item, flipped) → node, sound(item), onClose, onDone }
  function deck(o){
    const st = S[o.key] = S[o.key] || {};
    if (!Array.isArray(st.queue)) { st.queue = o.items.map((_, i) => i); st.known = 0; st.flip = false; }
    const total = o.items.length;
    if (!st.queue.length) { setTimeout(o.onDone, 60); return div('stage'); }
    const curI = st.queue[0], cur = o.items[curI];
    try { bumpPos(st.known + 1, total); } catch (e) {}
    const { root, shell } = layer('cd-deck');
    topBar(shell, st.known, total, o.onClose);
    shell.appendChild(txt('div', 'qx-eyebrow', o.eyebrow));

    const stack = node('div', 'cd-stack');
    if (st.queue.length > 2) stack.appendChild(node('div', 'cd-ghost g2'));
    if (st.queue.length > 1) stack.appendChild(node('div', 'cd-ghost g1'));
    const card = node('div', 'cd-card' + (st.flip ? ' flipped' : ''));
    card.setAttribute('role', 'button'); card.setAttribute('aria-label', st.flip ? 'Card' : 'Tap to reveal');
    card.appendChild(o.front(cur, st.flip));
    const lblL = txt('div', 'cd-stamp l', 'STILL LEARNING'), lblR = txt('div', 'cd-stamp r', 'KNOW IT');
    card.appendChild(lblL); card.appendChild(lblR);
    stack.appendChild(card); shell.appendChild(stack);

    let busy = false;
    const decide = (know) => {
      if (busy) return; busy = true; quiet();
      card.style.transition = ''; card.style.transform = '';
      card.classList.add(know ? 'fly-r' : 'fly-l');
      setTimeout(() => {
        st.queue.shift(); st.flip = false;
        if (know) st.known++; else st.queue.push(curI);
        if (!st.queue.length) { S[o.key] = null; o.onDone(); } else render();
      }, 240);
    };
    const flip = () => { if (!st.flip) { st.flip = true; o.sound && say(o.sound(cur)); render(); } else if (o.sound) say(o.sound(cur)); };

    // drag to swipe; a short tap flips
    let x0 = null, y0 = 0, dx = 0;
    card.addEventListener('pointerdown', (e) => { if (busy) return; x0 = e.clientX; y0 = e.clientY; dx = 0; card.style.transition = 'none'; try { card.setPointerCapture(e.pointerId); } catch (_) {} });
    card.addEventListener('pointermove', (e) => {
      if (x0 == null) return; dx = e.clientX - x0;
      card.style.transform = 'translateX(' + dx + 'px) rotate(' + (dx / 18) + 'deg)';
      lblR.style.opacity = Math.max(0, Math.min(1, dx / 90)); lblL.style.opacity = Math.max(0, Math.min(1, -dx / 90));
    });
    const end = (e) => {
      if (x0 == null) return;
      const moved = Math.abs(dx) > 6 || Math.abs((e.clientY || y0) - y0) > 10; x0 = null;
      card.style.transition = '';
      if (Math.abs(dx) > 90) { decide(dx > 0); return; }
      card.style.transform = ''; lblL.style.opacity = lblR.style.opacity = 0;
      if (!moved) flip();
    };
    card.addEventListener('pointerup', end); card.addEventListener('pointercancel', end);
    card.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') flip(); });
    card.tabIndex = 0;

    const row = node('div', 'cd-acts');
    row.appendChild(btn('cd-round no', svg('x', 26, 2.4) + '<span>Still learning</span>', 'Still learning', () => decide(false)));
    row.appendChild(btn('cd-round snd', svg('vol', 20, 2), 'Play', () => o.sound && say(o.sound(cur))));
    row.appendChild(btn('cd-round yes', svg('check', 26, 2.4) + '<span>Know it</span>', 'Know it', () => decide(true)));
    shell.appendChild(row);
    shell.appendChild(txt('div', 'cd-hint', st.flip ? 'Swipe right if you know it, left to see it again' : 'Tap the card to reveal'));
    return root;
  }

  // ── Vocabulary ─────────────────────────────────────────────────────────
  function vocabWords(blk){
    return ((blk.data && blk.data.words) || []).flatMap((e) => {
      const a = String(e.ar || '').split(' / ').map((s) => s.trim()).filter(Boolean);
      const b = String(e.en || '').split(' / ').map((s) => s.trim()).filter(Boolean);
      if (a.length > 1 && a.length === b.length) return a.map((ar, i) => Object.assign({}, e, { ar, en: b[i] }));
      return [e];
    });
  }
  mkVocab = function(blk){
    const words = vocabWords(blk);
    if (!words.length) { setTimeout(finishBlock, 80); return div('stage'); }
    const close = () => { quiet(); S.vPhase = null; S.cdVocab = null; S.view = 'blocks'; render(); };
    const finish = () => { quiet(); S.vPhase = null; S.cdVocab = null; S.vIdx = 0; finishBlock(); };
    const title = (blk.data && blk.data.title) || blk.title || 'Vocabulary';

    if (false && S.vPhase !== 'cards') {  // word grid retired: vocab opens straight on the card deck
      const { root, shell } = layer('cd-words');
      topBar(shell, 0, words.length, close);
      shell.appendChild(txt('div', 'qx-eyebrow', 'VOCABULARY'));
      shell.appendChild(txt('div', 'cd-title', title));
      shell.appendChild(txt('div', 'cd-sub', 'Tap a word to hear it'));
      const grid = node('div', 'cd-grid');
      words.forEach((w, i) => {
        const t = node('div', 'cd-tile ' + catCls(w.cat));
        t.setAttribute('role', 'button'); t.tabIndex = 0;
        const tp = node('div', 'cd-tile-top');
        tp.appendChild(w.cat ? txt('span', 'cd-tile-cat', w.cat) : node('span')); tp.appendChild(node('span', 'cd-tile-spk', svg('vol', 14, 2)));
        t.appendChild(tp);
        const a = txt('div', 'cd-tile-ar', w.ar); a.dir = 'rtl'; t.appendChild(a);
        t.appendChild(txt('div', 'cd-tile-en', meaning(w.en)));
        t.addEventListener('click', () => {
          grid.querySelectorAll('.cd-tile.on').forEach((n) => n.classList.remove('on'));
          t.classList.add('on'); say(w.ar);
        });
        grid.appendChild(t);
      });
      shell.appendChild(grid);
      shell.appendChild(node('div', 'qx-grow'));
      const acts = node('div', 'cd-foot');
      acts.appendChild(btn('qx-cta', 'Start practising ' + svg('fwd', 18, 2.2), null, () => { quiet(); S.vPhase = 'cards'; S.cdVocab = null; render(); }));
      acts.appendChild(btn('qx-link', 'I know these — skip', null, finish));
      shell.appendChild(acts);
      return root;
    }
    return deck({
      key: 'cdVocab', items: words, eyebrow: 'VOCABULARY · ' + String(title).toUpperCase(),
      sound: (w) => w.ar, onClose: close, onDone: finish,
      front: (w, flipped) => {
        const f = node('div', 'cd-face');
        const a = txt('div', 'cd-word', w.ar); a.dir = 'rtl'; if (String(w.ar).length > 12) a.classList.add('long'); f.appendChild(a);
        if (flipped) {
          f.appendChild(node('div', 'cd-rule'));
          f.appendChild(txt('div', 'cd-en', meaning(w.en)));
          if (w.cat) f.appendChild(txt('div', 'cd-tag ' + catCls(w.cat), String(w.cat).toUpperCase()));
        } else f.appendChild(node('div', 'cd-tap', svg('tap', 15, 1.8) + '<span>Tap to reveal</span>'));
        return f;
      },
    });
  };

  // ── Sentence swipe ─────────────────────────────────────────────────────
  mkSwipe = function(blk){
    const items = (blk.data && blk.data.sentences) || [];
    if (!items.length) { setTimeout(finishBlock, 80); return div('stage'); }
    const title = (blk.data && blk.data.title) || blk.title || 'Practice';
    return deck({
      key: 'cdSwipe', items, eyebrow: String(title).toUpperCase(),
      sound: (s) => s.ar,
      onClose: () => { quiet(); S.cdSwipe = null; S.view = 'blocks'; render(); },
      onDone: () => { quiet(); S.cdSwipe = null; finishBlock(); },
      front: (s, flipped) => {
        const f = node('div', 'cd-face');
        const a = arabicSentence(s.ar, s.pronoun); if (String(s.ar).length > 18) a.classList.add('long'); f.appendChild(a);
        if (flipped) {
          f.appendChild(node('div', 'cd-rule'));
          f.appendChild(txt('div', 'cd-en', meaning(s.en)));
          if (s.pronoun && s.pronoun_en) {
            const p = node('div', 'cd-pair'); const pa = txt('span', 'cd-pair-ar', s.pronoun); pa.dir = 'rtl';
            p.appendChild(pa); p.appendChild(txt('span', '', '= ' + s.pronoun_en)); f.appendChild(p);
          }
        } else f.appendChild(node('div', 'cd-tap', svg('tap', 15, 1.8) + '<span>Tap to reveal</span>'));
        return f;
      },
    });
  };

  // ── Sequential quiz ────────────────────────────────────────────────────
  mkSeqQuiz = function(blk){
    const qs = (blk.data && blk.data.questions) || [];
    if (!qs.length) { setTimeout(finishBlock, 80); return div('stage'); }
    if (typeof S.sqIdx !== 'number') { S.sqIdx = 0; S.sqChosen = null; S.sqLocked = false; S.sqScore = 0; S.sqWrong = 0; }
    const total = qs.length, q = qs[S.sqIdx];
    try { bumpPos(S.sqIdx + 1, total); } catch (e) {}
    const locked = !!S.sqLocked, chosen = S.sqChosen, right = chosen === q.correct;
    const { root, shell } = layer('cd-quiz');
    topBar(shell, S.sqIdx, total, () => { quiet(); S.sqIdx = 0; S.sqChosen = null; S.sqLocked = false; S.view = 'blocks'; render(); });
    const blank = q.promptType === 'ar' && /_{2,}/.test(q.prompt || '');
    shell.appendChild(txt('div', 'qx-eyebrow', blank ? 'PRACTICE · FILL THE BLANK' : q.promptType === 'en' ? 'PRACTICE · SAY IT IN ARABIC' : 'PRACTICE'));

    const card = node('div', 'cd-qcard');
    const cue = String(q.question || '').replace(/\s*(Choose|Pick|Select)[^.?!]*[:.]?\s*$/i, '').trim();
    if (q.promptType === 'en') {
      card.appendChild(txt('div', 'cd-q-cap', 'How do you say'));
      card.appendChild(txt('div', 'cd-q-en', q.prompt));
    } else {
      if (cue) card.appendChild(txt('div', 'cd-q-cap', cue.toUpperCase()));
      const a = node('div', 'cd-q-ar'); a.dir = 'rtl';
      String(q.prompt || '').split(/(_{2,})/).forEach((part) => {
        if (/^_{2,}$/.test(part)) {
          const slot = txt('span', 'cd-slot' + (chosen ? (locked ? (right ? ' good' : ' bad') : ' fill') : ''), chosen || '\u00a0');
          a.appendChild(slot);
        } else if (part.trim()) a.appendChild(txt('span', '', part.trim()));
      });
      card.appendChild(a);
    }
    card.addEventListener('click', () => say(blank ? String(q.prompt).replace(/_{2,}/, S.sqChosen || '') : (q.promptType === 'en' ? '' : q.prompt)));
    shell.appendChild(card);

    const short = q.options.every((o) => String(o).replace(/[\u064B-\u0652]/g, '').length <= 6);
    shell.appendChild(txt('div', 'cd-q-ask', blank ? 'Pick the word that fits' : 'Pick the answer'));
    const opts = node('div', short ? 'cd-chips' : 'cd-opts'); if (short) opts.dir = 'rtl';
    q.options.forEach((o) => {
      let cls = 'cd-opt';
      if (locked) cls += o === q.correct ? ' right' : o === chosen ? ' wrong' : ' dim';
      else if (o === chosen) cls += ' sel';
      const b = btn(cls, null, null, () => { if (S.sqLocked) return; S.sqChosen = o; say(o); render(); });
      b.textContent = o; if (AR.test(o)) b.classList.add('ar');
      opts.appendChild(b);
    });
    shell.appendChild(opts);
    shell.appendChild(node('div', 'qx-grow'));
    const chk = btn('qx-cta', 'Check', null, () => {
      if (S.sqLocked || !S.sqChosen) return;
      S.sqLocked = true;
      if (S.sqChosen === q.correct) { S.sqScore++; try { if (window.Lisaany) Lisaany.celebrate(); } catch (e) {} }
      else S.sqWrong++;
      const spoken = blank ? String(q.prompt).replace(/_{2,}/, q.correct) : q.correct;
      if (S.sqChosen === q.correct) window.lsSayAfterChime(spoken); else say(spoken);
      render();
    });
    if (!chosen || locked) chk.disabled = true;
    shell.appendChild(chk);

    if (locked) {
      const sh = node('div', 'qx-sheet ' + (right ? 'good' : 'bad'));
      sh.appendChild(node('div', 'qx-sheet-head', '<div class="qx-sheet-ic">' + svg(right ? 'check' : 'x', 16, 2.6) + '</div><div class="qx-sheet-title">' + (right ? 'Correct!' : 'Not quite') + '</div>'));
      const m = node('div', 'qx-sheet-mean');
      if (!right) { const a = txt('span', 'qx-sheet-ar', q.correct); a.dir = 'rtl'; m.appendChild(a); }
      if (q.explain) m.appendChild(bidi('span', 'qx-sheet-en', noRoman(q.explain)));
      sh.appendChild(m);
      const last = S.sqIdx >= total - 1;
      sh.appendChild(btn('qx-sheet-btn', right ? 'Continue' : 'Got it', null, () => {
        quiet();
        if (!last) { S.sqIdx++; S.sqChosen = null; S.sqLocked = false; render(); }
        else { S.sqIdx = 0; S.sqScore = 0; S.sqWrong = 0; S.sqChosen = null; S.sqLocked = false; finishBlock(); }
      }));
      root.appendChild(sh);
      requestAnimationFrame(() => requestAnimationFrame(() => sh.classList.add('in')));
    }
    return root;
  };

  // fresh deck every time a block is entered
  if (typeof resetBS === 'function') {
    const _reset = resetBS;
    resetBS = function(){ S.vPhase = null; S.cdVocab = null; S.cdSwipe = null; return _reset.apply(this, arguments); };
  }
})();
