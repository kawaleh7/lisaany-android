/* ═══ Lisaany app — Quick check + "what's next" result ═══
   App-only replacements for three website views, same rules underneath:
   • mkQuickCheck — a timer ring that simply runs out (no penalty, no restart),
     a 2×2 answer grid, and a feedback panel that slides up after each answer
     ("Correct!" / "Not quite" + the meaning) with a Continue button.
   • showQuickCheckResult — score ring, XP and streak in one line, the unit's
     progress, and the next block front and centre. XP rules are the website's.
   • mkComplete — the same next-step screen for blocks without a quick check.
   Built into the page by tools/build-lesson-page.py (before the bridge, which
   wraps showQuickCheckResult to report the view). */
(function(){
  if (typeof mkQuickCheck !== 'function' || typeof showQuickCheckResult !== 'function') return;

  // ── Correct-answer chime (louder than the website's, and never drowned by speech) ──
  let ctx = null;
  window.lsChime = function(){
    try {
      ctx = ctx || new (window.AudioContext || window.webkitAudioContext)();
      if (ctx.state === 'suspended') ctx.resume();
      const now = ctx.currentTime + 0.01;
      [[784, 0], [1047, 0.1], [1319, 0.2]].forEach(([f, dt]) => {
        const o = ctx.createOscillator(), g = ctx.createGain();
        o.type = 'sine'; o.frequency.value = f;
        const t = now + dt;
        g.gain.setValueAtTime(0, t);
        g.gain.linearRampToValueAtTime(0.32, t + 0.02);
        g.gain.exponentialRampToValueAtTime(0.001, t + 0.5);
        o.connect(g); g.connect(ctx.destination); o.start(t); o.stop(t + 0.55);
      });
    } catch (e) {}
  };
  // speak a word just after the chime has sounded
  window.lsSayAfterChime = function(t){ setTimeout(() => { try { speak(t); } catch (e) {} }, 520); };
  if (window.Lisaany && typeof Lisaany.celebrate === 'function' && !Lisaany._lsWrapped) {
    const orig = Lisaany.celebrate;
    Lisaany.celebrate = function(o){ window.lsChime(); return orig(Object.assign({}, o || {}, { quiet: true })); };
    Lisaany._lsWrapped = true;
  }

  const LIMIT = 10000;
  const TYPE_LABEL = { dialogue:'Conversation', vocab:'Vocabulary', grammar:'Grammar', cloze:'Listening dictation',
    clutter:'Sentence builder', quiz:'Practice drill', fill:'Sentence fill', seqquiz:'Quiz', possessive:'Suffix tap',
    swipe:'Swipe drill', conjugation:'Conjugation', video:'Video', choose:'Choose' };
  const ICON = {
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    bolt: '<path d="M13 3L5 13.5h6L10 21l8-10.5h-6z"/>',
    vol: '<path d="M4 9.5h3.5L12 6v12l-4.5-3.5H4z"/><path d="M15.5 9a4 4 0 0 1 0 6"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7"/>',
    x: '<path d="M7 7l10 10M17 7L7 17"/>',
    star: '<path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8-5.2-2.8-5.2 2.8 1-5.8-4.3-4.1 5.9-.9z"/>',
    fire: '<path d="M12 21c-4 0-6.5-2.6-6.5-6 0-3.5 3-5.5 3.5-9 2 1.5 3 3.5 3 5 1-1 1.5-2 1.5-3.5 2.5 2 4.5 4.8 4.5 7.5 0 3.4-2.5 6-6 6z"/>',
    fwd: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    replay: '<path d="M4 12a8 8 0 1 0 2.4-5.7M4 4.5v4h4"/>',
  };
  const svg = (n, s, w) => '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="' + (w || 2) +
    '" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ICON[n] + '</svg>';
  function node(tag, cls, html){ const n = document.createElement(tag); if (cls) n.className = cls; if (html != null) n.innerHTML = html; return n; }
  function txt(tag, cls, text){ const n = node(tag, cls); n.textContent = text; return n; }
  function btn(cls, html, label, fn){
    const b = node('button', cls, html); b.type = 'button';
    if (label) b.setAttribute('aria-label', label);
    b.addEventListener('click', (e) => { e.stopPropagation(); fn(e); });
    return b;
  }
  function ring(size, stroke, frac, cls, inner){
    const r = (size - stroke) / 2, c = 2 * Math.PI * r;
    const w = node('div', 'qx-ring ' + (cls || ''));
    w.style.width = w.style.height = size + 'px';
    w.innerHTML = '<svg width="' + size + '" height="' + size + '"><circle cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r +
      '" class="qx-ring-track" stroke-width="' + stroke + '"/><circle cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r +
      '" class="qx-ring-fill" stroke-width="' + stroke + '" stroke-dasharray="' + c.toFixed(1) + '" stroke-dashoffset="' + (c * (1 - frac)).toFixed(1) + '"/></svg>';
    const mid = node('div', 'qx-ring-mid'); if (inner) mid.appendChild(inner); w.appendChild(mid);
    w._set = (f) => { w.querySelector('.qx-ring-fill').setAttribute('stroke-dashoffset', (c * (1 - Math.max(0, Math.min(1, f)))).toFixed(1)); };
    return w;
  }
  function layer(){
    document.body.classList.add('dl-active');
    const root = node('div', 'qx');
    const shell = node('div', 'qx-shell'); root.appendChild(shell);
    return { root, shell };
  }
  function segs(n, lit, cur, cls){
    const s = node('div', cls || 'qx-segs');
    for (let i = 0; i < n; i++) s.appendChild(node('div', 'qx-seg' + (i < lit ? ' done' : i === cur ? ' cur' : '')));
    return s;
  }

  // ── Quick check question ──────────────────────────────────────────────
  mkQuickCheck = function(){
    const qs = S.qcQuestions || [];
    if (!qs.length) { S.view = 'complete'; render(); return div('stage'); }
    const q = qs[S.qcIdx];
    const total = qs.length;
    const locked = !!S.qcLocked;
    const arText = (q.ar || '').split(' — ')[0];
    const { root, shell } = layer();

    const top = node('div', 'qx-top');
    top.appendChild(btn('qx-close', svg('close', 16, 2.2), 'Close', () => { clearQzTimer(); S.view = 'blocks'; render(); }));
    top.appendChild(segs(total, S.qcIdx, S.qcIdx));
    top.appendChild(txt('div', 'qx-count', (S.qcIdx + 1) + '/' + total));
    shell.appendChild(top);
    shell.appendChild(txt('div', 'qx-eyebrow', 'QUICK CHECK · LIGHTNING'));
    shell.appendChild(node('div', 'qx-note', svg('bolt', 14) + '<span>Answer before the ring runs out · no penalty</span>'));

    // timer ring
    if (!S.qzDeadline || S.qzForIdx !== 'qc' + S.qcIdx) { S.qzDeadline = Date.now() + LIMIT; S.qzForIdx = 'qc' + S.qcIdx; }
    const left0 = Math.max(0, S.qzDeadline - Date.now());
    const secEl = node('div', 'qx-sec');
    const num = txt('span', 'qx-sec-n', String(Math.ceil(left0 / 1000)));
    const unit = txt('span', 'qx-sec-u', 'SEC');
    secEl.appendChild(num); secEl.appendChild(unit);
    const ok = locked && S.qcChosen === q.correct;
    const timer = ring(96, 5, locked ? (S.qcFrozen || 0) : left0 / LIMIT, locked ? (ok ? 'good' : 'bad') : 'gold', secEl);
    if (locked) num.textContent = String(Math.ceil((S.qcFrozen || 0) * LIMIT / 1000));
    shell.appendChild(timer);

    clearQzTimer();
    if (!locked) {
      S.qzTick = setInterval(() => {
        if (!document.body.contains(timer)) { clearQzTimer(); return; }
        const left = Math.max(0, S.qzDeadline - Date.now());
        timer._set(left / LIMIT);
        timer.classList.toggle('low', left < 3000);
        if (left <= 0) { num.textContent = '–'; unit.textContent = 'TAKE YOUR TIME'; clearQzTimer(); }
        else num.textContent = String(Math.ceil(left / 1000));
      }, 100);
    }

    const prompt = node('div', 'qx-prompt');
    const ar = txt('div', 'qx-ar', q.ar || ''); ar.dir = 'rtl';
    if ((q.ar || '').length > 18) ar.classList.add('long');
    prompt.appendChild(ar);
    prompt.appendChild(btn('qx-hear', svg('vol', 17), 'Hear it', () => { try { speak(arText); } catch (_) {} }));
    // the whole word area plays the sound, not just the small speaker
    prompt.classList.add('tap'); prompt.setAttribute('role', 'button');
    prompt.addEventListener('click', () => { try { speak(arText); } catch (_) {} });
    shell.appendChild(prompt);
    shell.appendChild(txt('div', 'qx-ask', q.question || 'What does this mean?'));

    const grid = node('div', 'qx-grid');
    q.opts.forEach((opt) => {
      const isCor = opt === q.correct, isCh = S.qcChosen === opt;
      let cls = 'qx-opt';
      if (locked) cls += isCor ? ' right' : isCh ? ' wrong' : ' dim';
      const b = node('button', cls); b.type = 'button';
      b.appendChild(document.createTextNode(/^[a-z][a-z\-' ]*\s*\((.+)\)$/.test(opt) ? opt.replace(/^[a-z][a-z\-' ]*\s*\((.+)\)$/, '$1') : opt));
      b.dataset.value = opt;
      if (locked && (isCor || isCh)) b.appendChild(node('span', 'qx-mark', svg(isCor ? 'check' : 'x', 16, 2.6)));
      b.addEventListener('click', () => {
        if (S.qcLocked) return;
        S.qcFrozen = Math.max(0, S.qzDeadline - Date.now()) / LIMIT;
        clearQzTimer();
        S.qcChosen = opt; S.qcLocked = true;
        if (opt === q.correct) { S.qcScore++; S.qcStreak = (S.qcStreak || 0) + 1; window.lsChime(); window.lsSayAfterChime(arText); }
        else { S.qcStreak = 0; try { speak(arText); } catch (_) {} }
        render();
      });
      grid.appendChild(b);
    });
    shell.appendChild(grid);

    if (locked) {
      const sheet = node('div', 'qx-sheet ' + (ok ? 'good' : 'bad'));
      const head = node('div', 'qx-sheet-head');
      head.appendChild(node('span', 'qx-sheet-ic', svg(ok ? 'check' : 'x', 16, 2.8)));
      head.appendChild(txt('span', 'qx-sheet-title', ok ? 'Correct!' : 'Not quite'));
      sheet.appendChild(head);
      const mean = node('div', 'qx-sheet-mean');
      const a = txt('span', 'qx-sheet-ar', arText); a.dir = 'rtl';
      mean.appendChild(a); mean.appendChild(txt('span', 'qx-sheet-en', '= ' + String(q.correct).replace(/^[a-z][a-z\-' ]*\s*\((.+)\)$/, '$1')));
      sheet.appendChild(mean);
      sheet.appendChild(btn('qx-sheet-btn', ok ? 'Continue' : 'Got it', null, () => { S.qcFrozen = null; advQuickCheck(); }));
      root.appendChild(sheet);
      requestAnimationFrame(() => sheet.classList.add('in'));
    }
    return root;
  };

  // ── Next-step screen (quick-check result and plain block complete) ─────
  function nextStep(o){
    const { root, shell } = layer();
    const unit = getUnit(S.mId, S.uId) || { blocks: [] };
    const blk = getBlk(S.mId, S.uId, S.bId) || {};
    const idx = unit.blocks.findIndex((b) => b.id === S.bId);
    const next = idx >= 0 ? unit.blocks[idx + 1] : null;
    const doneN = unit.blocks.filter((b) => getBlock_(S.mId, S.uId, b.id) === 'done').length;

    const head = node('div', 'qx-res-head');
    if (o.score != null) {
      head.appendChild(ring(72, 6, o.total ? o.score / o.total : 0, o.passed ? 'good' : 'warn', txt('span', 'qx-res-score', o.score + '/' + o.total)));
    } else {
      head.appendChild(node('div', 'qx-res-check', svg('check', 30, 2.6)));
    }
    const ht = node('div', 'qx-res-ht');
    ht.appendChild(txt('div', 'qx-res-eyebrow ' + (o.passed ? 'good' : 'warn'), o.eyebrow));
    ht.appendChild(txt('div', 'qx-res-title', o.title));
    head.appendChild(ht);
    shell.appendChild(head);
    if (o.sub) shell.appendChild(txt('div', 'qx-res-sub', o.sub));

    const stats = node('div', 'qx-res-stats');
    stats.appendChild(node('span', 'st gold', svg('star', 15) + '<b>+' + (o.xp || 0) + ' XP</b>'));
    stats.appendChild(node('span', 'st fire', svg('fire', 15) + '<b>' + (STREAK || 0) + '-day streak</b>'));
    shell.appendChild(stats);

    shell.appendChild(txt('div', 'qx-res-unit', String(unit.title || '').toUpperCase()));
    shell.appendChild(segs(unit.blocks.length, doneN, -1, 'qx-unit-segs'));
    shell.appendChild(txt('div', 'qx-res-unitn', doneN + ' of ' + unit.blocks.length + ' parts'));

    if (o.passed && next) {
      const card = node('div', 'qx-next');
      card.appendChild(txt('div', 'qx-next-lbl', 'UP NEXT · PART ' + (idx + 2) + ' OF ' + unit.blocks.length));
      const row = node('div', 'qx-next-row');
      const ic = node('div', 'qx-next-ic');
      try { ic.appendChild(ms(next.icon || 'play_arrow')); } catch (_) {}
      row.appendChild(ic);
      const t = node('div', '');
      t.appendChild(txt('div', 'qx-next-title', next.title || 'Next part'));
      const d = next.data || {};
      const size = next.type === 'dialogue' && d.lines ? d.lines.length + ' lines' : next.type === 'vocab' && d.words ? d.words.length + ' words' : '';
      t.appendChild(txt('div', 'qx-next-sub', (TYPE_LABEL[next.type] || 'Lesson') + (size ? ' · ' + size : '')));
      row.appendChild(t);
      card.appendChild(row);
      shell.appendChild(card);
    } else if (o.passed && !next) {
      const card = node('div', 'qx-next done');
      card.appendChild(txt('div', 'qx-next-lbl', 'LESSON COMPLETE'));
      card.appendChild(txt('div', 'qx-next-title', 'Every part of ' + (unit.title || 'this lesson') + ' is done.'));
      shell.appendChild(card);
    }

    shell.appendChild(node('div', 'qx-grow'));
    let pairRow = null;
    for (const a of o.actions) {
      if (a.pair) {
        if (!pairRow) { pairRow = node('div', 'qx-pair'); shell.appendChild(pairRow); }
        pairRow.appendChild(btn('qx-ghost' + (a.icon === 'replay' ? ' gold' : ''), (a.icon === 'replay' ? REPLAY_SVG : BACK_SVG) + '<span>' + a.label + '</span>', null, a.run));
        continue;
      }
      shell.appendChild(btn(a.primary ? 'qx-cta' : 'qx-link', a.primary ? '<span>' + a.label + '</span>' + svg(a.icon || 'fwd', 18, 2.2) : a.label, null, a.run));
    }
    return root;
  }
  const REPLAY_SVG = '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12a8 8 0 1 1-2.3-5.7"/><path d="M20 4v5h-5"/></svg>';
  const BACK_SVG = '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M11 6l-6 6 6 6"/></svg>';
  function goNextBlock(){
    const unit = getUnit(S.mId, S.uId) || { blocks: [] };
    const idx = unit.blocks.findIndex((b) => b.id === S.bId);
    const next = idx >= 0 ? unit.blocks[idx + 1] : null;
    if (next) { S.bId = next.id; resetBS(); S.view = 'lesson'; render(); }
    else { S.view = 'units'; render(); }
  }
  function nextActions(){
    const unit = getUnit(S.mId, S.uId) || { blocks: [] };
    const idx = unit.blocks.findIndex((b) => b.id === S.bId);
    const last = !(idx >= 0 && unit.blocks[idx + 1]);
    const prev = idx > 0 ? unit.blocks[idx - 1] : null;
    const again = () => { if (window.lsRestartPart) window.lsRestartPart(); else { resetBS(); S.view = 'lesson'; render(); } };
    return [
      { label: last ? 'Finish lesson' : 'Next part', primary: true, run: goNextBlock },
      { label: 'Do it again', pair: true, icon: 'replay', run: again },
      prev ? { label: 'Previous', pair: true, icon: 'back', run: () => { S.bId = prev.id; resetBS(); S.view = 'lesson'; render(); } } : null,
      { label: 'Back to lesson', run: () => { S.view = 'blocks'; render(); } },
    ].filter(Boolean);
  }

  showQuickCheckResult = function(){
    clearQzTimer();
    const score = S.qcScore;
    const total = (S.qcQuestions || []).length;
    const passed = score >= Math.ceil(total * 0.67);
    const earnedXP = score === total ? 20 : passed ? 15 : 10;   // the website's rule
    XP += earnedXP; S.lastXP = earnedXP; save();
    const blk = getBlk(S.mId, S.uId, S.bId) || {};
    const screen = nextStep(passed ? {
      score, total, passed: true, xp: earnedXP,
      eyebrow: 'Quick Check Passed', title: (blk.title || 'Part') + ' done',
      actions: nextActions(),
    } : {
      score, total, passed: false, xp: earnedXP,
      eyebrow: 'Keep Practising', title: 'Almost there',
      sub: 'You got ' + score + ' of ' + total + '. One more go and it will stick.',
      actions: [
        { label: 'Try again', primary: true, icon: 'replay', run: () => { S.qcIdx = 0; S.qcScore = 0; S.qcChosen = null; S.qcLocked = false; S.qzDeadline = null; S.view = 'quickcheck'; render(); } },
        { label: 'Review the lesson', run: () => { S.view = 'lesson'; render(); } },
      ],
    });
    const app = document.getElementById('app'); app.innerHTML = '';
    app.appendChild(screen);
    try { if (window.Lisaany && passed) Lisaany.celebrate(); } catch (_) {}
  };

  mkComplete = function(){
    const blk = getBlk(S.mId, S.uId, S.bId) || {};
    return nextStep({
      score: null, passed: true, xp: S.lastXP || 15,
      eyebrow: 'Part Complete', title: (blk.title || 'Part') + ' done',
      actions: nextActions(),
    });
  };
})();
