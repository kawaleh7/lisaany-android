/* ═══ Lisaany app — the gold star guide (all lesson views) ═══
   A glossy gold star that lives in a small slot in each lesson top bar
   (.ls-slot). At the start of a quiz it flies out, explains the task in a white
   bubble, then tucks back into its slot; tapping it repeats the instruction.
   It never sits on top of words: it talks from free space (.ls-gap, or the
   emptiest band of the question card .ls-area) or from a talk row (.ls-talk)
   under the top bar that opens and pushes the content down.
   Right answer → a loop, sparkles, a gold ring, "+N XP", and star bits that fly
   into the XP pill (.ls-xp). Wrong answer → a short word of encouragement.
   Effects use CSS transitions only (no Web Animations API). The star is silent.
   Also here: lsT (English/French strings) and the line-icon clean-up
   (no people or animal icons / emoji in lesson views). */
(function(){
  if (window.lsStar) return;
  const FR = (function(){ try { return LISAANY_LANG === 'fr'; } catch (e) { return false; } })();
  window.lsT = function(en, fr){ return FR ? fr : en; };
  // A data string (an English meaning) in French, when the page's dictionaries know it.
  window.lsFr = function(s){
    if (!FR) return s;
    const k = String(s || '').trim();
    try { if (LISAANY_FR_UI[k]) return LISAANY_FR_UI[k]; } catch (e) {}
    try { if (LISAANY_FR[k]) return LISAANY_FR[k]; } catch (e) {}
    return s;
  };
  const T = window.lsT;

  // ── sound (soft, optional) ──
  let ac = null;

  // ── sound effects only (no music, no melodies): noise-based whoosh, shimmer,
  //    click, a soft pop and a low bump. WebAudio, no files.
  let master = null, noiseBuf = null;
  // Sound is OFF unless the app switches it on (Settings → Sounds). Learners
  // found the chimes tiring, so silence is the default everywhere.
  const soundOn = () => !!(window.__LISAANY_APP && window.__LISAANY_APP.sfx);
  function out(){
    ac = ac || new (window.AudioContext || window.webkitAudioContext)();
    if (ac.state === 'suspended') ac.resume();
    if (!master) {
      const comp = ac.createDynamicsCompressor(); comp.threshold.value = -14; comp.ratio.value = 4;
      master = ac.createGain(); master.gain.value = 0.9; master.connect(comp); comp.connect(ac.destination);
    }
    return master;
  }
  function noise(){
    if (noiseBuf) return noiseBuf;
    const n = Math.floor(ac.sampleRate * 1.5); noiseBuf = ac.createBuffer(1, n, ac.sampleRate);
    const ch = noiseBuf.getChannelData(0); for (let i = 0; i < n; i++) ch[i] = Math.random() * 2 - 1;
    return noiseBuf;
  }
  // filtered noise with an envelope: the building block for every effect
  function hiss(o){
    if (!soundOn()) return;
    try {
      const o0 = out(), t0 = ac.currentTime + (o.at || 0), d = o.dur;
      const src = ac.createBufferSource(); src.buffer = noise();
      const f = ac.createBiquadFilter(); f.type = o.type || 'bandpass'; f.Q.value = o.q || 1;
      f.frequency.setValueAtTime(o.f0, t0); if (o.f1) f.frequency.exponentialRampToValueAtTime(o.f1, t0 + d);
      const g = ac.createGain(); g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(o.vol, t0 + (o.attack || 0.005)); g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
      src.connect(f); f.connect(g); g.connect(o0); src.start(t0, Math.random()); src.stop(t0 + d + 0.02);
    } catch (e) {}
  }
  // a single quick pitch drop — a bubble "pop", not a note
  function pop(at, vol){
    try {
      const o0 = out(), t0 = ac.currentTime + (at || 0), o = ac.createOscillator(), g = ac.createGain();
      o.type = 'sine'; o.frequency.setValueAtTime(700, t0); o.frequency.exponentialRampToValueAtTime(140, t0 + 0.09);
      g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(vol || 0.35, t0 + 0.004); g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.11);
      o.connect(g); g.connect(o0); o.start(t0); o.stop(t0 + 0.13);
    } catch (e) {}
  }
  // a low soft bump (wrong answer / time's up)
  function bump(vol){
    try {
      const o0 = out(), t0 = ac.currentTime, o = ac.createOscillator(), g = ac.createGain();
      o.type = 'sine'; o.frequency.setValueAtTime(150, t0); o.frequency.exponentialRampToValueAtTime(60, t0 + 0.18);
      g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(vol || 0.4, t0 + 0.008); g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.22);
      o.connect(g); g.connect(o0); o.start(t0); o.stop(t0 + 0.25);
    } catch (e) {}
    hiss({ f0: 300, type: 'lowpass', dur: 0.12, vol: 0.12 });
  }
  // metal / glass strike with inharmonic partials: a coin clink or a star
  // sparkle — single struck sounds, not notes
  function metal(f, at, vol, dur, parts){
    if (!soundOn()) return;
    try {
      const o0 = out(), t0 = ac.currentTime + (at || 0);
      (parts || [[1, 1], [2.76, 0.5], [5.4, 0.25], [8.93, 0.12]]).forEach(([m, g], k) => {
        const o = ac.createOscillator(), a = ac.createGain(), dd = (dur || 0.35) * (1 - k * 0.18);
        o.type = 'sine'; o.frequency.setValueAtTime(f * m, t0);
        a.gain.setValueAtTime(0.0001, t0); a.gain.exponentialRampToValueAtTime(vol * g, t0 + 0.002); a.gain.exponentialRampToValueAtTime(0.0001, t0 + dd);
        o.connect(a); a.connect(o0); o.start(t0); o.stop(t0 + dd + 0.02);
      });
      hiss({ at, f0: f * 2, type: 'highpass', dur: 0.015, vol: vol * 0.35, attack: 0.001 });
    } catch (e) {}
  }
  const GLASS = [[1, 1], [2.32, 0.45], [4.25, 0.2]];
  const twinkles = (n, span, lo, hi, vol, at) => { for (let i = 0; i < n; i++) metal(lo + Math.random() * (hi - lo), (at || 0) + Math.random() * span, vol * (1 - i / n * 0.6), 0.22, GLASS); };
  const whoosh = () => {};  // the star's flight is silent
  const shimmer = (at, vol) => twinkles(6, 0.35, 3500, 6500, vol || 0.16, at);
  const click = (at, vol) => hiss({ at, f0: 3500, type: 'highpass', dur: 0.03, vol: vol || 0.2, attack: 0.002 });
  const coin = (at, vol) => metal(2350, at, vol || 0.32, 0.45);
  // The star's twinkle is a highlight, not a UI click: it is kept quiet and it
  // may not repeat inside STAR_GAP ms, so routine star activity stays silent.
  const STAR_GAP = 4000;
  const sfxAt = {};
  const gate = (k, ms) => { const t = Date.now(); if (t - (sfxAt[k] || 0) < (ms == null ? STAR_GAP : ms)) return false; sfxAt[k] = t; return true; };
  const SFX = {
    whoosh, shimmer, click, pop, bump, coin, twinkles,
    // right answer: coin clink + a little twinkle (not rate-limited — it answers a tap)
    right(){ coin(0, 0.3); twinkles(4, 0.2, 5000, 8000, 0.1, 0.06); },
    // the star, on a real moment only (a landing, a milestone): a soft twinkle
    star(){ /* silent: the star makes no sound */ },
    // star lands (part complete): sparkle burst — still the biggest of the three
    land(){ /* silent: the star makes no sound */ },
    sparkle(){ /* silent: the star makes no sound */ },
    // moved up: rising swoosh + glass ting
    levelUp(){ hiss({ f0: 800, f1: 6000, q: 2, dur: 0.35, vol: 0.25, attack: 0.25 }); metal(2800, 0.33, 0.26, 0.45, GLASS); },
    // each XP counted / star bit landing in the XP pill: a small coin clink
    tick(){ coin(0, 0.12); },
    jingle(){ SFX.land(); },
  };
  window.lsSfx = SFX;
  // Phones only allow sound after a touch: wake the audio on the first tap.
  document.addEventListener('pointerdown', () => { try { out(); } catch (e) {} }, { capture: true, passive: true });
  const chime = () => SFX.right();

  const STAR_SVG = '<svg viewBox="0 0 100 100" aria-hidden="true"><defs>' +
    '<radialGradient id="ls-puff" cx=".38" cy=".3" r=".75"><stop offset="0" stop-color="#FFF6C2"/><stop offset=".35" stop-color="#FFD84A"/><stop offset=".75" stop-color="#E6A800"/><stop offset="1" stop-color="#B07A00"/></radialGradient>' +
    '<radialGradient id="ls-halo" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#FFD84A" stop-opacity=".6"/><stop offset=".6" stop-color="#FFD84A" stop-opacity=".12"/><stop offset="1" stop-color="#FFD84A" stop-opacity="0"/></radialGradient>' +
    '<radialGradient id="ls-spec" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#fff" stop-opacity=".95"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient></defs>' +
    '<circle cx="50" cy="50" r="62" fill="url(#ls-halo)"/>' +
    '<path d="M50 9 C55 9 58 29 64 32 C70 35 90 32 92 38 C94 44 76 53 74 60 C72 67 83 85 78 89 C73 93 57 79 50 79 C43 79 27 93 22 89 C17 85 28 67 26 60 C24 53 6 44 8 38 C10 32 30 35 36 32 C42 29 45 9 50 9 Z" fill="url(#ls-puff)" stroke="#C98C00" stroke-width="1.2"/>' +
    '<ellipse cx="40" cy="36" rx="9" ry="6" fill="url(#ls-spec)" transform="rotate(-25 40 36)"/></svg>';
  const SPARK = '<svg viewBox="0 0 10 10"><path d="M5 0 L6.2 3.8 L10 5 L6.2 6.2 L5 10 L3.8 6.2 L0 5 L3.8 3.8Z" fill="#FFE98A"/></svg>';
  const XP_IC = '<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path d="M12 2.5l2.7 6.2 6.8.6-5.2 4.5 1.6 6.6L12 16.9l-5.9 3.5 1.6-6.6-5.2-4.5 6.8-.6z" fill="currentColor"/></svg>';

  let star = null, bubble = null, combo = null;
  let x = -200, y = -200, rot = 0, vr = 0, t = 0, sc = 0.5, mode = 'home', loop = null;
  let talking = false, talkT = null, where = 'row', rowH = 0, help = '', shown = false, dim = false, lastAct = Date.now();
  let party = null, pending = 0, lastSlot = null, quitOpen = false, askKey = null;

  function el(tag, cls, html){ const n = document.createElement(tag); if (cls) n.className = cls; if (html != null) n.innerHTML = html; return n; }
  function box(n){ const r = n.getBoundingClientRect(); return { left: r.left, top: r.top, w: r.width, h: r.height, x: r.left + r.width / 2, y: r.top + r.height / 2 }; }
  // Where the star rests on this screen. A question card that asks in a speech
  // bubble puts its own slot (.ls-slot.ls-ask) beside the bubble; the star
  // lives there instead of in the top bar, so the learner never sees two stars.
  function homeSlot(){ return document.querySelector('.ls-slot.ls-ask') || document.querySelector('.ls-slot'); }

  function build(){
    if (star || !document.body) return;
    star = el('div', 'ls-star', STAR_SVG);
    star.setAttribute('role', 'button'); star.setAttribute('aria-label', T('Guide star — repeat the instruction', 'Étoile guide — répéter la consigne'));
    bubble = el('div', 'ls-bubble'); bubble.setAttribute('role', 'status'); bubble.setAttribute('aria-live', 'polite');
    combo = el('div', 'ls-combo');
    document.body.appendChild(star); document.body.appendChild(bubble); document.body.appendChild(combo);
    star.addEventListener('pointerdown', (e) => {
      e.stopPropagation(); wake(); sc *= 1.25; burst(x, y, 8);
      if (talking) tuck(); else if (help && !party) explain(help); else spin(24);
    });
    star.addEventListener('click', (e) => e.stopPropagation());
    document.addEventListener('pointerdown', (e) => { if (star && e.target !== star && !star.contains(e.target)) { wake(); if (talking && !party) tuck(); } }, true);
    requestAnimationFrame(frame);
  }

  // ── free space for the star to talk / celebrate in ──
  function freeBand(){
    const g = document.querySelector('.ls-gap');
    if (g) { const r = box(g); if (r.h > 0 && r.w > 0) return r; }
    const a = document.querySelector('.ls-area');
    if (!a) return null;
    const ar = a.getBoundingClientRect();
    const kids = Array.prototype.filter.call(a.children, (c) => { const s = getComputedStyle(c); return s.position !== 'absolute' && s.position !== 'fixed' && s.display !== 'none'; })
      .map((c) => c.getBoundingClientRect()).filter((r) => r.height > 0).sort((p, q) => p.top - q.top);
    let best = null, prev = ar.top + 6;
    const consider = (top, bottom) => { const h = bottom - top; if (!best || h > best.h) best = { left: ar.left + 8, top, w: ar.width - 16, h, x: ar.left + ar.width / 2, y: top + h / 2 }; };
    kids.forEach((r) => { consider(prev, r.top - 4); prev = Math.max(prev, r.bottom + 4); });
    consider(prev, ar.bottom - 6);
    return best;
  }
  function row(){ return document.querySelector('.ls-talk'); }
  function setRow(h){
    rowH = h;
    const r = row(); if (r) r.style.height = h + 'px';
  }
  function measureBubble(width){
    bubble.style.width = width + 'px';
    return bubble.offsetHeight || 60;
  }
  function talkPos(){
    if (where === 'band') {
      const b = freeBand();
      if (b && b.h >= bubble.offsetHeight + 8) return { x: b.left + 34, y: b.y, band: b };
      where = 'row'; setRow(Math.max(78, bubble.offsetHeight + 18));
    }
    const r = row();
    if (r) { const b = box(r); return { x: b.left + 34, y: b.top + Math.max(rowH, b.h) / 2, band: { left: b.left, top: b.top, w: b.w, h: Math.max(rowH, b.h) } }; }
    return { x: 44, y: 110, band: { left: 0, top: 70, w: innerWidth, h: 80 } };
  }

  function explain(text, ms){
    if (!star || !text) return;
    talking = true; mode = 'talk'; wake();
    bubble.textContent = text;
    const W = innerWidth;
    const b = freeBand();
    const bw = Math.max(170, Math.min(270, (b ? b.w : W) - 84));
    const bh = measureBubble(bw);
    if (b && b.h >= bh + 10 && b.w >= 230) { where = 'band'; if (rowH) setRow(0); }
    else {
      where = 'row';
      const rb = measureBubble(Math.max(170, Math.min(290, W - 110)));
      setRow(Math.max(78, rb + 18));
    }
    spin(14);
    bubble.classList.remove('show');
    clearTimeout(talkT);
    setTimeout(() => { if (talking) bubble.classList.add('show'); }, 380);
    talkT = setTimeout(tuck, ms || 4500);
  }
  function tuck(){
    clearTimeout(talkT);
    if (!talking) return;
    talking = false; bubble.classList.remove('show');
    if (rowH && !(party && party.useRow)) setRow(0);
    if (!party) mode = 'home';
  }
  function spin(v){ vr += v; }
  function wake(){ lastAct = Date.now(); if (dim && star) { dim = false; star.classList.remove('dim'); spin(10); } }

  // ── effects: CSS transitions only ──
  function fly(n, from, to, ms, ease, done){
    n.style.transition = 'none'; Object.assign(n.style, from); void n.offsetWidth;
    requestAnimationFrame(() => { n.style.transition = 'transform ' + ms + 'ms ' + (ease || 'cubic-bezier(.2,.7,.3,1)') + ',opacity ' + ms + 'ms ease'; Object.assign(n.style, to); });
    setTimeout(() => { if (done) done(); else n.remove(); }, ms + 60);
  }
  function fx(cls, px, py, html){ const d = el('div', 'ls-fx ' + cls, html); d.style.left = px + 'px'; d.style.top = py + 'px'; document.body.appendChild(d); return d; }
  function burst(px, py, n){
    for (let i = 0; i < n; i++) {
      const d = fx('ls-spark', px, py, SPARK), a = Math.random() * Math.PI * 2, r = 30 + Math.random() * 50;
      fly(d, { transform: 'translate(0,0) scale(1.3)', opacity: '1' }, { transform: 'translate(' + Math.cos(a) * r + 'px,' + Math.sin(a) * r + 'px) scale(.3)', opacity: '0' }, 650 + Math.random() * 300);
    }
  }
  function ringFx(px, py, big){ const d = fx('ls-ringfx', px, py); fly(d, { transform: 'scale(.4)', opacity: '1' }, { transform: 'scale(' + (big ? 4.4 : 3) + ')', opacity: '0' }, big ? 900 : 700); }
  function plus(px, py, text){
    const d = fx('ls-plus', px, py); d.textContent = text;
    fly(d, { transform: 'translateY(0) scale(.7)', opacity: '0' }, { transform: 'translateY(-20px) scale(1.1)', opacity: '1' }, 260, 'ease-out',
      () => fly(d, {}, { transform: 'translateY(-60px)', opacity: '0' }, 1000, 'ease-in'));
  }
  function xpEls(){ return document.querySelectorAll('.ls-xp b'); }
  function showXp(){ const v = String(Math.max(0, (typeof XP === 'number' ? XP : 0) - pending)); xpEls().forEach((b) => { b.textContent = v; }); }
  function bits(px, py, n){
    const pill = document.querySelector('.ls-xp');
    if (!pill) { pending = 0; showXp(); return; }
    for (let i = 0; i < n; i++) setTimeout(() => {
      const d = fx('ls-spark', px, py, SPARK), mx = (Math.random() - 0.5) * 120, my = -40 - Math.random() * 60;
      fly(d, { transform: 'translate(0,0) scale(1.6)' }, { transform: 'translate(' + mx + 'px,' + my + 'px) scale(1.3)' }, 300, 'ease-out', () => {
        const p = document.querySelector('.ls-xp'); const tb = p ? box(p) : { x: innerWidth - 50, y: 30 };
        fly(d, {}, { transform: 'translate(' + (tb.x - px) + 'px,' + (tb.y - py) + 'px) scale(.6)' }, 600, 'cubic-bezier(.5,0,.3,1)', () => {
          d.remove(); pending = Math.max(0, pending - 1); showXp();
          const q = document.querySelector('.ls-xp'); if (q) { q.classList.remove('pop'); void q.offsetWidth; q.classList.add('pop'); }
          coin(0, 0.1);
        });
      });
    }, i * 60);
  }
  function partyCenter(){
    if (party && party.useRow) { const r = row(); if (r) { const b = box(r); return { x: b.x, y: b.top + Math.max(rowH, b.h) / 2 + 20, h: Math.max(rowH, b.h) }; } }
    const b = freeBand();
    if (b) return { x: b.x, y: b.y, h: b.h };
    return { x: innerWidth / 2, y: innerHeight / 3, h: 120 };
  }
  // the star shrinks to fit a small free band (74px is its full size)
  function partyScale(c){ return Math.max(0.5, Math.min(0.9, ((c.h || 120) - 8) / 74)); }
  // Right answer: loop in free space, sparkles, a ring, +N XP, bits into the XP pill.
  function celebrate(o){
    o = o || {};
    build(); if (!star) return;
    const pts = o.pts || 0, streak = o.combo || 0;
    wake(); if (talking) { talking = false; bubble.classList.remove('show'); clearTimeout(talkT); }
    const b = freeBand();
    const useRow = !b || b.h < 84;
    party = { useRow };
    if (useRow) setRow(120); else if (rowH) setRow(0);
    mode = 'fly';
    setTimeout(() => { if (!party) return; const c = partyCenter(); loop = { a: 0, r: Math.max(10, Math.min(46, (c.h - 70) / 2)) }; mode = 'loop'; }, 420);
    setTimeout(() => {
      if (!party) return;
      loop = null; mode = 'fly';
      const c = partyCenter(), big = streak >= 3;
      spin(big ? 42 : 28); sc = partyScale(c) * 1.45;
      burst(c.x, c.y, big ? 26 : 16); ringFx(c.x, c.y, big);
      if (pts) { plus(Math.min(c.x + 44, innerWidth - 90), c.y - 18, '+' + pts + ' XP'); bits(c.x, c.y, pts); }
      chime();
      if (streak >= 2) {
        combo.textContent = T(streak + ' in a row!', streak + ' à la suite !');
        const top = document.querySelector('.qx-top, .lm-top');
        combo.style.top = ((top ? top.getBoundingClientRect().bottom : 56) + 8) + 'px';
        combo.classList.add('show'); setTimeout(() => combo.classList.remove('show'), 1500);
      }
      setTimeout(() => { const wasRow = party && party.useRow; party = null; if (mode === 'fly' || mode === 'loop') mode = 'home'; if (wasRow && !talking) setRow(0); }, 1000);
    }, 1150);
  }
  const CHEER = [
    ['Nearly — try again!', 'Presque — réessayez !'],
    ['You can do it — have another go.', 'Vous pouvez y arriver — encore un essai.'],
    ['Not that one — try again.', 'Pas celle-ci — réessayez.'],
    ['Close! Have another look.', 'Pas loin ! Regardez encore.'],
  ];
  const CHEER2 = [
    ['Listen again and look closely.', 'Réécoutez et regardez bien.'],
    ['Take your time — you’re learning.', 'Prenez votre temps — vous apprenez.'],
  ];
  const pick = (a) => { const p = a[Math.floor(Math.random() * a.length)]; return T(p[0], p[1]); };
  // Wrong answer: a small wobble, then a short word of encouragement.
  function encourage(misses, text){
    build(); if (!star) return;
    wake(); if (talking) tuck();
    mode = 'wobble';
    const msg = text || (misses >= 2 ? pick(CHEER2) : pick(CHEER));
    setTimeout(() => { if (mode === 'wobble') mode = 'home'; explain(msg, 3000); spin(8); }, 600);
  }
  function wrongTone(){ bump(0.3); }
  function timeTone(){ bump(0.4); if (star) { star.classList.add('dim'); setTimeout(() => { if (!dim) star.classList.remove('dim'); }, 900); } }

  function hide(){
    shown = false; talking = false; party = null; loop = null; mode = 'home'; rowH = 0;
    clearTimeout(talkT);
    if (star) { star.style.opacity = '0'; star.style.pointerEvents = 'none'; }
    if (bubble) bubble.classList.remove('show');
  }
  function frame(){
    requestAnimationFrame(frame);
    const slot = homeSlot();
    if (!slot || document.querySelector('.rs-back')) { if (shown) hide(); return; }
    if (!shown) {
      shown = true; star.style.opacity = ''; star.style.pointerEvents = '';
      // fly in from the top right when the star was away
      x = innerWidth + 40; y = 70; sc = 0.9; spin(18);
    }
    star.style.visibility = quitOpen ? 'hidden' : '';
    if (slot !== lastSlot) { lastSlot = slot; if (talking && where === 'row') { const r = row(); if (r) { r.style.transition = 'none'; r.style.height = rowH + 'px'; void r.offsetWidth; r.style.transition = ''; } } }
    // A new bubble question: the star flies down into it and sparkles (no sound).
    const ak = slot.getAttribute('data-ask');
    if (ak && ak !== askKey) {
      askKey = ak; spin(12);
      setTimeout(() => { if (slot.isConnected) { const b = box(slot); burst(b.x, b.y, 8); } }, 520);
    } else if (!ak && askKey) askKey = null;
    t += 1 / 60;
    if (!dim && !talking && !party && Date.now() - lastAct > 15000) { dim = true; star.classList.add('dim'); }
    let gx = x, gy = y, target = 0.52;
    if (mode === 'home') { const b = box(slot); gx = b.x; gy = b.y + Math.sin(t * 1.6) * 3; if (slot.classList.contains('ls-ask')) target = 0.86; }
    else if (mode === 'talk') { const p = talkPos(); gx = p.x; gy = p.y + Math.sin(t * 1.6) * 3; target = 0.82; }
    else if (mode === 'loop' && loop) { const c = partyCenter(); loop.a += 0.17; gx = c.x + Math.sin(loop.a) * loop.r; gy = c.y + Math.cos(loop.a) * loop.r; target = partyScale(c); }
    else if (mode === 'fly') { const c = party ? partyCenter() : box(slot); gx = c.x; gy = c.y; target = party ? partyScale(c) : 0.6; }
    else if (mode === 'wobble') { gx = x + Math.sin(Date.now() / 40) * 4; gy = y; }
    if (dim && mode === 'home') gy += 3;
    const k = mode === 'loop' ? 0.35 : mode === 'fly' ? 0.14 : 0.1;
    x += (gx - x) * k; y += (gy - y) * k; vr *= 0.94; rot += vr + Math.sin(t * 1.2) * 0.25;
    sc += (target + Math.sin(t * 2.2) * 0.03 - sc) * 0.12;
    star.style.transform = 'translate(' + x.toFixed(1) + 'px,' + y.toFixed(1) + 'px) rotate(' + rot.toFixed(1) + 'deg) scale(' + sc.toFixed(3) + ')';
    if (talking) {
      const p = talkPos();
      const bw = Math.max(160, Math.min(290, p.band.left + p.band.w - (x + 34) - 8));
      bubble.style.width = bw + 'px';
      bubble.style.left = (x + 34) + 'px';
      const bh = bubble.offsetHeight;
      const top = Math.max(p.band.top + 2, Math.min(y - bh / 2, p.band.top + p.band.h - bh - 2));
      bubble.style.top = top + 'px';
    }
  }

  // ── pieces a view puts into its layout ──
  function slotEl(){ build(); const s = el('span', 'ls-slot'); s.setAttribute('aria-hidden', 'true'); return s; }
  function rowEl(){
    const r = el('div', 'ls-talk');
    if (rowH) { r.style.transition = 'none'; r.style.height = rowH + 'px'; requestAnimationFrame(() => { r.style.transition = ''; }); }
    return r;
  }
  function xpPill(){
    const p = el('div', 'ls-xp', XP_IC + '<b></b><span>XP</span>');
    p.querySelector('b').textContent = String(Math.max(0, (typeof XP === 'number' ? XP : 0) - pending));
    return p;
  }
  // Real XP for a right answer: counted now, shown as the bits land.
  function award(pts){
    if (!pts) return;
    try { XP += pts; S.lsPartXP = (S.lsPartXP || 0) + pts; if (pts >= 10) S.lsFirst = (S.lsFirst || 0) + 1; else S.lsRetry = (S.lsRetry || 0) + 1; save(); } catch (e) {}
    pending += pts;
  }
  // Explain once per key (e.g. once per block), a moment after the view appears.
  let introKey = null;
  function intro(key, text, delay){
    help = text;
    if (key === introKey) return;
    introKey = key;
    setTimeout(() => { if (homeSlot() && help === text) explain(text); }, delay == null ? 550 : delay);
  }
  function setHelp(text){ help = text || ''; }

  // ── Daily minutes goal ──
  // Active learning time: counted each second while the page is visible and
  // the learner is active (a tap / key in the last 60 s, or lesson audio
  // playing). Deltas reach the shell as { type:'minutes', secs } every 15 s,
  // when the page is hidden and just before a quit / hand-off. The daily goal
  // (day.minGoal, in minutes) and the seconds already counted today
  // (day.daySecs) come from window.__LISAANY_APP.day; without minGoal the goal
  // features stay off and the page behaves as before.
  const NBS = ' ';
  const SHELL_V = { hub: 1, units: 1, blocks: 1, signup: 1, upgrade: 1 };
  let mBase = null, mSess = 0, mSent = 0, mTicks = 0, mGoalSet = 0, mInput = Date.now(), mHit = false, mPend = false;
  function cfgDay(){ const a = window.__LISAANY_APP; return (a && a.day) || null; }
  function newShell(){ const d = cfgDay(); return !!d && ('minGoal' in d || 'daySecs' in d); }
  function baseSecs(){
    if (mBase == null) { const d = cfgDay(); if (!d) return 0; mBase = Math.max(0, Number(d.daySecs) || 0); }
    return mBase;
  }
  function minGoal(){ if (mGoalSet) return mGoalSet; const d = cfgDay(); const g = d ? Number(d.minGoal) : 0; return g > 0 ? g : 0; }
  function todaySecs(){ return baseSecs() + mSess; }
  function dateKey(){ const n = new Date(); return n.getFullYear() + '-' + (n.getMonth() + 1) + '-' + n.getDate(); }
  try { mHit = sessionStorage.getItem('lsMinGoalHit') === dateKey(); } catch (e) {}
  function markHit(){ mHit = true; mPend = false; try { sessionStorage.setItem('lsMinGoalHit', dateKey()); } catch (e) {} }
  function bridgePost(m){
    try {
      if (window.LisaanyApp && typeof LisaanyApp.post === 'function') { LisaanyApp.post(m); return; }
      const s = JSON.stringify(m);
      if (window.ReactNativeWebView && window.ReactNativeWebView.postMessage) window.ReactNativeWebView.postMessage(s);
    } catch (e) {}
  }
  function reportMin(){
    const d = mSess - mSent;
    if (d <= 0 || !newShell()) return;
    mSent = mSess;
    bridgePost({ type: 'minutes', secs: d });
  }
  function audioOn(){
    try { if (typeof _curAudio !== 'undefined' && _curAudio && !_curAudio.paused) return true; } catch (e) {}
    try { if (window.speechSynthesis && window.speechSynthesis.speaking) return true; } catch (e) {}
    return false;
  }
  function inLesson(){
    try { if (window.LisaanyApp && !LisaanyApp.opened) return false; } catch (e) {}
    try { return !!S.view && !SHELL_V[S.view]; } catch (e) { return false; }
  }
  // "That's your N minutes — well done!" once per day, in a lesson view.
  function goalCheer(){
    const g = minGoal();
    if (!g || mHit || !star || quitOpen || party || !homeSlot()) return false;
    // Reaching the daily goal is never announced in a lesson — nothing should
    // suggest it's time to stop. It's only recorded.
    markHit();
    return true;
  }
  function tickMin(){
    mTicks++;
    const was = todaySecs();
    if (document.visibilityState !== 'hidden' && inLesson() && (Date.now() - mInput < 60000 || audioOn())) mSess++;
    const g = minGoal(), now = todaySecs();
    if (g && !mHit && was < g * 60 && now >= g * 60) mPend = true;
    if (mPend && !mHit) { let v = ''; try { v = S.view; } catch (e) {} if (v !== 'complete') goalCheer(); }
    if (mTicks % 15 === 0) reportMin();
  }
  setInterval(tickMin, 1000);
  ['pointerdown', 'keydown'].forEach((ev) => document.addEventListener(ev, () => { mInput = Date.now(); }, { capture: true, passive: true }));
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') reportMin(); });
  window.addEventListener('pagehide', reportMin);
  // A later LisaanyApp.open() with a fresh day config: take its counts.
  window.addEventListener('message', (e) => {
    try {
      const m = typeof e.data === 'string' ? JSON.parse(e.data) : e.data;
      if (!m || m.type !== 'open' || !m.cfg || !m.cfg.day) return;
      reportMin();
      window.__LISAANY_APP = Object.assign({}, window.__LISAANY_APP || {}, { day: m.cfg.day });
      mBase = Math.max(0, Number(m.cfg.day.daySecs) || 0); mSess = 0; mSent = 0; mGoalSet = 0;
    } catch (_) {}
  });
  window.lsToday = () => ({ secs: todaySecs(), goalMin: minGoal() });
  window.lsMinutes = {
    today: window.lsToday, report: reportMin, markHit, hit: () => mHit,
    // test hook: run the per-second tick n times
    tick(n){ for (let i = 0; i < (n || 1); i++) tickMin(); },
  };
  function setMinGoal(n){
    mGoalSet = n;
    const d = cfgDay(); if (d) d.minGoal = n;
    bridgePost({ type: 'setGoal', minutes: n });
  }
  // minutes still to go today (0 = no goal, or goal met)
  function goalLeft(){
    const g = minGoal(); if (!g) return 0;
    const m = Math.floor(todaySecs() / 60);
    return m >= g ? 0 : Math.max(1, g - m);
  }

  // ── "Leaving already?" — shown when ✕ is tapped part-way through a part ──
  // The star flies from its slot into a small card and says how close the
  // learner is to the end, word by word. Quit / Keep learning. Nothing answered
  // yet → close straight away.
  function progress(){
    const segs = document.querySelectorAll('.qx-segs .qx-seg, .lm-segs .lm-seg');
    let done = document.querySelectorAll('.qx-segs .qx-seg.done').length;
    // Conversation: the line on screen is lit but not finished yet.
    const lit = document.querySelectorAll('.lm-segs .lm-seg.on').length;
    if (lit) done += Math.max(0, lit - 1);
    return { total: segs.length, done: done };
  }
  function noun(k){
    const lines = !!document.querySelector('.lm-segs');
    const cards = !lines && !!document.querySelector('.cd-card, .cd-tile, .cd-swipe');
    if (lines) return k === 1 ? T('line', 'réplique') : T('lines', 'répliques');
    if (cards) return k === 1 ? T('card', 'carte') : T('cards', 'cartes');
    return k === 1 ? T('question', 'question') : T('questions', 'questions');
  }
  function quitLine(k){
    const NB = ' ', n = noun(k);
    return k === 1
      ? T('Leaving already? You’re 1 ' + n + ' from the end.', 'Déjà' + NB + '? Il ne reste qu’une ' + n + '.')
      : T('Leaving already? You’re ' + k + ' ' + n + ' from the end.', 'Déjà' + NB + '? Il ne reste que ' + k + ' ' + n + '.');
  }
  let qFly = 0, qTalk = [];
  function goalLine(l, g){
    return l === 1
      ? T('Only 1 minute left to reach your ' + g + '-minute goal. Let’s finish it!', 'Plus que 1' + NBS + 'minute pour atteindre votre objectif de ' + g + NBS + 'minutes. On termine' + NBS + '!')
      : T('Only ' + l + ' minutes left to reach your ' + g + '-minute goal. Let’s finish it!', 'Plus que ' + l + NBS + 'minutes pour atteindre votre objectif de ' + g + NBS + 'minutes. On termine' + NBS + '!');
  }
  function askQuit(go0, opts){
    if (quitOpen) return;
    const goalDone = opts && opts.goalDone;
    const go = () => { reportMin(); go0(); };
    // Daily goal not met yet → the star holds the learner to it, however far into the part they are.
    const gLeft = goalLeft(), g0 = minGoal();
    const pr = progress(), left = pr.total - pr.done;
    if (!goalDone && !gLeft && (!pr.total || pr.done === 0 || left <= 0)) { go(); return; }
    build();
    if (talking) tuck();
    quitOpen = true;
    const layer = el('div', 'ls-quit');
    layer.innerHTML =
      '<div class="ls-quit-veil"></div>' +
      '<div class="ls-quit-card" role="dialog" aria-modal="true">' +
        '<div class="ls-quit-row"><span class="ls-quit-star">' + STAR_SVG + '</span><div class="ls-quit-say"></div></div>' +
        '<div class="ls-quit-btns"><button class="ls-quit-no" type="button"></button><button class="ls-quit-go" type="button"></button></div>' +
      '</div>';
    const say = layer.querySelector('.ls-quit-say'), home = layer.querySelector('.ls-quit-star'), btns = layer.querySelector('.ls-quit-btns');
    say.setAttribute('role', 'status');
    const words = (text) => {
      say.textContent = '';
      text.split(/(\s+)/).forEach((w) => {
        if (!w) return;
        if (/^\s+$/.test(w)) { say.appendChild(document.createTextNode(w)); return; }
        say.appendChild(el('span', 'ls-w', null)).textContent = w;
      });
    };
    // the star nods while the words appear one by one
    const talkNow = () => {
      qTalk.forEach(clearTimeout); qTalk = [];
      say.classList.add('talk');
      const ws = [...say.querySelectorAll('.ls-w')];
      ws.forEach((w, i) => qTalk.push(setTimeout(() => w.classList.add('in'), 160 + i * 85)));
      let n = 0; const nod = () => { if (!layer.isConnected) return; home.style.transform = n % 2 ? '' : 'scale(1.08) rotate(-6deg)'; n++; if (n < Math.min(10, ws.length)) qTalk.push(setTimeout(nod, 170)); else home.style.transform = ''; };
      nod();
    };
    // a new line in the same card, with new buttons under it
    const reply = (text, html, wire) => {
      words(text); talkNow();
      btns.className = 'ls-quit-btns col'; btns.innerHTML = html;
      btns.querySelectorAll('button').forEach((b) => { b.classList.add('ls-quit-fade'); });
      requestAnimationFrame(() => requestAnimationFrame(() => btns.querySelectorAll('.ls-quit-fade').forEach((b) => b.classList.add('in'))));
      wire();
    };
    if (goalDone) {
      words(T('That’s your ' + goalDone + ' minutes — well done! Want to keep going?', 'Voilà vos ' + goalDone + NBS + 'minutes — bravo' + NBS + '! On continue' + NBS + '?'));
      layer.querySelector('.ls-quit-no').textContent = T('Done for today', 'Fini pour aujourd’hui');
      layer.querySelector('.ls-quit-no').classList.add('soft');
      layer.querySelector('.ls-quit-go').textContent = T('Keep going', 'Continuer');
    } else {
      words(gLeft ? goalLine(gLeft, g0) : quitLine(left));
      layer.querySelector('.ls-quit-no').textContent = gLeft ? T('Leave for now', 'Quitter pour l’instant') : T('Quit', 'Quitter');
      layer.querySelector('.ls-quit-go').textContent = T('Keep learning', 'Continuer');
    }
    document.body.appendChild(layer);
    requestAnimationFrame(() => layer.classList.add('on'));

    // fly from the slot (or the top right) into the card
    const slot = homeSlot();
    const from = slot ? box(slot) : { x: innerWidth - 40, y: 60 };
    const flyer = el('div', 'ls-quit-flyer', STAR_SVG);
    document.body.appendChild(flyer);
    const flyTo = (a, bEl, s0, s1, ms, done) => {
      const t0 = performance.now(); cancelAnimationFrame(qFly);
      flyer.style.opacity = '1';
      const step = (now) => {
        const b = typeof bEl === 'function' ? bEl() : bEl;
        const k = Math.min(1, (now - t0) / ms), e = 1 - Math.pow(1 - k, 3);
        const mx = (a.x + b.x) / 2 + (b.x > a.x ? -70 : 70), my = Math.min(a.y, b.y) - 40;
        const px = (1 - e) * (1 - e) * a.x + 2 * (1 - e) * e * mx + e * e * b.x;
        const py = (1 - e) * (1 - e) * a.y + 2 * (1 - e) * e * my + e * e * b.y;
        const sz = s0 + (s1 - s0) * e;
        flyer.style.transform = 'translate(' + (px - 50) + 'px,' + (py - 50) + 'px) rotate(' + ((1 - e) * -360) + 'deg) scale(' + (sz / 100) + ')';
        if (k < 1) qFly = requestAnimationFrame(step); else { flyer.style.opacity = '0'; if (done) done(); }
      };
      qFly = requestAnimationFrame(step);
    };
    setTimeout(() => {
      if (!layer.isConnected) return;
      flyTo(from, () => box(home), 34, 58, 760, () => {
        if (!layer.isConnected) return;
        layer.classList.add('landed');
        const h = box(home); burst(h.x, h.y, goalDone ? 22 : 10); if (goalDone) { ringFx(h.x, h.y, true); SFX.land(); } else SFX.star();
        talkNow();
      });
    }, 220);

    const close = (keep) => {
      qTalk.forEach(clearTimeout); qTalk = [];
      layer.classList.remove('on');
      if (keep && layer.classList.contains('landed')) {
        const h = box(home); layer.classList.remove('landed');
        flyTo(h, () => { const s2 = homeSlot(); return s2 ? box(s2) : { x: innerWidth - 40, y: 60 }; }, 58, 34, 620, () => {
          flyer.remove(); quitOpen = false; const s2 = homeSlot(); if (s2) { const b = box(s2); burst(b.x, b.y, 8); }
        });
      } else { cancelAnimationFrame(qFly); flyer.remove(); quitOpen = false; }
      if (keep) setTimeout(() => layer.remove(), 320);
      else { layer.remove(); go(); }
    };
    const on = (sel, f) => { const b = layer.querySelector(sel); if (b) b.addEventListener('click', (e) => { e.stopPropagation(); f(e); }); };
    on('.ls-quit-go', () => close(true));
    on('.ls-quit-veil', () => close(true));
    // Leaving is always allowed — but the app never offers to shrink the goal.
    // Suggesting 5 minutes at the moment someone wants to stop just teaches them
    // to aim lower; the goal they set stands, and they can change it in Settings.
    on('.ls-quit-no', () => close(false));
  }
  // Every lesson ✕ asks first (capture phase, before the view's own handler).
  window.addEventListener('click', (e) => {
    const b = e.target && e.target.closest && e.target.closest('.qx-close, .lm-close');
    if (!b || b._lsOk) return;
    const pr = progress();
    if (!goalLeft() && (!pr.total || pr.done === 0 || pr.done >= pr.total)) { reportMin(); return; }
    e.preventDefault(); e.stopImmediatePropagation();
    askQuit(() => { b._lsOk = true; try { b.click(); } finally { b._lsOk = false; } });
  }, true);

  window.lsStar = {
    slot: slotEl, row: rowEl, xpPill, award, intro, setHelp, explain, tuck, celebrate, encourage, wrongTone, timeTone,
    isTalking: () => talking || quitOpen, busy: () => !!party, tone: () => click(0, 0.12), askQuit,
  };

  // ── One-line auto-fit, shared by every card that shows a sentence ──────
  // A sentence card reads badly when its one line breaks in two ("وَعَلَيْكُم /
  // السَّلام"), so every Arabic line — and the translation under it — starts at
  // its designed size and steps the font down until the whole sentence sits on
  // ONE line. Floors keep it legible (Arabic keeps its diacritics readable); if
  // one line is impossible even at the floor it wraps instead of overflowing,
  // and then comes back down from the top to the largest size that still fits
  // two lines, so a long line lands on a comfortable layout, never a cramped one.
  // The line is usually a row of per-word spans (tap-a-word, glossaries, audio
  // highlighting), so the container is measured, never a single text node.
  // fitOne(el, { max, min, twoLineMin, box }) — box: the element whose content
  // width is the room available (defaults to the parent).
  // Floors: Arabic keeps its diacritics legible, so it never goes tiny; the big
  // dialogue / vocabulary cards stop at 26px, smaller cards at 20px, Latin at 15px.
  const AR_FLOOR = 26, AR_SMALL = 20, LAT_FLOOR = 15;
  window.lsFitFloor = { ar: AR_FLOOR, arSmall: AR_SMALL, latin: LAT_FLOOR };
  const FIT_MAX = 8;   // ancestors to look through for the box that sets the width
  function fitBox(el, o){
    if (o && o.box && o.box.isConnected) return o.box;
    const id = el.getAttribute('data-fit-box');
    if (id) { const n = el.closest('.' + id); if (n && n !== el) return n; }
    return el.parentElement;
  }
  // Room for the element's own inline content: the box's content width, less
  // everything between the box and the text (margins, borders, padding).
  function availW(el, o){
    const box = fitBox(el, o);
    if (!box) return 0;
    const bs = getComputedStyle(box);
    let w = box.clientWidth - (parseFloat(bs.paddingLeft) || 0) - (parseFloat(bs.paddingRight) || 0);
    for (let n = el, i = 0; n && n !== box && i < FIT_MAX; n = n.parentElement, i++) {
      const s = getComputedStyle(n);
      w -= (parseFloat(s.marginLeft) || 0) + (parseFloat(s.marginRight) || 0) +
           (parseFloat(s.borderLeftWidth) || 0) + (parseFloat(s.borderRightWidth) || 0) +
           (parseFloat(s.paddingLeft) || 0) + (parseFloat(s.paddingRight) || 0);
    }
    return Math.max(0, w);
  }
  // Out-of-flow bits (a tapped word's glossary bubble) must not count as width.
  function hideFloating(el){
    const kept = [];
    try {
      el.querySelectorAll('*').forEach((n) => {
        const p = getComputedStyle(n).position;
        if (p === 'absolute' || p === 'fixed') { kept.push([n, n.style.display]); n.style.display = 'none'; }
      });
    } catch (e) {}
    return kept;
  }
  // width of one line, however it is built (a text node or a row of spans)
  function lineW(q){
    let w = 0;
    try { const r = document.createRange(); r.selectNodeContents(q); w = r.getBoundingClientRect().width; } catch (e) {}
    return w || q.scrollWidth;
  }
  function contentH(q){
    const s = getComputedStyle(q);
    return q.scrollHeight - (parseFloat(s.paddingTop) || 0) - (parseFloat(s.paddingBottom) || 0);
  }
  function fitOne(el, o){
    o = o || {};
    if (!el || !el.isConnected) return;
    // the designed size, remembered once so repeat passes never shrink twice
    let max = parseFloat(el.getAttribute('data-fit-max'));
    if (!(max > 0)) {
      max = parseFloat(el.getAttribute('data-max')) || parseFloat(o.max) ||
            parseFloat(el.style.fontSize) || parseFloat(getComputedStyle(el).fontSize) || 20;
      el.setAttribute('data-fit-max', String(max));
      if (o.min != null && !el.hasAttribute('data-min')) el.setAttribute('data-min', String(o.min));
      if (o.twoLineMin != null) el.setAttribute('data-min2', String(o.twoLineMin));
      el.classList.add('ls-fit');
    }
    let min = parseFloat(el.getAttribute('data-min')) || parseFloat(o.min) || Math.min(max, 15);
    if (min > max) min = max;
    let two = parseFloat(el.getAttribute('data-min2')) || parseFloat(o.twoLineMin) || min;
    if (two > max) two = max;
    const a = availW(el, o);
    if (!a) return;
    const flex = getComputedStyle(el).display.indexOf('flex') >= 0;
    const hidden = hideFloating(el);
    try {
      el.style.whiteSpace = 'nowrap';
      if (flex) el.style.flexWrap = 'nowrap';
      let s = max; el.style.fontSize = s + 'px';
      // guess the size from how far over the line is, then walk the last half-pixels
      for (let i = 0; i < 4; i++) {
        const w = lineW(el);
        if (w <= a || s <= min) break;
        s = Math.max(min, Math.floor((s * a / w) * 2) / 2);
        el.style.fontSize = s + 'px';
      }
      for (let i = 0; i < 12 && s > min && lineW(el) > a; i++) { s = Math.max(min, s - 0.5); el.style.fontSize = s + 'px'; }
      if (lineW(el) <= a + 0.5) return;            // one line — done
      // Too long even at the floor: wrap rather than overflow, and as large as
      // two lines allow, so it reads as a comfortable two-line sentence.
      el.style.whiteSpace = '';
      if (flex) el.style.flexWrap = '';
      s = max; el.style.fontSize = s + 'px';
      const room = () => (parseFloat(getComputedStyle(el).lineHeight) || s * 1.4) * 2 + 2;
      for (let i = 0; i < 48 && s > two && contentH(el) > room(); i++) { s = Math.max(two, s - 1); el.style.fontSize = s + 'px'; }
      // a shrunken Arabic line still needs air, or diacritics touch the line above
      if (el.getAttribute('data-fit-ar')) {
        const lh = parseFloat(getComputedStyle(el).lineHeight) || 0;
        if (!lh || lh / s < 1.45) el.style.lineHeight = '1.5';
      }
    } finally {
      hidden.forEach((p) => { p[0].style.display = p[1]; });
    }
  }
  // Fit once the node is in the DOM: the next frame, again when the web fonts
  // have landed, and a short second pass for late layout.
  function fitSoon(el, o){
    if (!el) return el;
    fitOne(el, o);
    requestAnimationFrame(() => fitOne(el, o));
    setTimeout(() => fitOne(el, o), 280);
    try { if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => fitOne(el, o)); } catch (e) {}
    return el;
  }
  window.lsFit = fitSoon;
  window.lsFitNow = fitOne;

  // The website's own renderers (the quick-review / daily-review cards, the
  // full-conversation view) write their Arabic lines with inline styles and no
  // class of their own, so they are picked up by shape: an inline Amiri, RTL
  // line. They get the same one-line fit as every card built here.
  function sweep(){
    document.querySelectorAll('div[style*="Amiri"]').forEach((n) => {
      if (n.classList.contains('ls-fit') || n.querySelector('div')) return;
      const size = parseFloat(getComputedStyle(n).fontSize) || 0;
      if (size < 20) return;
      fitOne(n, { min: size >= 30 ? AR_FLOOR : AR_SMALL });
      n.setAttribute('data-fit-ar', '1');
    });
  }
  let sweepT = null;
  try {
    new MutationObserver(() => { clearTimeout(sweepT); sweepT = setTimeout(sweep, 80); })
      .observe(document.documentElement, { childList: true, subtree: true });
  } catch (e) {}

  // ── The star asks the question ────────────────────────────────────────
  // A white speech bubble beside the gold star, its tail pointing at it, so the
  // prompt reads as the star asking. The holder carries .ls-slot.ls-ask, which
  // is where the one guide star rests while the bubble is up (see homeSlot).
  const ASK_MAX = 27, ASK_MIN = 17, ASK_AR_MAX = 34, ASK_AR_MIN = 21;
  // the bubble's question uses the same one-line fit as every other card
  function fitAsk(q){ fitOne(q, { max: ASK_MAX, min: ASK_MIN }); }
  function fitAll(){ sweep(); document.querySelectorAll('.ls-fit, .cd-ask-q').forEach((n) => fitOne(n)); }
  let fitT = null;
  addEventListener('resize', () => { clearTimeout(fitT); fitT = setTimeout(fitAll, 120); });
  addEventListener('orientationchange', () => setTimeout(fitAll, 260));
  try { if (document.fonts && document.fonts.ready) document.fonts.ready.then(fitAll); } catch (e) {}
  // o: { cap, text, fill(q), ar, key, onTap, extra, cls }
  function askCard(o){
    o = o || {};
    build();
    const wrap = el('div', 'cd-ask' + (o.cls ? ' ' + o.cls : ''));
    const slot = el('span', 'ls-slot ls-ask');
    slot.setAttribute('aria-hidden', 'true');
    if (o.key) slot.setAttribute('data-ask', String(o.key));
    wrap.appendChild(slot);
    const bub = el('div', 'cd-ask-bub');
    wrap.appendChild(bub);
    if (o.cap) { const c = el('div', 'cd-ask-cap' + (o.capPlain ? ' plain' : '')); c.textContent = o.cap; bub.appendChild(c); }
    const q = el('div', 'cd-ask-q' + (o.ar ? ' ar' : ''));
    if (o.ar) q.dir = 'rtl';
    q.setAttribute('data-max', String(o.max || (o.ar ? ASK_AR_MAX : ASK_MAX)));
    q.setAttribute('data-min', String(o.min || (o.ar ? ASK_AR_MIN : ASK_MIN)));
    if (o.ar) q.setAttribute('data-fit-ar', '1');
    // The stored meaning is sometimes lower-case; the star asks in a sentence.
    const capFirst = (t) => String(t).replace(/^(\s*)(\p{Ll})/u, (m, sp, ch) => sp + ch.toUpperCase());
    if (o.fill) o.fill(q); else q.textContent = o.ar ? (o.text || '') : capFirst(o.text || '');
    bub.appendChild(q);
    if (o.extra) bub.appendChild(o.extra);
    if (o.onTap) {
      bub.classList.add('tap'); bub.setAttribute('role', 'button');
      bub.addEventListener('click', o.onTap);
    }
    fitSoon(q, { max: ASK_MAX, min: ASK_MIN });
    wrap.qNode = q; wrap.bubble = bub;
    return wrap;
  }
  window.lsAsk = askCard;
  window.lsStar.ask = askCard;
  window.lsStar.fit = fitAll;

  // ── Line icons only: no people or animal icons / emoji in lesson views ──
  const ICON_MAP = {
    waving_hand: 'chat', person: 'badge', person_filled: 'badge', person_outline: 'badge', perm_identity: 'badge', face: 'badge', face_unlock: 'badge',
    portrait: 'badge', account_box: 'badge', boy: 'badge', girl: 'badge', man: 'badge', woman: 'badge', artist: 'badge', female: 'badge', male: 'badge',
    groups: 'hub', group: 'hub', people: 'hub', people_alt: 'hub', people_outline: 'hub', family_restroom: 'home', pets: 'eco',
    record_voice_over: 'podcasts', psychology: 'lightbulb', hearing: 'headphones', touch_app: 'adjust', swipe: 'adjust',
    accessibility_new: 'interests', accessible: 'interests', exercise: 'interests', volunteer_activism: 'favorite', personal_injury: 'healing',
    airline_seat_recline_normal: 'chair', cheer: 'celebration', sick: 'healing', skeleton: 'medical_services', emoji_people: 'chat',
  };
  window.lsIcon = (n) => ICON_MAP[n] || n;
  try {
    if (typeof ms === 'function' && !ms._ls) {
      const _ms = ms;
      ms = function(icon){ return _ms(ICON_MAP[icon] || icon); };
      ms._ls = true;
    }
  } catch (e) {}
  // People, body parts, faces and animals (with skin tones / joiners / variation selectors).
  const FIG = /(?:[\u{1F466}-\u{1F487}\u{1F442}-\u{1F450}\u{1F4AA}\u{1F5E3}\u{1F574}-\u{1F57A}\u{1F590}\u{1F595}\u{1F596}\u{1F600}-\u{1F64F}\u{1F6A3}\u{1F6B4}-\u{1F6B6}\u{1F6C0}\u{1F6CC}\u{1F90C}-\u{1F90F}\u{1F910}-\u{1F93E}\u{1F970}-\u{1F97A}\u{1F9B0}-\u{1F9BB}\u{1F9CD}-\u{1F9DF}\u{1FAC3}-\u{1FAC5}\u{1FAF0}-\u{1FAF8}\u{270A}-\u{270D}\u{261D}\u{26F9}\u{1F3C3}-\u{1F3CC}\u{1F400}-\u{1F43F}\u{1F980}-\u{1F9AE}\u{1F54A}\u{1F577}\u{1F578}\u{1F440}\u{1F441}\u{263A}\u{2639}\u{1F479}-\u{1F480}\u{1FAE0}-\u{1FAE8}\u{1F9D0}])(?:[\u{1F3FB}-\u{1F3FF}️]|‍[\s\S]?[️]?)*/gu;
  function clean(root){
    if (!root) return;
    try {
      root.querySelectorAll('.material-symbols-outlined, span[style*="Material Symbols"]').forEach((n) => {
        const v = n.textContent.trim(); if (ICON_MAP[v]) n.textContent = ICON_MAP[v];
      });
      const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      let n; const hits = [];
      while ((n = w.nextNode())) { FIG.lastIndex = 0; if (FIG.test(n.nodeValue)) hits.push(n); }
      hits.forEach((m) => { m.nodeValue = m.nodeValue.replace(FIG, '').replace(/^\s+(?=\S)/, (s) => (m.previousSibling ? s : '')); });
    } catch (e) {}
  }
  window.lsCleanIcons = clean;
  // Thin strips at the top and bottom edges: the app shell reads their colour
  // for the phone's safe areas (the space background is a gradient).
  function edges(layer){
    if (!layer || layer.querySelector(':scope > .ls-edge')) return;
    layer.appendChild(el('div', 'ls-edge t')); layer.appendChild(el('div', 'ls-edge b'));
  }
  window.lsStar.edges = edges;
  // Effects for the part-complete celebration (tools/app-check.js, next section).
  window.lsFx = { burst, ringFx, plus, tone: () => click(0, 0.12), box, fly, svg: STAR_SVG };
  // Star League rivals — the same formula as the app's Circle tab
  // (src/lib/circles.ts → starRivals): steady daily paces around the goal.
  window.lsRivals = function(goal, now){
    now = now || new Date();
    const pad = (n) => String(n).padStart(2, '0');
    const monday = new Date(now); monday.setHours(0, 0, 0, 0); monday.setDate(monday.getDate() - ((monday.getDay() + 6) % 7));
    const key = monday.getFullYear() + '-' + pad(monday.getMonth() + 1) + '-' + pad(monday.getDate());
    const days = Math.min(7, Math.max(0, (now.getTime() - monday.getTime()) / 86400000));
    let h = 2166136261;
    for (let i = 0; i < key.length; i++) h = Math.imul(h ^ key.charCodeAt(i), 16777619) >>> 0;
    const rand = () => { h = Math.imul(h ^ (h >>> 15), 2246822507) >>> 0; h = Math.imul(h ^ (h >>> 13), 3266489909) >>> 0; return ((h ^= h >>> 16) >>> 0) / 4294967296; };
    const names = ['Vega', 'Altair', 'Rigel', 'Sirius', 'Deneb', 'Capella', 'Polaris', 'Antares'];
    for (let i = names.length - 1; i > 0; i--) { const j = Math.floor(rand() * (i + 1)); const t = names[i]; names[i] = names[j]; names[j] = t; }
    const PACE = [1.9, 1.55, 1.3, 1.1, 0.9, 0.7, 0.5, 0.3];
    return names.map((name, i) => ({ name, xp: Math.round(Math.max(10, goal) * PACE[i] * days + rand() * 6) }));
  };
  if (typeof render === 'function') {
    const _render = render;
    render = function(){
      try { if (SHELL_V[S.view]) reportMin(); } catch (e) {}
      const out = _render.apply(this, arguments);
      try { if (S.view === 'lesson' || S.view === 'quickcheck' || S.view === 'complete') clean(document.getElementById('app')); } catch (e) {}
      try { document.querySelectorAll('#app .qx, #app .dl-pearl-layer.lm').forEach(edges); } catch (e) {}
      return out;
    };
  }
  // A new block starts with no XP earned in it yet.
  if (typeof resetBS === 'function') {
    const _reset = resetBS;
    resetBS = function(){ S.lsSecs0 = todaySecs(); S.lsPartXP = 0; S.lsFirst = 0; S.lsRetry = 0; try { S.lsStreak0 = STREAK || 0; } catch (e) { S.lsStreak0 = 0; } setHelp(''); return _reset.apply(this, arguments); };
  }
  // Answers now earn XP one by one (+10, or +5 after a miss). A part that
  // earned XP that way doesn't add the old flat +15 on top when it finishes.
  if (typeof finishBlock === 'function') {
    const _finish = finishBlock;
    finishBlock = function(){
      const part = S.lsPartXP || 0, xp0 = XP;
      const out = _finish.apply(this, arguments);
      if (part > 0 && S.view === 'complete' && XP === xp0 + 15) { XP -= 15; S.lastXP = part; save(); render(); }
      return out;
    };
  }
})();

/* ═══ Lisaany app — Quick check + "what's next" result ═══
   App-only replacements for three website views, same rules underneath:
   • mkQuickCheck — a timer ring and a 2×2 answer grid, with the star guide.
     Right → the star celebrates (+10 XP, +5 after a miss), then Continue.
     Wrong → the tile turns red, the star encourages, the learner tries again.
     Time's up → the right answer shows in green, the star says what it means,
     and the question comes back at the end: every question must be got right.
   • showQuickCheckResult — score ring (right first time), XP earned in the part,
     streak, the unit's progress, and the next block front and centre.
   • mkComplete — the same next-step screen for blocks without a quick check.
   Built into the page by tools/build-lesson-page.py (before the bridge, which
   wraps showQuickCheckResult to report the view). */
(function(){
  // one-line auto-fit (the shared helper is set up in the block above)
  const AR_FLOOR = 26, AR_SMALL = 20, LAT_FLOOR = 15;
  function fitSoon(el, o){ try { if (window.lsFit) window.lsFit(el, o); } catch (e) {} return el; }
  if (typeof mkQuickCheck !== 'function' || typeof showQuickCheckResult !== 'function') return;
  const T = window.lsT || ((en) => en);

  // ── Correct-answer chime (louder than the website's, and never drowned by speech) ──
  let ctx = null;
  window.lsChime = function(){ if (window.lsSfx) window.lsSfx.right(); };
  // speak a word just after the chime has sounded
  window.lsSayAfterChime = function(t){ setTimeout(() => { try { speak(t); } catch (e) {} }, 520); };
  if (window.Lisaany && typeof Lisaany.celebrate === 'function' && !Lisaany._lsWrapped) {
    const orig = Lisaany.celebrate;
    Lisaany.celebrate = function(o){ window.lsChime(); return orig(Object.assign({}, o || {}, { quiet: true })); };
    Lisaany._lsWrapped = true;
  }

  const LIMIT = 10000;
  const TYPE_LABEL = { dialogue:T('Conversation', 'Conversation'), vocab:T('Vocabulary', 'Vocabulaire'), grammar:T('Grammar', 'Grammaire'),
    cloze:T('Listening dictation', 'Dictée'), clutter:T('Sentence builder', 'Construction de phrases'), quiz:T('Practice drill', 'Exercice'),
    fill:T('Sentence fill', 'Phrase à compléter'), seqquiz:T('Quiz', 'Quiz'), possessive:T('Suffix tap', 'Choix du suffixe'),
    swipe:T('Swipe drill', 'Cartes à glisser'), conjugation:T('Conjugation', 'Conjugaison'), video:T('Video', 'Vidéo'), choose:T('Choose', 'Choix') };
  const ICON = {
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    bolt: '<path d="M13 3L5 13.5h6L10 21l8-10.5h-6z"/>',
    vol: '<path d="M4 9.5h3.5L12 6v12l-4.5-3.5H4z"/><path d="M15.5 9a4 4 0 0 1 0 6"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7"/>',
    x: '<path d="M7 7l10 10M17 7L7 17"/>',
    star: '<path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8-5.2-2.8-5.2 2.8 1-5.8-4.3-4.1 5.9-.9z"/>',
    fire: '<path d="M12 21c-4 0-6.5-2.6-6.5-6 0-3.5 3-5.5 3.5-9 2 1.5 3 3.5 3 5 1-1 1.5-2 1.5-3.5 2.5 2 4.5 4.8 4.5 7.5 0 3.4-2.5 6-6 6z"/>',
    fwd: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    target: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r="1"/>',
    replay: '<path d="M4 12a8 8 0 1 0 2.4-5.7M4 4.5v4h4"/>',
  };
  const svg = (n, s, w) => '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="' + (w || 2) +
    '" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ICON[n] + '</svg>';
  function node(tag, cls, html){ const n = document.createElement(tag); if (cls) n.className = cls; if (html != null) n.innerHTML = html; return n; }
  function txt(tag, cls, text){ const n = node(tag, cls); n.textContent = text; return n; }
  function btn(cls, html, label, fn){
    const b = node('button', cls, html); b.type = 'button';
    if (label) b.setAttribute('aria-label', label);
    b.addEventListener('click', (e) => { e.stopPropagation(); fn(e); });
    return b;
  }
  // Countdown clicks for the last 3 seconds, and a low bump at time's up.
  let tickCtx = null;
  // countdown: a woodblock-like click (no notes); a low bump at time's up
  function tick(freq, dur, vol){ const f = window.lsSfx; if (!f) return; if (dur > 0.2) f.bump(0.35); else f.click(0, Math.min(0.3, (vol || 0.1) * 3)); }
  function ring(size, stroke, frac, cls, inner){
    const r = (size - stroke) / 2, c = 2 * Math.PI * r;
    const w = node('div', 'qx-ring ' + (cls || ''));
    w.style.width = w.style.height = size + 'px';
    w.innerHTML = '<svg width="' + size + '" height="' + size + '"><circle cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r +
      '" class="qx-ring-track" stroke-width="' + stroke + '"/><circle cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r +
      '" class="qx-ring-fill" stroke-width="' + stroke + '" stroke-dasharray="' + c.toFixed(1) + '" stroke-dashoffset="' + (c * (1 - frac)).toFixed(1) + '"/></svg>';
    const mid = node('div', 'qx-ring-mid'); if (inner) mid.appendChild(inner); w.appendChild(mid);
    w._set = (f) => { w.querySelector('.qx-ring-fill').setAttribute('stroke-dashoffset', (c * (1 - Math.max(0, Math.min(1, f)))).toFixed(1)); };
    return w;
  }
  function layer(){
    document.body.classList.add('dl-active');
    const root = node('div', 'qx');
    const shell = node('div', 'qx-shell'); root.appendChild(shell);
    return { root, shell };
  }
  function segs(n, lit, cur, cls){
    const s = node('div', cls || 'qx-segs');
    for (let i = 0; i < n; i++) s.appendChild(node('div', 'qx-seg' + (i < lit ? ' done' : i === cur ? ' cur' : '')));
    return s;
  }

  // ── Quick check question ──────────────────────────────────────────────
  mkQuickCheck = function(){
    const qs = S.qcQuestions || [];
    if (!qs.length) { S.view = 'complete'; render(); return div('stage'); }
    // Every question has to be answered right to finish. A wrong tap is tried
    // again straight away; a question whose time runs out goes to the back.
    if (S.qcQueueFor !== qs || !Array.isArray(S.qcQueue) || !S.qcQueue.length) {
      S.qcQueueFor = qs; S.qcQueue = qs.map((_, i) => i); S.qcDone = 0; S.qcMissed = []; S.qcTried = []; S.qcTries = 0;
      S.qcTurn = (S.qcTurn || 0) + 1; S.qcScore = 0; S.qcStreak = 0;
      S.qcLocked = false; S.qcChosen = null; S.qcTimedOut = false; S.qzDeadline = null; S.qcFrozen = null; S.qcNextAt = 0;
    }
    S.qcIdx = S.qcQueue[0];
    const q = qs[S.qcIdx];
    const total = qs.length;
    const locked = !!S.qcLocked;
    const arText = (q.ar || '').split(' — ')[0];
    const shown = (o) => /^[a-z][a-z\-' ]*\s*\((.+)\)$/.test(o) ? o.replace(/^[a-z][a-z\-' ]*\s*\((.+)\)$/, '$1') : o;
    const tried = S.qcTried || [];
    const { root, shell } = layer();
    const star = window.lsStar;

    const top = node('div', 'qx-top');
    top.appendChild(btn('qx-close', svg('close', 16, 2.2), T('Close', 'Fermer'), () => { clearQzTimer(); if (star) star.tuck(); S.view = 'blocks'; render(); }));
    top.appendChild(segs(total, S.qcDone, S.qcDone));
    top.appendChild(txt('div', 'qx-count', Math.min(S.qcDone + 1, total) + '/' + total));
    if (star) { top.appendChild(star.slot()); top.appendChild(star.xpPill()); }
    shell.appendChild(top);
    if (star) shell.appendChild(star.row());
    shell.appendChild(txt('div', 'qx-eyebrow', T('QUICK CHECK · LIGHTNING', 'VÉRIFICATION ÉCLAIR')));

    // One navy card holds the timer, the word, the play button and the answers.
    const dcard = node('div', 'qx-dcard');
    const turnKey = 'qc' + S.qcTurn + ':' + S.qcDone + ':' + S.qcQueue.length + ':' + S.qcIdx;
    if (!S.qzDeadline || S.qzForIdx !== turnKey) { S.qzDeadline = Date.now() + LIMIT; S.qzForIdx = turnKey; }
    const left0 = Math.max(0, S.qzDeadline - Date.now());
    const secEl = node('div', 'qx-sec');
    const num = txt('span', 'qx-sec-n', String(Math.ceil(left0 / 1000)));
    const unit = txt('span', 'qx-sec-u', T('SEC', 'S'));
    secEl.appendChild(num); secEl.appendChild(unit);
    const ok = locked && S.qcChosen === q.correct;
    const timer = ring(96, 5, locked ? (S.qcFrozen || 0) : left0 / LIMIT, locked ? (ok ? 'good' : 'bad') : 'gold', secEl);
    if (locked) num.textContent = String(Math.ceil((S.qcFrozen || 0) * LIMIT / 1000));
    dcard.appendChild(timer);

    const nextBtn = btn('qx-cta ls-next', '<span>' + T('Continue', 'Continuer') + '</span>' + svg('fwd', 18, 2.2), null, () => {
      if (!S.qcLocked) return;
      if (star) star.tuck();
      try { stopAudio(); } catch (_) {}
      const cur = S.qcQueue.shift();
      if (S.qcTimedOut) S.qcQueue.push(cur); else S.qcDone++;
      S.qcTimedOut = false; S.qcLocked = false; S.qcChosen = null; S.qcTried = []; S.qcTries = 0;
      S.qzDeadline = null; S.qcFrozen = null; S.qcNextAt = 0; S.qcTurn = (S.qcTurn || 0) + 1;
      if (S.qcQueue.length) render();
      else { S.qcStreak = 0; showQuickCheckResult(); }
    });
    const showNext = () => { if (document.body.contains(nextBtn)) nextBtn.classList.add('show'); };
    if (locked) { const wait = (S.qcNextAt || 0) - Date.now(); if (wait > 0) setTimeout(showNext, wait); else nextBtn.classList.add('show'); }

    const timeUp = () => {
      clearQzTimer();
      if (S.qcLocked) return;
      S.qcFrozen = 0; S.qcChosen = null; S.qcLocked = true; S.qcTimedOut = true; S.qcStreak = 0;
      if (S.qcMissed.indexOf(S.qcIdx) < 0) S.qcMissed.push(S.qcIdx);
      S.qcNextAt = Date.now() + 900;
      if (star) star.timeTone(); else tick(330, 0.28, 0.08);
      try { speak(arText); } catch (_) {}
      render();
      const m = window.lsFr ? window.lsFr(shown(String(q.correct))) : shown(String(q.correct));
      if (star) star.encourage(0, T('Time’s up! It means “' + m + '”. We’ll come back to it at the end.',
        'Temps écoulé ! Cela veut dire « ' + m + ' ». On y reviendra à la fin.'));
    };

    clearQzTimer();
    if (!locked) {
      let lastSec = Math.ceil(left0 / 1000);
      S.qzTick = setInterval(() => {
        if (!document.body.contains(timer)) { clearQzTimer(); return; }
        // the clock waits while the star is explaining
        if (star && (star.isTalking() || star.busy())) { S.qzDeadline += 100; return; }
        const left = Math.max(0, S.qzDeadline - Date.now());
        timer._set(left / LIMIT);
        timer.classList.toggle('low', left < 3000);
        if (left <= 0) timeUp();
        else {
          const sec = Math.ceil(left / 1000);
          if (sec !== lastSec) { lastSec = sec; if (sec <= 3) tick(sec === 1 ? 1175 : 988, 0.09, 0.07); }
          num.textContent = String(sec);
        }
      }, 100);
    }

    const prompt = node('div', 'qx-prompt');
    const ar = txt('div', 'qx-ar', q.ar || ''); ar.dir = 'rtl';
    if ((q.ar || '').length > 10) ar.classList.add('long');
    ar.setAttribute('data-fit-ar', '1');
    prompt.appendChild(ar);
    fitSoon(ar, { min: AR_FLOOR });
    prompt.appendChild(btn('qx-hear qx-play', svg('vol', 26, 2.2), T('Hear it', 'Écouter'), (e) => { if (e) e.stopPropagation(); try { speak(arText); } catch (_) {} }));
    // the whole word area plays the sound, not just the small speaker
    prompt.classList.add('tap'); prompt.setAttribute('role', 'button');
    prompt.addEventListener('click', () => { try { speak(arText); } catch (_) {} });
    dcard.appendChild(prompt);
    dcard.appendChild(node('div', 'qx-dgrow ls-gap'));
    dcard.appendChild(txt('div', 'qx-ask', q.question || T('What does this mean?', 'Que signifie ceci ?')));

    const grid = node('div', 'qx-grid');
    q.opts.forEach((opt) => {
      const isCor = opt === q.correct;
      let cls = 'qx-opt';
      if (locked) cls += isCor ? ' right' : ' dim';
      else if (tried.indexOf(opt) >= 0) cls += ' tried';
      const b = node('button', cls); b.type = 'button';
      b.appendChild(document.createTextNode(shown(opt)));
      // Arabic choices are gold (the script's colour everywhere else); Latin stays white.
      if (/[\u0600-\u06FF]/.test(opt)) { b.classList.add('ar'); b.dir = 'rtl'; }
      b.dataset.value = opt;
      if (locked && isCor) b.appendChild(node('span', 'qx-mark', svg('check', 16, 2.6)));
      b.addEventListener('click', (e) => {
        e.stopPropagation();
        if (S.qcLocked || b.classList.contains('tried') || b.classList.contains('wrong')) return;
        if (opt === q.correct) {
          S.qcFrozen = Math.max(0, S.qzDeadline - Date.now()) / LIMIT;
          clearQzTimer();
          S.qcChosen = opt; S.qcLocked = true;
          const first = !S.qcTries && S.qcMissed.indexOf(S.qcIdx) < 0;
          const pts = first ? 10 : 5;
          if (first) S.qcScore++;
          S.qcStreak = S.qcTries ? 0 : (S.qcStreak || 0) + 1;
          S.qcNextAt = Date.now() + 1500;
          // show the result in place, so the celebration isn't interrupted by a redraw
          grid.querySelectorAll('.qx-opt').forEach((o) => { o.classList.remove('wrong', 'tried'); o.classList.add(o === b ? 'right' : 'dim'); });
          b.appendChild(node('span', 'qx-mark', svg('check', 16, 2.6)));
          timer.classList.remove('gold', 'low'); timer.classList.add('good');
          if (star) { star.award(pts); star.celebrate({ pts, combo: S.qcStreak }); } else if (window.lsChime) window.lsChime();
          setTimeout(() => { try { speak(arText); } catch (_) {} }, 1700);
          setTimeout(showNext, 1500);
        } else {
          S.qcTries = (S.qcTries || 0) + 1; S.qcStreak = 0;
          if (tried.indexOf(opt) < 0) tried.push(opt); S.qcTried = tried;
          b.classList.add('wrong');
          if (star) { star.wrongTone(); star.encourage(S.qcTries); }
          setTimeout(() => { b.classList.remove('wrong'); b.classList.add('tried'); }, 1300);
        }
      });
      grid.appendChild(b);
    });
    dcard.appendChild(grid);
    shell.appendChild(dcard);
    shell.appendChild(nextBtn);

    // The star explains the task once, when the quick check opens.
    const help = T('Listen, then tap the meaning before the timer runs out.', 'Écoutez, puis touchez le sens avant la fin du chrono.');
    if (star) star.intro(qs, help);
    // Each new word is heard once as it appears (after the star's explanation on the first one).
    const sayKey = turnKey + ':' + (S.qcTimedOut ? 't' : '');
    if (!locked && S.qcSaidKey !== sayKey) {
      S.qcSaidKey = sayKey;
      const first = S.qcDone === 0 && S.qcQueue.length === total && !tried.length;
      setTimeout(() => { if (document.body.contains(timer) && !S.qcLocked) { try { speak(arText); } catch (_) {} } }, first ? 5200 : 350);
    }
    return root;
  };

  // ── Next-step screen (quick-check result and plain block complete) ─────
  function nextStep(o){
    const { root, shell } = layer();
    const unit = getUnit(S.mId, S.uId) || { blocks: [] };
    const blk = getBlk(S.mId, S.uId, S.bId) || {};
    const idx = unit.blocks.findIndex((b) => b.id === S.bId);
    const next = idx >= 0 ? unit.blocks[idx + 1] : null;
    const doneN = unit.blocks.filter((b) => getBlock_(S.mId, S.uId, b.id) === 'done').length;

    // ── Celebration: the star shoots into the daily-goal ring, the ring fills,
    //    the numbers count up, the star says how it went, the streak ticks and
    //    the Star League card moves. Numbers are the learner's real ones.
    const day = (window.__LISAANY_APP && window.__LISAANY_APP.day) || null;
    const partXP = Math.max(0, o.xp || 0);
    const gained = day ? Math.max(0, (typeof XP === 'number' ? XP : 0) - day.xp) : partXP;
    const goal = day ? Math.max(1, day.goal) : 20;
    const dayNow = day ? day.dayXp + gained : partXP;
    const dayBefore = Math.max(0, dayNow - partXP);
    const weekNow = day ? day.weekXp + gained : partXP;
    const weekBefore = Math.max(0, weekNow - partXP);
    const first = S.lsFirst || 0, retry = S.lsRetry || 0, answered = first + retry;
    const streakNow = (typeof STREAK === 'number' ? STREAK : 0) || 0;
    const streak0 = typeof S.lsStreak0 === 'number' ? S.lsStreak0 : streakNow;
    const NB = ' ';

    const cel = node('div', 'lc');
    // The star lands here (no ring: the day's XP shows in the XP tile and the star's words).
    const hero = node('div', 'lc-hero');
    cel.appendChild(hero);
    const kick = txt('div', 'lc-kick', o.eyebrow);
    cel.appendChild(kick);
    const title = txt('div', 'lc-title', T('Well done!', 'Bravo' + NB + '!'));
    cel.appendChild(title);
    const sub = txt('div', 'lc-sub', [blk.title, unit.title].filter(Boolean).join(' · '));
    cel.appendChild(sub);
    const talk = node('div', 'lc-talk', '<div class="lc-row"><span class="lc-anchor"></span><div class="lc-bub"></div></div>');
    cel.appendChild(talk);

    const tiles = node('div', 'lc-stats');
    const tile = (icon, val, label, cls) => { const d = node('div', 'lc-st' + (cls ? ' ' + cls : ''), svg(icon, 18) + '<b>' + val + '</b><small></small>'); d.querySelector('small').textContent = label; tiles.appendChild(d); return d; };
    const tXP = tile('star', '+<span>0</span>', T('XP earned', 'XP gagnés'), 'gold');
    const tAcc = answered
      ? tile('target', '<span>0</span>%', T('right first time', 'justes du premier coup'))
      : tile('check', doneN + '/' + unit.blocks.length, T('parts done', 'parties faites'));
    const tStr = tile('fire', '<span>' + streak0 + '</span>', T('day streak', 'jours de série'));
    cel.appendChild(tiles);

    // Star League: the same rivals as the app's Circle tab.
    const rivals = window.lsRivals ? window.lsRivals(goal) : [];
    const rankOf = (xp) => 1 + rivals.filter((r) => r.xp > xp).length;
    const r0 = rankOf(weekBefore), r1 = rankOf(weekNow);
    const passed = rivals.filter((r) => r.xp > weekBefore && r.xp <= weekNow).sort((a, b) => b.xp - a.xp);
    const aheadNow = rivals.filter((r) => r.xp > weekNow).sort((a, b) => a.xp - b.xp)[0];
    const ord = (n) => (window.lsT && T('x', 'y') === 'y') ? (n === 1 ? '1er' : n + 'e') : n + (n % 100 >= 11 && n % 100 <= 13 ? 'th' : ['th', 'st', 'nd', 'rd'][n % 10] || 'th');
    let league = null;
    if (rivals.length) {
      league = node('div', 'lc-league');
      const rk = node('div', 'lc-rank', '<span class="o">' + r0 + '</span><span class="n">' + r1 + '</span>');
      league.appendChild(rk);
      const lt = node('div', 'lc-lt');
      lt.appendChild(txt('b', '', r1 === 1 ? T('Top of the Star League', 'En tête de la Ligue des étoiles') : T('Now ' + ord(r1) + ' in the Star League', ord(r1) + ' de la Ligue des étoiles')));
      lt.appendChild(txt('small', '', passed.length
        ? T('You passed ' + passed.map((r) => r.name).join(', '), 'Vous avez dépassé ' + passed.map((r) => r.name).join(', '))
        : aheadNow ? T((aheadNow.xp - weekNow + 1) + ' XP to pass ' + aheadNow.name, 'Encore ' + (aheadNow.xp - weekNow + 1) + NB + 'XP pour dépasser ' + aheadNow.name) : ''));
      league.appendChild(lt);
      if (r1 < r0) { league.classList.add('moving'); league.appendChild(txt('span', 'lc-up', '▲ ' + (r0 - r1))); }
      cel.appendChild(league);
    }
    shell.appendChild(cel);

    // What the star says, in order.
    const lines = [];
    if (answered) lines.push(retry === 0
      ? T('Perfect — every answer right first time!', 'Parfait — tout juste du premier coup' + NB + '!')
      : T('Great work — ' + first + ' of ' + answered + ' right first time.', 'Excellent travail — ' + first + ' sur ' + answered + ' justes du premier coup.'));
    else lines.push(T('Nice work — part ' + doneN + ' of ' + unit.blocks.length + ' done.', 'Bien joué — partie ' + doneN + ' sur ' + unit.blocks.length + ' terminée.'));
    // With a daily minutes goal, "goal reached" means the minutes crossed it during this part.
    const mg = window.lsToday ? window.lsToday().goalMin : 0;
    const secsNow = mg ? window.lsToday().secs : 0, secs0 = typeof S.lsSecs0 === 'number' ? S.lsSecs0 : secsNow;
    const cheered = !!(window.lsMinutes && window.lsMinutes.hit());
    const goalHit = mg ? (secs0 < mg * 60 && secsNow >= mg * 60 && !cheered) : (dayBefore < goal && dayNow >= goal);
    if (goalHit && mg && window.lsMinutes) window.lsMinutes.markHit(); // recorded, never announced
    if (streakNow > streak0) lines.push(streakNow === 1 ? T('Day 1 of your streak — a great start!', 'Jour 1 de votre série — un beau début' + NB + '!') : T('That’s ' + streakNow + ' days in a row!', streakNow + ' jours d’affilée' + NB + '!'));
    if (passed.length) lines.push(T('You passed ' + passed[0].name + ' in the Star League!', 'Vous avez dépassé ' + passed[0].name + ' dans la Ligue des étoiles' + NB + '!'));

    requestAnimationFrame(() => runCelebration({ cel, hero, kick, title, sub, talk, tiles: [tXP, tAcc, tStr], league, goal, dayBefore, dayNow, partXP, acc: answered ? Math.round(first / answered * 100) : null, streak0, streakNow, moved: r1 < r0, lines }));

    if (o.passed && next) {
      const card = node('div', 'qx-next');
      // The whole card starts the next part.
      card.setAttribute('role', 'button');
      card.addEventListener('click', () => goNextBlock());
      card.appendChild(txt('div', 'qx-next-lbl', T('UP NEXT · PART ' + (idx + 2) + ' OF ' + unit.blocks.length, 'ENSUITE · PARTIE ' + (idx + 2) + ' SUR ' + unit.blocks.length)));
      const row = node('div', 'qx-next-row');
      const ic = node('div', 'qx-next-ic');
      try { ic.appendChild(ms(next.icon || 'play_arrow')); } catch (_) {}
      row.appendChild(ic);
      const t = node('div', '');
      t.appendChild(txt('div', 'qx-next-title', next.title || T('Next part', 'Partie suivante')));
      const d = next.data || {};
      const size = next.type === 'dialogue' && d.lines ? d.lines.length + T(' lines', ' répliques') : next.type === 'vocab' && d.words ? d.words.length + T(' words', ' mots') : '';
      t.appendChild(txt('div', 'qx-next-sub', (TYPE_LABEL[next.type] || T('Lesson', 'Leçon')) + (size ? ' · ' + size : '')));
      row.appendChild(t);
      card.appendChild(row);
      if (next.desc) {
        const isAr = /[\u0600-\u06FF]/.test(next.desc);
        const ds = txt('div', 'qx-next-desc', next.desc); ds.dir = isAr ? 'rtl' : 'ltr';
        if (isAr) ds.setAttribute('data-fit-ar', '1');
        card.appendChild(ds);
        fitSoon(ds, { min: isAr ? AR_SMALL : LAT_FLOOR });
      }
      // No "Start" inside the card: the "Next part →" button below is the single
      // primary action (the card stays tappable and does the same thing).
      shell.appendChild(card);
    } else if (o.passed && !next) {
      const card = node('div', 'qx-next done');
      card.appendChild(txt('div', 'qx-next-lbl', T('LESSON COMPLETE', 'LEÇON TERMINÉE')));
      card.appendChild(txt('div', 'qx-next-title', T('Every part of ' + (unit.title || 'this lesson') + ' is done.', 'Toutes les parties de ' + (unit.title || 'cette leçon') + ' sont faites.')));
      shell.appendChild(card);
    }

    shell.appendChild(node('div', 'qx-grow'));
    let pairRow = null;
    for (const a of o.actions) {
      if (a.pair) {
        if (!pairRow) { pairRow = node('div', 'qx-pair'); shell.appendChild(pairRow); }
        pairRow.appendChild(btn('qx-ghost' + (a.icon === 'replay' ? ' gold' : ''), (a.icon === 'replay' ? REPLAY_SVG : BACK_SVG) + '<span>' + a.label + '</span>', null, a.run));
        continue;
      }
      shell.appendChild(btn(a.primary ? 'qx-cta' : 'qx-link', a.primary ? '<span>' + a.label + '</span>' + svg(a.icon || 'fwd', 18, 2.2) : a.label, null, a.run));
    }
    return root;
  }
  // Timeline for the part-complete celebration (CSS transitions + timers only).
  function runCelebration(c){
    const fx = window.lsFx;
    const alive = () => c.cel.isConnected;
    const at = (ms, f) => setTimeout(() => { if (alive()) { try { f(); } catch (e) {} } }, ms);
    const count = (el, from, to, ms) => { const t0 = performance.now(); const step = (n) => { if (!alive()) return; const k = Math.min(1, (n - t0) / ms), e = 1 - Math.pow(1 - k, 3); el.textContent = Math.round(from + (to - from) * e); if (k < 1) requestAnimationFrame(step); }; requestAnimationFrame(step); };
    const center = (el) => { const r = el.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; };
    // the star: a fixed layer while it flies, then it settles into the talk row
    const star = node('div', 'lc-star', fx ? fx.svg : '');
    document.body.appendChild(star);
    const cleanup = () => { if (!alive()) { star.remove(); return true; } return false; };
    const watch = setInterval(() => { if (cleanup()) clearInterval(watch); }, 400);
    const place = (x, y, s, r, ms, ease) => { star.style.transition = ms ? 'transform ' + ms + 'ms ' + (ease || 'cubic-bezier(.2,.8,.3,1)') + ',opacity .3s' : 'none'; star.style.transform = 'translate(' + x + 'px,' + y + 'px) rotate(' + (r || 0) + 'deg) scale(' + s + ')'; };
    const tone = fx ? fx.tone : () => {};
    const sfx = window.lsSfx || { whoosh(){}, land(){}, sparkle(){}, levelUp(){}, tick(){} };
    const fanfare = () => sfx.land();
    // The star never covers words. .lc-hero is empty space kept for it above the
    // kicker and the title, so every size and radius below is measured from that
    // box: the landing scale, the loop radius and the burst all stay inside it at
    // any screen width. HALO is how far the star's glow reaches out of its own
    // 100px box (the halo circle is r=62 in a 100 viewBox).
    const HALO = 0.62;
    const room = () => { const r = c.hero.getBoundingClientRect(); return Math.max(40, Math.min(r.width, r.height) / 2); };
    const r0 = room();
    const landS = Math.min(0.95, r0 / (100 * HALO));        // lands filling its space, glow and all
    const loopS = Math.max(0.42, landS * 0.62);             // smaller while it loops…
    const loopR = Math.max(8, r0 - 100 * HALO * loopS);     // …so the loop still fits inside
    const h0 = center(c.hero);
    place(-60, h0.y - 170, landS * 0.74, -120, 0);
    star.style.opacity = '1';
    // trail
    const trail = node('div', 'lc-trail');
    trail.style.left = '-40px'; trail.style.top = (h0.y - 170) + 'px'; trail.style.width = (h0.x + 40) + 'px';
    document.body.appendChild(trail);
    requestAnimationFrame(() => requestAnimationFrame(() => { place(h0.x, h0.y, landS, 0, 750); trail.classList.add('go'); sfx.whoosh(700); }));
    setTimeout(() => { trail.classList.add('out'); setTimeout(() => trail.remove(), 700); }, 700);
    at(760, () => { const h = center(c.hero); if (fx) fx.burst(h.x, h.y, 26); fanfare(); });
    let looping = false;
    at(1050, () => { c.kick.classList.add('on'); c.title.classList.add('on'); c.sub.classList.add('on'); });
    at(1400, () => { c.tiles[0].classList.add('on'); count(c.tiles[0].querySelector('span'), 0, c.partXP, 900); for (let i = 0; i < 8; i++) setTimeout(() => { if (alive()) sfx.tick(); }, i * 105); });
    at(1600, () => { c.tiles[1].classList.add('on'); if (c.acc != null) count(c.tiles[1].querySelector('span'), 0, c.acc, 900); });
    at(1800, () => { c.tiles[2].classList.add('on'); });
    // the star loops the ring, then moves to the talk row and speaks
    at(2300, () => { const h = center(c.hero); const R = loopR; let a = 0; const t0 = performance.now(); star.style.transition = 'none'; looping = true;
      const loop = (n) => { if (!alive() || !looping) return; a = (n - t0) / 1000 * 6.2; place(h.x + Math.sin(a) * R, h.y + Math.cos(a) * R, loopS, a * 57, 0); if (n - t0 < 900) requestAnimationFrame(loop); else looping = false; };
      requestAnimationFrame(loop); });
    const bub = c.talk.querySelector('.lc-bub'), anchor = c.talk.querySelector('.lc-anchor');
    // Down the side, never across the words. The star leaves its space sideways,
    // small, in a column clear of the kicker and the title, drops straight down
    // that column and only then settles beside the bubble. A diagonal from the
    // hero to the talk row would cut right through the words. If a screen is so
    // narrow that no clear column exists, the star steps out of sight for the
    // move instead of crossing them.
    const TINY = 0.36;
    const sideColumn = () => {
      const half = 100 * HALO * TINY;
      const lefts = [c.kick, c.title, c.sub].filter(Boolean)
        .map((e) => e.getBoundingClientRect()).filter((r) => r.width > 0).map((r) => r.left);
      const lim = Math.min.apply(null, lefts.concat([innerWidth]));
      const x = Math.min(center(anchor).x, lim - half - 6);
      return x >= half + 2 ? x : null;
    };
    let parked = false;
    const say = (text) => {
      looping = false;                 // the loop never fights the move to the talk row
      bub.classList.remove('on'); bub.innerHTML = '';
      text.split(/(\s+)/).forEach((w) => { if (!w) return; if (/^\s+$/.test(w)) { bub.appendChild(document.createTextNode(w)); return; } const sp = document.createElement('span'); sp.className = 'w'; sp.textContent = w; bub.appendChild(sp); });
      c.talk.style.height = c.talk.firstElementChild.offsetHeight + 'px';
      const settle = (ms) => { const a = center(anchor); place(a.x, a.y, 0.56, 0, ms); star.style.opacity = '1'; };
      const firstMove = !parked;
      if (firstMove) {
        parked = true;
        const col = sideColumn();
        at(30, () => { if (col == null) { star.style.transition = 'opacity .18s'; star.style.opacity = '0'; } else place(col, center(c.hero).y, TINY, 0, 200); });
        at(250, () => { if (col == null) { const a = center(anchor); place(a.x, a.y, 0.56, 0, 0); } else place(col, center(anchor).y, TINY, 0, 220); });
        at(500, () => settle(col == null ? 0 : 180));
      } else at(30, () => settle(220));
      setTimeout(() => { if (!alive()) return; bub.classList.add('on'); bub.querySelectorAll('.w').forEach((w, i) => setTimeout(() => w.classList.add('lit'), 100 + i * 80)); }, firstMove ? 620 : 400);
    };
    let t = 3300;
    c.lines.forEach((line, i) => {
      at(t, () => say(line));
      if (i === 0 && c.streakNow > c.streak0) at(t + 1500, () => { const s = c.tiles[2].querySelector('span'); s.style.transform = 'rotateX(90deg)'; setTimeout(() => { s.textContent = c.streakNow; s.style.transform = ''; const p = center(s); if (fx) fx.burst(p.x, p.y, 8); sfx.sparkle(); }, 320); });
      t += 2200;
    });
    if (c.league) at(Math.max(4200, t - 2000), () => {
      c.league.classList.add('on');
      if (c.moved) setTimeout(() => { if (!alive()) return; c.league.classList.add('moved'); const p = center(c.league.querySelector('.lc-rank')); if (fx) fx.burst(p.x, p.y, 10); sfx.levelUp(); }, 500);
    });
    // keep the star parked beside the bubble while the page scrolls
    const park = () => { if (!alive()) return; const a = center(anchor); if (c.talk.offsetHeight > 0) place(a.x, a.y, 0.56, 0, 0); requestAnimationFrame(park); };
    at(t + 200, () => requestAnimationFrame(park));
  }
  const REPLAY_SVG = '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12a8 8 0 1 1-2.3-5.7"/><path d="M20 4v5h-5"/></svg>';
  const BACK_SVG = '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M11 6l-6 6 6 6"/></svg>';
  function goNextBlock(){
    const unit = getUnit(S.mId, S.uId) || { blocks: [] };
    const idx = unit.blocks.findIndex((b) => b.id === S.bId);
    const next = idx >= 0 ? unit.blocks[idx + 1] : null;
    if (next) { S.bId = next.id; resetBS(); S.view = 'lesson'; render(); }
    else { S.view = 'units'; render(); }
  }
  function nextActions(){
    const unit = getUnit(S.mId, S.uId) || { blocks: [] };
    const idx = unit.blocks.findIndex((b) => b.id === S.bId);
    const last = !(idx >= 0 && unit.blocks[idx + 1]);
    const prev = idx > 0 ? unit.blocks[idx - 1] : null;
    const again = () => { if (window.lsRestartPart) window.lsRestartPart(); else { resetBS(); S.view = 'lesson'; render(); } };
    return [
      { label: last ? T('Finish lesson', 'Terminer la leçon') : T('Next part', 'Partie suivante'), primary: true, run: goNextBlock },
      { label: T('Do it again', 'Recommencer'), pair: true, icon: 'replay', run: again },
      prev ? { label: T('Previous', 'Précédente'), pair: true, icon: 'back', run: () => { S.bId = prev.id; resetBS(); S.view = 'lesson'; render(); } } : null,
      { label: T('Back to lesson', 'Retour à la leçon'), run: () => { S.view = 'blocks'; render(); } },
    ].filter(Boolean);
  }

  showQuickCheckResult = function(){
    clearQzTimer();
    // Every question ends answered right (wrong taps are retried, timed-out ones
    // come back at the end), so the quick check always counts as passed. The
    // ring shows how many were right first time; XP was earned answer by answer.
    const total = (S.qcQuestions || []).length;
    const score = Math.min(S.qcScore || 0, total);
    const earnedXP = S.lsPartXP || 0;
    S.lastXP = earnedXP; save();
    const blk = getBlk(S.mId, S.uId, S.bId) || {};
    const screen = nextStep({
      score, total, passed: true, xp: earnedXP,
      eyebrow: T('Quick Check Passed', 'Vérification réussie'), title: T((blk.title || 'Part') + ' done', (blk.title || 'Partie') + '\u00a0: terminé'),
      sub: score < total ? T(score + ' of ' + total + ' right first time.', score + ' sur ' + total + ' justes du premier coup.') : '',
      actions: nextActions(),
    });
    const app = document.getElementById('app'); app.innerHTML = '';
    app.appendChild(screen);
    try { if (window.lsStar) window.lsStar.edges(screen); } catch (_) {}
    try { if (window.Lisaany) Lisaany.celebrate(); } catch (_) {}
  };

  mkComplete = function(){
    const blk = getBlk(S.mId, S.uId, S.bId) || {};
    return nextStep({
      score: null, passed: true, xp: S.lastXP || 15,
      eyebrow: T('Part Complete', 'Partie terminée'), title: T((blk.title || 'Part') + ' done', (blk.title || 'Partie') + '\u00a0: terminé'),
      actions: nextActions(),
    });
  };
})();
