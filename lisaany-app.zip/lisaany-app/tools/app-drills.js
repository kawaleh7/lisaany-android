/* ═══ Lisaany app — grammar, practice drill, listen & choose, sentence builder, dictation ═══
   App-only replacements for five website views. Same data, same scoring and
   pass rules underneath (advQuiz / advFill / advClutter / advCloze / finishBlock);
   only the screens change:
   • one top bar (close · progress · count), no score boxes, no extra headers
   • no feedback panel: right answers get the star's celebration and a
     Continue button; wrong ones turn red for a moment and are tried again
   • grammar is a short step-through: rule → examples, tap anything to hear it
   Built into the page by tools/build-lesson-page.py after app-cards.js; reuses
   the .qx / .cd styles from app-check.css and app-cards.css. */
(function(){
  if (typeof mkGrammar !== 'function' || typeof mkQuiz !== 'function' || typeof mkFill !== 'function' ||
      typeof mkClutter !== 'function' || typeof mkCloze !== 'function') return;

  const ICON = {
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    vol: '<path d="M4 9.5h3.5L12 6v12l-4.5-3.5H4z"/><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7"/>',
    x: '<path d="M7 7l10 10M17 7L7 17"/>',
    fwd: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    back: '<path d="M19 12H5M11 6l-6 6 6 6"/>',
    replay: '<path d="M4 12a8 8 0 1 0 2.4-5.7M4 4.5v4h4"/>',
    bulb: '<path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2V16h5v-.1c0-.8.4-1.5 1-2A6 6 0 0 0 12 3z"/>',
  };
  const svg = (n, s, w) => '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="' + (w || 2) +
    '" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ICON[n] + '</svg>';
  function node(tag, cls, html){ const n = document.createElement(tag); if (cls) n.className = cls; if (html != null) n.innerHTML = html; return n; }
  function txt(tag, cls, text){ const n = node(tag, cls); n.textContent = text; return n; }
  function artxt(tag, cls, text){ const n = txt(tag, cls, text); n.dir = 'rtl'; n.setAttribute('data-fit-ar', '1'); return n; }
  // one-line auto-fit (shared helper, defined in app-check.js)
  const FLOOR = { ar: 26, arSmall: 20, latin: 15 };
  function fit(el, o){ try { if (window.lsFit) window.lsFit(el, o); } catch (e) {} return el; }
  function btn(cls, html, label, fn){
    const b = node('button', cls, html); b.type = 'button';
    if (label) b.setAttribute('aria-label', label);
    b.addEventListener('click', (e) => { e.stopPropagation(); fn(e); });
    return b;
  }
  const T = (en, fr) => (window.lsT ? window.lsT(en, fr) : en);
  const say = (t) => { try { stopAudio(); } catch (e) {} try { if (t) speak(t); } catch (e) {} };
  const quiet = () => { try { stopAudio(); } catch (e) {} };
  const AR = /[؀-ۿ]/;
  const meaning = (en) => { const m = String(en || '').match(/^([a-z][a-z\-' ]*)\s*\((.+)\)$/); return m ? m[2] : String(en || ''); };
  const noRoman = (s) => String(s || '').replace(/\s*\([a-zāīūḥṣḍṭẓʿʾ\-' ]+\)/g, '');
  // mixed Arabic/English: isolate each Arabic run (gold when asked)
  function bidi(tag, cls, text, goldAr){
    const n = node(tag, cls);
    String(text).split(/([؀-ۿ][؀-ۿً-ْ\s]*[؀-ۿً-ْ]|[؀-ۿ])/).forEach((part) => {
      if (!part) return;
      if (AR.test(part)) { const b = document.createElement('bdi'); b.className = 'cd-bidi' + (goldAr ? ' gold' : ''); b.dir = 'rtl'; b.textContent = part; n.appendChild(b); }
      else n.appendChild(document.createTextNode(part));
    });
    n.dir = 'ltr';
    return n;
  }

  function layer(extra){
    document.body.classList.add('dl-active');
    const root = node('div', 'qx cd dx' + (extra ? ' ' + extra : ''));
    const shell = node('div', 'qx-shell'); root.appendChild(shell);
    return { root, shell };
  }
  function topBar(shell, done, total, onClose){
    const top = node('div', 'qx-top');
    top.appendChild(btn('qx-close', svg('close', 16, 2.2), 'Close', onClose));
    if (total <= 12) {
      const s = node('div', 'qx-segs');
      for (let i = 0; i < total; i++) s.appendChild(node('div', 'qx-seg' + (i < done ? ' done' : i === done ? ' cur' : '')));
      top.appendChild(s);
    } else {
      const t = node('div', 'cd-track'); const f = node('div', 'cd-fill');
      f.style.width = Math.round(100 * done / Math.max(1, total)) + '%'; t.appendChild(f); top.appendChild(t);
    }
    top.appendChild(txt('div', 'qx-count', Math.min(done + 1, total) + '/' + total));
    if (window.lsStar) { top.appendChild(window.lsStar.slot()); top.appendChild(window.lsStar.xpPill()); }
    shell.appendChild(top);
    if (window.lsStar) shell.appendChild(window.lsStar.row());
  }
  // Continue button that waits below the answers until a question is done.
  function nextButton(fn){ return btn('qx-cta ls-next', '<span>' + T('Continue', 'Continuer') + '</span>' + svg('fwd', 18, 2.2), null, fn); }
  // Right answer: star celebration (+10 XP, +5 after a miss), Continue appears,
  // and the next question follows on its own.
  function rightAnswer(first, next, advance, spoken){
    const star = window.lsStar;
    S.lsStreak = first ? (S.lsStreak || 0) + 1 : 0;
    const pts = first ? 10 : 5;
    if (star) { star.award(pts); star.celebrate({ pts, combo: S.lsStreak }); } else if (window.lsChime) window.lsChime();
    if (spoken) setTimeout(() => say(spoken), 1650);
    setTimeout(() => { if (document.body.contains(next)) next.classList.add('show'); }, 1300);
    setTimeout(() => { if (document.body.contains(next)) advance(); }, 2700);
  }
  function wrongAnswer(tries){
    S.lsStreak = 0;
    const star = window.lsStar;
    if (star) { star.wrongTone(); star.encourage(tries); }
  }
  // Answer tiles (2×2, or a row of chips for short Arabic words). Tap = answer:
  // right → green + celebration; wrong → red for a moment, then that tile is
  // set aside and the learner tries again.
  // st: { key, correct, locked, onRight(o, first), onWrong(o), next, advance, spoken }
  function options(list, st){
    const short = list.every((o) => AR.test(o) && String(o).replace(/[ً-ْ]/g, '').length <= 6);
    const wrap = node('div', short ? 'cd-chips' : 'cd-opts'); if (short) wrap.dir = 'rtl';
    const tried = S[st.key + 'Tried'] || [];
    list.forEach((o) => {
      let cls = 'cd-opt';
      if (st.locked) cls += o === st.correct ? ' right' : ' dim';
      else if (tried.indexOf(o) >= 0) cls += ' tried';
      const b = btn(cls, null, null, () => {
        if (st.isLocked() || b.classList.contains('tried') || b.classList.contains('wrong')) return;
        if (o === st.correct) {
          const first = !S[st.key + 'Tries'];
          st.onRight(o, first);
          wrap.querySelectorAll('.cd-opt').forEach((x) => { x.classList.remove('wrong', 'tried'); x.classList.add(x === b ? 'right' : 'dim'); });
          rightAnswer(first, st.next, st.advance, st.spoken);
        } else {
          S[st.key + 'Tries'] = (S[st.key + 'Tries'] || 0) + 1;
          if (tried.indexOf(o) < 0) tried.push(o); S[st.key + 'Tried'] = tried;
          st.onWrong(o);
          b.classList.add('wrong');
          wrongAnswer(S[st.key + 'Tries']);
          setTimeout(() => { b.classList.remove('wrong'); b.classList.add('tried'); }, 1300);
        }
      });
      b.textContent = AR.test(o) ? o : meaning(o); b.dataset.value = o;
      if (AR.test(o)) { b.classList.add('ar'); b.setAttribute('data-fit-ar', '1'); }
      wrap.appendChild(b);
      fit(b, { max: AR.test(o) ? (short ? 27 : 25) : 15, min: AR.test(o) ? 17 : 12 });
    });
    return wrap;
  }

  // ── Practice drill (quiz) ─────────────────────────────────────────────
  mkQuiz = function(blk){
    const d = getQuizData(blk);
    if (!d.questions || !d.questions.length) { setTimeout(finishBlock, 80); return div('stage'); }
    if (typeof S.quizIdx !== 'number') { S.quizIdx = 0; S.quizChosen = null; S.quizFb = null; S.quizLocked = false; S.quizScore = 0; S.quizWrong = 0; }
    clearQzTimer();
    const total = d.questions.length, q = d.questions[S.quizIdx];
    try { bumpPos(S.quizIdx + 1, total); } catch (e) {}
    const arP = q.promptType === 'ar';
    const { root, shell } = layer('dx-quiz' + (window.lsAsk ? ' qx-ask' : ''));
    topBar(shell, S.quizIdx, total, () => { quiet(); S.quizTried = []; S.quizTries = 0; S.view = 'blocks'; render(); });
    shell.appendChild(txt('div', 'qx-eyebrow', T('PRACTICE DRILL', 'EXERCICE')));
    // The star asks: a white speech bubble beside it, its tail pointing at the star.
    let card;
    if (window.lsAsk) {
      const askKey = 'quiz:' + S.mId + ':' + S.uId + ':' + S.bId + ':' + S.quizIdx;
      card = arP
        ? window.lsAsk({ key: askKey, ar: true, cap: T('WHAT DOES THIS MEAN?', 'QUE SIGNIFIE CECI ?'), text: q.prompt,
            extra: btn('qx-hear dx-hear', svg('vol', 18, 2), T('Hear it', 'Écouter'), () => say(q.prompt)), onTap: () => say(q.prompt) })
        : window.lsAsk({ key: askKey, cap: T('HOW DO YOU SAY', 'COMMENT DIT-ON'), text: meaning(q.prompt) });
    } else {
      card = node('div', 'cd-qcard ls-area');
      if (arP) {
        card.appendChild(txt('div', 'cd-q-cap', T('WHAT DOES THIS MEAN?', 'QUE SIGNIFIE CECI ?')));
        fit(card.appendChild(artxt('div', 'dx-q-ar', q.prompt)), { min: FLOOR.ar });
        card.appendChild(btn('qx-hear dx-hear', svg('vol', 18, 2), T('Hear it', 'Écouter'), () => say(q.prompt)));
        card.classList.add('dx-tap'); card.addEventListener('click', () => say(q.prompt));
      } else {
        card.appendChild(txt('div', 'cd-q-cap', T('HOW DO YOU SAY', 'COMMENT DIT-ON')));
        fit(card.appendChild(txt('div', 'cd-q-en', meaning(q.prompt))), { min: FLOOR.latin });
      }
    }
    shell.appendChild(card);
    shell.appendChild(txt('div', 'cd-q-ask', T('Tap the answer', 'Touchez la réponse')));
    // the word lists sometimes hold the same word twice with different vowel marks — never show both
    const nk = (t) => String(t).replace(/[ً-ٰٟۖ-ۭ]/g, '').replace(/[.؟?!،,]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
    const seen = new Set([nk(q.correct)]);
    const opts = q.options.filter((o) => { if (o === q.correct) return true; const k = nk(o); if (seen.has(k)) return false; seen.add(k); return true; });
    const advance = () => { if (!S.quizLocked) return; quiet(); if (window.lsStar) window.lsStar.tuck(); S.quizTried = []; S.quizTries = 0; advQuiz(d); };
    const next = nextButton(advance);
    shell.appendChild(options(opts, {
      key: 'quiz', locked: S.quizLocked, correct: q.correct, isLocked: () => S.quizLocked, next, advance,
      spoken: arP ? q.prompt : q.correct,
      onRight: (o, first) => { S.quizChosen = o; S.quizLocked = true; S.quizFb = 'correct'; if (first) S.quizScore++; },
      onWrong: () => { S.quizWrong++; },
    }));
    shell.appendChild(next);
    if (S.quizLocked) next.classList.add('show');
    // The bubble already carries the question, so the star does not talk over it:
    // its tip waits behind a tap on the star.
    const tip = arP ? T('Tap what it means.', 'Touchez ce que cela veut dire.') : T('Tap the Arabic that matches.', 'Touchez l’arabe qui correspond.');
    if (window.lsStar) { if (window.lsAsk) window.lsStar.setHelp(tip);
      else window.lsStar.intro('quiz:' + S.mId + ':' + S.uId + ':' + S.bId + ':' + (S.lessonEnterAt || ''), tip); }
    return root;
  };

  // ── Listen & choose (fill) ────────────────────────────────────────────
  mkFill = function(blk){
    const d = getFillData(blk);
    if (!d.questions || !d.questions.length) { setTimeout(finishBlock, 80); return div('stage'); }
    if (typeof S.fillIdx !== 'number') { S.fillIdx = 0; S.fillChosen = null; S.fillFb = null; S.fillLocked = false; S.fillScore = 0; S.fillWrong = 0; S.fillPlayedIdx = -1; }
    const total = d.questions.length, q = d.questions[S.fillIdx];
    try { bumpPos(S.fillIdx + 1, total); } catch (e) {}
    const { root, shell } = layer('dx-fill');
    topBar(shell, S.fillIdx, total, () => { quiet(); S.fillTried = []; S.fillTries = 0; S.view = 'blocks'; render(); });
    shell.appendChild(txt('div', 'qx-eyebrow', T('LISTEN & CHOOSE', 'ÉCOUTE ET CHOIX')));
    const stage = node('div', 'dx-listen ls-area');
    const play = btn('dx-play', '<i></i><i></i>' + svg('vol', 38, 2), T('Play the word', 'Écouter le mot'), () => { say(q.answer); pulse(); });
    stage.appendChild(play);
    stage.appendChild(txt('div', 'dx-listen-t', T('Which word do you hear?', 'Quel mot entendez-vous ?')));
    stage.appendChild(btn('dx-replay', svg('replay', 14, 2) + '<span>' + T('Hear again', 'Réécouter') + '</span>', null, () => { say(q.answer); pulse(); }));
    shell.appendChild(stage);
    function pulse(){ play.classList.remove('live'); void play.offsetWidth; play.classList.add('live'); }
    const firstQ = S.fillPlayedIdx !== S.fillIdx && S.fillIdx === 0;
    if (S.fillPlayedIdx !== S.fillIdx) { S.fillPlayedIdx = S.fillIdx; setTimeout(() => { if (document.body.contains(play)) { say(q.answer); pulse(); } }, firstQ ? 4600 : 320); }
    const nk2 = (t) => String(t).replace(/[ً-ٰٟۖ-ۭ]/g, '').replace(/[.؟?!،,]/g, '').replace(/\s+/g, ' ').trim();
    const seen2 = new Set([nk2(q.answer)]);
    const fopts = q.options.filter((o) => { if (o === q.answer) return true; const k = nk2(o); if (seen2.has(k)) return false; seen2.add(k); return true; });
    const advance = () => { if (!S.fillLocked) return; quiet(); if (window.lsStar) window.lsStar.tuck(); S.fillTried = []; S.fillTries = 0; advFill(d); };
    const next = nextButton(advance);
    shell.appendChild(options(fopts, {
      key: 'fill', locked: S.fillLocked, correct: q.answer, isLocked: () => S.fillLocked, next, advance, spoken: q.answer,
      onRight: (o, first) => { S.fillChosen = o; S.fillLocked = true; S.fillFb = 'correct'; if (first) S.fillScore++; },
      onWrong: () => { S.fillWrong++; setTimeout(() => { if (document.body.contains(play) && !S.fillLocked) { say(q.answer); pulse(); } }, 900); },
    }));
    shell.appendChild(next);
    if (S.fillLocked) next.classList.add('show');
    if (window.lsStar) window.lsStar.intro('fill:' + S.mId + ':' + S.uId + ':' + S.bId + ':' + (S.lessonEnterAt || ''),
      T('Listen, then tap the word you hear.', 'Écoutez, puis touchez le mot que vous entendez.'));
    return root;
  };

  // ── Sentence builder (clutter) ────────────────────────────────────────
  mkClutter = function(blk){
    const d = blk.data, total = d.sentences.length, cur = d.sentences[S.cIdx];
    try { bumpPos(S.cIdx + 1, total); } catch (e) {}
    const norm = (s) => (s || '').replace(/[ً-ٰٟۖ-ۭ]/g, '').replace(/\s+/g, ' ').trim();
    let en = cur.en;
    if (!en) {
      const unit = getUnit(S.mId, S.uId);
      const dl = unit && unit.blocks.find((b) => b.type === 'dialogue');
      const m = ((dl && dl.data && dl.data.lines) || []).find((l) => l.ar && norm(l.ar) === norm(cur.ar));
      if (m && m.en) en = m.en;
    }
    const { root, shell } = layer('dx-build');
    topBar(shell, S.cIdx, total, () => { quiet(); S.view = 'blocks'; render(); });
    shell.appendChild(txt('div', 'qx-eyebrow', T('SENTENCE BUILDER', 'CONSTRUCTION DE PHRASES')));
    if (en) {
      const card = node('div', 'cd-qcard');
      card.appendChild(txt('div', 'cd-q-cap', T('SAY IT IN ARABIC', 'DITES-LE EN ARABE')));
      fit(card.appendChild(txt('div', 'cd-q-en', meaning(en))), { min: FLOOR.latin });
      shell.appendChild(card);
    }
    const az = node('div', 'dx-answer' + (S.cFb === 'correct' ? ' good' : S.cFb === 'wrong' ? ' bad' : S.cFb === 'shown' ? ' good' : '')); az.dir = 'rtl';
    if (S.cFb === 'shown') S.cAns = String(cur.ar).split(/\s+/).filter(Boolean);
    if (!S.cAns.length) az.appendChild(txt('span', 'dx-answer-ph', T('Tap the words below in order', 'Touchez les mots ci-dessous dans l\u2019ordre')));
    S.cAns.forEach((w, i) => {
      az.appendChild(btn('dx-tok placed', null, null, () => { if (S.cLocked) return; S.cAns.splice(i, 1); S.cBank.push(w); render(); })).textContent = w;
    });
    shell.appendChild(az);
    if (!S.cLocked) {
      const bank = node('div', 'dx-bank'); bank.dir = 'rtl';
      S.cBank.forEach((w, i) => {
        bank.appendChild(btn('dx-tok', null, null, () => { S.cAns.push(w); S.cBank.splice(i, 1); say(w); render(); })).textContent = w;
      });
      shell.appendChild(bank);
    }
    shell.appendChild(node('div', 'qx-grow'));
    const star = window.lsStar;
    if (!S.cLocked) {
      const row = node('div', 'dx-row');
      const clear = btn('dx-ghost', T('Clear', 'Effacer'), null, () => { S.cAns = []; S.cBank = buildBankWithDistractors(cur.words, S.mId, S.uId); render(); });
      if (!S.cAns.length) clear.disabled = true;
      row.appendChild(clear);
      const chk = btn('qx-cta', T('Check Answer', 'Vérifier'), null, () => {
        const ua = S.cAns.join(' '), nsp = S.cAns.join('');
        const one = (t) => ua === t || nsp === t.replace(/\s/g, '');
        const ok = one(cur.ar) || (cur.alts || []).some(one);
        S.cFb = ok ? 'correct' : 'wrong'; S.cLocked = true;
        if (ok) {
          const first = !S.cAttempts; S.cScore++;
          render();
          rightAnswer(first, document.querySelector('.qx .ls-next'), () => { if (S.cFb !== 'correct') return; quiet(); if (star) star.tuck(); advClutter(d); }, cur.ar);
        } else {
          S.cWrong++; S.cAttempts = (S.cAttempts || 0) + 1;
          if (S.cAttempts >= SCAFFOLD_THRESHOLD) {
            // after a few tries the sentence is shown, then the learner moves on
            S.cFb = 'shown'; render(); say(cur.ar);
            if (star) { star.timeTone(); star.encourage(0, T('Here it is — have a good look, then continue.', 'La voici — regardez-la bien, puis continuez.')); }
          } else {
            render(); wrongAnswer(S.cAttempts);
            setTimeout(() => { if (S.cFb === 'wrong' && S.cLocked) { S.cAns = []; S.cBank = buildBankWithDistractors(cur.words, S.mId, S.uId); S.cFb = null; S.cLocked = false; render(); } }, 1500);
          }
        }
      });
      if (!S.cAns.length) chk.disabled = true;
      row.appendChild(chk);
      shell.appendChild(row);
    } else if (S.cFb === 'correct' || S.cFb === 'shown') {
      const next = nextButton(() => { quiet(); if (star) star.tuck(); advClutter(d); });
      if (S.cFb === 'shown') next.classList.add('show');
      shell.appendChild(next);
    }
    if (star) star.setHelp(T('Tap the words in the right order, then check.', 'Touchez les mots dans le bon ordre, puis vérifiez.'));
    return root;
  };

  // ── Listening dictation (cloze) ───────────────────────────────────────
  mkCloze = function(blk){
    const d = getClozeData(blk);
    if (!d.sentences.length) { setTimeout(finishBlock, 80); return div('stage'); }
    if (typeof S.clzIdx !== 'number') { S.clzIdx = 0; S.clzAns = []; S.clzFb = null; S.clzLocked = false; S.clzScore = 0; S.clzWrong = 0; }
    const total = d.sentences.length, cur = d.sentences[S.clzIdx];
    try { bumpPos(S.clzIdx + 1, total); } catch (e) {}
    const { root, shell } = layer('dx-cloze');
    topBar(shell, S.clzIdx, total, () => { quiet(); S.clzIdx = 0; S.clzAns = []; S.clzFb = null; S.clzLocked = false; S.view = 'blocks'; render(); });
    shell.appendChild(txt('div', 'qx-eyebrow', T('LISTENING DICTATION', 'DICTÉE')));
    const top = node('div', 'dx-dict-top');
    const play = btn('dx-play sm', '<i></i><i></i>' + svg('vol', 26, 2), T('Play the sentence', 'Écouter la phrase'), () => { say(cur.ar); play.classList.remove('live'); void play.offsetWidth; play.classList.add('live'); });
    top.appendChild(play);
    const tt = node('div', 'dx-dict-txt');
    tt.appendChild(txt('div', 'dx-dict-t', T('Fill in what you hear', 'Complétez ce que vous entendez')));
    tt.appendChild(txt('div', 'dx-dict-s', cur.speaker ? T(cur.speaker + ' says…', cur.speaker + ' dit…') : T('Tap play, then place the missing words', 'Écoutez, puis placez les mots manquants')));
    top.appendChild(tt);
    shell.appendChild(top);
    if (S.clzPlayedIdx !== S.clzIdx) { S.clzPlayedIdx = S.clzIdx; setTimeout(() => { say(cur.ar); play.classList.add('live'); }, 320); }

    const box = node('div', 'dx-sent' + (S.clzFb === 'correct' ? ' good' : S.clzFb === 'wrong' ? ' bad' : '')); box.dir = 'rtl'; box.setAttribute('data-fit-ar', '1');
    box.addEventListener('click', (e) => { if (!e.target.closest('.dx-blank')) say(cur.ar); });
    const nrm = (s) => String(s || '').replace(/[ً-ٰٟۖ-ۭ]/g, '').trim();
    cur.words.forEach((w, i) => {
      if (i) box.appendChild(document.createTextNode(' '));
      const bi = cur.blankIndices.indexOf(i);
      if (bi < 0) { box.appendChild(txt('span', '', w)); return; }
      const ch = S.clzAns[bi];
      let cls = 'dx-blank' + (ch ? ' full' : '');
      if (S.clzLocked) cls += nrm(ch) === nrm(w) ? ' right' : ' wrong';
      else if ((S.clzBad || []).indexOf(bi) >= 0) cls += ' wrong';
      const b = btn(cls, null, null, () => { if (!S.clzLocked && ch) { S.clzAns[bi] = undefined; render(); } });
      b.textContent = S.clzLocked && nrm(ch) !== nrm(w) ? w : (ch || ' '); b.dataset.slot = bi;
      box.appendChild(b);
    });
    shell.appendChild(box);
    fit(box, { min: FLOOR.arSmall });
    if (cur.en) fit(shell.appendChild(txt('div', 'dx-sent-en', meaning(cur.en))), { min: FLOOR.latin });

    if (!S.clzLocked) {
      if (!cur._bank) {
        const correct = cur.blankIndices.map((i) => cur.words[i]);
        const seen = {}; correct.forEach((w) => { seen[w] = (seen[w] || 0) + 1; });
        const extra = [];
        (cur.choicesPerBlank || []).forEach((arr, bi) => { const right = cur.words[cur.blankIndices[bi]]; (arr || []).forEach((c) => { if (c !== right && !seen[c]) { seen[c] = 1; extra.push(c); } }); });
        const pool = correct.concat(extra);
        for (let k = pool.length - 1; k > 0; k--) { const j = Math.floor(Math.random() * (k + 1)); const t = pool[k]; pool[k] = pool[j]; pool[j] = t; }
        cur._bank = pool;
      }
      const used = {}; S.clzAns.forEach((w) => { if (w != null) used[w] = (used[w] || 0) + 1; });
      const bank = node('div', 'dx-bank'); bank.dir = 'rtl';
      cur._bank.forEach((w) => {
        if (used[w] > 0) { used[w]--; return; }
        bank.appendChild(btn('dx-tok', null, null, () => {
          if ((S.clzBad || []).length) return;
          const nx = cur.blankIndices.findIndex((_, bi) => S.clzAns[bi] == null);
          if (nx >= 0) { S.clzAns[nx] = w; render(); }
        })).textContent = w;
      });
      shell.appendChild(bank);
    }
    shell.appendChild(node('div', 'qx-grow'));
    const star = window.lsStar;
    const next = nextButton(() => { quiet(); if (star) star.tuck(); S.clzShown = false; S.clzBad = []; advCloze(d); });
    if (!S.clzLocked) {
      const all = cur.blankIndices.every((_, ai) => S.clzAns[ai] != null);
      const row = node('div', 'dx-row');
      row.appendChild(btn('dx-ghost', T('Show answer', 'Voir la réponse'), null, () => {
        S.clzAns = cur.blankIndices.map((i) => cur.words[i]); S.clzLocked = true; S.clzFb = 'wrong'; S.clzShown = true; S.clzBad = [];
        S.clzWrong++; S.clzAttempts = (S.clzAttempts || 0) + 1; say(cur.ar); render();
        if (star) star.explain(T('Here it is — listen once more, then continue.', 'La voici — réécoutez-la, puis continuez.'), 3500);
      }));
      const chk = btn('qx-cta', T('Check', 'Vérifier'), null, () => {
        if (!all || (S.clzBad || []).length) return;
        const bad = cur.blankIndices.map((wi, ai) => (nrm(S.clzAns[ai]) === nrm(cur.words[wi]) ? -1 : ai)).filter((i) => i >= 0);
        if (!bad.length) {
          const first = !S.clzAttempts;
          S.clzLocked = true; S.clzFb = 'correct'; S.clzShown = false; S.clzScore++;
          render();
          rightAnswer(first, document.querySelector('.qx .ls-next'), () => { if (S.clzFb !== 'correct') return; quiet(); if (star) star.tuck(); S.clzBad = []; advCloze(d); }, cur.ar);
        } else {
          // wrong words turn red for a moment, then empty again for another try
          S.clzWrong++; S.clzAttempts = (S.clzAttempts || 0) + 1; S.clzBad = bad;
          render(); wrongAnswer(S.clzAttempts);
          setTimeout(() => { if (!S.clzLocked && (S.clzBad || []).length) { S.clzBad.forEach((ai) => { S.clzAns[ai] = undefined; }); S.clzBad = []; render(); } }, 1400);
        }
      });
      if (!all || (S.clzBad || []).length) chk.disabled = true;
      row.appendChild(chk);
      shell.appendChild(row);
    } else {
      if (S.clzFb !== 'correct') next.classList.add('show');
      shell.appendChild(next);
    }
    if (star) star.setHelp(T('Listen, then tap the missing words into the gaps.', 'Écoutez, puis placez les mots manquants dans les trous.'));
    return root;
  };

  // ── Grammar ───────────────────────────────────────────────────────────
  const _origGrammar = mkGrammar;
  // A switched-on bulb: filled gold, with rays.
  const BULB_ON = '<svg class="dx-bulb" width="22" height="22" viewBox="0 0 24 24" aria-hidden="true">' +
    '<g stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M12 1.2v1.6M4.4 4.4l1.1 1.1M19.6 4.4l-1.1 1.1M1.6 11h1.6M20.8 11h1.6"/></g>' +
    '<path d="M12 4.6a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2v.3h5v-.3c0-.8.4-1.5 1-2A6 6 0 0 0 12 4.6z" fill="currentColor"/>' +
    '<path d="M9.6 19.6h4.8M10.4 22h3.2" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>';
  // Detached pronouns in a rule are shown in gold.
  const PRONOUNS = new Set(['انا','انت','هو','هي','نحن','انتم','انتما','انتن','هم','هما','هن']);
  const bareAr = (w) => String(w).replace(/[\u064B-\u0652\u0670\u0640]/g, '').replace(/[أإآ]/g, 'ا').replace(/[؟?.,،!]/g, '');
  function arWithPronouns(cls, text){
    const e = node('div', cls); e.dir = 'rtl'; e.setAttribute('data-fit-ar', '1');
    String(text).split(/(\s+)/).forEach((w) => {
      if (!w) return;
      if (/^\s+$/.test(w)) { e.appendChild(document.createTextNode(w)); return; }
      const s = document.createElement('span'); s.textContent = w;
      if (PRONOUNS.has(bareAr(w))) s.className = 'dx-pron';
      e.appendChild(s);
    });
    return e;
  }

  function keyRuleCard(kr){
    const c = node('div', 'dx-rule');
    c.appendChild(node('div', 'dx-rule-lbl', BULB_ON + '<span>KEY RULE</span>'));
    const eq = (kr.match(/=/g) || []).length, parts = kr.split('='), left = parts[0], right = parts.slice(1).join('=');
    if (eq === 1 && AR.test(left) && !AR.test(right)) {
      fit(c.appendChild(arWithPronouns('dx-rule-ar', left.trim())), { min: FLOOR.arSmall });
      fit(c.appendChild(txt('div', 'dx-rule-en', right.trim())), { min: FLOOR.latin });
    } else fit(c.appendChild(bidi('div', 'dx-rule-en', kr, true)), { min: FLOOR.latin });
    return c;
  }
  function hlArabic(text, hl){
    const e = node('div', 'dx-g-ar'); e.dir = 'rtl'; e.setAttribute('data-fit-ar', '1');
    const t = text || '', k = hl ? t.indexOf(hl) : -1;
    if (hl && k >= 0) {
      if (k) e.appendChild(document.createTextNode(t.slice(0, k)));
      e.appendChild(txt('span', 'dx-hl', hl));
      if (k + hl.length < t.length) e.appendChild(document.createTextNode(t.slice(k + hl.length)));
    } else e.textContent = t;
    return e;
  }
  mkGrammar = function(blk){
    const d = blk.data || {};
    const exs = (d.examples || []).filter((x) => x && x.ar);
    if (S.gScreen === 1 && d.more) return _origGrammar(blk);   // rich "more examples" page keeps the website layout
    const tbl = d.table && d.table.rows && d.table.rows.length ? d.table : null;
    const pair = tbl && tbl.rows.some((r) => r.roman);
    const notice = tbl && !pair && (tbl.rows.some((r) => r.hl || r.note) || (Array.isArray(d.practice) && d.practice.length) || d.noticeFirst === true);
    const steps = [];
    if (notice) {
      tbl.rows.forEach((r, i) => steps.push({ k: 'notice', r, last: i === tbl.rows.length - 1 }));
      (d.practice || []).forEach((p) => steps.push({ k: 'practice', p }));
    } else if (tbl) tbl.rows.forEach((r, i) => steps.push({ k: 'card', r, last: i === tbl.rows.length - 1 }));
    else steps.push({ k: 'rule' });
    exs.forEach((x) => steps.push({ k: 'ex', x }));
    const more = !!d.more && !exs.length;
    if (typeof S.gStep !== 'number' || S.gStep < 0 || S.gStep >= steps.length) S.gStep = 0;
    const gi = S.gStep, st = steps[gi], total = steps.length, last = gi >= total - 1;
    try { bumpPos(gi + 1, total); } catch (e) {}

    const { root, shell } = layer('dx-gram');
    topBar(shell, gi, total, () => { quiet(); S.gStep = 0; S.view = 'blocks'; render(); });
    const eyebrow = st.k === 'ex' ? 'IN A SENTENCE' : st.k === 'practice' ? 'YOUR TURN' : st.k === 'notice' ? 'NOTICE' : 'GRAMMAR';
    shell.appendChild(txt('div', 'qx-eyebrow', eyebrow));
    if (gi === 0) {
      const h = node('div', 'dx-g-head');
      h.appendChild(txt('div', 'cd-title', d.title || blk.title || 'Grammar'));
      if (d.titleAr) fit(h.appendChild(artxt('div', 'dx-g-titlear', d.titleAr)), { min: FLOOR.arSmall });
      shell.appendChild(h);
      if (d.intro) shell.appendChild(txt('div', 'dx-g-intro', d.intro));
    }
    const body = node('div', 'dx-g-body');
    if (st.k === 'rule') {
      if (d.keyRule) body.appendChild(keyRuleCard(d.keyRule));
    } else if (st.k === 'notice' || st.k === 'card') {
      const r = st.r;
      const card = node('div', 'dx-g-card'); card.setAttribute('role', 'button'); card.tabIndex = 0;
      const arCell = ['ar', 'roman', 'en', 'enWord', 'ex'].map((k) => r[k]).find((v) => v && AR.test(v)) || r.ar;
      if (st.k === 'notice') {
        fit(card.appendChild(hlArabic(r.ar, r.hl)), { min: FLOOR.ar });
        card.appendChild(node('div', 'cd-rule'));
        fit(card.appendChild(txt('div', 'cd-en', r.en || '')), { min: FLOOR.latin });
        if (r.note) card.appendChild(node('div', 'dx-g-note', r.note));
        card.addEventListener('click', () => say(r.ar));
      } else {
        const cells = ['ar', 'roman', 'en', 'enWord', 'ex'].map((k) => r[k]).filter((v) => v != null && String(v).trim() !== '').map(String);
        const head = cells[0] || '';
        const isAr = (t) => (t.match(/[\u0600-\u06FF]/g) || []).length > (t.match(/[A-Za-z]/g) || []).length;
        fit(card.appendChild(isAr(head) ? arWithPronouns('dx-g-ar', head) : bidi('div', 'cd-en', head, true)), { min: isAr(head) ? FLOOR.ar : FLOOR.latin });
        if (!S.gFlip) card.appendChild(node('div', 'cd-tap', '<span>Tap to reveal</span>'));
        else {
          card.appendChild(node('div', 'cd-rule'));
          cells.slice(1).forEach((c) => fit(card.appendChild(isAr(c) ? artxt('div', 'dx-g-ar2', c) : bidi('div', 'dx-g-sub', c, true)), { min: isAr(c) ? FLOOR.arSmall : FLOOR.latin }));
        }
        card.addEventListener('click', () => { S.gFlip = !S.gFlip; if (S.gFlip) say(arCell); render(); });
      }
      card.appendChild(btn('qx-hear dx-hear', svg('vol', 18, 2), 'Hear it', () => say(arCell)));
      body.appendChild(card);
      if (st.last && d.keyRule) {
        if (st.k === 'notice' && !S.gRuleRevealed) {
          const p = node('div', 'dx-rule ask');
          p.appendChild(node('div', 'dx-rule-lbl', BULB_ON + '<span>WHAT PATTERN DO YOU NOTICE?</span>'));
          p.appendChild(btn('dx-reveal', 'Reveal the rule', null, () => { S.gRuleRevealed = true; render(); }));
          body.appendChild(p);
        } else body.appendChild(keyRuleCard(d.keyRule));
      }
    } else if (st.k === 'practice') {
      const q = st.p;
      if (!S.gPopts || S.gPopts.i !== gi) {
        let o = []; (d.practice || []).forEach((p) => { if (p.correct && o.indexOf(p.correct) < 0) o.push(p.correct); });
        if (o.length < 2) o = ['أُ', 'تُ', 'يُ', 'نُ'];
        for (let k = o.length - 1; k > 0; k--) { const j = Math.floor(Math.random() * (k + 1)); const t = o[k]; o[k] = o[j]; o[j] = t; }
        S.gPopts = { i: gi, o };
      }
      const card = node('div', 'cd-qcard');
      card.appendChild(txt('div', 'cd-q-cap', 'ADD THE PREFIX FOR ' + String(q.pronEn || q.pron || '').toUpperCase()));
      const w = node('div', 'dx-pword'); w.dir = 'rtl'; w.setAttribute('data-fit-ar', '1');
      const slot = txt('span', 'cd-slot', ' '); w.appendChild(slot); w.appendChild(txt('span', '', q.root || ''));
      card.appendChild(w); body.appendChild(card); fit(w, { min: FLOOR.arSmall });
      const chips = node('div', 'cd-chips dx-pchips'); chips.dir = 'rtl';
      const fb = txt('div', 'dx-pfb', '');
      S.gPopts.o.forEach((o) => {
        const b = btn('cd-opt ar', null, null, () => {
          chips.querySelectorAll('.cd-opt').forEach((x) => { if (!x.classList.contains('right')) x.className = 'cd-opt ar'; });
          if (o === q.correct) { b.classList.add('right'); slot.textContent = o; slot.className = 'cd-slot good'; fb.textContent = 'Correct!'; fb.className = 'dx-pfb good'; window.lsChime(); window.lsSayAfterChime(o + (q.root || '')); }
          else { b.classList.add('wrong'); fb.textContent = 'Not quite — think about who is doing it'; fb.className = 'dx-pfb bad'; }
        });
        b.textContent = o; chips.appendChild(b);
      });
      body.appendChild(chips); body.appendChild(fb);
    } else if (st.k === 'ex') {
      const card = node('div', 'dx-g-card'); card.setAttribute('role', 'button'); card.tabIndex = 0;
      fit(card.appendChild(arWithPronouns('dx-g-ar', st.x.ar)), { min: FLOOR.ar });
      card.appendChild(node('div', 'cd-rule'));
      fit(card.appendChild(txt('div', 'cd-en', meaning(st.x.en || ''))), { min: FLOOR.latin });
      card.appendChild(btn('qx-hear dx-hear', svg('vol', 18, 2), 'Hear it', () => say(st.x.ar)));
      card.addEventListener('click', () => say(st.x.ar));
      body.appendChild(card);
      body.appendChild(txt('div', 'cd-hint', 'Tap the sentence to hear it'));
    }
    shell.appendChild(body);
    shell.appendChild(node('div', 'qx-grow'));
    const row = node('div', 'dx-row');
    row.appendChild(btn('dx-ghost icon', svg('back', 18, 2.2), 'Back', () => {
      quiet(); S.gFlip = false;
      if (S.gStep > 0) { S.gStep--; render(); } else { S.view = 'blocks'; render(); }
    }));
    const lbl = last ? (more ? 'More examples' : 'Got it') : (steps[gi + 1].k === 'ex' && st.k !== 'ex' ? 'See examples' : 'Next');
    row.appendChild(btn('qx-cta', lbl + ' ' + svg(last && !more ? 'check' : 'fwd', 18, 2.2), null, () => {
      quiet(); S.gFlip = false;
      if (!last) { S.gStep++; render(); }
      else if (more) { S.gScreen = 1; render(); }
      else { S.gStep = 0; finishBlock(); }
    }));
    shell.appendChild(row);
    return root;
  };

  if (typeof resetBS === 'function') {
    const _reset = resetBS;
    resetBS = function(){ S.gStep = 0; S.gPopts = null; S.clzPlayedIdx = -1; S.clzShown = false; S.clzBad = [];
      S.quizTried = []; S.quizTries = 0; S.fillTried = []; S.fillTries = 0; S.lsStreak = 0; return _reset.apply(this, arguments); };
  }
})();
