/* ═══ Lisaany app — Listen mode for conversation blocks ═══
   App-only replacement for the website's dialogue "stage" (mkDlPearl in play
   mode). Same data, same queue/progress/finish rules as the website; a dark,
   audio-first layout: one line at a time in a big card, a small speaker label,
   words lighting up (gold, with a glow) as they're spoken, Back / play-pause / Next controls and a strip
   to jump back to the previous speaker. The "full conversation" view (play
   mode off) still falls through to the website renderer.
   Built into the page by tools/build-lesson-page.py. */
(function(){
  if (typeof mkDlPearl !== 'function') return;
  const _orig = mkDlPearl;

  // one-line auto-fit (the shared helper lives in app-check.js, loaded after this file)
  const FLOOR = { ar: 26, arSmall: 20, latin: 15 };
  function fit(el, o){ try { if (window.lsFit) window.lsFit(el, o); } catch (e) {} return el; }

  const RATES = [1, 0.75];
  let rateIdx = 0;
  let lastAutoKey = null;   // which line was last auto-played, so re-renders don't replay it
  let live = null;          // DOM handles for the per-frame updater
  let rafId = 0;
  let kwOn = -1;       // which key-word tile is sounding
  let kwToken = 0;     // bumps to cancel a running "Play all"

  const ICON = {
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    mic: '<rect x="9" y="3.5" width="6" height="11" rx="3"/><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v2.5"/>',
    replay: '<path d="M4 12a8 8 0 1 0 2.4-5.7M4 4.5v4h4"/>',
    play: '<path d="M8 5.5v13l10.5-6.5z" fill="currentColor" stroke="none"/>',
    pause: '<path d="M8.5 5.5v13M15.5 5.5v13" stroke-width="2.8"/>',
    back: '<path d="M6 5.5v13" stroke-width="2.4"/><path d="M19 5.5v13l-10-6.5z" fill="currentColor"/>',
    next: '<path d="M18 5.5v13" stroke-width="2.4"/><path d="M5 5.5v13l10-6.5z" fill="currentColor"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7" stroke-width="2.4"/>',
    eye: '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="2.8"/>',
    eyeOff: '<path d="M3 3l18 18"/><path d="M9.9 5.2A10.6 10.6 0 0 1 12 5c5.5 0 9 5 9 7-.5.9-1.5 2.4-3 3.7M6.3 6.9C4 8.4 2.6 10.5 2 12c1 1.9 3.5 5 8.5 5.7"/>',
    vol: '<path d="M4 9.5h3.5L12 6v12l-4.5-3.5H4z"/><path d="M15.5 9a4 4 0 0 1 0 6"/>',
  };
  const T = (en, fr) => (window.lsT ? window.lsT(en, fr) : en);
  function svg(name, size, extra){
    return '<svg width="' + size + '" height="' + size + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="' + (extra || 1.9) +
      '" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ICON[name] + '</svg>';
  }
  function node(tag, cls, html){
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (html != null) n.innerHTML = html;
    return n;
  }
  function button(cls, html, label, onClick){
    const b = node('button', cls, html);
    b.type = 'button';
    if (label) b.setAttribute('aria-label', label);
    b.addEventListener('click', function(e){ e.stopPropagation(); onClick(e); });
    return b;
  }
  // Some lines carry "transliteration (meaning)" in their English field; the app
  // shows the meaning only.
  function meaning(en){
    const s = String(en || '').trim();
    const m = s.match(/^([a-z][^()]*)\(([^()]+)\)\s*$/);
    if (!m) return s;
    const t = m[2].trim();
    return t.charAt(0).toUpperCase() + t.slice(1);
  }
  const bare = (s) => (s || '').replace(/[ً-ْٰـ]/g, '');

  function audioState(){
    let a = null;
    try { a = _curAudio; } catch (e) {}
    if (a) {
      const d = isFinite(a.duration) && a.duration > 0 ? a.duration : 0;
      return { audio: a, playing: !a.paused && !a.ended, t: d ? a.currentTime / d : 0, known: !!d };
    }
    let tts = false;
    try { tts = 'speechSynthesis' in window && window.speechSynthesis.speaking; } catch (e) {}
    return { audio: null, playing: tts, t: 0, known: false };
  }

  function tick(){
    rafId = 0;
    if (!live || !document.body.contains(live.root)) { live = null; return; }
    const st = audioState();
    if (st.audio && st.audio.playbackRate !== RATES[rateIdx]) {
      try { st.audio.playbackRate = RATES[rateIdx]; } catch (e) {}
    }
    live.root.classList.toggle('lm-live', st.playing);
    live.play.innerHTML = svg(st.playing ? 'pause' : 'play', 30, 2.2);
    live.play.setAttribute('aria-label', st.playing ? 'Pause' : 'Play');

    // Words light up in order. The clips carry no word timings, so each word
    // gets a share of the clip in proportion to its length.
    const words = live.words;
    if (words.length) {
      if (st.playing || (st.audio && st.t > 0 && st.t < 1)) {
        const shown = st.known ? st.t * 1.06 : 0;
        let now = -1;
        for (let i = 0; i < words.length; i++) {
          const on = st.known ? shown >= words[i].start : true;
          words[i].el.classList.toggle('lm-said', on);
          words[i].el.classList.toggle('lm-wait', !on);
          if (on && st.known) now = i;
        }
        for (let i = 0; i < words.length; i++) words[i].el.classList.toggle('lm-now', i === now);
      } else {
        for (let i = 0; i < words.length; i++) { words[i].el.classList.remove('lm-said', 'lm-wait', 'lm-now'); }
      }
    }
    if (live.tiles) {
      if (!st.playing && !live.playingAll) kwOn = -1;
      for (let i = 0; i < live.tiles.length; i++) live.tiles[i].classList.toggle('on', i === kwOn);
    }
    if (live.bars) {
      const n = live.bars.length;
      const lit = st.known ? Math.round(st.t * n) : (st.playing ? n : 0);
      for (let i = 0; i < n; i++) live.bars[i].classList.toggle('on', i < lit);
    }
    rafId = requestAnimationFrame(tick);
  }
  function startTicking(){ if (!rafId) rafId = requestAnimationFrame(tick); }

  mkDlPearl = function(blk){
    if (!S.dlPlayMode) return _orig(blk);
    const d = blk.data || {};
    const lines = d.lines || [];
    if (!lines.length) return _orig(blk);
    if (typeof S.lmShowEn === 'undefined') S.lmShowEn = true;
    // Key words start with English hidden, so learners test themselves first.
    if (typeof S.kwShowEn === 'undefined') S.kwShowEn = false;

    const hasKw = Array.isArray(d.keywords) && d.keywords.length > 0;
    if (!Array.isArray(S.dlQueue) || !S.dlQueue.length) {
      S.dlQueue = lines.map((_, i) => i); if (hasKw) S.dlQueue.push(-1);
      S.dlQPos = 0; S.dlAgain = []; S.dlKnown = new Set(); S.dlRound = 1;
    }
    if (S.dlQPos == null) S.dlQPos = 0;
    if (S.dlQPos > S.dlQueue.length - 1) S.dlQPos = S.dlQueue.length - 1;
    const lineIdx = S.dlQueue[S.dlQPos];
    const isKw = lineIdx === -1;
    const total = lines.length;
    S.dlPlayIdx = isKw ? total - 1 : lineIdx;
    bumpPos(Math.min(S.dlPlayIdx + 1, total), total);
    const line = isKw ? null : lines[lineIdx];
    const isLast = S.dlQPos >= S.dlQueue.length - 1;
    const sideOf = (l) => (l && l.side === 'right') ? 'r' : 'l';

    const goNext = () => {
      S.lmWord = null;
      if (isLast) { try { stopAudio(); } catch (e) {} S.dlQueue = null; finishBlock(); }
      else { S.dlQPos++; render(); }
    };
    const goBack = () => {
      if (S.dlQPos <= 0) return;
      S.lmWord = null; S.dlQPos--; lastAutoKey = null; render();
    };
    const playLine = () => { if (line && line.ar) { try { speak(line.ar); } catch (e) {} } };

    document.body.classList.add('dl-active');
    const root = node('div', 'dl-pearl-layer lm');
    const shell = node('div', 'lm-shell'); root.appendChild(shell);

    // ── top: close · segmented progress · count ──
    const top = node('div', 'lm-top');
    top.appendChild(button('lm-close', svg('close', 16, 2.2), T('Close lesson', 'Fermer la leçon'), () => { try { stopAudio(); } catch (e) {} S.view = 'blocks'; render(); }));
    const segs = node('div', 'lm-segs');
    const doneTo = isKw ? total : lineIdx + 1;
    for (let i = 0; i < total; i++) segs.appendChild(node('div', 'lm-seg' + (i < doneTo ? ' on' : '')));
    top.appendChild(segs);
    top.appendChild(node('div', 'lm-count', isKw ? T('Key words', 'Mots clés') : (lineIdx + 1) + '/' + total));
    if (window.lsStar) top.appendChild(window.lsStar.slot());
    shell.appendChild(top);
    if (window.lsStar) shell.appendChild(window.lsStar.row());

    const body = node('div', 'lm-body'); shell.appendChild(body);
    body.appendChild(node('div', 'lm-eyebrow', (isKw ? T('KEY WORDS · ', 'MOTS CLÉS · ') : 'CONVERSATION · ') + String(d.title || 'Dialogue').toUpperCase()));

    // ── previous speaker ──
    const prevQ = S.dlQPos > 0 ? S.dlQueue[S.dlQPos - 1] : null;
    if (!isKw && prevQ != null && prevQ >= 0) {
      const p = lines[prevQ];
      const prev = button('lm-prev lm-' + sideOf(p), '', 'Go back to ' + (p.spk || 'the previous line'), goBack);
      prev.innerHTML =
        '<span class="lm-prev-ic">' + svg('replay', 16) + '</span>' +
        '<span class="lm-prev-dot">' + svg('mic', 13, 2) + '</span>' +
        '<span class="lm-prev-txt"><span class="lm-prev-lbl">' + T('PREVIOUS · ', 'PRÉCÉDENT · ') + String(p.spk || '').toUpperCase() + '</span>' +
        (S.lmShowEn && p.en ? '<span class="lm-prev-en"></span>' : '') + '</span>' +
        '<span class="lm-prev-ar" dir="rtl"></span>';
      prev.querySelector('.lm-prev-ar').textContent = p.ar || '';
      const en = prev.querySelector('.lm-prev-en'); if (en) en.textContent = meaning(p.en);
      body.appendChild(prev);
    }

    const stage = node('div', 'lm-stage'); body.appendChild(stage);
    const words = [];

    let kwTiles = null, kws = null;
    if (isKw) {
      kws = d.keywords.flatMap(k => {
        const ap = (k.ar || '').split(' / ').map(s => s.trim()).filter(Boolean);
        const ep = (k.en || '').split(' / ').map(s => s.trim()).filter(Boolean);
        return (ap.length > 1 && ap.length === ep.length) ? ap.map((ar, i) => ({ ar, en: ep[i] })) : [k];
      });
      stage.classList.add('lm-kw-stage');
      const head = node('div', 'lm-kw-head');
      head.appendChild(node('div', 'lm-kw-title', T('Words to keep', 'Mots à retenir')));
      head.appendChild(node('div', 'lm-kw-sub', T(kws.length + ' words from this conversation · tap to hear', kws.length + ' mots de cette conversation · touchez pour écouter')));
      stage.appendChild(head);
      const grid = node('div', 'lm-kw-grid');
      kwTiles = kws.map((k, i) => {
        const tile = node('div', 'lm-tile');
        tile.setAttribute('role', 'button');
        tile.setAttribute('aria-label', 'Hear ' + (k.en || 'this word'));
        const row = node('div', 'lm-tile-top');
        row.appendChild(node('span', 'lm-tile-n', String(i + 1).padStart(2, '0')));
        row.appendChild(node('span', 'lm-tile-spk', svg('vol', 15, 2)));
        tile.appendChild(row);
        const ar = node('div', 'lm-tile-ar'); ar.dir = 'rtl'; ar.textContent = k.ar; ar.setAttribute('data-fit-ar', '1'); tile.appendChild(ar);
        fit(ar, { min: FLOOR.arSmall });
        if (S.kwShowEn && k.en) { const en = node('div', 'lm-tile-en'); en.textContent = meaning(String(k.en).replace(/\s+\/\s+/g, ' · ')); tile.appendChild(en); }
        tile.addEventListener('click', (e) => { e.stopPropagation(); kwToken++; if (live) live.playingAll = false; kwOn = i; try { speak(k.ar); } catch (_) {} });
        grid.appendChild(tile);
        return tile;
      });
      stage.appendChild(grid);
    } else {
      const side = sideOf(line);
      // speaker: a small mic and the name; the line itself sits in a big card
      const who = node('div', 'lm-who');
      const badge = node('div', 'lm-badge lm-' + side,
        '<span class="lm-ring r1"></span><span class="lm-ring r2"></span><span class="lm-ring r3"></span>' +
        '<span class="lm-mic">' + svg('mic', 20, 2) + '</span>');
      badge.setAttribute('role', 'button');
      badge.setAttribute('aria-label', (line.spk || T('Speaker', 'Interlocuteur')) + T(' — play', ' — écouter'));
      badge.addEventListener('click', playLine);
      who.appendChild(badge);
      who.appendChild(node('div', 'lm-name lm-' + side, String(line.spk || T('Speaker', 'Interlocuteur')).toUpperCase()));
      stage.appendChild(who);
      const lcard = node('div', 'lm-card');
      stage.appendChild(lcard);

      const wordIdx = buildWordIndex(S.mId, S.uId);
      const ar = node('div', 'lm-ar'); ar.dir = 'rtl';
      const arLen = bare(line.ar).length;
      ar.style.fontSize = (arLen > 60 ? 32 : arLen > 42 ? 38 : arLen > 26 ? 46 : 56) + 'px';
      const tokens = (line.ar || '').split(/(\s+)/);
      const weights = tokens.map(t => /^\s*$/.test(t) ? 0 : Math.max(1, bare(t).length));
      const sum = weights.reduce((a, b) => a + b, 0) || 1;
      let acc = 0;
      tokens.forEach((token, ti) => {
        if (!token) return;
        if (/^\s+$/.test(token)) { ar.appendChild(document.createTextNode(' ')); return; }
        const w = node('span', 'lm-w');
        w.textContent = token;
        words.push({ el: w, start: acc / sum });
        acc += weights[ti];
        const on = S.lmWord && S.lmWord.q === S.dlQPos && S.lmWord.ti === ti;
        if (on) {
          w.classList.add('lm-picked');
          const gloss = lookupGloss(wordIdx, token) || wordIdx[normalizeAr(token)];
          const pop = node('span', 'lm-pop');
          pop.dir = 'ltr';
          pop.textContent = gloss || T('— no translation yet —', '— pas encore de traduction —');
          w.appendChild(pop);
        }
        w.addEventListener('click', (e) => {
          e.stopPropagation();
          S.lmWord = on ? null : { q: S.dlQPos, ti };
          render();
        });
        ar.appendChild(w);
      });
      lcard.appendChild(ar);
      // the whole spoken line on one line: shrink, never break "وَعَلَيْكُمُ السَّلام" in two
      ar.setAttribute('data-fit-ar', '1');
      fit(ar, { min: FLOOR.ar });
      if (S.lmShowEn && line.en) {
        const en = node('div', 'lm-en'); en.textContent = meaning(line.en);
        lcard.appendChild(en); fit(en, { min: FLOOR.latin });
      }
    }

    // ── sound wave ──
    const wave = node('div', 'lm-wave');
    const H = [8, 14, 22, 30, 18, 26, 36, 24, 14, 20, 32, 40, 28, 18, 24, 30, 16, 10, 22, 34, 26, 16, 12, 20, 28, 18, 10, 8];
    const bars = H.map((h, i) => {
      const b = node('span', 'lm-bar');
      b.style.height = h + 'px';
      b.style.animationDelay = (i % 7) * 0.09 + 's';
      wave.appendChild(b);
      return b;
    });
    if (!isKw) body.appendChild(wave);

    // ── controls ──
    const ctl = node('div', 'lm-ctl');
    const rate = button('lm-rate', RATES[rateIdx] === 1 ? '1×' : '0.75×', T('Playback speed', 'Vitesse de lecture'), () => {
      rateIdx = (rateIdx + 1) % RATES.length;
      rate.textContent = RATES[rateIdx] === 1 ? '1×' : '0.75×';
    });
    const back = button('lm-skip', svg('back', 22) + '<span>' + T('Back', 'Retour') + '</span>', T('Previous line', 'Réplique précédente'), goBack);
    if (S.dlQPos <= 0) back.disabled = true;
    const play = button('lm-play', svg('play', 28, 2.2), T('Play', 'Écouter'), () => {
      if (isKw) return;
      const st = audioState();
      if (st.playing && st.audio) { st.audio.pause(); return; }
      if (st.audio && st.audio.paused && !st.audio.ended && st.audio.currentTime > 0) { st.audio.play().catch(() => {}); return; }
      playLine();
    });
    const next = button('lm-skip', svg(isLast ? 'check' : 'next', 22) + '<span>' + (isLast ? T('Finish', 'Terminer') : T('Next', 'Suivant')) + '</span>', isLast ? T('Finish', 'Terminer') : T('Next line', 'Réplique suivante'), goNext);
    const eng = button('lm-eye' + (S.lmShowEn ? '' : ' off'), svg(S.lmShowEn ? 'eye' : 'eyeOff', 22), S.lmShowEn ? T('Hide English', 'Masquer la traduction') : T('Show English', 'Afficher la traduction'), () => {
      S.lmShowEn = !S.lmShowEn; render();
    });
    const state = { root, play, words, bars, tiles: kwTiles, playingAll: false };
    if (isKw) {
      const row = node('div', 'lm-kw-actions');
      const all = button('lm-pill ghost', '<span>' + T('Listen to all', 'Tout écouter') + '</span>' + svg('play', 14), T('Listen to all words', 'Écouter tous les mots'), async () => {
        const my = ++kwToken;
        state.playingAll = true;
        for (let i = 0; i < kws.length; i++) {
          if (my !== kwToken || !document.body.contains(root)) break;
          kwOn = i;
          try { await speak(kws[i].ar); } catch (_) {}
          await new Promise(r => setTimeout(r, 350));
        }
        if (my === kwToken) { state.playingAll = false; kwOn = -1; }
      });
      const fin = button('lm-pill', '<span>' + (isLast ? T('Finish', 'Terminer') : T('Next', 'Suivant')) + '</span>' + svg('next', 16), isLast ? T('Finish', 'Terminer') : T('Next', 'Suivant'), () => { kwToken++; goNext(); });
      row.appendChild(all); row.appendChild(fin);
      const tg = button('lm-kw-eng' + (S.kwShowEn ? '' : ' off'), svg(S.kwShowEn ? 'eye' : 'eyeOff', 18) + '<span>' + (S.kwShowEn ? T('Hide English', 'Masquer la traduction') : T('Show English', 'Afficher la traduction')) + '</span>', T('Toggle English', 'Afficher ou masquer la traduction'), () => { S.kwShowEn = !S.kwShowEn; render(); });
      body.appendChild(tg);
      body.appendChild(row);
    } else {
      [rate, back, play, next, eng].forEach(b => ctl.appendChild(b));
      body.appendChild(ctl);
      body.appendChild(node('div', 'lm-hint', T('Tap a word to see its meaning', 'Touchez un mot pour voir son sens')));
    }
    if (window.lsStar) {
      const tip = isKw ? T('Tap a word to hear it. Tap Next when you know them.', 'Touchez un mot pour l\u2019écouter. Touchez Suivant quand vous les connaissez.')
        : T('Tap play to hear the line. Tap a word to see its meaning.', 'Touchez lecture pour écouter la réplique. Touchez un mot pour voir son sens.');
      if (S.dlQPos === 0 && !isKw) window.lsStar.intro('dl:' + S.mId + ':' + S.uId + ':' + S.bId + ':' + (S.lessonEnterAt || ''), tip, 450);
      else window.lsStar.setHelp(tip);
    }

    live = state;
    startTicking();

    // Each new line plays once as it appears (as on the website).
    const key = [S.mId, S.uId, S.bId, S.dlQPos, S.lessonEnterAt].join('|');
    if (!isKw && key !== lastAutoKey) {
      lastAutoKey = key;
      setTimeout(() => { if (live && live.root === root && document.body.contains(root)) playLine(); }, 380);
    }
    return root;
  };
})();
