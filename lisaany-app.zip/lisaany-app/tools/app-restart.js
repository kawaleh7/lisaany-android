/* Lisaany app — "start this part again".
 * A ↻ button joins the top bar of every part (and its quick check). It asks
 * first, then sends the learner back to step 1 of the same part — or, on the
 * quick check, back to its first question (not to the start of the lesson).
 * Progress, XP and "done" marks are kept: nothing is erased. */
(function(){
  if (typeof render !== 'function' || typeof resetBS !== 'function') return;
  const ICON = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12a8 8 0 1 1-2.3-5.7"/><path d="M20 4v5h-5"/></svg>';

  function restartQuickCheck(){
    try { if (typeof clearQzTimer === 'function') clearQzTimer(); } catch (e) {}
    try {
      const blk = typeof getBlk === 'function' ? getBlk(S.mId, S.uId, S.bId) : null;
      const qs = blk && typeof buildQuickCheckQuestions === 'function' ? buildQuickCheckQuestions(blk) : null;
      if (qs && qs.length) S.qcQuestions = qs;
    } catch (e) {}
    S.qcIdx = 0; S.qcScore = 0; S.qcChosen = null; S.qcLocked = false; S.qcRetry = false;
    S.qzDeadline = null; S.qzRetry = 0; S.qcStreak = 0; S.qcTimedOut = false;
    S.view = 'quickcheck';
    render();
    toast();
  }

  function restart(){
    if (S.view === 'quickcheck' && (S.qcQuestions || []).length) return restartQuickCheck();
    try { if (typeof stopAudio === 'function') stopAudio(); } catch (e) {}
    try { if (typeof clearQzTimer === 'function') clearQzTimer(); } catch (e) {}
    // State the engine's reset does not cover (cloze, listening, quick check).
    ['clzIdx','clzAns','clzFb','clzLocked','clzScore','clzWrong','lmWord'].forEach((k) => { try { delete S[k]; } catch (e) {} });
    S.qcQuestions = null; S.qcIdx = 0; S.qcScore = 0; S.qcChosen = null; S.qcLocked = false;
    resetBS();
    S.view = 'lesson';
    render();
    try { const sc = document.getElementById('main-scroll'); if (sc) sc.scrollTop = 0; } catch (e) {}
    toast();
  }

  function toast(){
    const t = document.createElement('div');
    t.className = 'rs-toast';
    t.innerHTML = ICON + '<span>Started over</span>';
    document.body.appendChild(t);
    setTimeout(() => t.classList.add('in'), 20);
    setTimeout(() => { t.classList.remove('in'); setTimeout(() => t.remove(), 300); }, 1600);
  }

  function ask(){
    if (document.querySelector('.rs-back')) return;
    const back = document.createElement('div');
    back.className = 'rs-back';
    const sheet = document.createElement('div');
    sheet.className = 'rs-sheet';
    const qc = S.view === 'quickcheck';
    sheet.innerHTML =
      '<div class="rs-ic">' + ICON + '</div>' +
      '<div class="rs-title">' + (qc ? 'Start the quick check again?' : 'Start this part again?') + '</div>' +
      '<div class="rs-sub">' + (qc ? 'You\u2019ll go back to the first question.' : 'You\u2019ll go back to the first step.') + ' Your progress and XP are kept.</div>';
    const go = document.createElement('button');
    go.className = 'rs-go'; go.textContent = 'Start over';
    const keep = document.createElement('button');
    keep.className = 'rs-keep'; keep.textContent = 'Keep going';
    sheet.appendChild(go); sheet.appendChild(keep);
    back.appendChild(sheet);
    document.body.appendChild(back);
    requestAnimationFrame(() => back.classList.add('in'));
    const close = () => { back.classList.remove('in'); setTimeout(() => back.remove(), 250); };
    back.addEventListener('click', (e) => { if (e.target === back) close(); });
    keep.addEventListener('click', close);
    go.addEventListener('click', () => { back.remove(); restart(); });
  }
  window.lsRestartPart = restart;

  function addButton(){
    if (S.view !== 'lesson' && S.view !== 'quickcheck') return;
    const top = document.querySelector('.qx-top, .lm-top') || document.querySelector('.lesson-hdr');
    if (!top || top.querySelector('.rs-btn')) return;
    const b = document.createElement('button');
    b.className = 'rs-btn';
    b.setAttribute('aria-label', 'Start this part again');
    b.innerHTML = ICON;
    b.addEventListener('click', (e) => { e.stopPropagation(); ask(); });
    top.appendChild(b);
  }

  const _render = render;
  render = function(){
    const out = _render.apply(this, arguments);
    try { addButton(); } catch (e) {}
    return out;
  };
})();
