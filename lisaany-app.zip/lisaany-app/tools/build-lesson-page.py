#!/usr/bin/env python3
"""
Build the in-app lesson page from the website's arabic_platform.html.

The website file is a single-page app: all views render into #app from one
engine script (state object S + render()). This script lifts that engine out
unchanged, drops everything that belongs to the website (top nav, footer nav,
Qur'an/school links, analytics, session redirects), embeds the fonts and the
Supabase client so the page boots with no network, and adds a small bridge so
React Native can open a unit/block and receive progress.

Usage:
  python3 tools/build-lesson-page.py [path/to/arabic_platform.html]

Outputs:
  assets/lesson/lesson.html      — the page (open it in a browser to test)
  src/data/lesson-page.ts        — the same page as a string for the WebView

Every edit to the engine is an exact-match patch that must hit once; the build
fails loudly if the website file changed underneath it, instead of silently
producing a broken page.
"""
from __future__ import annotations

import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = (
    sys.argv[1]
    if len(sys.argv) > 1
    else os.path.join(os.path.dirname(ROOT), "src", "Lisaany-main", "arabic_platform.html")
)
FONTS_CSS = os.path.join(ROOT, "tools", "fonts", "fonts.css")
SUPABASE_UMD = os.path.join(ROOT, "node_modules", "@supabase", "supabase-js", "dist", "umd", "supabase.js")
OUT_HTML = os.path.join(ROOT, "assets", "lesson", "lesson.html")
OUT_TS = os.path.join(ROOT, "src", "data", "lesson-page.ts")


def patch(src: str, old: str, new: str, count: int = 1, label: str = "") -> str:
    found = src.count(old)
    if found != count:
        raise SystemExit(f"patch {label or old[:60]!r}: expected {count} match(es), found {found}")
    return src.replace(old, new)


def main() -> None:
    html = open(SRC, encoding="utf-8").read()

    styles = re.findall(r"<style[^>]*>(.*?)</style>", html, flags=re.S)
    scripts = re.findall(r"<script>(.*?)</script>", html, flags=re.S)
    if len(styles) != 4:
        raise SystemExit(f"expected 4 <style> blocks, found {len(styles)}")
    if len(scripts) != 6:
        raise SystemExit(f"expected 6 inline <script> blocks, found {len(scripts)}")

    site_css, _canon_nav_css, _profilebar_css, lesson_css = styles
    _ga, engine, rewards, _signin_badge, _profile_badge, _resume_nav = scripts

    # ── paywall: the app gives Units 1.1–1.3 free (website may still say 1.1–1.2) ──
    engine = engine.replace("const FREE_UNITS = ['1.1','1.2'];", "const FREE_UNITS = ['1.1','1.2','1.3'];")
    # ── content fixes (applied only while the website still has the old wording) ──
    engine = engine.replace(
        'ar:"خَيْر، الْحَمْدُ لِلَّه، شُكْرًا يَا أَحْمَد.",en:"Good, praise be to God, thank you Ahmad"',
        'ar:"بِخَيْر، الْحَمْدُ لِلَّه، شُكْرًا يَا أَحْمَد.",en:"I\'m well, praise be to God, thank you Ahmad"',
    )

    # ── engine patches ────────────────────────────────────────────────────
    # 1. The website boots itself (restores the hub, renders, wires the nav's
    #    profile indicator). In the app the shell decides what opens.
    tail_start = engine.index("\n// Restore last view\n")
    engine = engine[:tail_start] + "\n"

    # 2. render(): views the native shell owns are handed back to it instead
    #    of being drawn, and the website's bottom tab bar is not appended.
    engine = patch(
        engine,
        "  try{document.body.classList.remove('dl-active');}catch(e){}\n"
        "  const app=document.getElementById('app'); app.innerHTML='';",
        "  try{document.body.classList.remove('dl-active');}catch(e){}\n"
        "  if(window.LisaanyApp && LisaanyApp._handoff(S.view)) return;\n"
        "  const app=document.getElementById('app'); app.innerHTML='';",
        label="render handoff",
    )
    engine = patch(engine, "  app.appendChild(mkNav());\n", "", label="render nav")
    engine = patch(
        engine,
        "  app.appendChild(sc); app.appendChild(mkNav());",
        "  app.appendChild(sc);",
        label="quick-check result nav",
    )
    # Quick-check result (teaching blocks end here): same next-step buttons.
    engine = patch(
        engine,
        "    nav.appendChild(el('button',{className:'btn btn-ghost',onclick:function(){S.view='blocks';render();}},'← All Blocks'));\n"
        "    nav.appendChild(el('button',{className:'btn btn-primary',onclick:function(){\n"
        "      S.reviewItems=null; S.reviewIdx=0; S.reviewFlipped=false;\n"
        "      S.view='review'; render();\n"
        "    }},'Quick Review →'));",
        "    const _u = getUnit(S.mId, S.uId) || {blocks:[]};\n"
        "    const _bIdx = _u.blocks.findIndex(b => b.id === S.bId);\n"
        "    const _next = _bIdx >= 0 ? _u.blocks[_bIdx + 1] : null;\n"
        "    nav.appendChild(el('button',{className:'btn btn-ghost',onclick:function(){S.view='blocks';render();}},'← Back to Unit'));\n"
        "    if(_next){\n"
        "      nav.appendChild(el('button',{className:'btn btn-primary',onclick:function(){ S.bId=_next.id; resetBS(); S.view='lesson'; render(); }},'Next Block →'));\n"
        "    } else {\n"
        "      nav.appendChild(el('button',{className:'btn btn-primary',onclick:function(){ S.view='units'; render(); }},'Finish Unit ✓'));\n"
        "    }",
        label="quick-check result buttons",
    )
    engine = patch(
        engine,
        "sc.appendChild(mkBackC('Back to Blocks', () => { S.view='blocks'; render(); }));",
        "sc.appendChild(mkBackC('Back to Unit', () => { S.view='blocks'; render(); }));",
        label="lesson back label",
    )

    # 3. Block-complete screen: in the app the natural next step is the next
    #    block, so offer it (no extra Quick Review — the quick check already
    #    reviews the block); "All Blocks" becomes "Back to Unit" (handoff).
    engine = patch(
        engine,
        "  nav.appendChild(el('button', {className:'btn btn-ghost', onclick:() => { S.view='blocks'; render(); }}, '← All Blocks'));\n"
        "  nav.appendChild(el('button', {className:'btn btn-primary', onclick:() => {\n"
        "    S.reviewItems = null; S.reviewIdx = 0; S.reviewFlipped = false;\n"
        "    S.view = 'review'; render();\n"
        "  }}, 'Quick Review →'));",
        "  const _bIdx = unit.blocks.findIndex(b => b.id === S.bId);\n"
        "  const _next = _bIdx >= 0 ? unit.blocks[_bIdx + 1] : null;\n"
        "  nav.appendChild(el('button', {className:'btn btn-ghost', onclick:() => { S.view='blocks'; render(); }}, '← Back to Unit'));\n"
        "  if(_next){\n"
        "    nav.appendChild(el('button', {className:'btn btn-primary', onclick:() => {\n"
        "      S.bId = _next.id; resetBS(); S.view = 'lesson'; render();\n"
        "    }}, 'Next Block →'));\n"
        "  } else {\n"
        "    nav.appendChild(el('button', {className:'btn btn-primary', onclick:() => { S.view='units'; render(); }}, 'Finish Unit ✓'));\n"
        "  }",
        label="complete nav",
    )

    # 4. Keep a handle on the cloud-progress load so the bridge can wait for
    #    it (briefly) before opening the lesson.
    engine = patch(
        engine,
        "try { if (typeof loadCloudProgress === 'function') loadCloudProgress(session.user.id); } catch(e){}",
        "try { if (typeof loadCloudProgress === 'function') window.__cloudLoad = loadCloudProgress(session.user.id); } catch(e){}",
        label="cloud load handle",
    )

    # 5. Access is decided by the native shell; the page trusts what it says.
    engine = patch(
        engine,
        "function isPremium(){ return window.__IS_PREMIUM === true; }",
        "function isPremium(){ return window.__IS_PREMIUM === true || window.__APP_PREMIUM === true; }",
        label="premium override",
    )

    # 6. The page's Supabase client must never refresh or persist the token:
    #    the native app owns the session and hands the page a fresh access
    #    token on every open. Two clients rotating one refresh token would
    #    sign the user out of the app.
    engine = patch(
        engine,
        "  window.sbClient = createClient(\n"
        "    'https://cfaxrzfqvoalwznkhwnx.supabase.co',\n"
        "    'sb_publishable_JzVuIvyj2OEP4o0zbURcQA_NhfBFPaa'\n"
        "  );",
        "  window.sbClient = createClient(\n"
        "    'https://cfaxrzfqvoalwznkhwnx.supabase.co',\n"
        "    'sb_publishable_JzVuIvyj2OEP4o0zbURcQA_NhfBFPaa',\n"
        "    { auth: { autoRefreshToken: false, persistSession: false, detectSessionInUrl: false } }\n"
        "  );",
        label="supabase client options",
    )

    # 7. Review session (opened from the native Today tab): only units the
    #    learner can open. The website lists every unit of a browsable module,
    #    which hands free users the Premium vocabulary of 1.4 and 1.5.
    engine = patch(
        engine,
        "    mod.units.forEach(u=>{\n"
        "      if(u.blocks.some(b=>b.type==='vocab')){\n"
        "        opts.push({mId:mod.id, uId:u.id, group:mod.id+' \\u00b7 '+mod.title, label:u.id+' \\u2014 '+(u.title||('Unit '+u.id))});\n",
        "    mod.units.forEach(u=>{\n"
        "      if(!canAccess(mod.id, u.id)) return;\n"
        "      if(u.blocks.some(b=>b.type==='vocab')){\n"
        "        opts.push({mId:mod.id, uId:u.id, group:mod.id+' \\u00b7 '+mod.title, label:u.id+' \\u2014 '+(u.title||('Unit '+u.id))});\n",
        label="review builder access",
    )

    # 8. Analytics stub — the website's gtag is not loaded in the app.
    engine = "function gtag(){}\n" + engine

    # ── rewards engine (celebrations, hero word, audio pulse, toasts) ─────
    rewards = patch(
        rewards,
        "  window.addEventListener('load', ()=> setTimeout(showWelcome, 600));\n",
        "",
        label="welcome toast",
    )

    # ── bridge ────────────────────────────────────────────────────────────
    bridge = r"""
/* ═══ Lisaany app bridge — React Native ⇄ lesson engine ═══
   The shell sets window.__LISAANY_APP before this document loads (or calls
   LisaanyApp.open later). UI language is read by the engine at load from
   localStorage 'lisaany_lang', so the shell writes that key before load too. */
window.__APP_MODE = true;
window.LisaanyApp = (function(){
  let opened = false, opening = false, current = null, applied = null;
  function post(msg){
    try{
      const s = JSON.stringify(msg);
      if(window.ReactNativeWebView && window.ReactNativeWebView.postMessage) window.ReactNativeWebView.postMessage(s);
      else if(window.parent && window.parent !== window) window.parent.postMessage(s, '*');
    }catch(e){}
  }
  function snapshot(){
    return { prog: PROG, pos: POS, xp: XP, streak: STREAK, uid: _STORAGE_UID,
      last_day: (function(){ try { return localStorage.getItem(storageKey('last_day')) || null; } catch(e){ return null; } })() };
  }
  function wait(ms){ return new Promise(r => setTimeout(r, ms)); }
  // Is this access token already past its `exp`? auth-js would refresh it inside
  // setSession and rotate the refresh token the app still holds, which signs the
  // app out. The shell hands us a fresh one instead (see needSession).
  function jwtExpired(token){
    try{
      let part = String(token).split('.')[1] || '';
      part = part.replace(/-/g, '+').replace(/_/g, '/');
      while(part.length % 4) part += '=';
      const exp = JSON.parse(atob(part)).exp;
      return typeof exp === 'number' && exp * 1000 <= Date.now();
    }catch(e){ return false; }
  }
  let askedFor = null;
  function needSession(token){
    if(askedFor === token) return; // once per token: the shell answers with setSession
    askedFor = token;
    post({ type:'needSession' });
  }
  async function applySession(cfg){
    const sb = getSb(); if(!sb) return;
    try{
      const { data:{ session } } = await sb.auth.getSession();
      const want = cfg.session && cfg.session.access_token ? cfg.session : null;
      if(want){
        const sameUser = session && session.access_token === want.access_token;
        if(sameUser){ applied = want.access_token; }
        else if(jwtExpired(want.access_token)){ needSession(want.access_token); }
        else { await sb.auth.setSession({ access_token: want.access_token, refresh_token: want.refresh_token }); applied = want.access_token; }
      } else if(session){
        await sb.auth.signOut({ scope: 'local' });
      }
    }catch(e){ console.warn('[app] session', e && e.message); }
  }
  async function open(cfg){
    cfg = cfg || {};
    const key = JSON.stringify([cfg.view, cfg.mId, cfg.uId, cfg.bId, cfg.session && cfg.session.access_token]);
    if((opened || opening) && current === key) return;
    current = key; opening = true;
    try{
      window.__APP_PREMIUM = cfg.premium === true;
      // The learner's own storage slot, whether or not the session below can
      // be applied (offline, expired token): saves and snapshots must never
      // fall into the guest slot for a signed-in learner.
      if(cfg.uid){ try{ _applyStorageUid(String(cfg.uid)); }catch(e){} }
      await applySession(cfg);
      try{ window.__cloudLoad = null; await Promise.race([loadPremiumStatus(), wait(4000)]); }catch(e){}
      if(window.__cloudLoad){ try{ await Promise.race([window.__cloudLoad, wait(2500)]); }catch(e){} }
      if(cfg.prog && typeof cfg.prog === 'object'){
        try{ _applyingRemote = true; _mergeProg(cfg.prog); if(cfg.pos) _mergePos(cfg.pos); }finally{ _applyingRemote = false; }
        try{ save(); savePos(); }catch(e){}
      }
      navigate(cfg);
    }finally{ opening = false; }
  }
  function navigate(cfg){
    try{ document.documentElement.classList.toggle('ls-light', cfg.theme === 'light'); }catch(e){}
    const view = cfg.view || 'lesson';
    if(cfg.mId != null) S.mId = Number(cfg.mId);
    if(cfg.uId != null) S.uId = String(cfg.uId);
    if(view === 'lesson'){
      S.bId = Number(cfg.bId);
      if(!getBlk(S.mId, S.uId, S.bId)){ post({ type:'error', message:'Lesson not found', cfg }); return; }
      resetBS(); S.view = 'lesson';
    } else if(view === 'review'){
      S.reviewItems = null; S.reviewIdx = 0; S.reviewFlipped = false; S.reviewCustom = false; S.view = 'review';
    } else if(view === 'srsreview' || view === 'reviewBuilder'){
      S.view = view;
    } else {
      post({ type:'error', message:'Unknown view ' + view }); return;
    }
    opened = true;
    try{ const sc = document.getElementById('main-scroll'); if(sc) sc.scrollTop = 0; }catch(e){}
    render();
    post({ type:'opened', view: S.view, mId: S.mId, uId: S.uId, bId: S.bId });
  }
  // Views the native shell owns. Before the first open, nothing is drawn.
  const SHELL_VIEWS = { hub:1, units:1, blocks:1, signup:1, upgrade:1 };
  function _handoff(view){
    if(!opened) return true;
    if(!SHELL_VIEWS[view]) return false;
    try{ if(_pushDirty){ if(_pushTimer) clearTimeout(_pushTimer); pushCloudProgress(); } }catch(e){}
    post({ type:'navigate', view, mId:S.mId, uId:S.uId, bId:S.bId, progress: snapshot() });
    return true;
  }
  function close(){ S.view = 'blocks'; render(); }
  async function setSession(session){
    try{
      const sb = getSb(); if(!sb || !session || !session.access_token) return;
      if(session.access_token === applied) return;
      if(jwtExpired(session.access_token)){ needSession(session.access_token); return; }
      const wasIn = window.__IS_LOGGED_IN === true;
      await sb.auth.setSession({ access_token: session.access_token, refresh_token: session.refresh_token });
      applied = session.access_token;
      // Signed in only now (the token at open was stale): switch to this
      // learner's storage slot and pull the cloud row, as an open would have.
      if(!wasIn){ try{ await loadPremiumStatus(); }catch(e){} }
    }catch(e){}
  }
  // auth-js refreshes inside getSession() when a token is near expiry, whatever
  // autoRefreshToken says. If that happens here the app must adopt the rotated
  // pair, or its own refresh token is dead and it signs out at the next tick.
  try{
    const sb0 = getSb();
    if(sb0) sb0.auth.onAuthStateChange(function(event, session){
      if(event !== 'TOKEN_REFRESHED' || !session || !session.access_token) return;
      applied = session.access_token;
      post({ type:'session', access_token: session.access_token, refresh_token: session.refresh_token });
    });
  }catch(e){}
  function flush(){ try{ if(_pushDirty){ if(_pushTimer) clearTimeout(_pushTimer); pushCloudProgress(); } }catch(e){} post(Object.assign({ type:'progress' }, snapshot())); }
  return { open, navigate, close, flush, setSession, post, snapshot, _handoff, get opened(){ return opened; } };
})();

// Progress: every local save also reaches the shell (debounced).
(function(){
  let t = null;
  function ping(){ clearTimeout(t); t = setTimeout(() => LisaanyApp.post(Object.assign({ type:'progress' }, LisaanyApp.snapshot())), 120); }
  const _save = save;       save = function(){ const r = _save.apply(this, arguments); ping(); return r; };
  const _savePos = savePos; savePos = function(){ const r = _savePos.apply(this, arguments); ping(); return r; };
})();

// After each render, tell the shell which view is up and what colour meets
// the screen edges, so the native safe areas can match.
(function(){
  function edgeColor(y){
    try{
      let el = document.elementFromPoint(Math.floor(window.innerWidth / 2), y);
      while(el){
        const bg = window.getComputedStyle(el).backgroundColor;
        if(bg && bg !== 'transparent' && !/rgba\(\s*\d+,\s*\d+,\s*\d+,\s*0\s*\)/.test(bg)) return bg;
        el = el.parentElement;
      }
    }catch(e){}
    return window.getComputedStyle(document.body).backgroundColor;
  }
  function report(){
    if(!LisaanyApp.opened) return;
    requestAnimationFrame(() => requestAnimationFrame(() => {
      LisaanyApp.post({ type:'view', view:S.view, mId:S.mId, uId:S.uId, bId:S.bId,
        top: edgeColor(2), bottom: edgeColor(window.innerHeight - 3), stage: document.body.classList.contains('dl-active') });
    }));
  }
  const _render = render;
  render = function(){ const r = _render.apply(this, arguments); report(); return r; };
  const _qcr = showQuickCheckResult;
  showQuickCheckResult = function(){ const r = _qcr.apply(this, arguments); report(); return r; };
})();

// Errors reach the shell's console instead of vanishing.
window.addEventListener('error', e => { try{ LisaanyApp.post({ type:'jserror', message: String(e.message), source: String(e.filename||''), line: e.lineno }); }catch(_){} });
window.addEventListener('unhandledrejection', e => { try{ LisaanyApp.post({ type:'jserror', message: 'unhandled: ' + String(e.reason && e.reason.message || e.reason) }); }catch(_){} });

// Boot: config injected before load, or a later LisaanyApp.open() call.
if(window.__LISAANY_APP) LisaanyApp.open(window.__LISAANY_APP);
window.addEventListener('message', e => {
  try{ const d = typeof e.data === 'string' ? JSON.parse(e.data) : e.data; if(d && d.type === 'open') LisaanyApp.open(d.cfg); }catch(_){}
});
"""

    app_css = """
/* ═══ app mode ═══ */
#app{top:0 !important;}
.lis-nav,.lis-mobile-menu,.lis-contact-modal,.bottom-nav,.geo-bg-anim,.bg-stars,.bg-glow,.star-dot,#lisaany-lang-toggle{display:none !important;}
html,body{overscroll-behavior:none;-webkit-tap-highlight-color:transparent;-webkit-touch-callout:none;}
body{-webkit-user-select:none;user-select:none;}
input,textarea{-webkit-user-select:text;user-select:text;}
.scroll{padding-bottom:56px !important;}
"""

    # App-only restyles of individual lesson views (the website is untouched).
    listen_css = open(os.path.join(ROOT, "tools", "app-listen.css"), encoding="utf-8").read()
    listen_js = open(os.path.join(ROOT, "tools", "app-listen.js"), encoding="utf-8").read()
    check_css = open(os.path.join(ROOT, "tools", "app-check.css"), encoding="utf-8").read()
    check_js = open(os.path.join(ROOT, "tools", "app-check.js"), encoding="utf-8").read()
    cards_css = open(os.path.join(ROOT, "tools", "app-cards.css"), encoding="utf-8").read()
    cards_js = open(os.path.join(ROOT, "tools", "app-cards.js"), encoding="utf-8").read()
    drills_css = open(os.path.join(ROOT, "tools", "app-drills.css"), encoding="utf-8").read()
    drills_js = open(os.path.join(ROOT, "tools", "app-drills.js"), encoding="utf-8").read()
    restart_css = open(os.path.join(ROOT, "tools", "app-restart.css"), encoding="utf-8").read()
    restart_js = open(os.path.join(ROOT, "tools", "app-restart.js"), encoding="utf-8").read()
    light_css = open(os.path.join(ROOT, "tools", "app-light.css"), encoding="utf-8").read()

    fonts_css = open(FONTS_CSS, encoding="utf-8").read()
    supabase_js = open(SUPABASE_UMD, encoding="utf-8").read()

    page = (
        "<!DOCTYPE html>\n"
        "<!-- Lisaany — in-app lesson page. Generated by tools/build-lesson-page.py from arabic_platform.html. Do not edit by hand. -->\n"
        '<html lang="en" dir="ltr">\n<head>\n<meta charset="UTF-8">\n'
        '<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover">\n'
        '<meta name="google" content="notranslate">\n'
        "<title>Lisaany Lesson</title>\n"
        "<style>\n" + fonts_css + "\n</style>\n"
        "<style>\n" + site_css + "\n</style>\n"
        "<style>\n" + lesson_css + "\n</style>\n"
        "<style>\n" + app_css + "\n</style>\n"
        "<style>\n" + listen_css + "\n</style>\n"
        "<style>\n" + check_css + "\n</style>\n"
        "<style>\n" + cards_css + "\n</style>\n"
        "<style>\n" + drills_css + "\n</style>\n"
        "<style>\n" + restart_css + "\n</style>\n"
        "<style>\n" + light_css + "\n</style>\n"
        "<script>\n" + supabase_js + "\n</script>\n"
        "</head>\n<body>\n"
        '<div id="app"></div>\n'
        "<script>\n" + engine + "\n</script>\n"
        "<script>\n" + rewards + "\n</script>\n"
        "<script>\n" + listen_js + "\n</script>\n"
        "<script>\n" + check_js + "\n</script>\n"
        "<script>\n" + cards_js + "\n</script>\n"
        "<script>\n" + drills_js + "\n</script>\n"
        "<script>\n" + restart_js + "\n</script>\n"
        "<script>\n" + bridge + "\n</script>\n"
        "</body>\n</html>\n"
    )

    os.makedirs(os.path.dirname(OUT_HTML), exist_ok=True)
    open(OUT_HTML, "w", encoding="utf-8").write(page)

    ts = (
        "/* Generated by tools/build-lesson-page.py — do not edit. */\n"
        "// The lesson engine lifted from lisaany.com's arabic_platform.html, with the\n"
        "// fonts and Supabase client embedded so it boots offline.\n"
        "export const LESSON_HTML: string = " + json.dumps(page, ensure_ascii=False) + ";\n"
    )
    open(OUT_TS, "w", encoding="utf-8").write(ts)

    def kb(s: str) -> str:
        return f"{len(s.encode('utf-8')) // 1024} KB"

    print(f"engine {kb(engine)} · rewards {kb(rewards)} · css {kb(site_css + lesson_css)} · fonts {kb(fonts_css)} · supabase {kb(supabase_js)}")
    print(f"→ {os.path.relpath(OUT_HTML, ROOT)} ({kb(page)})")
    print(f"→ {os.path.relpath(OUT_TS, ROOT)} ({kb(ts)})")


if __name__ == "__main__":
    main()
