"""Builds the in-app Norania (learn-to-read) page from the website's
aqida-norania.html.

Outputs
  assets/norania/norania.html   — the page, for checking in a browser
  src/data/norania-page.ts      — the same page as a string (NORANIA_HTML)
  src/data/norania.json         — steps + lessons, for the native screens

In the app the page never shows its own home: it opens straight into one
lesson (window.__NORANIA_APP = { lesson, done, theme }), reports progress with
`norania-progress`, and asks the app to close with `norania-close`.
"""
import json, os, re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.environ.get('NORANIA_SRC', '/home/claude/src/Lisaany-main/aqida-norania.html')
html = open(SRC, encoding='utf-8').read()

def js_unescape(s):
    return re.sub(r'\\u([0-9a-fA-F]{4})', lambda m: chr(int(m.group(1), 16)), s).replace("\\'", "'")

# ── lessons / steps for the native screens ──
body = html[html.index('const LESSONS=['):]
body = body[:body.index('\n];')]
lessons = []
for m in re.finditer(r"\{part:'((?:[^'\\]|\\.)*)',type:'([a-z]+)',title:'((?:[^'\\]|\\.)*)'(?:,icon:'((?:[^'\\]|\\.)*)')?", body):
    lessons.append({'i': len(lessons), 'part': js_unescape(m.group(1)), 'type': m.group(2),
                    'title': js_unescape(m.group(3)), 'icon': js_unescape(m.group(4) or '')})
# letters per lesson (for the sticker album)
gsrc = re.search(r"const G=\[(.*?)\];", html, re.S).group(1)
groups = [[chr(int(x, 16)) for x in re.findall(r'\\u([0-9a-fA-F]{4})', g)] for g in re.findall(r'\[(.*?)\]', gsrc)]
gi = 0
for l in lessons:
    if l['type'] == 'letters' and gi < len(groups):
        l['letters'] = groups[gi]
        gi += 1
    else:
        l['letters'] = []
ALL_LETTERS = [c for g in groups for c in g]

parts = json.loads(js_unescape(re.search(r"const parts=(\[[^\]]*\]);", html).group(1)).replace("'", '"'))
icons = json.loads(js_unescape(re.search(r"const CHICON=(\[[^\]]*\]);", html).group(1)).replace("'", '"'))
desc_src = re.search(r"const CHDESC=\[\s*(.*?)\s*\];", html, re.S).group(1)
descs = [js_unescape(d) for d in re.findall(r"'((?:[^'\\]|\\.)*)'", desc_src)]
steps = [{'name': p, 'icon': icons[k] if k < len(icons) else '', 'desc': descs[k] if k < len(descs) else '',
          'lessons': [l['i'] for l in lessons if l['part'] == p]} for k, p in enumerate(parts)]
for l in lessons:
    l['step'] = parts.index(l['part']) if l['part'] in parts else 0
    if l['icon'] in ('BOOK', 'STAR', '✓'):
        l['icon'] = ''
assert len(lessons) >= 30, f'only {len(lessons)} lessons parsed'
os.makedirs(os.path.join(ROOT, 'src', 'data'), exist_ok=True)
json.dump({'steps': steps, 'lessons': lessons, 'letters': ALL_LETTERS}, open(os.path.join(ROOT, 'src', 'data', 'norania.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

# ── the page ──
APP_CSS = """
<style id="app-norania">
.topnav,.thero,#home,footer,.site-footer{display:none!important}
body{padding-top:env(safe-area-inset-top)}
.wrap{padding:12px 16px 120px!important;max-width:720px}
#player{display:block}
.exit{font-size:0!important;width:40px;height:40px;border-radius:20px;padding:0!important}
.exit::before{content:'\\2715';font-size:16px}
.navbar{padding-bottom:calc(12px + env(safe-area-inset-bottom))!important}


/* ---- Lesson content: bigger, calmer, one font ----
   Arabic letters are drawn in Noto Naskh: Amiri (the page's display font)
   detaches the vowel marks from their letter on phones, so words like ثُمَّ
   and رَبُّهُ fell apart. Everything that shows a letter is also larger. */
.tile,.cell,.scell,.joined,.bigletter,.qword .ar,.cmpc .ca,.fact .v.ar,.dagger-mark-key{font-family:'Noto Naskh Arabic','Amiri',serif!important}
.tiles.latin .tile{font-family:'Inter',sans-serif!important}
.lessoncoach{display:none!important}
.tile{box-sizing:border-box;padding:0;width:72px;height:86px;min-width:72px;min-height:86px;font-size:44px;border-radius:18px}
.tiles{gap:10px}
/* Drills size their tiles inline (min-width 84px, 30px letters): four no longer
   fit a phone row, and the letters were small. */
.tiles .tile{min-width:72px!important}
.tiles:not(.latin) .tile{font-size:40px!important}
.cell{font-size:38px;min-width:64px;padding:10px 12px;border-radius:16px}
.rrow{gap:12px}
/* Spell & read: one row of letters, then the word */
.spellrow{background:#fff;padding:20px 12px 16px;border-radius:20px}
.rrow.sp{flex-wrap:wrap;gap:10px}
.scell{font-size:42px;height:88px;min-width:70px;padding:0 12px;border-radius:18px;line-height:1.2;box-shadow:0 8px 22px -16px rgba(27,33,84,.4)}
.rrow.sp.many .scell{font-size:34px;height:72px;min-width:54px;padding:0 8px}
.sarrow{font-size:18px;color:var(--gold);opacity:1;margin:4px 0}
.joined{font-size:66px;line-height:1.6}
/* The hero letter grows with its content (a fixed 140px square clipped
   whole words and verses) */
.bigletter{background:var(--paper)!important;border:1px solid var(--border);width:auto!important;height:auto!important;min-width:140px;min-height:140px;max-width:100%;padding:12px 26px;flex-wrap:wrap;line-height:1.5}
.cmpc .ca{font-size:56px;line-height:1.6}
.fact .v.ar{font-size:30px}
.note{border-left:4px solid var(--gold)}
/* Words: a 2-up grid of big cards, the whole card plays the word;
   long verses take the full width */
.qgrid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:6px 0 12px}
.qgrid .qword{position:relative;flex-direction:column;justify-content:center;gap:4px;min-height:118px;padding:22px 10px 12px;margin:0;border-radius:18px;cursor:pointer;box-shadow:0 8px 22px -16px rgba(27,33,84,.4)}
.qgrid .qword.wide{grid-column:1 / -1;min-height:96px}
.qgrid .qword .ar{font-size:38px;line-height:1.7;text-align:center}
.qgrid .qword.wide .ar{font-size:30px}
.qgrid .qword .tx{text-align:center;font-size:13px}
.qgrid .qword .tx:empty{display:none}
.qgrid .qword .listen.sm{position:absolute;top:8px;left:8px;width:30px;height:30px;min-height:30px;padding:0;border-radius:15px;justify-content:center;box-shadow:none}
.qgrid .qword .listen.sm svg{width:14px;height:14px}
</style>
"""
APP_JS = """
<script id="app-norania-bridge">
(function(){
  var cfg = window.__NORANIA_APP || {};
  function post(m){
    try{
      if (window.ReactNativeWebView) window.ReactNativeWebView.postMessage(JSON.stringify(m));
      else if (window.parent && window.parent !== window) window.parent.postMessage(m, '*');
    }catch(e){}
  }
  try{
    if (cfg.done) { for (var k in cfg.done) if (cfg.done[k]) done[k] = true; }
    var _save = saveDone;
    saveDone = function(){ _save(); post({ type: 'norania-progress', done: done }); };
    goHome = function(){ post({ type: 'norania-close', done: done }); };
    window.addEventListener('error', function(e){ post({ type: 'jserror', message: String(e.message || e) }); });
    // Count wrong taps so the app can award 1-3 stars.
    var wrong = 0;
    try{
      new MutationObserver(function(ms){
        for (var i = 0; i < ms.length; i++) {
          var t = ms[i].target;
          if (t && t.classList && t.classList.contains('wrong')) wrong++;
        }
      }).observe(document.body, { subtree: true, attributes: true, attributeFilter: ['class'] });
    }catch(e){}
    var lessonIdx = Math.max(0, Math.min(LESSONS.length - 1, Number(cfg.lesson) || 0));
    var reported = false;
    var _save2 = saveDone;
    saveDone = function(){
      _save2();
      if (!reported && done[LESSONS[lessonIdx] && LESSONS[lessonIdx].title]) {
        reported = true;
        post({ type: 'norania-finished', lesson: lessonIdx, wrong: wrong, done: done });
      }
    };

    // Layout pass: group word rows into a 2-up grid (long verses full width)
    // and shrink spell cells when a word has many parts. Idempotent, so it can
    // run on every re-render.
    function layout(){
      var card = document.getElementById('card'); if (!card) return;
      var q = card.querySelectorAll('.qword');
      for (var i = 0; i < q.length; i++) {
        var el = q[i];
        if (el.parentNode.classList && el.parentNode.classList.contains('qgrid')) continue;
        var grid = document.createElement('div'); grid.className = 'qgrid';
        el.parentNode.insertBefore(grid, el);
        var n = el;
        while (n && n.classList && n.classList.contains('qword')) { var nx = n.nextElementSibling; grid.appendChild(n); n = nx; }
      }
      var ws = card.querySelectorAll('.qgrid .qword');
      for (var j = 0; j < ws.length; j++) {
        var ar = ws[j].querySelector('.ar');
        var len = ar ? ar.textContent.replace(/[ً-ٰٟۖ-ۭ\s]/g, '').length : 0;
        ws[j].classList.toggle('wide', len > 6 || !!(ar && /\s/.test(ar.textContent.trim())));
      }
      var sp = card.querySelectorAll('.rrow.sp');
      for (var k = 0; k < sp.length; k++) sp[k].classList.toggle('many', sp[k].children.length >= 5);
    }
    try{
      var cardEl = document.getElementById('card');
      if (cardEl) new MutationObserver(function(){ layout(); }).observe(cardEl, { childList: true, subtree: true });
    }catch(e){}
    document.addEventListener('click', function(e){
      var w = e.target && e.target.closest ? e.target.closest('.qgrid .qword') : null;
      if (!w || (e.target.closest && e.target.closest('button'))) return;
      var b = w.querySelector('.listen'); if (b) b.click();
    });
    openLesson(lessonIdx);
    post({ type: 'norania-opened' });
  }catch(e){ post({ type: 'jserror', message: String(e && e.message || e) }); }
})();
</script>
"""
page = html.replace('</head>', APP_CSS + '</head>', 1)
page = page.replace('<head>', '<head>\n<script>/*__NORANIA_CFG__*/</script>', 1)
page = page.replace('function spellOne(w,showOriginal=false){', 'function spellOne(w,showOriginal=false){showOriginal=false;', 1)
assert 'showOriginal=false;' in page, 'spellOne patch did not apply'
idx = page.rindex('</body>')
page = page[:idx] + APP_JS + page[idx:]
page = '<!-- Lisaany — in-app Norania page. Generated by tools/build-norania-page.py from aqida-norania.html. Do not edit by hand. -->\n' + page

os.makedirs(os.path.join(ROOT, 'assets', 'norania'), exist_ok=True)
open(os.path.join(ROOT, 'assets', 'norania', 'norania.html'), 'w', encoding='utf-8').write(page)
open(os.path.join(ROOT, 'src', 'data', 'norania-page.ts'), 'w', encoding='utf-8').write(
    '// Generated by tools/build-norania-page.py — do not edit.\n'
    'export const NORANIA_HTML: string = ' + json.dumps(page, ensure_ascii=False) + ';\n')
print(f'{len(lessons)} lessons in {len(steps)} steps; page {len(page)//1024} KB')
