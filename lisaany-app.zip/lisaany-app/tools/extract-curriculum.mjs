/**
 * Extract the course structure the native shell needs from the lesson page.
 *
 * The website builds its curriculum at runtime: the static `CUR` constant is
 * augmented with generated blocks (Listening Dictation, Practice Drill,
 * Sentence Fill) and per-unit objectives. Reading the finished structure out
 * of the running page is the only way to match what learners actually see.
 *
 * Writes src/data/curriculum.json (ids, titles, types — no lesson content; the
 * page renders that) and src/data/objectives.json.
 *
 *   PLAYWRIGHT_PKG=/path/to/node_modules/playwright/index.mjs node tools/extract-curriculum.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const { chromium } = await import(process.env.PLAYWRIGHT_PKG || 'playwright');

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const pageUrl = 'file://' + path.join(root, 'assets', 'lesson', 'lesson.html');

const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
const page = await browser.newPage();
await page.route(/r2\.dev|supabase\.co/, (r) => r.abort());
await page.addInitScript(() => { window.ReactNativeWebView = { postMessage: () => {} }; });
await page.goto(pageUrl);
await page.waitForFunction(() => window.LisaanyApp && typeof CUR !== 'undefined');

const { modules, objectives, freeUnits } = await page.evaluate(() => {
  const size = (b) => {
    const d = b.data || {};
    if (Array.isArray(d.lines)) return { count: d.lines.length, unit: 'lines' };
    if (Array.isArray(d.words)) return { count: d.words.length, unit: 'words' };
    if (Array.isArray(d.sentences)) return { count: d.sentences.length, unit: 'sentences' };
    if (Array.isArray(d.items)) return { count: d.items.length, unit: 'items' };
    if (Array.isArray(d.questions)) return { count: d.questions.length, unit: 'questions' };
    if (Array.isArray(d.examples)) return { count: d.examples.length, unit: 'examples' };
    return null;
  };
  const modules = CUR.map((m) => ({
    id: m.id,
    title: m.title,
    color: m.color,
    icon: m.icon,
    units: m.units.map((u) => ({
      id: u.id,
      title: u.title,
      icon: u.icon,
      desc: u.desc,
      blocks: u.blocks.map((b) => ({
        id: b.id,
        type: b.type,
        title: b.title,
        desc: b.desc,
        icon: b.icon,
        color: b.color,
        ...(size(b) ? { size: size(b) } : {}),
      })),
    })),
  }));
  const objectives = {};
  for (const m of CUR) for (const u of m.units) {
    const list = u.objectives || (typeof UNIT_OBJECTIVES !== 'undefined' ? UNIT_OBJECTIVES[u.id] : null);
    if (Array.isArray(list) && list.length) objectives[u.id] = list;
  }
  return { modules, objectives, freeUnits: typeof FREE_UNITS !== 'undefined' ? FREE_UNITS : [] };
});
await browser.close();

const blocks = modules.reduce((n, m) => n + m.units.reduce((k, u) => k + u.blocks.length, 0), 0);
const units = modules.reduce((n, m) => n + m.units.length, 0);
const types = {};
for (const m of modules) for (const u of m.units) for (const b of u.blocks) types[b.type] = (types[b.type] || 0) + 1;

fs.writeFileSync(path.join(root, 'src', 'data', 'curriculum.json'), JSON.stringify(modules, null, 1) + '\n');
fs.writeFileSync(path.join(root, 'src', 'data', 'objectives.json'), JSON.stringify(objectives, null, 1) + '\n');
console.log(`${modules.length} modules · ${units} units · ${blocks} blocks · objectives for ${Object.keys(objectives).length} units · free units ${JSON.stringify(freeUnits)}`);
console.log('block types:', Object.entries(types).sort((a, b) => b[1] - a[1]).map(([t, n]) => `${t} ${n}`).join(', '));
