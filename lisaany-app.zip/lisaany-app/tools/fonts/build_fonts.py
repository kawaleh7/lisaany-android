import subprocess, base64, os, json, sys
import subset_icons
SRC_HTML = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), '..', '..', '..', 'src', 'Lisaany-main', 'arabic_platform.html')
subset_icons.main(SRC_HTML)
HERE=os.path.dirname(os.path.abspath(__file__))
NM=os.path.join(HERE,'..','..','node_modules','@expo-google-fonts')+'/'
CG=os.environ.get('CORMORANT_DIR', os.path.join(HERE,'cormorant-garamond'))+'/'
LATIN='U+0000-024F,U+02B0-02FF,U+0300-036F,U+1E00-1EFF,U+2000-206F,U+20A0-20CF,U+2100-214F,U+2190-21FF,U+2200-22FF,U+25A0-25FF,U+2600-26FF,U+2700-27BF,U+FB00-FB06,U+FEFF,U+FFFD'
ARABIC='U+0600-06FF,U+0750-077F,U+08A0-08FF,U+FB50-FDFF,U+FE70-FEFF,U+200B-200F,U+2010-2027,U+0020-007E,U+00A0-00BF,U+060C,U+061B,U+061F,U+066A-066D,U+06D4,U+2E41'
fonts=[
 ('Cinzel',400,'normal',NM+'cinzel/400Regular/Cinzel_400Regular.ttf',LATIN),
 ('Cinzel',600,'normal',NM+'cinzel/600SemiBold/Cinzel_600SemiBold.ttf',LATIN),
 ('Cinzel',700,'normal',NM+'cinzel/700Bold/Cinzel_700Bold.ttf',LATIN),
 ('Inter',400,'normal',NM+'inter/400Regular/Inter_400Regular.ttf',LATIN),
 ('Inter',500,'normal',NM+'inter/500Medium/Inter_500Medium.ttf',LATIN),
 ('Inter',600,'normal',NM+'inter/600SemiBold/Inter_600SemiBold.ttf',LATIN),
 ('Inter',700,'normal',NM+'inter/700Bold/Inter_700Bold.ttf',LATIN),
 ('Inter',400,'italic',NM+'inter/400Regular_Italic/Inter_400Regular_Italic.ttf',LATIN),
 ('Amiri',400,'normal',NM+'amiri/400Regular/Amiri_400Regular.ttf',ARABIC),
 ('Amiri',700,'normal',NM+'amiri/700Bold/Amiri_700Bold.ttf',ARABIC),
 ('Cormorant Garamond',400,'normal',CG+'400Regular/CormorantGaramond_400Regular.ttf',LATIN),
 ('Cormorant Garamond',500,'normal',CG+'500Medium/CormorantGaramond_500Medium.ttf',LATIN),
 ('Cormorant Garamond',600,'normal',CG+'600SemiBold/CormorantGaramond_600SemiBold.ttf',LATIN),
 ('Cormorant Garamond',400,'italic',CG+'400Regular_Italic/CormorantGaramond_400Regular_Italic.ttf',LATIN),
]
css=[]; total=0
for fam,wt,style,path,uni in fonts:
    assert os.path.exists(path), path
    os.makedirs(os.path.join(HERE,'build'), exist_ok=True)
    out=os.path.join(HERE,'build',f"{fam.replace(' ','')}-{wt}{'i' if style=='italic' else ''}.woff2")
    subprocess.check_call(['pyftsubset',path,'--unicodes='+uni,'--layout-features=*','--flavor=woff2','--no-hinting','--output-file='+out],stderr=subprocess.DEVNULL)
    b=open(out,'rb').read(); total+=len(b)
    css.append(f"@font-face{{font-family:'{fam}';font-style:{style};font-weight:{wt};font-display:swap;src:url(data:font/woff2;base64,{base64.b64encode(b).decode()}) format('woff2');}}")
    print(f"{fam} {wt} {style}: {len(b)//1024} KB")
b=open(os.path.join(HERE,'icons.woff2'),'rb').read(); total+=len(b)
css.append("@font-face{font-family:'Material Symbols Outlined';font-style:normal;font-weight:400;font-display:block;src:url(data:font/woff2;base64,"+base64.b64encode(b).decode()+") format('woff2');}")
open(os.path.join(HERE,'fonts.css'),'w').write('\n'.join(css))
print('total font bytes', total//1024, 'KB; css', os.path.getsize(os.path.join(HERE,'fonts.css'))//1024, 'KB')
