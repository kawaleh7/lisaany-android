"""Subset Material Symbols Outlined to the icons the lesson engine uses.

Icon names are found by intersecting every identifier-like token in the
website source with the font's own ligature table, so nothing is missed
however the name is written (ms('x'), icon:"x", innerHTML, templates).
Ligature rules are kept, so <span class="ms">volume_up</span> still works.
"""
import sys, subprocess, re, json, os
from fontTools.ttLib import TTFont

SRC_FONT = os.path.join(os.path.dirname(__file__), '..', '..', 'node_modules', '@expo-google-fonts', 'material-symbols-outlined', '400Regular', 'MaterialSymbolsOutlined_400Regular.ttf')
OUT = os.path.join(os.path.dirname(__file__), 'icons.woff2')

def ligature_map(font):
    cmap = font.getBestCmap()
    letters = {ch: cmap[ord(ch)] for ch in 'abcdefghijklmnopqrstuvwxyz0123456789_' if ord(ch) in cmap}
    inv = {v: k for k, v in letters.items()}
    out = {}
    for lk in font['GSUB'].table.LookupList.Lookup:
        for st in lk.SubTable:
            t = st.ExtSubTable if lk.LookupType == 7 else st
            if not hasattr(t, 'ligatures'):
                continue
            for first, ligs in t.ligatures.items():
                for L in ligs:
                    comps = [first] + list(L.Component)
                    try:
                        out[''.join(inv[c] for c in comps)] = L.LigGlyph
                    except KeyError:
                        pass
    return letters, out

def main(source_html, extra=()):
    text = open(source_html, encoding='utf-8').read()
    font = TTFont(SRC_FONT)
    letters, ligs = ligature_map(font)
    tokens = set(re.findall(r'[a-z][a-z0-9_]{2,}', text)) | set(extra)
    used = sorted(t for t in tokens if t in ligs)
    glyphs = set(letters.values()) | {ligs[t] for t in used} | {'.notdef'}
    gf = os.path.join(os.path.dirname(__file__), 'icon-glyphs.txt')
    open(gf, 'w').write('\n'.join(sorted(glyphs)))
    subprocess.check_call(['pyftsubset', SRC_FONT, '--glyphs-file=' + gf, '--no-layout-closure',
                           '--layout-features=liga,rlig,calt,ccmp', '--flavor=woff2', '--no-hinting',
                           '--output-file=' + OUT], stderr=subprocess.DEVNULL)
    open(os.path.join(os.path.dirname(__file__), 'icon-names.txt'), 'w').write('\n'.join(used))
    print(f'icons: {len(used)} names, {os.path.getsize(OUT)//1024} KB')
    return used

if __name__ == '__main__':
    main(sys.argv[1])
