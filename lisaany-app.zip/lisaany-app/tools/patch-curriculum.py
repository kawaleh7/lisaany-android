#!/usr/bin/env python3
"""
Curriculum patch — greetings vocabulary (platform-wide) + Unit 1.1 restructure.

The curriculum lives inside the page as the `CUR` JavaScript literal. This
script applies an ordered list of exact find → replace edits to that page, so
the same change can be made to the website's arabic_platform.html and to the
app's assets/lesson/lesson.html (which is generated from it):

    python3 tools/patch-curriculum.py path/to/arabic_platform.html
    python3 tools/patch-curriculum.py assets/lesson/lesson.html   # then: python3 /tmp/lm/star/sync.py

Options:
    --dry-run   report what would change, write nothing

Every edit must match exactly once; the script refuses to run when the page
was already patched (all edits applied) and stops without writing when the
source text has drifted (an edit matches zero or several times).

What it changes
  A. Greetings relabelled everywhere: أَهلاً → "Hello", مَرحَباً → "Welcome",
     أَهلاً بِكَ / بِكِ and مَرحَباً بِكَ / بِكِ → "Welcome to you (to a man / to a woman)".
  B. Unit 1.1 goes from 11 parts to 7: First Meeting (1) · Two Students Meet (2)
     · Vocabulary (3) · How Pronouns Work (41, now holds the pronoun table)
     · Practice Drill (54, pinned, with five pronoun questions) · Sentence
     Builder (5, taught words only) · Listening Dictation (44, pinned).
     Detached Pronouns (4), Pronoun Matching (42), Pronouns Practice Quiz (43)
     and Sentence Fill (65) leave the unit.
  C. Two small engine hooks the data relies on: a hand-placed Practice Drill
     can opt out of the auto-injected Sentence Fill (data.fill === false) and
     can carry fixed questions (data.fixedQuestions) that the generated
     vocabulary questions are topped up around.
  D. French entries for every new English label (the FR pack maps strings by
     exact English text).
"""
from __future__ import annotations

import sys

# Each edit: label, old (must occur exactly once), new. `mark` is a snippet that
# exists only once the edit is applied (defaults to `new`); removal edits give
# an explicit mark because their `new` is empty.
EDITS: list[dict] = []


def edit(label: str, old: str, new: str, mark: str | None = None) -> None:
    EDITS.append({"label": label, "old": old, "new": new, "mark": mark if mark is not None else new})


# ─────────────────────────────────────────────────────────────────────────────
# C. Engine hooks (website engine code — identical in both files)
# ─────────────────────────────────────────────────────────────────────────────
edit(
    "engine: a hand-placed Practice Drill can opt out of the auto Sentence Fill (data.fill === false)",
    "      var hasQuiz=unit.blocks.some(function(b){return b.type==='quiz';});\n"
    "      var hasFill=unit.blocks.some(function(b){return b.type==='fill';});\n"
    "      var hasVocab=unit.blocks.some(function(b){return b.type==='vocab';});\n"
    "      if(hasQuiz&&hasVocab&&!hasFill){\n",
    "      var hasQuiz=unit.blocks.some(function(b){return b.type==='quiz';});\n"
    "      var hasFill=unit.blocks.some(function(b){return b.type==='fill';});\n"
    "      var hasVocab=unit.blocks.some(function(b){return b.type==='vocab';});\n"
    "      var noFill=unit.blocks.some(function(b){return b.type==='quiz'&&b.data&&b.data.fill===false;}); // a hand-placed drill can opt out of Part 2\n"
    "      if(hasQuiz&&hasVocab&&!hasFill&&!noFill){\n",
)
edit(
    "engine: Practice Drill keeps data.fixedQuestions and tops them up with generated vocabulary questions",
    "  if(allWords.length<4){ blk._quizData={questions:[],passing:60}; return blk._quizData; }\n"
    "  var pool=shuffle(allWords).slice(0,Math.min(10,allWords.length));\n",
    "  var fixed=(blk.data&&Array.isArray(blk.data.fixedQuestions))?blk.data.fixedQuestions.filter(function(q){return q&&q.prompt&&q.correct&&Array.isArray(q.options);}):[];\n"
    "  if(allWords.length<4){ blk._quizData={questions:fixed,passing:(blk.data&&blk.data.passing)||60}; return blk._quizData; }\n"
    "  var pool=shuffle(allWords).slice(0,Math.max(0,Math.min(10-fixed.length,allWords.length)));\n",
)
edit(
    "engine: fixed and generated drill questions are shuffled together",
    "  blk._quizData={questions:questions,passing:(blk.data&&blk.data.passing)||60};\n"
    "  return blk._quizData;\n"
    "}\n"
    "\n"
    "function mkQuiz(blk){\n",
    "  blk._quizData={questions:shuffle(fixed.concat(questions)),passing:(blk.data&&blk.data.passing)||60};\n"
    "  return blk._quizData;\n"
    "}\n"
    "\n"
    "function mkQuiz(blk){\n",
)

# ─────────────────────────────────────────────────────────────────────────────
# B. Unit 1.1
# ─────────────────────────────────────────────────────────────────────────────
edit(
    "1.1 First Meeting (1): speaking to a man — desc, setting, note, greeting labels, key words",
    '          { id:1, type:"dialogue", title:"First Meeting", desc:"خالد وفاطمة يلتقيان", icon:"forum", color:"#D4A34A",\n'
    '            data:{ title:"First Meeting", setting:"خالد وفاطمة يلتقيان لأول مرة",\n'
    "              lines:[\n"
    '                {spk:"Ahmad",side:"left",ar:"السَّلَامُ عَلَيْكُمْ.",en:"as-salaamu alaykum (peace be upon you)"},\n'
    '                {spk:"Khalid",side:"right",ar:"وَعَلَيْكُمُ السَّلَامُ.",en:"wa alaykum as-salaam (and peace be upon you)"},\n'
    '                {spk:"Ahmad",side:"left",ar:"أَهْلًا، أَنَا أَحْمَد.",en:"Hello, I am Ahmad"},\n'
    '                {spk:"Khalid",side:"right",ar:"أَهْلًا بِكَ، أَنَا خَالِد.",en:"Hello, I am Khalid"},\n'
    '                {spk:"Ahmad",side:"left",ar:"كَيْفَ حَالُكَ يَا خَالِد؟",en:"How are you Khalid?"},\n',
    '          { id:1, type:"dialogue", title:"First Meeting", desc:"Speaking to a man — بِكَ ، اسْمُكَ", icon:"forum", color:"#D4A34A",\n'
    '            data:{ title:"First Meeting", setting:"أحمد وخالد يلتقيان لأول مرة", note:"Ahmad and Khalid are both men. When you speak <strong>to a man</strong> the ending is <strong>كَ</strong>: <strong>أَهْلًا بِكَ</strong> (welcome to you) and <strong>مَا اسْمُكَ؟</strong> (what is your name?). In the next conversation two women use <strong>بِكِ</strong> and <strong>اسْمُكِ</strong> instead.",\n'
    "              lines:[\n"
    '                {spk:"Ahmad",side:"left",ar:"السَّلَامُ عَلَيْكُمْ.",en:"as-salaamu alaykum (peace be upon you)"},\n'
    '                {spk:"Khalid",side:"right",ar:"وَعَلَيْكُمُ السَّلَامُ.",en:"wa alaykum as-salaam (and peace be upon you)"},\n'
    '                {spk:"Ahmad",side:"left",ar:"أَهْلًا، أَنَا أَحْمَد.",en:"Hello, I am Ahmad"},\n'
    '                {spk:"Khalid",side:"right",ar:"أَهْلًا بِكَ، أَنَا خَالِد.",en:"Welcome to you (to a man), I am Khalid"},\n'
    '                {spk:"Ahmad",side:"left",ar:"كَيْفَ حَالُكَ يَا خَالِد؟",en:"How are you Khalid?"},\n',
)
edit(
    "1.1 First Meeting (1): key-word tiles — أَهْلًا = Hello, أَهْلًا بِكَ added, كَيْفَ حَالُكَ؟ marked (to a man)",
    '                {ar:"السَّلَامُ عَلَيْكُمْ",en:"Peace be upon you (greeting)"},\n'
    '                {ar:"أَهْلًا",en:"Hello / Welcome"},\n'
    '                {ar:"كَيْفَ حَالُكَ؟",en:"How are you?"},\n'
    '                {ar:"بِخَيْرٍ",en:"Well / Fine"},\n',
    '                {ar:"السَّلَامُ عَلَيْكُمْ",en:"Peace be upon you (greeting)"},\n'
    '                {ar:"أَهْلًا",en:"Hello"},\n'
    '                {ar:"أَهْلًا بِكَ",en:"Welcome to you (to a man) — reply to أَهلاً"},\n'
    '                {ar:"كَيْفَ حَالُكَ؟",en:"How are you? (to a man)"},\n'
    '                {ar:"بِخَيْرٍ",en:"Well / Fine"},\n',
)
edit(
    "1.1 Two Students Meet (2): speaking to a woman — desc, مَرْحَبًا = Welcome, بِكِ / اسْمُكِ marked",
    '          { id:2, type:"dialogue", title:"Two Students Meet", desc:"سارة ومريم في المكتبة", icon:"forum", color:"#D4A34A",\n'
    '            data:{ title:"في المكتبة", setting:"سارة ومريم يلتقيان", note:"Both speakers are women. In Arabic, pronouns change for gender: when speaking <strong>to a woman</strong>, your name becomes <strong>اسْمُكِ</strong> (with كِ), not اسْمُكَ (with كَ for a man). Watch the underlined endings as Sara and Maryam address each other.",\n'
    "              lines:[\n"
    '                {spk:"Sara",side:"left",ar:"مَرْحَبًا.",en:"Hello"},\n'
    '                {spk:"Maryam",side:"right",ar:"مَرْحَبًا بِكِ.",en:"Hello to you"},\n'
    '                {spk:"Sara",side:"left",ar:"مَا اسْمُكِ؟",en:"What is your name?"},\n',
    '          { id:2, type:"dialogue", title:"Two Students Meet", desc:"Speaking to a woman — بِكِ ، اسْمُكِ", icon:"forum", color:"#D4A34A",\n'
    '            data:{ title:"في المكتبة", setting:"سارة ومريم يلتقيان", note:"Both speakers are women. In Arabic, pronouns change for gender: when speaking <strong>to a woman</strong>, your name becomes <strong>اسْمُكِ</strong> (with كِ), not اسْمُكَ (with كَ for a man). Watch the underlined endings as Sara and Maryam address each other.",\n'
    "              lines:[\n"
    '                {spk:"Sara",side:"left",ar:"مَرْحَبًا.",en:"Welcome"},\n'
    '                {spk:"Maryam",side:"right",ar:"مَرْحَبًا بِكِ.",en:"Welcome to you (to a woman)"},\n'
    '                {spk:"Sara",side:"left",ar:"مَا اسْمُكِ؟",en:"What is your name? (to a woman)"},\n',
)
edit(
    "1.1 Two Students Meet (2): key-word tiles — مَرْحَبًا = Welcome, مَرْحَبًا بِكِ added, مَا اسْمُكِ؟ marked (to a woman)",
    '                {ar:"مَرْحَبًا",en:"Hello"},\n'
    '                {ar:"مَا اسْمُكِ؟",en:"What is your name? (f)"},\n',
    '                {ar:"مَرْحَبًا",en:"Welcome"},\n'
    '                {ar:"مَرْحَبًا بِكِ",en:"Welcome to you (to a woman) — reply to مَرحَباً"},\n'
    '                {ar:"مَا اسْمُكِ؟",en:"What is your name? (to a woman)"},\n',
)
edit(
    "1.1 Vocabulary (3): greetings relabelled, m/f pairs added as entries, جَزِيلاً added (20 words)",
    '          { id:3, type:"vocab", title:"Vocabulary", desc:"13 كلمات أساسية", icon:"translate", color:"#D4A34A",\n'
    "            data:{ words:[\n"
    '              {ar:"السَّلامُ عَلَيْكُم",en:"as-salaamu alaykum (peace be upon you)"},\n'
    '              {ar:"أَهلاً وَسَهلاً",en:"Welcome"},\n'
    '              {ar:"مَرحَباً",en:"Hello"},\n'
    '              {ar:"اسْم",en:"Name"},\n'
    '              {ar:"اسْمِي",en:"My name is"},\n'
    '              {ar:"كَيْفَ الحال؟",en:"How are you?"},\n'
    '              {ar:"بِخَيْرٍ",en:"Well"},\n'
    '              {ar:"شُكْراً",en:"Thank you"},\n'
    '              {ar:"تَشَرَّفْنَا.",en:"An honor to meet you"},\n'
    '              {ar:"الْحَمْدُ لِلَّه",en:"alhamdulillah (praise be to God)"},\n'
    '              {ar:"كَيْفَ",roman:"kayfa",en:"how"},\n'
    '              {ar:"مِنْ",roman:"min",en:"from / of"},\n'
    '              {ar:"أَيْنَ",roman:"ayna",en:"where"},\n'
    "            ]}\n"
    "          },\n",
    '          { id:3, type:"vocab", title:"Vocabulary", desc:"20 كلمة أساسية", icon:"translate", color:"#D4A34A",\n'
    "            data:{ words:[\n"
    '              {ar:"السَّلامُ عَلَيْكُم",en:"as-salaamu alaykum (peace be upon you)"},\n'
    '              {ar:"أَهلاً وَسَهلاً",en:"Hello (warm greeting)"},\n'
    '              {ar:"أَهلاً بِكَ",roman:"ahlan bika",en:"Welcome to you (to a man) — reply to أَهلاً"},\n'
    '              {ar:"أَهلاً بِكِ",roman:"ahlan biki",en:"Welcome to you (to a woman) — reply to أَهلاً"},\n'
    '              {ar:"مَرحَباً",en:"Welcome"},\n'
    '              {ar:"مَرحَباً بِكَ",roman:"marḥaban bika",en:"Welcome to you (to a man) — reply to مَرحَباً"},\n'
    '              {ar:"مَرحَباً بِكِ",roman:"marḥaban biki",en:"Welcome to you (to a woman) — reply to مَرحَباً"},\n'
    '              {ar:"اسْم",en:"Name"},\n'
    '              {ar:"اسْمِي",en:"My name is"},\n'
    '              {ar:"ما اسْمُكَ؟",roman:"mā ismuka?",en:"What is your name? (to a man)"},\n'
    '              {ar:"ما اسْمُكِ؟",roman:"mā ismuki?",en:"What is your name? (to a woman)"},\n'
    '              {ar:"كَيْفَ الحال؟",en:"How are you?"},\n'
    '              {ar:"بِخَيْرٍ",en:"Well"},\n'
    '              {ar:"شُكْراً",en:"Thank you"},\n'
    '              {ar:"شُكْراً جَزِيلاً",roman:"shukran jazīlan",en:"Thank you very much"},\n'
    '              {ar:"تَشَرَّفْنَا.",en:"An honor to meet you"},\n'
    '              {ar:"الْحَمْدُ لِلَّه",en:"alhamdulillah (praise be to God)"},\n'
    '              {ar:"كَيْفَ",roman:"kayfa",en:"how"},\n'
    '              {ar:"مِنْ",roman:"min",en:"from / of"},\n'
    '              {ar:"أَيْنَ",roman:"ayna",en:"where"},\n'
    "            ]}\n"
    "          },\n",
)
edit(
    "1.1 remove Detached Pronouns (4), Pronoun Matching (42) and Pronouns Practice Quiz (43) from the unit",
    '          { id:4, type:"vocab", title:"Detached Pronouns", desc:"أنا، أنتَ، أنتِ، هو، هي", icon:"translate", color:"#D4A34A",\n'
    '            data:{ title:"Detached Pronouns", titleAr:"الضَّمائِر المُنفَصِلَة",\n'
    "              words:[\n"
    '                {ar:"أَنا", roman:"ana", en:"I", cat:"any gender"},\n'
    '                {ar:"أَنْتَ", roman:"anta", en:"You (m)", cat:"masculine"},\n'
    '                {ar:"أَنْتِ", roman:"anti", en:"You (f)", cat:"feminine"},\n'
    '                {ar:"هُوَ", roman:"huwa", en:"He", cat:"masculine"},\n'
    '                {ar:"هِيَ", roman:"hiya", en:"She", cat:"feminine"},\n'
    '                {ar:"نَحْنُ", roman:"naḥnu", en:"We", cat:"any gender"},\n'
    "              ]\n"
    "            }\n"
    "          },\n"
    '          { id:42, type:"swipe", title:"Pronoun Matching", desc:"جمل قصيرة — اختر الصحيح", icon:"join_right", color:"#D4A34A",\n'
    '            data:{ title:"Pronoun Matching",\n'
    "              sentences:[\n"
    '                { ar:"أَنَا مُدَرِّس", roman:"Anā mudarris", en:"I am a teacher (male)", pronoun:"أَنَا", pronoun_en:"I" },\n'
    '                { ar:"أَنْتَ رَجُل", roman:"Anta rajul", en:"You are a man", pronoun:"أَنْتَ", pronoun_en:"You (m)" },\n'
    '                { ar:"أَنْتِ مُدَرِّسَة", roman:"Anti mudarrisah", en:"You are a teacher (female)", pronoun:"أَنْتِ", pronoun_en:"You (f)" },\n'
    '                { ar:"هُوَ مُدَرِّس", roman:"Huwa mudarris", en:"He is a teacher", pronoun:"هُوَ", pronoun_en:"He" },\n'
    '                { ar:"هِيَ بِنْت", roman:"Hiya bint", en:"She is a girl", pronoun:"هِيَ", pronoun_en:"She" },\n'
    '                { ar:"أَنَا بِنْت", roman:"Anā bint", en:"I am a girl", pronoun:"أَنَا", pronoun_en:"I" },\n'
    '                { ar:"أَنْتَ مُدَرِّس", roman:"Anta mudarris", en:"You are a teacher (male)", pronoun:"أَنْتَ", pronoun_en:"You (m)" },\n'
    '                { ar:"هِيَ مُدَرِّسَة", roman:"Hiya mudarrisah", en:"She is a teacher (female)", pronoun:"هِيَ", pronoun_en:"She" },\n'
    "              ]\n"
    "            }\n"
    "          },\n"
    '          { id:43, type:"seqquiz", title:"Pronouns Practice Quiz", desc:"Part A: Fill the blank · Part B: Translate", icon:"quiz", color:"#D4A34A",\n'
    '            data:{ title:"Pronouns Practice Quiz", passing:70,\n'
    "              questions:[\n"
    '                { promptType:"ar", prompt:"___ بِنْت", question:"She is a girl. Choose the correct pronoun:",\n'
    '                  options:["أَنَا","أَنْتَ","أَنْتِ","هِيَ"], correct:"هِيَ",\n'
    '                  explain:"هِيَ (hiya) = She" },\n'
    '                { promptType:"ar", prompt:"___ رَجُل", question:"You [male] are a man. Choose the correct pronoun:",\n'
    '                  options:["هُوَ","أَنْتَ","أَنَا","أَنْتِ"], correct:"أَنْتَ",\n'
    '                  explain:"أَنْتَ (anta) = You (masculine)" },\n'
    '                { promptType:"ar", prompt:"___ مُدَرِّسَة", question:"You [female] are a teacher. Choose the correct pronoun:",\n'
    '                  options:["هِيَ","أَنَا","أَنْتَ","أَنْتِ"], correct:"أَنْتِ",\n'
    '                  explain:"أَنْتِ (anti) = You (feminine)" },\n'
    '                { promptType:"ar", prompt:"___ مُدَرِّس", question:"He is a teacher. Choose the correct pronoun:",\n'
    '                  options:["أَنَا","أَنْتَ","هِيَ","هُوَ"], correct:"هُوَ",\n'
    '                  explain:"هُوَ (huwa) = He" },\n'
    '                { promptType:"en", prompt:"I am a teacher (male)",\n'
    '                  options:["هُوَ مُدَرِّس","أَنَا مُدَرِّس","أَنْتَ مُدَرِّس","هِيَ مُدَرِّسَة"], correct:"أَنَا مُدَرِّس",\n'
    '                  explain:"أَنَا (I) + مُدَرِّس (teacher, male) — no verb needed!" },\n'
    '                { promptType:"en", prompt:"She is a teacher",\n'
    '                  options:["أَنَا مُدَرِّسَة","أَنْتِ مُدَرِّسَة","هِيَ مُدَرِّسَة","هُوَ مُدَرِّس"], correct:"هِيَ مُدَرِّسَة",\n'
    '                  explain:"هِيَ (She) + مُدَرِّسَة (teacher, female)" },\n'
    '                { promptType:"en", prompt:"You (female) are a girl",\n'
    '                  options:["هِيَ بِنْت","أَنَا بِنْت","أَنْتَ بِنْت","أَنْتِ بِنْت"], correct:"أَنْتِ بِنْت",\n'
    '                  explain:"أَنْتِ (You, feminine) + بِنْت (girl)" },\n'
    '                { promptType:"en", prompt:"I am a man",\n'
    '                  options:["هُوَ رَجُل","أَنْتَ رَجُل","أَنَا رَجُل","هِيَ رَجُل"], correct:"أَنَا رَجُل",\n'
    '                  explain:"أَنَا (I) + رَجُل (man)" },\n'
    "              ]\n"
    "            }\n"
    "          },\n",
    "",
    mark='title:"How Pronouns Work", desc:"الضَّمائِر المُنفَصِلَة — لا فِعْل «يَكون» في الحاضِر"',
)
edit(
    "1.1 How Pronouns Work (41): the six detached pronouns become the block's first section (table)",
    '          { id:41, type:"grammar", title:"How Pronouns Work", desc:"لا فِعْل «يَكون» في الحاضِر", icon:"psychology", color:"#D4A34A",\n'
    '            data:{ title:"How Pronouns Work", titleAr:"الضَّمائِر المُنفَصِلَة",\n'
    '              intro:"Arabic has no verb \'to be\' in the present tense. The pronoun alone completes the sentence.",\n'
    '              keyRule:"أَنا + طالِب = I am a student. No verb needed!",\n',
    '          { id:41, type:"grammar", title:"How Pronouns Work", desc:"الضَّمائِر المُنفَصِلَة — لا فِعْل «يَكون» في الحاضِر", icon:"psychology", color:"#D4A34A",\n'
    '            data:{ title:"How Pronouns Work", titleAr:"الضَّمائِر المُنفَصِلَة",\n'
    '              intro:"Six detached pronouns stand on their own — tap each card to reveal it. Arabic has no verb \'to be\' in the present tense: the pronoun alone completes the sentence.",\n'
    '              table:{ cols:["Pronoun","Reading","Meaning"], colW:"1fr 1fr 1fr",\n'
    "                rows:[\n"
    '                  {ar:"أَنا",roman:"ana",en:"I"},\n'
    '                  {ar:"أَنْتَ",roman:"anta",en:"You (to a man)"},\n'
    '                  {ar:"أَنْتِ",roman:"anti",en:"You (to a woman)"},\n'
    '                  {ar:"هُوَ",roman:"huwa",en:"He"},\n'
    '                  {ar:"هِيَ",roman:"hiya",en:"She"},\n'
    '                  {ar:"نَحْنُ",roman:"naḥnu",en:"We"},\n'
    "                ]\n"
    "              },\n"
    '              keyRule:"أَنا + طالِب = I am a student. No verb needed!",\n',
)
edit(
    "1.1 Practice Drill pinned as block 54 (five pronoun questions + generated vocabulary), Sentence Builder rebuilt from taught words, Listening Dictation pinned as block 44",
    '          { id:5, type:"clutter", title:"Sentence Builder", desc:"جمل قصيرة — 2 كلمات", icon:"extension", color:"#D4A34A",\n'
    "            data:{ passing:70, sentences:[\n"
    '              {ar:"اسْمِي خالِد",en:"My name is Khalid", words:["اسْمِي","خالِد"]},\n'
    '              {ar:"اسْمِي فاطِمَة",en:"My name is Fatima", words:["اسْمِي","فاطِمَة"]},\n'
    '              {ar:"أَنا بِخَيْرٍ",en:"I am well", words:["أَنا","بِخَيْرٍ"]},\n'
    '              {ar:"كَيْفَ حالُكَ؟",en:"How are you?", words:["كَيْفَ","حالُكَ؟"]},\n'
    '              {ar:"الْحَمْدُ لِلَّه",en:"Praise be to God", words:["الْحَمْدُ","لِلَّه"]},\n'
    '              {ar:"أَهلاً بِكَ",en:"Welcome", words:["أَهلاً","بِكَ"]},\n'
    '              {ar:"تَشَرَّفْنَا.",en:"Pleased to meet you", words:["تَشَرَّفْنَا."]},\n'
    '              {ar:"ما اسْمُكَ؟",en:"What is your name?", words:["ما","اسْمُكَ؟"]},\n'
    '              {ar:"وَأَنا أَيْضاً",en:"And me too", words:["وَأَنا","أَيْضاً"]},\n'
    '              {ar:"شُكْراً جَزِيلاً",en:"Thank you very much", words:["شُكْراً","جَزِيلاً"]},\n'
    "            ]}\n"
    "          }\n"
    "        ]\n"
    "      },\n"
    '      { id:"1.2", title:"Nationalities & Countries", icon:"public",\n',
    '          { id:54, type:"quiz", title:"Practice Drill", desc:"اختَر الجَوابَ الصَّحِيح", icon:"quiz", color:"#D4A34A",\n'
    "            data:{ passing:60, fill:false,\n"
    "              // asked every time; the engine adds vocabulary questions from this unit up to ten\n"
    "              fixedQuestions:[\n"
    '                { promptType:"en", prompt:"I am a teacher (m)", correct:"أَنَا مُدَرِّس",\n'
    '                  options:["هُوَ مُدَرِّس","أَنَا مُدَرِّس","أَنْتَ مُدَرِّس","هِيَ مُدَرِّسَة"] },\n'
    '                { promptType:"en", prompt:"You are a teacher (to a man)", correct:"أَنْتَ مُدَرِّس",\n'
    '                  options:["أَنْتِ مُدَرِّسَة","هُوَ مُدَرِّس","أَنْتَ مُدَرِّس","أَنَا مُدَرِّس"] },\n'
    '                { promptType:"en", prompt:"You are a teacher (to a woman)", correct:"أَنْتِ مُدَرِّسَة",\n'
    '                  options:["أَنْتِ مُدَرِّسَة","أَنْتَ مُدَرِّس","هِيَ مُدَرِّسَة","أَنَا مُدَرِّس"] },\n'
    '                { promptType:"en", prompt:"He is a teacher", correct:"هُوَ مُدَرِّس",\n'
    '                  options:["هِيَ مُدَرِّسَة","أَنَا مُدَرِّس","أَنْتَ مُدَرِّس","هُوَ مُدَرِّس"] },\n'
    '                { promptType:"en", prompt:"She is a teacher", correct:"هِيَ مُدَرِّسَة",\n'
    '                  options:["أَنَا مُدَرِّسَة","هِيَ مُدَرِّسَة","هُوَ مُدَرِّس","أَنْتِ مُدَرِّسَة"] },\n'
    "              ]\n"
    "            }\n"
    "          },\n"
    '          { id:5, type:"clutter", title:"Sentence Builder", desc:"جمل قصيرة — 2 كلمات", icon:"extension", color:"#D4A34A",\n'
    "            data:{ passing:70, sentences:[\n"
    '              {ar:"اسْمِي خالِد",en:"My name is Khalid", words:["اسْمِي","خالِد"]},\n'
    '              {ar:"اسْمِي مَرْيَم",en:"My name is Maryam", words:["اسْمِي","مَرْيَم"]},\n'
    '              {ar:"أَنا بِخَيْرٍ",en:"I am well", words:["أَنا","بِخَيْرٍ"]},\n'
    '              {ar:"كَيْفَ حالُكَ؟",en:"How are you? (to a man)", words:["كَيْفَ","حالُكَ؟"], alts:["كَيْفَ الحال؟"]},\n'
    '              {ar:"الْحَمْدُ لِلَّه",en:"Praise be to God", words:["الْحَمْدُ","لِلَّه"]},\n'
    '              {ar:"أَهلاً بِكَ",en:"Welcome to you (to a man)", words:["أَهلاً","بِكَ"], alts:["أَهْلًا بِكَ","مَرحَباً بِكَ","مَرْحَبًا بِكَ"]},\n'
    '              {ar:"مَرحَباً بِكِ",en:"Welcome to you (to a woman)", words:["مَرحَباً","بِكِ"], alts:["مَرْحَبًا بِكِ","أَهلاً بِكِ","أَهْلًا بِكِ"]},\n'
    '              {ar:"ما اسْمُكَ؟",en:"What is your name? (to a man)", words:["ما","اسْمُكَ؟"], alts:["مَا اسْمُكَ؟"]},\n'
    '              {ar:"وَأَنا أَيْضاً",en:"And me too", words:["وَأَنا","أَيْضاً"]},\n'
    '              {ar:"شُكْراً جَزِيلاً",en:"Thank you very much", words:["شُكْراً","جَزِيلاً"]},\n'
    "            ]}\n"
    "          },\n"
    '          { id:44, type:"cloze", title:"Listening Dictation", desc:"استمع واملأ الفراغات", icon:"hearing", color:"#D4A34A", data:{} }\n'
    "        ]\n"
    "      },\n"
    '      { id:"1.2", title:"Nationalities & Countries", icon:"public",\n',
)

# ─────────────────────────────────────────────────────────────────────────────
# A. Greetings elsewhere in the course
# ─────────────────────────────────────────────────────────────────────────────
edit(
    "2.4 قَالَ builder: قالَ صَدِيقِي مَرْحَباً = My friend said welcome (so 'said hello' has one answer)",
    '{ar:"قالَ صَدِيقِي مَرْحَباً",en:"My friend said hello", words:["قالَ","صَدِيقِي","مَرْحَباً"]}',
    '{ar:"قالَ صَدِيقِي مَرْحَباً",en:"My friend said welcome", words:["قالَ","صَدِيقِي","مَرْحَباً"]}',
)
edit(
    "5.1 restaurant: أَهْلًا وَسَهْلًا، تَفَضَّلُوا بِالْجُلُوس = Hello, please have a seat",
    'ar:"أَهْلًا وَسَهْلًا، تَفَضَّلُوا بِالْجُلُوس",en:"Welcome, please have a seat"',
    'ar:"أَهْلًا وَسَهْلًا، تَفَضَّلُوا بِالْجُلُوس",en:"Hello, please have a seat"',
)
edit(
    "6.4 shaykh: أَهلاً وَسَهلاً، طالِبُ العِلمِ… = Hello, the student of knowledge is always welcome",
    'ar:"أَهلاً وَسَهلاً، طالِبُ العِلمِ دائِماً مُرَحَّب بِه",en:"Welcome, the student of knowledge is always welcome"',
    'ar:"أَهلاً وَسَهلاً، طالِبُ العِلمِ دائِماً مُرَحَّب بِه",en:"Hello, the student of knowledge is always welcome"',
)
edit(
    "6.5 bank customer: مَرْحَبًا، أُرِيدُ إِيدَاعَ… = Welcome, I'd like to deposit…",
    'ar:"مَرْحَبًا، أُرِيدُ إِيدَاعَ هَذَا الشِّيكِ فِي حِسَابِي، مِنْ فَضْلِكَ.",en:"Hello, I\'d like to deposit this cheque into my account, please."',
    'ar:"مَرْحَبًا، أُرِيدُ إِيدَاعَ هَذَا الشِّيكِ فِي حِسَابِي، مِنْ فَضْلِكَ.",en:"Welcome, I\'d like to deposit this cheque into my account, please."',
)
edit(
    "10.1 car showroom: أَهْلًا، هَلْ تُفَضِّلِينَ… = Hello, do you prefer…",
    'ar:"أَهْلًا، هَلْ تُفَضِّلِينَ سَيَّارَة صَغِيرَة أَمْ سَيَّارَة عَائِلِيَّة كَبِيرَة؟",en:"Welcome, do you prefer a small car or a large family car?"',
    'ar:"أَهْلًا، هَلْ تُفَضِّلِينَ سَيَّارَة صَغِيرَة أَمْ سَيَّارَة عَائِلِيَّة كَبِيرَة؟",en:"Hello, do you prefer a small car or a large family car?"',
)
edit(
    "14.1 travel office pilgrim: مَرْحَبًا. أُرِيدُ التَّقْدِيمَ… = Welcome. I want to apply…",
    'ar:"مَرْحَبًا. أُرِيدُ التَّقْدِيمَ عَلَى التَّأْشِيرَةِ. هَلْ يَمْلِكُ هَذَا الْمَكْتَبُ رُخْصَةً رَسْمِيَّةً مِنْ وِزَارَةِ الْحَجِّ؟",en:"Hello. I want to apply for the visa. Does this office have an official license from the Ministry of Hajj?"',
    'ar:"مَرْحَبًا. أُرِيدُ التَّقْدِيمَ عَلَى التَّأْشِيرَةِ. هَلْ يَمْلِكُ هَذَا الْمَكْتَبُ رُخْصَةً رَسْمِيَّةً مِنْ وِزَارَةِ الْحَجِّ؟",en:"Welcome. I want to apply for the visa. Does this office have an official license from the Ministry of Hajj?"',
)

# ─────────────────────────────────────────────────────────────────────────────
# D. French pack — new English labels
# ─────────────────────────────────────────────────────────────────────────────
FR_NEW = [
    ("Speaking to a man — بِكَ ، اسْمُكَ", "On parle à un homme — بِكَ ، اسْمُكَ"),
    ("Speaking to a woman — بِكِ ، اسْمُكِ", "On parle à une femme — بِكِ ، اسْمُكِ"),
    ("Ahmad and Khalid are both men. When you speak <strong>to a man</strong> the ending is <strong>كَ</strong>: <strong>أَهْلًا بِكَ</strong> (welcome to you) and <strong>مَا اسْمُكَ؟</strong> (what is your name?). In the next conversation two women use <strong>بِكِ</strong> and <strong>اسْمُكِ</strong> instead.",
     "Ahmad et Khalid sont tous deux des hommes. Quand on parle <strong>à un homme</strong>, la terminaison est <strong>كَ</strong> : <strong>أَهْلًا بِكَ</strong> (bienvenue à toi) et <strong>مَا اسْمُكَ؟</strong> (comment t'appelles-tu ?). Dans la conversation suivante, deux femmes utilisent <strong>بِكِ</strong> et <strong>اسْمُكِ</strong>."),
    ("Welcome to you (to a man), I am Khalid", "Bienvenue à toi (à un homme), je suis Khalid"),
    ("Welcome to you (to a man)", "Bienvenue à toi (à un homme)"),
    ("Welcome to you (to a woman)", "Bienvenue à toi (à une femme)"),
    ("Welcome to you (to a man) — reply to أَهلاً", "Bienvenue à toi (à un homme) — réponse à أَهلاً"),
    ("Welcome to you (to a woman) — reply to أَهلاً", "Bienvenue à toi (à une femme) — réponse à أَهلاً"),
    ("Welcome to you (to a man) — reply to مَرحَباً", "Bienvenue à toi (à un homme) — réponse à مَرحَباً"),
    ("Welcome to you (to a woman) — reply to مَرحَباً", "Bienvenue à toi (à une femme) — réponse à مَرحَباً"),
    ("How are you? (to a man)", "Comment vas-tu ? (à un homme)"),
    ("What is your name? (to a man)", "Comment t'appelles-tu ? (à un homme)"),
    ("What is your name? (to a woman)", "Comment t'appelles-tu ? (à une femme)"),
    ("Hello (warm greeting)", "Bonjour (salutation chaleureuse)"),
    ("Very much (after thank you)", "Beaucoup (après « merci »)"),
    ("Six detached pronouns stand on their own — tap each card to reveal it. Arabic has no verb 'to be' in the present tense: the pronoun alone completes the sentence.",
     "Six pronoms détachés se suffisent à eux-mêmes — touchez chaque carte pour la révéler. L'arabe n'a pas de verbe « être » au présent : le pronom seul complète la phrase."),
    ("You (to a man)", "Tu / Toi (à un homme)"),
    ("You (to a woman)", "Tu / Toi (à une femme)"),
    ("I am a teacher (m)", "Je suis enseignant (m)"),
    ("You are a teacher (to a man)", "Tu es enseignant (à un homme)"),
    ("You are a teacher (to a woman)", "Tu es enseignante (à une femme)"),
    ("She is a teacher", "Elle est enseignante"),
    ("My friend said welcome", "Mon ami a dit bienvenue"),
    ("Hello, please have a seat", "Bonjour, asseyez-vous je vous prie"),
    ("Hello, the student of knowledge is always welcome", "Bonjour ; l'étudiant en sciences religieuses est toujours le bienvenu"),
    ("Welcome, I'd like to deposit this cheque into my account, please.", "Bienvenue, je voudrais déposer ce chèque sur mon compte, s'il vous plaît."),
    ("Hello, do you prefer a small car or a large family car?", "Bonjour ; préférez-vous une petite voiture ou une grande familiale ?"),
    ("Welcome. I want to apply for the visa. Does this office have an official license from the Ministry of Hajj?", "Bienvenue. Je veux faire une demande de visa. Ce bureau a-t-il une licence officielle du ministère du Hajj ?"),
]


def _js(s: str) -> str:
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'


FR_LINES = ",\n".join(f"{_js(en)}: {_js(fr)}" for en, fr in FR_NEW) + "\n"
edit(
    "French pack: entries for the new English labels",
    '"your, m. (suffix)": "ton / ta, m. (suffixe)"\n'
    "};\n",
    '"your, m. (suffix)": "ton / ta, m. (suffixe)",\n'
    "/* greetings + Unit 1.1 restructure */\n"
    + FR_LINES
    + "};\n",
)


# ─────────────────────────────────────────────────────────────────────────────
def main(argv: list[str]) -> int:
    args = [a for a in argv if not a.startswith("--")]
    dry = "--dry-run" in argv
    if len(args) != 1:
        print(__doc__)
        return 64
    path = args[0]
    try:
        text = open(path, encoding="utf-8", newline="").read()
    except OSError as e:
        print(f"cannot read {path}: {e}")
        return 66

    pending, applied, broken = [], [], []
    for e in EDITS:
        n_old = text.count(e["old"])
        if n_old == 1:
            pending.append(e)
        elif n_old == 0 and text.count(e["mark"]) >= 1:
            applied.append(e)
        else:
            broken.append((e, n_old))

    if not pending and applied and not broken:
        print(f"{path}: already patched — all {len(applied)} edits are in place. Nothing to do.")
        return 1
    if broken or (applied and pending):
        print(f"{path}: refusing to patch — the text does not match what this script expects.")
        for e, n in broken:
            print(f"  ✗ {e['label']}  (found {n} match(es), need exactly 1)")
        for e in applied:
            print(f"  = already applied: {e['label']}")
        for e in pending:
            print(f"  · would apply: {e['label']}")
        return 2

    out = text
    for e in pending:
        assert out.count(e["old"]) == 1, e["label"]
        out = out.replace(e["old"], e["new"], 1)
        print(f"  ✓ {e['label']}")

    if dry:
        print(f"dry run: {len(pending)} edit(s) would be applied to {path}; nothing written.")
        return 0
    with open(path, "w", encoding="utf-8", newline="") as fh:
        fh.write(out)
    print(f"patched {path}: {len(pending)} edit(s) applied.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
