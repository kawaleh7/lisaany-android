#!/usr/bin/env python3
"""
Curriculum patch — "Option A: seven parts, like unit 1.1" for every unit
except 1.1, plus the new "name endings" section at the start of unit 2.1's
grammar block.

The curriculum lives inside the page as the `CUR` JavaScript literal. This
script reads that literal with a small JS-literal parser (so it knows exactly
where every unit, block and data object starts and ends) and rewrites only
the literals it has to, so the same change can be made to the website's
arabic_platform.html and to the app's assets/lesson/lesson.html:

    python3 tools/shorten-units.py path/to/arabic_platform.html
    python3 tools/shorten-units.py assets/lesson/lesson.html

Options:
    --dry-run   print the per-unit report, write nothing

The script refuses to run on a page it has already patched, and stops without
writing when the page does not look the way it expects (an engine snippet it
patches is missing or duplicated, a unit's blocks are not what it planned for).

What it changes
  A. Every unit except 1.1 keeps: its dialogues, vocabulary, video, conjugation
     and suffix-tap parts, one grammar part, the first Practice Drill, the
     first Sentence Builder and the Listening Dictation. Sentence Fill, the
     end quizzes / warm-ups (seqquiz), Choose, Swipe and any second Sentence
     Builder leave the unit.
  B. A unit with several grammar parts keeps the first one (same id and
     title); each later grammar part's data moves into it, verbatim, as a
     section (data.sections). The engine shows the sections one after another
     inside the one part, each exactly as it used to look on its own.
  C. The Practice Drill and Listening Dictation that the engine used to add at
     runtime are written into each shortened unit with the ids they had (saved
     progress is keyed by unit id + block id, and the runtime ids depend on the
     unit's other ids, which change when parts leave). The pinned drill carries
     fill:false, so the engine no longer adds a Sentence Fill after it.
  D. Engine hooks (identical in both files): grammar sections (render one
     section at a time, finishBlock moves to the next section; word frequency,
     review pools and the quick check read every section) and a grammar
     `quickCheck` list that the quick check always asks.
  E. Unit 2.1: "One word, six endings" (اسْم + ي / كَ / كِ / هُ / هَا / نَا) becomes
     the first section of its grammar part, with a fixed quick-check item
     (اسْمُهَا نُور = Her name is Nour, not His). Audio index entries for the five
     new clips; French entries for every new English string.
"""
from __future__ import annotations

import hashlib
import re
import sys

MARK = "function gramSectionView(blk){"

# ─────────────────────────────────────────────────────────────────────────────
# A tiny parser for the JavaScript literal subset CUR uses
# (objects, arrays, "…" '…' `…` strings, numbers, true/false/null, comments,
# bare or quoted keys, trailing commas). Every node records its source span.
# ─────────────────────────────────────────────────────────────────────────────
class Node:
    __slots__ = ("kind", "start", "end", "value", "items")

    def __init__(self, kind, start, end, value=None, items=None):
        self.kind, self.start, self.end, self.value, self.items = kind, start, end, value, items

    def get(self, key):
        if self.kind != "obj":
            return None
        for k, v in self.items:
            if k == key:
                return v
        return None

    def py(self):
        if self.kind == "obj":
            return {k: v.py() for k, v in self.items}
        if self.kind == "arr":
            return [v.py() for v in self.items]
        return self.value


class Parser:
    def __init__(self, text: str):
        self.t = text

    def ws(self, i: int) -> int:
        t = self.t
        while i < len(t):
            c = t[i]
            if c in " \t\r\n":
                i += 1
            elif t.startswith("//", i):
                j = t.find("\n", i)
                i = len(t) if j < 0 else j + 1
            elif t.startswith("/*", i):
                i = t.index("*/", i) + 2
            else:
                break
        return i

    def string(self, i: int):
        t, q = self.t, self.t[i]
        j, out = i + 1, []
        while True:
            c = t[j]
            if c == "\\":
                n = t[j + 1]
                if n == "u":
                    out.append(chr(int(t[j + 2:j + 6], 16)))
                    j += 6
                    continue
                out.append({"n": "\n", "t": "\t", "r": "\r", "\n": ""}.get(n, n))
                j += 2
                continue
            if c == q:
                return Node("str", i, j + 1, "".join(out)), j + 1
            if q == "`" and t.startswith("${", j):
                raise SystemExit(f"template substitution at {j} is not supported")
            out.append(c)
            j += 1

    def value(self, i: int):
        t = self.t
        i = self.ws(i)
        c = t[i]
        if c == "{":
            return self.obj(i)
        if c == "[":
            return self.arr(i)
        if c in "\"'`":
            return self.string(i)
        m = re.compile(r"-?\d+(\.\d+)?").match(t, i)
        if m:
            s = m.group(0)
            return Node("num", i, m.end(), float(s) if "." in s else int(s)), m.end()
        m = re.compile(r"true|false|null").match(t, i)
        if m:
            return Node("lit", i, m.end(), {"true": True, "false": False, "null": None}[m.group(0)]), m.end()
        raise SystemExit(f"unexpected {t[i:i+40]!r} at {i}")

    def obj(self, i: int):
        t, start, items = self.t, i, []
        i += 1
        while True:
            i = self.ws(i)
            if t[i] == "}":
                return Node("obj", start, i + 1, items=items), i + 1
            if t[i] in "\"'":
                k, i = self.string(i)
                key = k.value
            else:
                m = re.compile(r"[A-Za-z_$][\w$]*").match(t, i)
                if not m:
                    raise SystemExit(f"bad key at {i}: {t[i:i+30]!r}")
                key, i = m.group(0), m.end()
            i = self.ws(i)
            assert t[i] == ":", (i, t[i:i + 30])
            v, i = self.value(i + 1)
            items.append((key, v))
            i = self.ws(i)
            if t[i] == ",":
                i += 1

    def arr(self, i: int):
        t, start, items = self.t, i, []
        i += 1
        while True:
            i = self.ws(i)
            if t[i] == "]":
                return Node("arr", start, i + 1, items=items), i + 1
            v, i = self.value(i)
            items.append(v)
            i = self.ws(i)
            if t[i] == ",":
                i += 1


def js(s: str) -> str:
    """A JS double-quoted string literal; non-ASCII stays as-is except bidi isolates."""
    out = s.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")
    return '"' + out.replace("\u2066", "\\u2066").replace("\u2069", "\\u2069") + '"'


def md5_12(s: str) -> str:
    return hashlib.md5(s.encode("utf-8")).hexdigest()[:12]


# ─────────────────────────────────────────────────────────────────────────────
# Content: Unit 2.1 "One word, six endings"
# ─────────────────────────────────────────────────────────────────────────────
ROOT_LINE = "\u2066اسْم · ism · name\u2069"          # isolated so it reads left-to-right as in the mock
ROOT_LINE_FR = "\u2066اسْم · ism · nom\u2069"
ENDINGS_INTRO = "Add a short ending to اسْم (name) to say whose name it is."
ENDINGS_NOTE = "In this unit: هَذَا أَبِي، اسْمُهُ مُحَمَّد · هَذِهِ أُمِّي، اسْمُهَا نُور"
ENDING_ROWS = [  # (English, Arabic, transliteration, highlighted ending)
    ("My name", "اسْمِي", "ismī", "ي"),
    ("Your name (to a man)", "اسْمُكَ", "ismuka", "كَ"),
    ("Your name (to a woman)", "اسْمُكِ", "ismuki", "كِ"),
    ("His name", "اسْمُهُ", "ismuhu", "هُ"),
    ("Her name", "اسْمُهَا", "ismuhā", "هَا"),
    ("Our name", "اسْمُنَا", "ismunā", "نَا"),
]
NEW_AUDIO = ["اسْمُكَ", "اسْمُكِ", "اسْمُهُ", "اسْمُهَا", "اسْمُنَا"]


def endings_head(ind: str) -> str:
    """The new top-level fields of 2.1's grammar data (its first section)."""
    rows = "".join(
        f"{ind}    {{ar:{js(ar)}, hl:{js(hl)}, en:{js(en)}, note:{js(tr)}}},\n" for en, ar, tr, hl in ENDING_ROWS
    )
    return (
        f"{{ title:\"One word, six endings\", titleAr:{js(ROOT_LINE)},\n"
        f"{ind}intro:{js(ENDINGS_INTRO)},\n"
        f"{ind}// the ending is highlighted on each card; the reading is the caption under it\n"
        f"{ind}table:{{ cols:[\"Meaning\",\"Arabic\",\"Reading\"], colW:\"1.4fr 1fr 1fr\",\n"
        f"{ind}  rows:[\n{rows}{ind}  ]\n{ind}}},\n"
        f"{ind}keyRule:{js(ENDINGS_NOTE)},\n"
        f"{ind}// always asked in this part's quick check\n"
        f"{ind}quickCheck:[\n"
        f"{ind}  {{ ar:\"اسْمُهَا نُور\", en:\"Her name is Nour\", wrong:[\"His name is Nour\"] }}\n"
        f"{ind}],\n"
    )


FR_NEW = [
    ("One word, six endings", "Un mot, six terminaisons"),
    (ENDINGS_INTRO, "Ajoutez une courte terminaison à اسْم (nom) pour dire à qui est le nom."),
    (ROOT_LINE, ROOT_LINE_FR),
    ("My name", "Mon nom"),
    ("Your name (to a man)", "Ton nom (à un homme)"),
    ("Your name (to a woman)", "Ton nom (à une femme)"),
    ("His name", "Son nom (à lui)"),
    # "Her name" → "Son nom (à elle)" is already in the pack
    ("Our name", "Notre nom"),
    ("In this unit:", "Dans cette unité :"),
    (ENDINGS_NOTE, "Dans cette unité : هَذَا أَبِي، اسْمُهُ مُحَمَّد · هَذِهِ أُمِّي، اسْمُهَا نُور"),
    ("Her name is Nour", "Elle s'appelle Nour"),
    ("His name is Nour", "Il s'appelle Nour"),
]

# ─────────────────────────────────────────────────────────────────────────────
# Engine hooks — exact find → replace, each must match once
# ─────────────────────────────────────────────────────────────────────────────
ENGINE: list[tuple[str, str, str]] = []


def eng(label: str, old: str, new: str) -> None:
    ENGINE.append((label, old, new))


GRAM_HELPERS = r"""/* ── Grammar sections ──────────────────────────────────────────────────────
   A grammar part that merges several lessons keeps each one as a section:
   the block's own fields are the first section and data.sections follow.
   The renderer is handed one section at a time (gramSectionView), and
   finishBlock moves on to the next section before the part counts as done.
   Readers of grammar content (word frequency, review pools, quick check)
   read every section (gramParts). */
function gramParts(d){ d=d||{}; return [d].concat(Array.isArray(d.sections)?d.sections.filter(function(s){return s&&typeof s==='object';}):[]); }
function gramSectionView(blk){
  var d=blk&&blk.data; if(!d||!Array.isArray(d.sections)||!d.sections.length) return blk;
  var key=S.mId+'|'+S.uId+'|'+S.bId;
  if(S.gSecKey!==key){ S.gSecKey=key; S.gSec=0; }
  var parts=gramParts(d);
  if(typeof S.gSec!=='number'||S.gSec<0||S.gSec>=parts.length) S.gSec=0;
  var sd=parts[S.gSec];
  if(S.gSec===0){ sd=Object.assign({},d); delete sd.sections; }
  return Object.assign({},blk,{data:sd});
}
function gramNextSection(){
  if(S.view!=='lesson') return false;
  var blk=getBlk(S.mId,S.uId,S.bId); var d=blk&&blk.type==='grammar'&&blk.data;
  if(!d||!Array.isArray(d.sections)||!d.sections.length) return false;
  var key=S.mId+'|'+S.uId+'|'+S.bId;
  if(S.gSecKey!==key){ S.gSecKey=key; S.gSec=0; }
  if((S.gSec||0)>=gramParts(d).length-1){ S.gSec=0; return false; }
  S.gSec=(S.gSec||0)+1;
  S.gScreen=0; S.gIdx=0; S.gCard=0; S.gFlip=false; S.gEx=0; S.gRuleRevealed=false; S.gStep=0; S.gPopts=null;
  try{ window.scrollTo(0,0); }catch(e){}
  render(); return true;
}

"""

eng("engine: grammar-section helpers (gramParts / gramSectionView / gramNextSection)",
    "const WORD_FREQ = (function(){\n",
    GRAM_HELPERS + "const WORD_FREQ = (function(){\n")
eng("engine: word frequency reads every grammar section",
    "        if(blk.type==='grammar'){\n"
    "          (blk.data?.examples||[]).forEach(ex=>{\n"
    "            (ex.ar||'').split(/[\\s\\u060c.\\u061f!]+/).forEach(w=>bump(w, loc));\n"
    "          });\n"
    "          (blk.data?.table?.rows||[]).forEach(r=>bump(r.ar, loc));\n"
    "        }\n",
    "        if(blk.type==='grammar'){\n"
    "          gramParts(blk.data).forEach(gd=>{\n"
    "          (gd.examples||[]).forEach(ex=>{\n"
    "            (ex.ar||'').split(/[\\s\\u060c.\\u061f!]+/).forEach(w=>bump(w, loc));\n"
    "          });\n"
    "          (gd.table?.rows||[]).forEach(r=>bump(r.ar, loc));\n"
    "          });\n"
    "        }\n")
eng("engine: the lesson view shows one grammar section at a time",
    "if(blk.type==='grammar')return mkGrammar(blk);",
    "if(blk.type==='grammar')return mkGrammar(gramSectionView(blk));")
eng("engine: opening a grammar part starts at its first section",
    "if(blk?.type==='grammar'){ S.gScreen=0; S.gIdx=0; S.gCard=0; S.gFlip=false; S.gEx=0; S.gRuleRevealed=false; }",
    "if(blk?.type==='grammar'){ S.gScreen=0; S.gIdx=0; S.gCard=0; S.gFlip=false; S.gEx=0; S.gRuleRevealed=false; S.gSec=0; S.gSecKey=S.mId+'|'+S.uId+'|'+S.bId; }")
eng("engine: review harvest reads every grammar section",
    "          (b.data&&b.data.examples||[]).forEach(ex=>add(ex.ar,ex.en,label));\n",
    "          gramParts(b.data).forEach(gd=>(gd.examples||[]).forEach(ex=>add(ex.ar,ex.en,label)));\n")
eng("engine: review pool reads every grammar section",
    "      (b.data&&b.data.examples||[]).forEach(ex=>add(ex.ar,ex.en));\n",
    "      gramParts(b.data).forEach(gd=>(gd.examples||[]).forEach(ex=>add(ex.ar,ex.en)));\n")
eng("engine: finishing a grammar section opens the next one",
    "function finishBlock(){\n",
    "function finishBlock(){\n  if(gramNextSection()) return; // a merged grammar part: next section first\n")
eng("engine: grammar quick check reads every section and always asks data.quickCheck",
    "  } else if(type === 'grammar'){\n"
    "    const examples = (d.examples||[]).filter(function(e){return e.ar&&e.en;});\n"
    "    const extraEx = (d.table&&d.table.rows||[]).filter(function(r){return r.ar&&r.en;});\n"
    "    const all = examples.concat(extraEx).filter(function(e){return e.ar&&e.en;});\n"
    "    if(all.length < 3) return null;\n",
    "  } else if(type === 'grammar'){\n"
    "    const gparts = gramParts(d);\n"
    "    const examples = [].concat.apply([], gparts.map(function(p){return p.examples||[];})).filter(function(e){return e&&e.ar&&e.en;});\n"
    "    const extraEx = [].concat.apply([], gparts.map(function(p){return (p.table&&p.table.rows)||[];})).filter(function(r){return r&&r.ar&&r.en;});\n"
    "    const all = examples.concat(extraEx).filter(function(e){return e.ar&&e.en;});\n"
    "    // data.quickCheck: items asked every time — {ar, en, wrong:[…]} → pick the meaning of ar\n"
    "    const fixedQc = [].concat.apply([], gparts.map(function(p){return Array.isArray(p.quickCheck)?p.quickCheck:[];}))\n"
    "      .filter(function(q){return q&&q.ar&&q.en&&Array.isArray(q.wrong)&&q.wrong.length;})\n"
    "      .map(function(q){ return { ar:q.ar, question:q.question||null, correct:q.en, opts:shuffle([q.en].concat(q.wrong.filter(function(x){return x&&x!==q.en;}))) }; });\n"
    "    if(fixedQc.length){\n"
    "      const rest = shuffle(all.filter(function(e){ return !fixedQc.some(function(f){return f.ar===e.ar;}); })).slice(0,6);\n"
    "      const gen = rest.length>=3 ? rest.map(function(w,i,arr){\n"
    "        const distractors = shuffle(arr.filter(function(x){return x!==w;})).slice(0,3).map(function(x){return x.en;});\n"
    "        return { ar: w.ar, question: null, correct: w.en, opts: shuffle([w.en].concat(distractors)) };\n"
    "      }) : [];\n"
    "      return shuffle(fixedQc.concat(gen).slice(0, Math.max(3, fixedQc.length)));\n"
    "    }\n"
    "    if(all.length < 3) return null;\n")


def audio_edit(text: str) -> tuple[str, str]:
    """The line after the 'Recorded 24 Sep' comment, and that line + the new entries."""
    k = text.index("// Recorded 24 Sep:")
    a = text.index("\n", k) + 1
    b = text.index("\n", a) + 1
    line = text[a:b]
    assert line.startswith("Object.assign(audioIndex,"), line[:60]
    entries = ", ".join(f"{js(w)}: {js(md5_12(w))}" for w in NEW_AUDIO)
    add = ("// Unit 2.1 name endings (to be recorded): exact keys, so كَ / كِ and هُ / هَا never share a clip.\n"
           f"Object.assign(audioIndex, {{{entries}}});\n")
    return line, line + add


FR_ANCHOR = ('"Welcome. I want to apply for the visa. Does this office have an official license from the Ministry of Hajj?": '
             '"Bienvenue. Je veux faire une demande de visa. Ce bureau a-t-il une licence officielle du ministère du Hajj ?"\n};\n')


def fr_edit() -> tuple[str, str]:
    lines = ",\n".join(f"{js(en)}: {js(fr)}" for en, fr in FR_NEW)
    new = FR_ANCHOR[:-4] + ",\n/* seven-part units + Unit 2.1 name endings */\n" + lines + "\n};\n"
    return FR_ANCHOR, new


# ─────────────────────────────────────────────────────────────────────────────
# Curriculum planning
# ─────────────────────────────────────────────────────────────────────────────
REMOVE_TYPES = {"fill", "seqquiz", "choose", "swipe"}
KEEP_ALWAYS = {"dialogue", "vocab", "video", "conjugation", "possessive"}
QUIZ_LIT = ('{{ id:{id}, type:"quiz", title:"Practice Drill", desc:"اختَر الجَوابَ الصَّحِيح", icon:"quiz", color:"#D4A34A", '
            "data:{{ passing:60, fill:false }} }}")
CLOZE_LIT = '{{ id:{id}, type:"cloze", title:"Listening Dictation", desc:"استمع واملأ الفراغات", icon:"hearing", color:"#D4A34A", data:{{}} }}'


def runtime_blocks(blocks: list[dict]) -> list[tuple[int, str]]:
    """What the engine's injectors make of a unit's stored blocks: [(id, type)]."""
    out = [(b["id"], b["type"]) for b in blocks]
    types = [t for _, t in out]
    if "dialogue" in types and "cloze" not in types:
        out.append((max(i for i, _ in out) + 1, "cloze"))
    types = [t for _, t in out]
    if "vocab" in types and "clutter" in types and "quiz" not in types:
        ci = types.index("clutter")
        out.insert(ci, (max(i for i, _ in out) + 10, "quiz"))
    types = [t for _, t in out]
    no_fill = any(b["type"] == "quiz" and isinstance(b.get("data"), dict) and b["data"].get("fill") is False for b in blocks)
    if "quiz" in types and "vocab" in types and "fill" not in types and not no_fill:
        qi = types.index("quiz")
        out.insert(qi + 1, (max(i for i, _ in out) + 11, "fill"))
    return out


def main(argv: list[str]) -> int:
    args = [a for a in argv if not a.startswith("--")]
    dry = "--dry-run" in argv
    if len(args) != 1:
        print(__doc__)
        return 64
    path = args[0]
    text = open(path, encoding="utf-8", newline="").read()
    if MARK in text:
        print(f"{path}: already patched (grammar sections are in the engine). Nothing to do.")
        return 1

    # engine snippets must each match exactly once
    edits = list(ENGINE) + [("audio index: five new name-ending clips",) + audio_edit(text),
                            ("French pack: new English strings",) + fr_edit()]
    bad = [(lbl, text.count(old)) for lbl, old, _ in edits if text.count(old) != 1]
    if bad:
        print(f"{path}: refusing to patch — the engine text does not match what this script expects.")
        for lbl, n in bad:
            print(f"  ✗ {lbl}  (found {n} match(es), need exactly 1)")
        return 2

    i0 = text.index("const CUR = [") + len("const CUR = ")
    cur, _ = Parser(text).arr(i0)
    repl: list[tuple[int, int, str]] = []   # (start, end, new text) on the original
    report = []
    mod_before, mod_after = {}, {}

    for mod in cur.items:
        mid = mod.get("id").value
        for unit in mod.get("units").items:
            uid = unit.get("id").value
            barr = unit.get("blocks")
            blocks = barr.items
            bpy = [b.py() for b in blocks]
            before = runtime_blocks(bpy)
            mod_before[mid] = mod_before.get(mid, 0) + len(before)
            if uid == "1.1":
                mod_after[mid] = mod_after.get(mid, 0) + len(before)
                report.append(f"{uid:>5}  {len(before):>2} → {len(before):>2}  (left as it is)")
                continue

            rt_ids = {t: i for i, t in reversed(before)}   # first runtime id of each type
            kept, removed, merged = [], [], []
            seen = set()
            first_gram = None
            for b, p in zip(blocks, bpy):
                t = p["type"]
                if t in REMOVE_TYPES:
                    removed.append(p)
                elif t in KEEP_ALWAYS:
                    kept.append(b)
                elif t == "grammar":
                    if first_gram is None:
                        first_gram = b
                        kept.append(b)
                    else:
                        merged.append((b, p))
                elif t in ("quiz", "clutter", "cloze"):
                    if t in seen:
                        removed.append(p)
                    else:
                        seen.add(t)
                        kept.append(b)
                else:
                    raise SystemExit(f"{uid}: unknown block type {t!r}")

            types_kept = [b.get("type").value for b in kept]
            need_quiz = "vocab" in types_kept and "clutter" in types_kept and "quiz" not in types_kept
            need_cloze = "dialogue" in types_kept and "cloze" not in types_kept
            fill_would_come = any(t == "fill" for _, t in before)
            changed = bool(removed or merged or fill_would_come or uid == "2.1")
            if not changed:
                mod_after[mid] = mod_after.get(mid, 0) + len(before)
                report.append(f"{uid:>5}  {len(before):>2} → {len(before):>2}  (nothing to change)")
                continue
            if any(p["type"] == "quiz" for p in bpy) and fill_would_come:
                raise SystemExit(f"{uid}: a stored Practice Drill without fill:false — not planned for")

            # the new blocks list: kept blocks verbatim, the pinned drill before the
            # first Sentence Builder, the pinned dictation at the end
            ind = " " * (blocks[0].start - text.rfind("\n", 0, blocks[0].start) - 1)
            pieces, after = [], []
            for b in kept:
                t = b.get("type").value
                if t == "clutter" and need_quiz:
                    qid = rt_ids["quiz"]
                    pieces.append(QUIZ_LIT.format(id=qid))
                    after.append((qid, "quiz"))
                if b is first_gram and (merged or uid == "2.1"):
                    pieces.append(grammar_text(text, b, merged, uid, ind))
                else:
                    pieces.append(text[b.start:b.end])
                after.append((b.get("id").value, t))
            if need_cloze:
                cid = rt_ids["cloze"]
                pieces.append(CLOZE_LIT.format(id=cid))
                after.append((cid, "cloze"))

            # ids of kept blocks must be what learners already have
            old_ids = {(i, t) for i, t in before}
            lost = [x for x in after if x not in old_ids]
            if lost:
                raise SystemExit(f"{uid}: planned blocks {lost} do not match the runtime ids {before}")
            # every gap between blocks must be whitespace/commas (no comments get dropped)
            for a, b in zip(blocks, blocks[1:]):
                gap = text[a.end:b.start]
                if gap.strip(" \n,"):
                    raise SystemExit(f"{uid}: text between blocks would be lost: {gap.strip()[:60]!r}")
            close_ind = " " * (barr.end - 1 - text.rfind("\n", 0, barr.end - 1) - 1)
            body = "[\n" + ",\n".join(ind + p for p in pieces) + "\n" + close_ind + "]"
            repl.append((barr.start, barr.end, body))

            mod_after[mid] = mod_after.get(mid, 0) + len(after)
            rm = ", ".join(f"{p['type']}#{p['id']} {p.get('title','')!r}" for p in removed)
            if fill_would_come:
                fid = next(i for i, t in before if t == "fill")
                rm = (rm + ", " if rm else "") + f"fill#{fid} (injected — now off)"
            mg = ", ".join(f"grammar#{p['id']} {p.get('title','')!r} → section of #{first_gram.get('id').value}" for _, p in merged)
            line = f"{uid:>5}  {len(before):>2} → {len(after):>2}  " + " ".join(f"{t}#{i}" for i, t in after)
            if rm:
                line += f"\n         removed: {rm}"
            if mg:
                line += f"\n         merged:  {mg}"
            if need_quiz or need_cloze:
                line += "\n         pinned:  " + ", ".join(
                    ([f"quiz#{rt_ids['quiz']} (fill:false)"] if need_quiz else []) + ([f"cloze#{rt_ids['cloze']}"] if need_cloze else []))
            if uid == "2.1":
                line += "\n         added:   'One word, six endings' as the first section of grammar#4 (+ quick-check item)"
            report.append(line)

    out = text
    for s, e, new in sorted(repl, key=lambda r: -r[0]):
        out = out[:s] + new + out[e:]
    for lbl, old, new in edits:
        assert out.count(old) == 1, lbl
        out = out.replace(old, new, 1)

    print("\n".join(report))
    print()
    tb = sum(mod_before.values()); ta = sum(mod_after.values())
    print("module  " + " ".join(f"{m:>3}" for m in mod_before))
    print("before  " + " ".join(f"{mod_before[m]:>3}" for m in mod_before) + f"   total {tb}")
    print("after   " + " ".join(f"{mod_after[m]:>3}" for m in mod_after) + f"   total {ta}")
    for lbl, _, _ in edits:
        print(f"  ✓ {lbl}")
    print("  audio files to upload:", ", ".join(f"{md5_12(w)}.mp3 = {w}" for w in NEW_AUDIO))

    # the result must still parse, and its CUR must hold the planned structure
    cur2, _ = Parser(out).arr(out.index("const CUR = [") + len("const CUR = "))
    if dry:
        print(f"dry run: nothing written to {path}.")
        return 0
    with open(path, "w", encoding="utf-8", newline="") as fh:
        fh.write(out)
    print(f"patched {path}.")
    return 0


def grammar_text(text: str, b: Node, merged: list, uid: str, ind: str) -> str:
    """The first grammar block with the later grammar blocks' data appended as sections."""
    data = b.get("data")
    assert data is not None and data.kind == "obj"
    din = ind + "    "        # data's properties
    sin = din + "  "          # section objects
    secs = []
    if uid == "2.1":
        secs.append(f"{sin}// section 2 — was this part's own content ({b.get('title').value})\n{sin}" + text[data.start:data.end])
    for mb, mp in merged:
        secs.append(f"{sin}// section {len(secs) + 2 if uid == '2.1' else len(secs) + 2} — was grammar block {mp['id']}: {mp.get('title', '')}\n"
                    f"{sin}" + text[mb.get('data').start:mb.get('data').end])
    sections = f"{din}sections:[\n" + ",\n".join(secs) + f"\n{din}]"
    if uid == "2.1":
        new_data = endings_head(din) + sections + "\n" + ind + "  }"
    else:
        last = data.items[-1][1]
        tail = text[last.end:data.end - 1]
        assert not tail.strip(" \n,"), tail
        new_data = text[data.start:last.end] + ",\n" + f"{din}// the part's first section is the fields above; the sections below follow it\n" + sections + "\n" + ind + "  }"
    return text[b.start:data.start] + new_data + text[data.end:b.end]


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
