/**
 * End-to-end check of assets/lesson/lesson.html in headless Chromium.
 *
 * Boots the page the way the app does (config injected before load, a fake
 * ReactNativeWebView collecting bridge messages), plays through unit 1.1
 * block by block (answering the drills like a learner would: only controls a
 * finger could tap are tapped), then opens every block of every unit and
 * checks that it renders without JavaScript errors. Also checks that the
 * review session offers a free learner the free units only and that the
 * bridge snapshot carries `last_day`.
 *
 *   PLAYWRIGHT_PKG=/path/to/node_modules/playwright/index.mjs node tools/test-lesson-page.mjs [--shots]
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const { chromium } = await import(process.env.PLAYWRIGHT_PKG || 'playwright');

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const pageUrl = 'file://' + path.join(root, 'assets', 'lesson', 'lesson.html');
const shotsDir = path.join(root, 'tools', 'shots');
const wantShots = process.argv.includes('--shots');
if (wantShots) fs.mkdirSync(shotsDir, { recursive: true });

const curriculum = JSON.parse(fs.readFileSync(path.join(root, 'src', 'data', 'curriculum.json'), 'utf8'));

const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
const ctx = await browser.newContext({
  viewport: { width: 390, height: 844 },
  deviceScaleFactor: 2,
  isMobile: true,
  hasTouch: true,
});
const page = await ctx.newPage();

const errors = [];
const messages = [];
page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
page.on('console', (m) => {
  if (m.type() === 'error' && !/Failed to fetch|net::ERR|ERR_FAILED|audio/i.test(m.text())) errors.push('console: ' + m.text());
});
// No network in the sandbox: audio and Supabase calls fail fast instead of hanging.
await page.route(/r2\.dev|supabase\.co|googleapis|gstatic/, (r) => r.abort());

await page.addInitScript(() => {
  window.__msgs = [];
  window.ReactNativeWebView = { postMessage: (m) => window.__msgs.push(m) };
  window.__LISAANY_APP = { view: 'lesson', mId: 1, uId: '1.1', bId: 1, premium: true };
  // A control a finger could actually tap: laid out, not disabled, and not one of
  // the buttons the drills park off-screen (opacity 0, pointer-events none) until
  // an answer is given — element.click() would fire on those, a tap would not.
  window.__tapOK = (el) => {
    if (!el || el.disabled || el.offsetParent === null) return false;
    const cs = getComputedStyle(el);
    if (cs.pointerEvents === 'none' || cs.visibility === 'hidden' || parseFloat(cs.opacity) <= 0.1) return false;
    for (let p = el.parentElement; p; p = p.parentElement) {
      const pc = getComputedStyle(p);
      if (pc.visibility === 'hidden' || parseFloat(pc.opacity) <= 0.1) return false;
    }
    return true;
  };
});
await page.exposeFunction('__log', (s) => messages.push(s));

const t0 = Date.now();
await page.goto(pageUrl);
await page.waitForFunction(() => window.LisaanyApp && LisaanyApp.opened, null, { timeout: 15000 });
console.log(`booted in ${Date.now() - t0} ms`);

const fontsOk = await page.evaluate(async () => {
  const fams = ['Cinzel', 'Inter', 'Amiri', 'Cormorant Garamond', 'Material Symbols Outlined'];
  const out = [];
  for (const f of fams) { const faces = await document.fonts.load(`16px "${f}"`); out.push([f, faces.length > 0 && faces.every((x) => x.status === 'loaded')]); }
  return out;
});
console.log('fonts:', fontsOk.map(([f, ok]) => `${f}=${ok ? 'ok' : 'MISSING'}`).join(' '));

const drain = () => page.evaluate(() => { const m = window.__msgs.map((s) => JSON.parse(s)); window.__msgs = []; return m; });
const shot = async (name) => { if (wantShots) await page.screenshot({ path: path.join(shotsDir, name + '.png') }); };
const text = () => page.evaluate(() => document.getElementById('app').innerText.replace(/\s+/g, ' ').trim());

// Icons: every Material Symbols span must render as one glyph, not as text.
async function checkIcons(label) {
  const bad = await page.evaluate(() => {
    const out = [];
    for (const el of document.querySelectorAll('span, i, button')) {
      const cs = getComputedStyle(el);
      if (!/Material Symbols/.test(cs.fontFamily)) continue;
      const t = (el.textContent || '').trim();
      if (!t || el.children.length) continue;
      const r = el.getBoundingClientRect();
      if (r.width === 0) continue;
      const fs = parseFloat(cs.fontSize) || 24;
      if (r.width > fs * 1.6) out.push(`${t} (${Math.round(r.width)}px @${fs}px)`);
    }
    return out;
  });
  if (bad.length) errors.push(`${label}: icons rendered as text: ${bad.slice(0, 6).join(', ')}`);
}

// ── Play through unit 1.1 from the first block ────────────────────────────
async function clickByText(re, { optional = false } = {}) {
  const ok = await page.evaluate((src) => {
    const re = new RegExp(src, 'i');
    const els = [...document.querySelectorAll('button, [role="button"], .btn, a')];
    const el = els.find((e) => re.test((e.textContent || '').trim()) && window.__tapOK(e));
    if (!el) return false;
    el.click();
    return true;
  }, re.source);
  if (!ok && !optional) throw new Error(`no button matching ${re}`);
  return ok;
}

let view = await page.evaluate(() => S.view);
console.log('opened view:', view, '|', (await text()).slice(0, 100));
await shot('01-dialogue-stage');
await checkIcons('stage');

// Advance through whatever the current block shows until the unit's flow
// reaches the completion/quick-check screens, choosing the first answer in drills.
async function playCurrentBlock(maxSteps = 160) {
  for (let i = 0; i < maxSteps; i++) {
    const v = await page.evaluate(() => S.view);
    if (v === 'complete' || v === 'quickcheck') return v;
    const app = await text();
    if (/Quick Check Passed|Keep Practising|Block \d+ Complete|Unit \d+\.\d+ Complete/i.test(app)) return 'result';
    // Sentence builder: tap the answer words in order, then check.
    const solved = await page.evaluate(() => {
      const blk = getBlk(S.mId, S.uId, S.bId);
      if (!blk || blk.type !== 'clutter' || S.cLocked) return false;
      const words = (blk.data.sentences[S.cIdx] || {}).words || [];
      if (S.cAns.length < words.length) {
        const want = words[S.cAns.length];
        const tok = [...document.querySelectorAll('.token.t-bank, .dx-build .dx-bank .dx-tok')].find((t) => t.textContent.trim() === want);
        if (!tok) return false;
        tok.click(); return true;
      }
      const chk = [...document.querySelectorAll('button')].find((b) => /Check Answer/.test(b.textContent));
      if (chk) { chk.click(); return true; }
      return false;
    });
    // Dictation: drop the right word into each open blank, then check.
    const dictated = await page.evaluate(() => {
      const blk = getBlk(S.mId, S.uId, S.bId);
      if (!blk || blk.type !== 'cloze' || S.clzLocked) return false;
      const cur = getClozeData(blk).sentences[S.clzIdx]; if (!cur) return false;
      const nx = cur.blankIndices.findIndex((_, bi) => S.clzAns[bi] == null);
      if (nx >= 0) {
        const want = cur.words[cur.blankIndices[nx]];
        const tok = [...document.querySelectorAll('.dx-bank .dx-tok')].find((t) => t.textContent.trim() === want);
        if (!tok) return false; tok.click(); return true;
      }
      const chk = [...document.querySelectorAll('button')].find((b) => b.textContent.trim() === 'Check' && !b.disabled);
      if (chk) { chk.click(); return true; }
      return false;
    });
    if (solved || dictated) { await page.waitForTimeout(solved ? 1350 : 200); continue; }
    // Practice drill / listen & choose / quiz (app-drills.js, app-cards.js): tap the
    // right tile. The Continue button only becomes tappable ~1.3 s later, and the
    // drill moves on by itself at 2.7 s if nobody taps it.
    const answered = await page.evaluate(() => {
      const blk = getBlk(S.mId, S.uId, S.bId);
      if (!blk) return false;
      const tiles = [...document.querySelectorAll('#app .cd-opt')];
      if (!tiles.length) return false;
      let tile = null;
      if (blk.type === 'quiz' && !S.quizLocked) {
        const q = getQuizData(blk).questions[S.quizIdx];
        tile = q && tiles.find((b) => b.dataset.value === q.correct);
      } else if (blk.type === 'fill' && !S.fillLocked) {
        const q = getFillData(blk).questions[S.fillIdx];
        tile = q && tiles.find((b) => b.dataset.value === q.answer);
      } else if (blk.type === 'seqquiz' && !S.sqLocked) {
        const q = (blk.data.questions || [])[S.sqIdx];
        tile = q && tiles[q.options.indexOf(q.correct)];
      }
      if (!tile || !window.__tapOK(tile)) return false;
      tile.click();
      return true;
    });
    if (answered) { await page.waitForTimeout(1700); continue; }
    // Prefer the primary action; otherwise the first enabled option/tile.
    const clicked =
      (await clickByText(/^(Next|Next ›|Next →|Continue|Continue ›|Continue →|Finish|Finish ✓|Done|Got it|I know this|Start|Begin|Check|Show answer|Reveal|Try again|Skip|Next word|Next line|Play|Got it ✓)\b/i, { optional: true })) ||
      (await page.evaluate(() => {
        const cands = [...document.querySelectorAll('#app button, #app [role="button"], #app .opt, #app .tile, #app .choice, #app .chip, #app .word-tile, #app .bank-word')]
          .filter((e) => window.__tapOK(e) && !/back|exit|close|×|✕|english|transcript|full conversation|skip this/i.test(e.textContent || ''));
        const el = cands[cands.length - 1];
        if (!el) return false;
        el.click();
        return true;
      }));
    if (!clicked) return 'stuck';
    await page.waitForTimeout(120);
  }
  return 'timeout';
}

const unit11 = curriculum[0].units[0];
for (const blk of unit11.blocks) {
  await page.evaluate((b) => LisaanyApp.navigate({ view: 'lesson', mId: 1, uId: '1.1', bId: b }), blk.id);
  await page.waitForTimeout(150);
  const before = await text();
  const outcome = await playCurrentBlock();
  await checkIcons(`1.1/${blk.id}`);
  console.log(`block ${blk.id} (${blk.type}) → ${outcome} | start: ${before.slice(0, 60)}`);
  await shot(`02-block-${blk.id}-${blk.type}-end`);
  if (outcome === 'quickcheck') {
    // answer every question correctly; a correct pick auto-advances
    for (let i = 0; i < 12; i++) {
      const app = await text();
      if (/Quick Check Passed|Keep Practising/i.test(app)) break;
      const ok = await page.evaluate(() => {
        const q = S.qcQuestions && S.qcQuestions[S.qcIdx]; if (!q) return false;
        const btn = [...document.querySelectorAll('#app button')].find((b) => (b.dataset.value || b.textContent.trim()) === q.correct && window.__tapOK(b));
        if (!btn) return false; btn.click(); return true;
      });
      if (!ok) break;
      await page.waitForTimeout(450);
      // The app shows a feedback panel after each answer; move on from it.
      await clickByText(/^(Continue|Got it)$/, { optional: true });
      await page.waitForTimeout(450);
    }
    const res = await text();
    console.log('   quick check →', res.slice(0, 70));
    if (!/Quick Check Passed/i.test(res)) errors.push(`1.1/${blk.id}: quick check did not reach the passed screen: ${res.slice(0, 80)}`);
    await shot(`03-block-${blk.id}-quickcheck-result`);
  }
  // Next step from the completion screen: Next Block → opens the following block; Finish Unit → handoff.
  const isLast = blk === unit11.blocks[unit11.blocks.length - 1];
  await drain();
  const bIdBefore = await page.evaluate(() => S.bId);
  const pressed = await clickByText(isLast ? /Finish Unit|Finish lesson/i : /Next Block|Start next block|^Next part/i, { optional: true });
  await page.waitForTimeout(200);
  if (!pressed) errors.push(`1.1/${blk.id}: no ${isLast ? 'Finish Unit' : 'Next Block'} button on the completion screen`);
  else if (!isLast) {
    const after = await page.evaluate(() => [S.view, S.bId]);
    if (after[0] !== 'lesson' || after[1] === bIdBefore) errors.push(`1.1/${blk.id}: Next Block did not open the next block (${after})`);
  } else {
    const nav = (await drain()).find((m) => m.type === 'navigate');
    if (!nav || nav.view !== 'units') errors.push('Finish Unit did not hand off to the shell');
    else console.log('   finish unit → handoff', nav.view);
  }
}

const progressMsgs = (await drain()).filter((m) => m.type === 'progress');
const done = await page.evaluate(() => JSON.stringify(PROG));
console.log(`progress messages: ${progressMsgs.length}; PROG = ${done.slice(0, 120)}`);

// ── Every block of every unit renders ─────────────────────────────────────
let rendered = 0, thin = [];
const typeShot = new Set();
for (const mod of curriculum) {
  for (const unit of mod.units) {
    for (const blk of unit.blocks) {
      const errBefore = errors.length;
      await page.evaluate((c) => LisaanyApp.navigate(c), { view: 'lesson', mId: mod.id, uId: unit.id, bId: blk.id });
      await page.waitForTimeout(60);
      const t = await text();
      if (t.length < 12) thin.push(`${unit.id}/${blk.id} ${blk.type}`);
      rendered++;
      if (!typeShot.has(blk.type)) { typeShot.add(blk.type); await shot(`04-type-${blk.type}`); await checkIcons(blk.type); }
      if (errors.length > errBefore) errors[errors.length - 1] += ` @ ${unit.id}/${blk.id} ${blk.type}`;
    }
  }
}
console.log(`rendered ${rendered} blocks; thin: ${thin.length ? thin.join(', ') : 'none'}`);

// Review views open too
for (const v of ['review', 'srsreview', 'reviewBuilder']) {
  await page.evaluate((c) => LisaanyApp.navigate(c), { view: v, mId: 1, uId: '1.1' });
  await page.waitForTimeout(80);
  console.log(`view ${v}: ${(await text()).slice(0, 70)}`);
  await shot(`05-view-${v}`);
}

// Review session for a free learner: only the free units are offered (the Today
// tab opens this view for everyone).
const rbUnits = await page.evaluate(() => {
  window.__APP_PREMIUM = false; window.__IS_PREMIUM = false;
  LisaanyApp.navigate({ view: 'reviewBuilder', mId: 1, uId: '1.1' });
  const units = [...document.querySelectorAll('#app select option')].map((o) => o.value.split('|')[1]);
  window.__APP_PREMIUM = true;
  return units;
});
const paidListed = rbUnits.filter((u) => !['1.1', '1.2', '1.3'].includes(u));
console.log(`review builder (free): ${rbUnits.join(' ') || 'no units'}`);
if (!rbUnits.length) errors.push('review builder lists no units for a free learner');
if (paidListed.length) errors.push(`review builder offers Premium units to a free learner: ${paidListed.join(' ')}`);

// The bridge snapshot carries the engine's last activity day for the cloud row.
const snap = await page.evaluate(() => LisaanyApp.snapshot());
if (!('last_day' in snap)) errors.push('bridge snapshot has no last_day');
else console.log(`snapshot: uid=${snap.uid} xp=${snap.xp} streak=${snap.streak} last_day=${snap.last_day}`);

// Handoff: leaving to a shell view posts navigate and draws nothing new
await page.evaluate(() => { S.view = 'blocks'; render(); });
const nav = (await drain()).find((m) => m.type === 'navigate');
console.log('handoff message:', nav ? `${nav.view} ${nav.mId}/${nav.uId}` : 'MISSING');
if (!nav) errors.push('handoff did not post a navigate message');

await browser.close();
if (errors.length) {
  console.log(`\n${errors.length} error(s):`);
  for (const e of [...new Set(errors)].slice(0, 30)) console.log(' -', e);
  process.exit(1);
}
console.log('\nOK — no JavaScript errors.');
