/**
 * Bug report "if you press the Next button quickly it freezes" (Galaxy S21).
 *
 * Hammers the Next control of a conversation block (the Listen-mode stage built
 * by tools/app-listen.js) 15 times in about two seconds and checks that the
 * block behaves: one step per tap, the finish path taken once and once only, no
 * audio or auto-play left over from an abandoned line, no page errors, and a
 * screen that still responds afterwards.
 *
 * Two taps in quick succession are delivered against the SAME button node — on a
 * phone the second tap of a fast double tap is hit-tested against the DOM that
 * was on screen when the finger went down, which is the node the first tap has
 * just replaced.
 *
 *   PLAYWRIGHT_PKG=/path/to/node_modules/playwright/index.mjs node tools/test-listen-next.mjs
 */
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const { chromium } = await import(process.env.PLAYWRIGHT_PKG || 'playwright');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const pageUrl = 'file://' + path.join(root, 'assets', 'lesson', 'lesson.html');

const TAPS = 15;
const GAP = 130;            // ms between taps: 15 taps in ~2 s

const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
const page = await ctx.newPage();
const errors = [];
page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
await page.route(/r2\.dev|supabase\.co|googleapis|gstatic/, (r) => r.abort());
await page.addInitScript(() => {
  window.__msgs = [];
  window.ReactNativeWebView = { postMessage: (m) => window.__msgs.push(m) };
  window.__LISAANY_APP = { view: 'lesson', mId: 1, uId: '1.1', bId: 1, premium: true, theme: 'dark', lang: 'en' };
});
await page.goto(pageUrl);
await page.waitForFunction(() => window.LisaanyApp && LisaanyApp.opened, null, { timeout: 20000 });
await page.waitForTimeout(600);

// instrument: finish path, auto-play, audio
await page.evaluate(() => {
  window.__t = { fin: 0, said: [], steps: [] };
  const _f = finishBlock; window.finishBlock = function(){ window.__t.fin++; return _f.apply(this, arguments); };
  const _s = speak; window.speak = function(t){
    // which line is on screen right now?
    const cur = (document.querySelector('.lm-ar') || {}).textContent || '';
    window.__t.said.push({ text: String(t || ''), onScreen: cur, view: S.view });
    return _s.apply(this, arguments);
  };
});

const state = () => page.evaluate(() => ({ view: S.view, q: S.dlQPos }));
const steps = await page.evaluate(() => (S.dlQueue || []).length);
const t0 = Date.now();
let taps = 0;
for (let i = 0; i < TAPS; i++) {
  const r = await page.evaluate(() => {
    const b = [...document.querySelectorAll('.lm-ctl .lm-skip')].find((x) => /Next|Suivant|Finish|Terminer/.test(x.textContent))
           || document.querySelector('.lm-kw-actions .lm-pill:not(.ghost)');
    if (!b) return 'no-next';
    const before = S.dlQPos;
    b.click();
    // the second tap of a fast double tap, against the node the finger was on
    b.click();
    window.__t.steps.push([before, S.dlQPos, S.view]);
    return 'ok';
  });
  if (r === 'ok') taps++;
  if ((await state()).view !== 'lesson') break;
  await page.waitForTimeout(GAP);
}
const took = Date.now() - t0;
await page.waitForTimeout(1500);

const t = await page.evaluate(() => window.__t);
const after = await state();
const fails = [];

console.log(`conversation has ${steps} steps; ${taps} taps issued in ${took} ms`);
console.log('steps taken:', t.steps.map((s) => s[0] + '->' + s[1]).join(' '));
console.log('finishBlock calls:', t.fin);
console.log('speak() calls:', t.said.length);
console.log('final:', JSON.stringify(after));

// 1. one step per tap: never two (a skipped line), never none (a swallowed tap)
for (const [from, to, view] of t.steps) {
  if (view !== 'lesson') continue;
  if (to - from > 1) fails.push(`one tap moved ${to - from} lines (${from} -> ${to}) — a line was skipped`);
  if (to === from) fails.push(`a tap did nothing (stuck at line ${from}) — the tap was swallowed`);
}
// every step of the conversation must have been seen
const seen = t.steps.map((s) => s[0]);
for (let i = 0; i < steps - 1; i++) if (seen.indexOf(i) < 0) fails.push('line ' + i + ' was never shown');
// 2. the block must have finished
if (after.view === 'lesson') fails.push('the conversation never finished (still on the stage at step ' + after.q + ')');
// 3. the finish path is entered once and once only
if (t.fin !== 1) fails.push('finishBlock() ran ' + t.fin + ' times (must be exactly 1)');
// 4. no line is auto-played once it has been left behind
for (const s of t.said) {
  if (s.view !== 'lesson') fails.push('speak() fired after leaving the block (view=' + s.view + ')');
  else if (s.onScreen && s.text && s.onScreen.replace(/\s+/g, '') !== s.text.replace(/\s+/g, ''))
    fails.push('auto-play spoke a line that is not on screen: "' + s.text + '" while "' + s.onScreen + '" was showing');
}
// 5. nothing is still talking / playing after the hammering
const noise = await page.evaluate(() => {
  let a = false; try { a = !!(_curAudio && !_curAudio.paused); } catch (e) {}
  let s = false; try { s = !!(window.speechSynthesis && window.speechSynthesis.speaking); } catch (e) {}
  return { audio: a, tts: s };
});
if (noise.audio || noise.tts) fails.push('audio from the conversation is still playing on the next screen: ' + JSON.stringify(noise));
// 6. no errors
if (errors.length) fails.push('page errors: ' + errors.join(' | '));
// 7. the main thread is alive and the screen still responds
const rafAlive = await page.evaluate(() => new Promise((res) => { const k = setTimeout(() => res(false), 2000); requestAnimationFrame(() => { clearTimeout(k); res(true); }); }));
if (!rafAlive) fails.push('requestAnimationFrame stopped — the main thread is wedged');
const responds = await page.evaluate(async () => {
  const h0 = document.body.innerHTML;
  const b = [...document.querySelectorAll('button, [role="button"]')]
    .find((x) => !x.disabled && x.offsetParent && !x.closest('.qx-close, .lm-close'));
  if (!b) return 'no visible control';
  b.click();
  await new Promise((r) => setTimeout(r, 600));
  return document.body.innerHTML === h0 ? 'nothing happened' : 'ok';
});
console.log('screen still responds:', responds);
if (responds !== 'ok') fails.push('screen does not respond after the hammering: ' + responds);

await browser.close();
if (fails.length) { console.log('\nFAIL\n - ' + fails.join('\n - ')); process.exit(1); }
console.log('\nPASS');
